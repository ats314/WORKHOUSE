# HDTM SU(3) Cartan Matrix with Goldstine 16-Cycle Homology Integration

import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

# Define Goldstine-style 16-cycle adjacency matrix
A = np.array([
    [0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0],
    [0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0],
    [0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0],
    [0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0]
])

# Build Cartan matrix: C = 2I - A
I = np.identity(len(A), dtype=int)
C = 2 * I - A

def compute_net_charge(n_j, C):
    Q = (1/3) * C.dot(n_j)
    return Q, np.sum(Q)

# Define composite winding patterns
winding_patterns = {
    "Up-type quark (+2/3)":     np.array([1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1]),
    "Down-type quark (-1/3)":   np.array([0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0]),
    "Proton (uud = +1)":        np.array([1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1]) * 2 +
                                 np.array([0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0]),
    "Neutron (udd = 0)":        np.array([1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1]) +
                                 np.array([0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0]) * 2
}

# Display charge results
for label, n_j in winding_patterns.items():
    Q_vec, Q_total = compute_net_charge(n_j, C)
    print(f"\n{label}:")
    print("Winding pattern (n_j):", n_j.astype(int))
    print("Topological charge vector Q_i:", np.round(Q_vec, 3))
    print("Net charge:", round(Q_total, 3))

# Visualize the Goldstine 16-cycle topology
G = nx.from_numpy_matrix(A)
pos = nx.spring_layout(G, seed=42)
nx.draw(G, pos, with_labels=True, node_color='lightblue', edge_color='gray', node_size=700)
plt.title("Goldstine-Style 16-Cycle Graph (Genus-2 Surface)")
plt.show()

print("\nCartan matrix (C = 2I - A):")
print(C)
