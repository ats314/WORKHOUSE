# Document Inventory Summary

## Key Documents by Category

### Theoretical Foundations

- final_thesis.md (relevance score: 5)
- 06_connections_to_established_theories.txt (relevance score: 5)
- 03_double_torus_geometry.txt (relevance score: 5)

### Mathematical Formulation

- 09_appendices.txt (relevance score: 8)
- mathematical_accuracy.md (relevance score: 7)
- 04_ckm_matrix.md (relevance score: 7)

### Double Torus Geometry

- 03_double_torus_geometry.txt (relevance score: 16)
- final_thesis.md (relevance score: 13)
- extended_framework-1.pdf (relevance score: 9)

### Physical Interpretation

- 04_ckm_matrix.md (relevance score: 3)
- 05_physical_interpretation.txt (relevance score: 3)
- Unified parameter model.txt (relevance score: 2)

### Gravitational Waves

- 06_gravitational_waves.md (relevance score: 11)
- unified_gravitational_wave_framework 2.pdf (relevance score: 9)
- 06_connections_to_established_theories.txt (relevance score: 1)

### Connections To Established Theories

- 06_connections_to_established_theories.txt (relevance score: 9)
- extended_framework-1.pdf (relevance score: 8)
- MASTER TEXT.txt (relevance score: 6)

### Experimental Predictions

- 07_experimental_predictions_enhanced.txt (relevance score: 2)
- 07_experimental_predictions.txt (relevance score: 2)
- Perplexity 4.10.25 2.pdf (relevance score: 1)

### Implementation

- 07_implementation.md (relevance score: 5)

### Appendices

- Appendix A_ Modular Derivation of Spiral Parameters.md (relevance score: 3)
- 09_appendices_enhanced.txt (relevance score: 2)
- 09_appendices.txt (relevance score: 2)

## Most Comprehensive Documents

- MASTER TEXT.txt (333,949 characters)
- perplexity 4.10.25.md (117,647 characters)
- Monday.txt (44,628 characters)
- Perplexity 4.10.25 2.pdf (29,906 characters)
- Monday 2.txt (28,861 characters)
