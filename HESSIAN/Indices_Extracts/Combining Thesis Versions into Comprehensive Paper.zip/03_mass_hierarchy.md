# 3. Mass Hierarchy and Generation Structure

## Overview of Mass Hierarchy in the Standard Model

The Standard Model exhibits a puzzling mass hierarchy among fermions, spanning over twelve orders of magnitude from the sub-eV scale of neutrinos to the 173 GeV mass of the top quark. This vast hierarchy lacks explanation within the Standard Model framework, which treats particle masses as arbitrary input parameters.

The pattern of fermion masses presents one of the most striking puzzles in particle physics. The up, charm, and top quarks have masses of approximately 2.3 MeV, 1.27 GeV, and 173 GeV, respectively, while the down, strange, and bottom quarks have masses of approximately 4.8 MeV, 95 MeV, and 4.18 GeV. Each generation is roughly 10² to 10³ times heavier than the previous one, suggesting an underlying pattern rather than random values.

Similarly, the charged leptons (electron, muon, and tau) have masses of 0.511 MeV, 105.7 MeV, and 1.777 GeV, again showing a pattern of increasing mass across generations. The neutrinos are much lighter, with masses in the sub-eV range, but recent oscillation experiments confirm they also follow a hierarchical pattern.

This hierarchical structure strongly suggests an underlying mathematical framework that could explain these patterns and potentially reduce the number of free parameters in the Standard Model. The Holographic Double-Torus Model provides such a framework, deriving the mass hierarchy from geometric principles.

## Logarithmic Spiral Framework and Golden Ratio Parameterization

### Historical Development

Early explorations of particle mass patterns focused on exponential and logarithmic relationships between particle masses and generation numbers. Linear logarithmic relationships were first proposed, taking the form log₁₀(m(n)) = a·n + b, where m(n) represents the mass of a particle in generation n, and a and b are constants. While this simple relationship captured the general trend of increasing masses across generations, it failed to account for the specific mass ratios observed between particles.

The next significant development came with the recognition that a simple sinusoidal modulation of the logarithmic relationship could better account for the observed mass patterns. This led to the formulation of the quantum spiral concept, expressed mathematically as:

log₁₀(m(n)) = λ·n + ε·sin(ω·n + φ) + log₁₀(K)

This formula introduced oscillatory behavior superimposed on the exponential growth, creating a spiral pattern when visualized in polar coordinates.

### The Logarithmic Spiral in the HDTM

In the Holographic Double-Torus Model, the logarithmic spiral serves as the central mathematical framework for understanding mass patterns. In polar coordinates (r, θ), a logarithmic spiral is described by r = ae^(bθ), where a and b are constants. This spiral has the unique property that the angle between the radial line and the tangent to the spiral remains constant as the spiral expands.

When applied to particle masses, with mass corresponding to radius and generation or position corresponding to angle, this structure naturally accommodates the exponential hierarchy observed between generations. The specific form used in the HDTM is:

m_q = m_0·e^(n_q·ω_q)

where:
- m_q is the quark mass
- m_0 is the base mass (2.3 MeV for up-type, 4.8 MeV for down-type)
- n_q is the generation number (0, 1, 2)
- ω_q = 2π/φ is the angular frequency derived from the golden ratio

### Golden Ratio Parameterization

A remarkable feature of the HDTM is that the parameters of the logarithmic spiral can be derived from the golden ratio (φ = 1.618...), a fundamental mathematical constant that appears throughout nature. The angular frequency ω_q = 2π/φ determines the rate at which the spiral expands, while the base masses m_0 serve as scaling factors.

The longitudinal angles on the double-torus are related to the logarithm of the mass:

θ_q = (log(m_q/m_0)/ω_q)·(π/4)

This relationship maps the mass hierarchy directly onto the geometry of the double-torus, with heavier particles located at larger angular positions along the spiral.

The use of the golden ratio significantly reduces the number of free parameters in the model. Instead of treating each particle mass as an independent parameter, the HDTM derives them from a single fundamental constant (φ) and two base masses (one for up-type and one for down-type quarks). This represents a substantial reduction in the number of free parameters compared to the Standard Model.

## Quantum Mechanical Interpretation of Mass Hierarchy

### Particle Wavefunctions on the Double-Torus

In the quantum mechanical interpretation of the HDTM, particles are described by wavefunctions localized around specific positions on the double-torus. These wavefunctions can be approximated as Gaussian functions centered at the particle positions:

ψ_n(θ, φ, r) = A_n·exp(-(θ - θ_n)² + (φ - φ_n)² + (r - r_n)²)/(2σ_n²))

where (θ_n, φ_n, r_n) represents the position of particle n on the double-torus, and σ_n is the width of the wavefunction.

A key insight of the HDTM is that the width of these wavefunctions is inversely proportional to the square root of the particle mass:

σ_n ∝ 1/√(m_n)

where m_n is the mass of particle n. This relationship provides a quantum mechanical interpretation of the mass hierarchy: heavier particles correspond to more localized wavefunctions, while lighter particles have more spread-out wavefunctions.

### Overlap Integrals and Mixing Angles

The overlap between particle wavefunctions determines the mixing angles in the CKM and PMNS matrices. The overlap integral between particles i and j is given by:

I_ij = ∫ ψ_i*(θ, φ, r)·ψ_j(θ, φ, r) dθ dφ dr

This integral is related to the mixing angle θ_ij between particles i and j by:

sin(θ_ij) ∝ |I_ij|

The inverse relationship between wavefunction width and particle mass explains why heavier particles generally have smaller mixing angles: their wavefunctions are more localized and have less overlap with other particles.

## Potential Energy Landscape and Dynamical Systems Perspective

### Potential Energy Landscape

The double-torus features a potential energy landscape with minima corresponding to particle positions. This potential can be expressed as:

V(θ, φ, r) = V_0·∑_n exp(-(θ - θ_n)² + (φ - φ_n)² + (r - r_n)²)/(2λ_n²))

where V_0 is the overall scale of the potential, and λ_n is related to the width of the potential well for particle n.

The depths of these minima, determined by the values of V(θ_n, φ_n, r_n), are related to the binding energies of the particles. Deeper minima correspond to more tightly bound states and thus higher masses. With the golden ratio parameterization, the relative depths of the minima precisely account for the observed mass hierarchy of quarks.

### Dynamical Systems Perspective

From a dynamical systems perspective, particle masses correspond to stable fixed points of an underlying dynamical system. The stability of these fixed points is determined by the eigenvalues of the Hessian matrix of the potential:

H_ij = ∂²V/∂x_i∂x_j

where x_i represents the coordinates (θ, φ, r).

For the HDTM with the golden ratio parameterization, analysis of these eigenvalues confirms that all six quark positions correspond to stable fixed points. The magnitude of the negative eigenvalues is related to the masses of the corresponding particles, with larger negative values corresponding to heavier particles. This provides a dynamical explanation for the mass hierarchy: heavier particles correspond to more stable fixed points, where perturbations decay more rapidly.

## Extension to Neutrinos and the Geometric Seesaw Mechanism

### Neutrino Mass Hierarchy

The HDTM extends naturally to the neutrino sector, predicting a normal mass hierarchy with specific values for the three neutrino masses: 1.2 meV, 8.9 meV, and 50.4 meV. These values are consistent with current experimental constraints from neutrino oscillation experiments and cosmological observations.

The neutrino masses follow the same logarithmic spiral pattern as the quarks and charged leptons, but with a much smaller base mass. This base mass is suppressed by the geometric seesaw mechanism, which arises from the separation of left-handed and right-handed neutrinos in the extra dimensions.

### Geometric Seesaw Mechanism

In the HDTM, left-handed and right-handed fermions are located on different regions of the double-torus. For charged fermions, these regions are relatively close, leading to substantial Yukawa couplings and correspondingly large masses. For neutrinos, however, the left-handed and right-handed components are separated by a much larger distance in the extra dimensions.

This geometric separation leads to a suppression of the neutrino Yukawa couplings by a factor proportional to e^(-d/ℓ), where d is the distance between the left-handed and right-handed neutrinos in the extra dimensions, and ℓ is a characteristic length scale. This exponential suppression naturally explains why neutrino masses are so much smaller than charged lepton masses, without requiring extremely small coupling constants.

The geometric seesaw mechanism provides a natural explanation for the extreme suppression of neutrino masses relative to charged leptons, addressing one of the most puzzling aspects of the Standard Model's mass spectrum.

## Connection Between Mass Hierarchy and Generation Structure

The mass hierarchy in the HDTM is intimately connected to the generation structure of fermions. The three generations of fermions correspond to fundamental cycles of the double-torus, with specific geometric relationships that determine their mass ratios and mixing patterns.

### Generation Cycles

The four fundamental cycles of the double-torus provide a natural explanation for the existence of exactly three generations of fermions in the Standard Model, plus a potential "dark" or "sterile" sector:

1. First generation (γ₁): α₁ + β₁
2. Second generation (γ₂): α₂ + β₂
3. Third generation (γ₃): α₁ + α₂
4. Dark sector (γ₄): β₁ + β₂

Each generation cycle has specific topological properties, including zero self-intersection, which corresponds to the stability of the associated particles. The intersection numbers between different generation cycles determine the mixing patterns between generations.

### Geometric Origin of Mass Splitting

The asymmetries in the double-torus account for the differences between up-type and down-type quarks. Particles located on different constituent tori have their properties influenced by the specific geometry of their location. This provides a geometric explanation for the distinct mass patterns observed in up-type and down-type quarks, unifying them within a single geometric framework rather than treating them as separate patterns.

The specific geometry of particle locations on different constituent tori explains why up-type quarks have different masses than down-type quarks in the same generation. This mass splitting arises naturally from the geometric structure, rather than requiring separate parameters for each type of quark.

### Unification of Mass and Mixing

A key achievement of the HDTM is the unification of mass hierarchy and mixing patterns within a single geometric framework. Both phenomena emerge from the same underlying geometric structure, with masses determined by positions along the logarithmic spiral and mixing angles determined by the overlap of wavefunctions.

This unification represents a significant advance over the Standard Model, where masses and mixing angles are treated as independent parameters with no obvious relationship between them. In the HDTM, these parameters are connected through the geometry of the double-torus, reducing the number of truly independent parameters and providing a deeper understanding of the patterns observed in particle physics.
