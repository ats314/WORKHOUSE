# 3. Double Torus Geometry

## 3.1 Mathematical Structure of the Double Torus

The double torus, as a fundamental geometric object in the Holographic Double-Torus Model (HDTM), requires precise mathematical characterization. This section provides a comprehensive analysis of its geometric structure, including metric formulations, topological properties, and embedding characteristics.

### 3.1.1 Metric Formulation

The double torus Σ₂ can be equipped with various metrics, each providing different geometric realizations of the same topological structure. The most direct approach is to consider the double torus as two standard tori connected through a junction region.

For a standard torus with major radius R and minor radius r (where R > r), the metric in toroidal coordinates (θ, φ) is given by:

$$ds^2 = (R + r\cos\phi)^2 d\theta^2 + r^2 d\phi^2$$

where:
- θ is the longitudinal angle (0 to 2π), parameterizing the circle around the central axis
- φ is the poloidal angle (0 to 2π), parameterizing the circle in the cross-section

For the double torus, we need to consider two such tori with potentially different parameters (R₁, r₁) and (R₂, r₂), connected through a junction region. The metric on the double torus can be written piecewise:

$$ds^2 = \begin{cases}
(R_1 + r_1\cos\phi)^2 d\theta^2 + r_1^2 d\phi^2 & \text{on first torus} \\
(R_2 + r_2\cos\phi)^2 d\theta^2 + r_2^2 d\phi^2 & \text{on second torus} \\
g_{ij}dx^i dx^j & \text{on junction region}
\end{cases}$$

The junction region requires careful treatment to ensure a smooth transition between the two tori. One approach is to use a blending function that interpolates between the metrics of the two tori:

$$ds^2_{\text{junction}} = f(\xi)(ds^2_{\text{torus 1}}) + (1-f(\xi))(ds^2_{\text{torus 2}})$$

where f(ξ) is a smooth function that transitions from 1 to 0 as the parameter ξ varies across the junction region.

A more rigorous approach is to use the hyperbolic structure inherent to the double torus. As a genus-2 surface with Euler characteristic χ = -2, the double torus admits a unique hyperbolic metric with constant negative curvature K = -1, according to the uniformization theorem. This hyperbolic metric can be expressed in terms of local coordinates (u, v) as:

$$ds^2 = e^{2\varphi(u,v)}(du^2 + dv^2)$$

where the conformal factor φ(u,v) satisfies the Liouville equation:

$$\Delta\varphi = -e^{2\varphi}$$

This hyperbolic metric has total area 4π|χ| = 8π, as given by the Gauss-Bonnet theorem.

### 3.1.2 Fenchel-Nielsen Coordinates

The moduli space of hyperbolic structures on the double torus has dimension 6g - 6 = 6 (for g = 2). This space can be parameterized using Fenchel-Nielsen coordinates, which provide a global coordinate system for the Teichmüller space.

To construct these coordinates, we decompose the double torus into three pairs of pants (three-holed spheres) by cutting along three simple closed geodesics γ₁, γ₂, and γ₃. Each pair of pants has a hyperbolic structure determined by the lengths of its boundary geodesics. The Fenchel-Nielsen coordinates consist of:

1. The lengths l₁, l₂, l₃ of the three geodesics γ₁, γ₂, γ₃
2. The twist parameters τ₁, τ₂, τ₃ that specify how the pairs of pants are glued along these geodesics

These six parameters (l₁, l₂, l₃, τ₁, τ₂, τ₃) completely determine the hyperbolic structure on the double torus. The lengths l_i are positive real numbers, while the twist parameters τ_i are defined modulo l_i.

The Weil-Petersson symplectic form on the Teichmüller space can be expressed in terms of these coordinates as:

$$\omega_{WP} = \sum_{i=1}^3 dl_i \wedge d\tau_i$$

This symplectic structure is related to the intersection form on the homology of the double torus through the period mapping, providing a deep connection between the geometric and topological aspects of the double torus.

### 3.1.3 Conformal Structure and Complex Analysis

As a Riemann surface, the double torus possesses a complex structure that allows for the application of complex analysis. The complex structure is determined by a conformal class of metrics, where two metrics g and g' are conformally equivalent if g' = e^φg for some smooth function φ.

The moduli space of complex structures on the double torus is the quotient of the Teichmüller space by the mapping class group. This moduli space, denoted ℳ₂, has complex dimension 3 and can be described using period matrices.

For a genus-2 Riemann surface, we can choose a canonical basis {a₁, b₁, a₂, b₂} for the first homology group H₁(Σ₂, ℤ). The period matrix Ω is a 2×2 symmetric matrix with positive definite imaginary part, defined by:

$$\Omega_{ij} = \int_{b_j} \omega_i$$

where ω₁ and ω₂ form a basis for the space of holomorphic 1-forms (abelian differentials) on the Riemann surface, normalized so that:

$$\int_{a_i} \omega_j = \delta_{ij}$$

The period matrix Ω encodes the complex structure of the double torus and provides a coordinate system for the moduli space ℳ₂.

The Riemann theta function associated with the period matrix Ω is defined as:

$$\theta(z, \Omega) = \sum_{n \in \mathbb{Z}^2} e^{\pi i n^T \Omega n + 2\pi i n^T z}$$

This function plays a crucial role in the construction of meromorphic functions on the Riemann surface and in the study of its divisors.

### 3.1.4 Topological Invariants and Characteristic Classes

The double torus possesses several topological invariants that characterize its structure. We have already discussed the Euler characteristic χ = -2 and the first homology group H₁(Σ₂, ℤ) ≅ ℤ⁴. Additional topological invariants include:

1. **Betti Numbers**: b₀ = 1, b₁ = 4, b₂ = 1
2. **Poincaré Polynomial**: P(t) = 1 + 4t + t²
3. **Signature**: σ = 0 (as for any oriented surface)
4. **Fundamental Group**: π₁(Σ₂) is generated by elements a₁, b₁, a₂, b₂ with the relation [a₁, b₁][a₂, b₂] = 1, where [a, b] = aba⁻¹b⁻¹ is the commutator

The fundamental group π₁(Σ₂) is a free group of rank 4 modulo one relation, making it a one-relator group. This group has a rich structure and is related to the mapping class group of the double torus, which is the group of isotopy classes of orientation-preserving diffeomorphisms of Σ₂.

The characteristic classes of the double torus include the Stiefel-Whitney classes, Chern classes, and Pontryagin classes of its tangent bundle. For an oriented surface, the first Stiefel-Whitney class w₁ vanishes, while the second Stiefel-Whitney class w₂ is the mod 2 reduction of the Euler class e, which integrates to the Euler characteristic:

$$\int_{\Sigma_2} e = \chi(\Sigma_2) = -2$$

These topological invariants and characteristic classes provide a complete topological classification of the double torus and serve as the foundation for understanding its geometric properties.

## 3.2 Gluing Pattern and Construction

The double torus can be constructed through various gluing patterns, each providing insight into its topological and geometric structure. This section explores these construction methods, with particular emphasis on the octagon gluing pattern that reveals the fundamental group structure.

### 3.2.1 Octagon Gluing Pattern

The double torus can be constructed by identifying the edges of an octagon according to the pattern:

$$aba^{-1}b^{-1}cdc^{-1}d^{-1}$$

This means that the eight edges of the octagon are labeled a, b, a⁻¹, b⁻¹, c, d, c⁻¹, d⁻¹ in counterclockwise order, and edges with the same label (with or without the inverse) are identified with the appropriate orientation.

This gluing pattern can be visualized as follows:
1. Edges labeled a are identified, with the orientation preserved
2. Edges labeled b are identified, with the orientation preserved
3. Edges labeled c are identified, with the orientation preserved
4. Edges labeled d are identified, with the orientation preserved

The resulting surface has a single vertex (all vertices of the octagon are identified), eight edges (which become four edges after identification), and a single face (the interior of the octagon). Using the Euler characteristic formula:

$$\chi = V - E + F = 1 - 4 + 1 = -2$$

This confirms that the resulting surface is indeed a double torus.

The gluing pattern also reveals the fundamental group of the double torus:

$$\pi_1(\Sigma_2) = \langle a, b, c, d \mid [a,b][c,d] = 1 \rangle$$

where [a,b] = aba⁻¹b⁻¹ is the commutator. This presentation shows that the fundamental group is generated by four elements a, b, c, d, subject to the single relation [a,b][c,d] = 1.

### 3.2.2 Connected Sum Construction

Another way to construct the double torus is as the connected sum of two tori:

$$\Sigma_2 = T^2 \# T^2$$

This construction involves removing a small disk from each of two tori and then gluing the resulting boundaries together. Topologically, this corresponds to the operation of connected sum, which is associative and commutative for oriented surfaces.

The connected sum construction provides a natural decomposition of the double torus into two regions, each homeomorphic to a punctured torus. This decomposition is useful for understanding the homology of the double torus, as each punctured torus contributes two generators to the first homology group.

The Mayer-Vietoris sequence for the connected sum gives:

$$\ldots \to H_1(S^1) \to H_1(T^2 - D^2) \oplus H_1(T^2 - D^2) \to H_1(\Sigma_2) \to H_0(S^1) \to \ldots$$

Since H₁(S¹) ≅ ℤ and H₁(T² - D²) ≅ ℤ², this sequence yields:

$$0 \to \mathbb{Z}^2 \oplus \mathbb{Z}^2 \to H_1(\Sigma_2) \to 0$$

confirming that H₁(Σ₂) ≅ ℤ⁴.

### 3.2.3 Hyperbolic Pants Decomposition

The hyperbolic structure of the double torus allows for a decomposition into three pairs of pants (three-holed spheres). A pair of pants is a sphere with three boundary components, each a circle. Topologically, it can be obtained by removing three disjoint disks from a sphere.

The double torus can be decomposed into three pairs of pants by cutting along three simple closed curves. These curves correspond to the geodesics γ₁, γ₂, and γ₃ used in the Fenchel-Nielsen coordinates.

Each pair of pants admits a unique hyperbolic structure once the lengths of its three boundary geodesics are fixed. The hyperbolic structure on the double torus is then obtained by gluing these pairs of pants along their boundary geodesics, with the gluing determined by the twist parameters.

This pants decomposition provides a constructive approach to the hyperbolic geometry of the double torus and is fundamental to understanding its Teichmüller space.

### 3.2.4 Branched Covering Construction

The double torus can also be realized as a branched covering of the sphere. Specifically, there exists a branched covering map:

$$f: \Sigma_2 \to S^2$$

of degree 2, with 6 branch points, each with ramification index 2. This means that f is a 2-to-1 map except at 6 points on the sphere, where it is locally 1-to-1.

The Riemann-Hurwitz formula relates the Euler characteristics of the double torus and the sphere:

$$\chi(\Sigma_2) = d \cdot \chi(S^2) - \sum_{p \in B} (e_p - 1)$$

where d = 2 is the degree of the covering, B is the set of branch points, and e_p is the ramification index at point p. With χ(S²) = 2 and six branch points each with ramification index 2, we get:

$$\chi(\Sigma_2) = 2 \cdot 2 - 6 \cdot (2 - 1) = 4 - 6 = -2$$

This construction provides a connection between the double torus and algebraic curves of genus 2, which can be represented as hyperelliptic curves:

$$y^2 = P(x)$$

where P(x) is a polynomial of degree 5 or 6 with distinct roots.

## 3.3 Embedding in Higher Dimensions

The double torus can be embedded in various higher-dimensional spaces, each providing different geometric insights. This section explores these embeddings, with particular emphasis on the embedding in Anti-de Sitter space that is central to the holographic interpretation of the HDTM.

### 3.3.1 Embedding in Three-Dimensional Euclidean Space

The standard embedding of the double torus in ℝ³ can be parameterized as follows:

$$x(\theta, \phi) = \begin{cases}
(R_1 + r_1\cos\phi)\cos\theta & \text{on first torus} \\
(R_2 + r_2\cos\phi)\cos(\theta + \pi) & \text{on second torus}
\end{cases}$$

$$y(\theta, \phi) = \begin{cases}
(R_1 + r_1\cos\phi)\sin\theta & \text{on first torus} \\
(R_2 + r_2\cos\phi)\sin(\theta + \pi) & \text{on second torus}
\end{cases}$$

$$z(\theta, \phi) = \begin{cases}
r_1\sin\phi & \text{on first torus} \\
r_2\sin\phi & \text{on second torus}
\end{cases}$$

where (R₁, r₁) and (R₂, r₂) are the major and minor radii of the two tori, and the junction region requires a smooth interpolation between these parameterizations.

This embedding has the advantage of being easily visualizable, but it has limitations. In particular, it cannot realize the hyperbolic metric on the double torus, as the Nash embedding theorem requires at least a 4-dimensional ambient space to isometrically embed a hyperbolic surface.

### 3.3.2 Embedding in Four-Dimensional Euclidean Space

A more flexible embedding of the double torus is in ℝ⁴, which allows for the realization of a wider class of metrics. One such embedding uses the parameterization:

$$x_1(\theta, \phi, \psi) = (R + r\cos\phi)\cos\theta$$
$$x_2(\theta, \phi, \psi) = (R + r\cos\phi)\sin\theta$$
$$x_3(\theta, \phi, \psi) = r\sin\phi\cos\psi$$
$$x_4(\theta, \phi, \psi) = r\sin\phi\sin\psi$$

with appropriate constraints on the parameters to ensure that the resulting surface has genus 2.

This four-dimensional embedding allows for the realization of metrics with varying curvature, including regions of negative curvature that are necessary for the hyperbolic structure of the double torus.

### 3.3.3 Embedding in Anti-de Sitter Space

The embedding of the double torus in Anti-de Sitter space (AdS) is central to the holographic interpretation of the HDTM. Anti-de Sitter space is a maximally symmetric Lorentzian manifold with constant negative curvature, serving as the bulk geometry in the AdS/CFT correspondence.

The (n+1)-dimensional Anti-de Sitter space AdS_{n+1} can be embedded in ℝ^{2,n} (a flat space with two timelike dimensions and n spacelike dimensions) as the hyperboloid:

$$-X_0^2 - X_{n+1}^2 + X_1^2 + \ldots + X_n^2 = -L^2$$

where L is the AdS radius.

In the HDTM, the double torus is embedded in AdS₅ (5-dimensional Anti-de Sitter space). The embedding metric can be written as:

$$ds^2 = \frac{R^2}{z^2}(dz^2 + dx^2 + dy^2 + dw^2) + R^2(d\theta^2 + \sin^2\theta \cdot d\phi^2)$$

where:
- (z, x, y, w) are coordinates in the AdS space
- (θ, φ) are coordinates on the double torus
- R is the AdS radius

This embedding has several important properties:

1. **Conformal Boundary**: The conformal boundary of AdS₅ is 4-dimensional, corresponding to the z → 0 limit. This boundary is where the dual quantum field theory lives in the holographic interpretation.

2. **Isometry Group**: The isometry group of AdS₅ is SO(4,2), which is isomorphic to the conformal group in 4 dimensions. This correspondence is essential for the AdS/CFT duality.

3. **Geodesics**: The geodesics in AdS space have specific properties that are relevant for understanding particle trajectories in the HDTM. In particular, timelike geodesics are confined and never reach the boundary, while null geodesics can reach the boundary in finite affine parameter.

4. **Minimal Surfaces**: The area of minimal surfaces anchored to the boundary has a direct interpretation in terms of entanglement entropy in the dual field theory. This provides a geometric understanding of quantum entanglement in the HDTM.

The embedding of the double torus in AdS₅ allows for a holographic interpretation of the HDTM, where the 4-dimensional physics emerges as the boundary projection of the 5-dimensional bulk geometry. This holographic principle is a powerful framework for understanding the emergence of spacetime and the unification of quantum mechanics and gravity.

### 3.3.4 Embedding in Calabi-Yau Manifolds

In the context of string theory, the double torus can be embedded in higher-dimen
(Content truncated due to size limit. Use line ranges to read in chunks)