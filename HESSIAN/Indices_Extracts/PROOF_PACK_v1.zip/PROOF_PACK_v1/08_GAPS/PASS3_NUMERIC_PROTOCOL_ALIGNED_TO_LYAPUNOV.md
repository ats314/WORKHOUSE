# Pass 3 — Numerics protocol aligned to §7 / Appendix I (what to compute, exactly)

This protocol is the *numeric* analogue of the drift objects in the proof pack.

It specifies:
- the *state functionals* \(\widetilde z_p, \mathcal D_\Lambda, V_\Lambda\),
- the *generator estimator* (Hutchinson trace + directional derivatives),
- the *reporting* (trend + one-sided ceilings + holdout violations),
- and the *bridge quantities* that correspond to the open coercivity input.

---

## 1) Definitions (per configuration U)

Work on a periodic L^4 lattice with SU(2) link variables U(x,μ).

For each plaquette p=(x;μ,ν), compute
- plaquette holonomy P_p(U),
- plaquette defect z_p(U) := 1 - Re Tr(P_p(U))/2  (for SU(2): ReTr/2 = quaternion-a component).

Choose a smooth truncation window 0<z0<z1 and define
- \(\widetilde z_p(U)\) = z_p(U) for z≤z0,
- \(\widetilde z_p(U)\) = z0 for z≥z1,
- smooth interpolation on [z0,z1] (C^1 “smoothstep” blend).

Then define
- \(\mathcal D_\Lambda(U) := \sum_p \widetilde z_p(U)\)
- \(V_\Lambda(U) := \sum_p \widetilde z_p(U)^2\)  (this matches §7.3’s default Φ(s)=s^2 choice)
- Wilson action (for sampling or diagnostics): \(S_\Lambda(U):=\beta\sum_p z_p(U)\) (optionally replace z by \(\widetilde z\) if you want the action to respect the same truncation).

---

## 2) Generator estimator (Hutchinson + finite differences)

Let the tangent direction Xi be standard normal in the Lie algebra at each link.
For SU(2) we sample Xi as a 3-vector per link and map it via exp to an SU(2) increment.

For a small eps_fd:
- U_+ := U · exp(+eps_fd Xi)
- U_- := U · exp(-eps_fd Xi)

Compute:
- V0 = V(U), V+ = V(U+), V- = V(U-)
- S+ = S(U+), S- = S(U-)

Directional second derivative:
  lap_dir := (V+ + V- - 2 V0) / eps_fd^2
Directional derivatives:
  dS_dir := (S+ - S-) / (2 eps_fd)
  dV_dir := (V+ - V-) / (2 eps_fd)

Then:
- gip_dir := dS_dir * dV_dir  (estimates <∇S,∇V> in expectation)
- lv_dir := lap_dir - gip_dir

Average over mc directions:
- lap_hat := mean(lap_dir)
- gip_hat := mean(gip_dir)
- LV_hat  := mean(lv_dir)

Standard errors:
- LV_se := std(lv_dir)/sqrt(mc)
(similarly for lap_se, gip_se if desired)

Bridge to Appendix I:
- \(\widehat{\mathcal P_\Lambda} := 0.5\,\widehat{\langle\nabla S,\nabla V\rangle} = 0.5\,gip_hat\).

---

## 3) Fit / holdout reporting

Split your dataset into FIT and TEST.

Report:
- lambda_OLS from least-squares fit LV ≈ -lambda V + b on FIT.
- for σ ∈ {0,2,5}:
  b(σ) = max_{FIT} ( LV + lambda_OLS * V + σ * SE )
  holdout violations: count_{TEST}( LV + σ SE + lambda_OLS V - b(σ) > 0 )
  worst_diff(σ) = max_{TEST}( LV + σ SE + lambda_OLS V - b(σ) )

Optionally also report the legacy quantity:
- lambda_minb(σ): lambda chosen by minimizing b over a lambda grid under the one-sided constraint.
But keep it labeled; it is not the same object as lambda_OLS.

---

## 4) What this protocol does and does not say

It **does**:
- compute numeric proxies for LV and for the pairing term proxy \(\mathcal P_\Lambda\),
- allow apples-to-apples comparison across β, L, truncation windows, and sampling families.

It **does not**:
- establish the coercive lower bound (Assumption 7.38),
- establish typicality under the true Gibbs measure unless your sampling is an actual Gibbs sampler at the target β.

To move toward typicality numerics, you need a real sampler (e.g., heatbath/HMC/Langevin in group variables) and then measure the tail of \(\mathcal D_\Lambda\).
