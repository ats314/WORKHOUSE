# Pass 3 — Drift pipeline reconciliation (what is inconsistent, and how to make it single-source-of-truth)

This pass does **not** claim any new theorem. It does two things:

1) identifies the *specific* reason your printed “lambda” values disagree across runs, and  
2) freezes a single *canonical* numerical protocol so future runs are comparable and map to the analytic gaps (Appendix I / §7).

---

## 1) Why the same data can print wildly different “lambda”

You currently have (at least) two different fitting objectives:

### (A) Slope fit (regression-style)
Compute an “effective slope” from a regression
\[
LV \approx -\lambda\,V + b.
\]
This is what the beta-scan code does (polyfit on \(LV\) vs \(V\)): it reports a **trend** (how fast LV decreases with V).

**Property:** \(\lambda\) is essentially independent of the sigma-margin you later use for holdout checks.

### (B) One-sided bound selection (minimize b over a grid of lambdas)
Choose \(\lambda\ge 0\) and the *minimal* \(b\) such that, on the FIT set,
\[
LV_i + (\text{margin})\,SE_i \le -\lambda V_i + b \quad \forall i.
\]
Then pick the \(\lambda\) that minimizes \(b\) over a grid.

**Property (important):** increasing the margin typically pushes the “optimal” \(\lambda\) *down*, often to 0, because the objective is “smallest ceiling b” rather than “best negative slope.”

So:
- “lambda increases with beta” (regression) and
- “lambda becomes 0 at 5σ” (min-b one-sided selection)

can both be true simultaneously; they measure different things.

---

## 2) Canonical outputs to print (so runs are comparable)

For every run, print **both**:

- \(\lambda_{\mathrm{OLS}}\): least-squares slope of \(LV\) vs \(V\).
- \(b(\sigma)\): the one-sided ceiling for a **fixed** lambda:
  \[
  b(\sigma) := \max_{i\in\mathrm{FIT}}\{LV_i + \lambda_{\mathrm{OLS}}V_i + \sigma\,SE_i\}.
  \]
- Holdout violations at \(\sigma\in\{0,2,5\}\):
  \[
  \mathrm{viol}(\sigma) := \#\{i\in\mathrm{TEST}: LV_i + \sigma SE_i + \lambda_{\mathrm{OLS}}V_i - b(\sigma) > 0\}.
  \]

This pins down:
- trend (\(\lambda_{\mathrm{OLS}}\)) and
- certified ceiling at chosen margins (\(b(\sigma)\), violations).

If you still want the “min-b over λ grid” quantity, report it separately as \(\lambda_{\min b}(\sigma)\). Do not call that “the lambda” without a subscript.

---

## 3) Aligning numerics to the analytic gap (Appendix I / Assumption 7.38)

In §7 / Appendix I, the open object is
\[
\mathcal P_\Lambda(U)=\sum_p \widetilde z_p(U)\,\langle \nabla S_\Lambda(U),\nabla \widetilde z_p(U)\rangle.
\]

If you choose the Lyapunov base function
\[
V_\Lambda(U)=\sum_p \widetilde z_p(U)^2,
\]
then
\[
\langle \nabla S_\Lambda,\nabla V_\Lambda\rangle
=2\,\mathcal P_\Lambda.
\]

Your finite-difference/Hutchinson estimator naturally estimates
\[
\widehat{\langle \nabla S,\nabla V\rangle} \approx \mathbb E_\Xi[(\partial_\Xi S)(\partial_\Xi V)],
\]
so it gives a direct numerical proxy for \(\mathcal P_\Lambda\) **provided V is actually** \(\sum \widetilde z^2\).

Several of your current scripts instead use a “mean defect” proxy (Vbar/Bavg). That’s fine for diagnostics, but it is **not** the Lyapunov function used in §7. If you want numerics to speak to Assumption 7.38, measure with the aligned \(V_\Lambda\) above.

---

## 4) Artifact produced in this pass

- `pass3_drift_probe_su2.py`: a single standalone script that implements:
  - a smooth truncation \(z\mapsto \widetilde z\),
  - \(V_\Lambda=\sum \widetilde z^2\), \(\mathcal D_\Lambda=\sum \widetilde z\),
  - Hutchinson/finite-difference estimators for \(\Delta V\), \(\langle\nabla S,\nabla V\rangle\), hence \(LV\),
  - printing both \(\lambda_{\mathrm{OLS}}\) and one-sided ceilings \(b(\sigma)\) + holdout violation counts.

This does **not** prove the coercive inequality; it only standardizes what “the drift numerics” are even measuring.
