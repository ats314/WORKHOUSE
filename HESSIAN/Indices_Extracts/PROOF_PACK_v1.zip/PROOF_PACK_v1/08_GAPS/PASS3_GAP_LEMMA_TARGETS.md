# Pass 3 — Gap lemma targets (what the proof needs, stated as minimal, checkable inputs)

This file is a *target list*: each item is the sharpest lemma-shaped input that, if proved, closes a specific open dependency in the current proof DAG.

It is deliberately not “strategy” prose.

---

## G1. Coercive pairing inequality (Appendix I / Assumption 7.38)

Let \(S_\Lambda\) be the Wilson action at fixed cutoff, \(\widetilde z_p\) the smooth truncated plaquette deviation, and
\[
\mathcal D_\Lambda(U)=\sum_{p\in P(\Lambda)}\widetilde z_p(U),
\qquad
\mathcal P_\Lambda(U)=\sum_{p\in P(\Lambda)}\widetilde z_p(U)\,\langle \nabla S_\Lambda(U),\nabla \widetilde z_p(U)\rangle_{g_\Lambda}.
\]

**Target lemma (G1).** There exist constants \(c_{\mathrm{pair}}>0\) and \(C_{\mathrm{pair}}<\infty\), independent of \(\Lambda\), such that for all \(U\):
\[
\mathcal P_\Lambda(U)\ \ge\ c_{\mathrm{pair}}\,\mathcal D_\Lambda(U)\ -\ C_{\mathrm{pair}}.
\]

**Why it matters:** with \(V_\Lambda=\sum_p \widetilde z_p^2\) and \(W_\Lambda=e^{\kappa V_\Lambda}\), this is the only remaining non-controlled term in \((L_\Lambda W_\Lambda)/W_\Lambda\) after the smoothing/tubular repairs; it yields volume-uniform negative drift for suitable \(\kappa\).

---

## G2. Typicality of the “good event” K (localization penalty control)

Let \(K\subset M_\Lambda\) be the event used in the covariance decomposition / localization step (the event on which the local convexity / stiffness / kernel bounds are applied). The localization inequality introduces a penalty involving \(\mu_\Lambda(K^c)\).

**Target lemma (G2).** There exist constants \(a>0\), \(b<\infty\), independent of \(\Lambda\), such that for the chosen \(K\):
\[
\mu_\Lambda(K^c)\ \le\ b\,e^{-a\,|\Lambda|}\qquad\text{(or any bound strong enough that the resulting penalty stays volume-uniform).}
\]

**Why it matters:** this is the bridge from “conditional-on-K” clustering to unconditional clustering, without losing the exponent or uniformity.

---

## G3. One-step implication to a uniform functional inequality (if you want it explicit)

Assume:
1) a local/conditional spectral control statement on K (your current kernel-decay + stiffness package), and
2) a drift inequality for a Lyapunov function W with uniform constants (from G1).

**Target lemma (G3).** Under (1–2), the Gibbs measure \(\mu_\Lambda\) satisfies a volume-uniform Poincaré inequality (or LSI/SPI as appropriate):
\[
\mathrm{Var}_{\mu_\Lambda}(f)\ \le\ \frac{1}{\rho}\int \|\nabla f\|^2\,d\mu_\Lambda,
\quad \rho>0\text{ independent of }\Lambda.
\]

(If your manuscript already includes this theorem as an internal result, G3 is just the *explicit packaging target* to make the dependency atomic.)
