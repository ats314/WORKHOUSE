# NOTATION_AND_CONSTANTS.md

This file collects **notation**, **standing constants**, and the **exact points where each constant enters quantitative bounds**.  
The guiding separation is:

- **Uniform-in-volume** constants: may depend on the *local* geometry (dimension, group, representation), but **must not grow with** \(|\Lambda|\).
- **Cutoff/coupling dependence**: constants may depend on the lattice spacing \(a\) through \(\beta=\beta(a)\) (or through a chosen scaling trajectory), and that dependence is tracked explicitly.

Unless stated otherwise we work in **dimension \(d=4\)** on a finite periodic hypercubic lattice \(\Lambda\subset\mathbb Z^4\) (a 4‑torus), with the Euclidean time direction being the 0‑th coordinate.

---

## A. Lattice and combinatorics

### A.1 Cell sets and cardinalities
- \(\Lambda\): finite periodic region (4‑torus).
- \(V(\Lambda)\): vertices (sites).
- \(E(\Lambda)\): **oriented links** \(b=(x,\mu)\) from \(x\) to \(x+\hat e_\mu\) (orientation convention fixed once).
- \(P(\Lambda)\): **oriented plaquettes** \(p=(x;\mu,\nu)\) (\(\mu<\nu\)), with standard boundary orientation.
- \(|V|:=|V(\Lambda)|\), \(|E|:=|E(\Lambda)|\), \(|P|:=|P(\Lambda)|\).

On a periodic hypercubic lattice in dimension \(d\),
\[
|E| = d\,|V|,
\qquad
|P| = \binom{d}{2}\,|V|.
\]
Hence
\[
\frac{|E|}{|P|}=\frac{d}{\binom{d}{2}}=\frac{2}{d-1},
\qquad
\text{so in }d=4:\ \frac{|E|}{|P|}=\frac{2}{3}.
\]
We often use the uniform comparison
\[
|E|\le C_{E/P}\,|P|,
\qquad C_{E/P}:=\frac{2}{d-1}\ \ (=\tfrac23\text{ in }d=4).
\]

### A.2 Plaquette perimeter and bounded overlap
- \(m_\partial\): plaquette perimeter, always
\[
m_\partial:=|\partial p|=4.
\]

- \(\nu\): bounded overlap constant (“plaquette incidence per link”): each oriented link \(\ell\in E(\Lambda)\) appears in the boundary word of at most \(\nu\) oriented plaquettes.
For the \(d\)-dimensional hypercubic lattice,
\[
\nu \le 2(d-1),
\qquad\text{so in }d=4:\ \nu\le 6.
\]
(Used critically in §5.4 (Hessian stability) and §7.2 (uniform derivative bookkeeping).)

### A.3 Link adjacency distance
- Link adjacency \(b\sim b'\): \(b\sim b'\) iff there exists a plaquette whose boundary contains **both** links (possibly as inverses).
- \(\mathrm{dist}_E(b,b')\): graph distance on \(E(\Lambda)\) induced by \(\sim\).
- For link sets \(A,B\subseteq E(\Lambda)\),
\[
\mathrm{dist}_E(A,B):=\min\{\mathrm{dist}_E(b,b'):\ b\in A,\ b'\in B\}.
\]
This is the distance used for finite‑range bounds on \(d_1^\*d_1\) and the Combes–Thomas inverse decay (Part 9).

---

## B. Gauge group, representation, and geometric radii

### B.1 Group and Lie algebra
- \(G\): compact Lie group.
- \(\mathfrak g\): Lie algebra.
- \(g_G\): fixed bi‑invariant Riemannian metric on \(G\) (from an \(\mathrm{Ad}\)-invariant inner product \(\langle\cdot,\cdot\rangle_{\mathfrak g}\)).
- \(d_G\): Riemannian distance on \((G,g_G)\).
- \(\exp:\mathfrak g\to G\): Lie/group exponential.
- \(\log\): local inverse of \(\exp\) on a ball about \(\mathbf 1\).
- \(\iota_G:=\mathrm{inj}_G(\mathbf 1)\): injectivity radius at the identity.

### B.2 Representation and its constants
- \(\rho:G\to U(n)\): fixed faithful unitary representation.
- \(n\): representation dimension (also the matrix size in the trace).
- \(\lambda_\rho>0\): the representation constant appearing in the quadratic expansion of the trace defect:
  \[
  \widetilde z(\exp Y)=\frac{1}{2n\lambda_\rho}|Y|_{\mathfrak g}^2+O(|Y|^3)
  \quad (Y\to 0),
  \]
  equivalently
  \[
  \nabla_G^2\widetilde z(\mathbf 1)[A,B]=\frac{1}{n\lambda_\rho}\langle A,B\rangle_{\mathfrak g}.
  \]
  (Introduced in §5.1–§5.2, used throughout Parts 5–7, and in the Maxwell coefficient \(\alpha\) below.)

### B.3 Small-field radii (from §5.1 / §5.3)
We keep three radii from the local Lie‑theoretic expansions:
- \(r_\star>0\): domain radius where \(\log\) is smooth.
- \(r_0>0\): radius for uniform BCH estimates.
- \(r_{\mathrm{Tr}}>0\): radius for the trace‑potential cubic remainder control.

Define the canonical **small-field radius**
\[
r_{\mathrm{sf}}:=\min\Big\{\frac{r_\star}{4},\ \frac{r_0}{4},\ \frac{r_{\mathrm{Tr}}}{4}\Big\}.
\]
A working small-field parameter is always chosen as
\[
0<r\le r_{\mathrm{sf}}.
\]

---

## C. Configuration manifold, cochains, and operators

### C.1 Configuration manifold
- \(M_\Lambda:=G^{E(\Lambda)}\): configuration manifold.
- \(g_\Lambda\): product metric (bi-invariant in each factor).
- \(U^{(0)}\): vacuum configuration \(U^{(0)}_b=\mathbf 1\) for all links \(b\).

### C.2 Cochains and differentials
Identify right‑trivialized tangent vectors with \(\mathfrak g\)-valued 1‑cochains:
\[
T_U M_\Lambda \simeq \mathcal C^1(\Lambda;\mathfrak g)=\mathfrak g^{E(\Lambda)}.
\]
Similarly \(\mathcal C^0(\Lambda;\mathfrak g)=\mathfrak g^{V(\Lambda)}\) and \(\mathcal C^2(\Lambda;\mathfrak g)=\mathfrak g^{P(\Lambda)}\).

- \(d_0:\mathcal C^0\to\mathcal C^1\): discrete gradient (gauge differential).
- \(d_1:\mathcal C^1\to\mathcal C^2\): discrete curl (plaquette differential).
- \(d_0^\*,d_1^\*\): \(\ell^2\) adjoints with respect to the product inner products.

Key identities:
\[
d_1d_0=0,\qquad d_0^\*d_1^\*=0.
\]

### C.3 Horizontal sector at vacuum
- Gauge directions: \(\mathrm{im}(d_0)\subset \mathcal C^1\).
- Vacuum horizontals:
\[
H^{(0)}:=H_{U^{(0)}}=\ker(d_0^\*)\subset \mathcal C^1.
\]
The orthogonal splitting
\[
\mathcal C^1 = \mathrm{im}(d_0)\ \oplus\ H^{(0)}
\]
is preserved by \(d_1^\*d_1\) and by \(M=m^2I+\alpha d_1^\*d_1\) (Lemma 6.14).

### C.4 Discrete Maxwell operator
- Maxwell/Hodge operator on 1‑cochains:
\[
d_1^\*d_1:\mathcal C^1\to\mathcal C^1,
\qquad d_1^\*d_1\succeq 0.
\]
It is **finite range** with respect to \(\mathrm{dist}_E\): \((d_1^\*d_1)_{bb'}=0\) unless \(\mathrm{dist}_E(b,b')\le 1\).

---

## D. Wilson action, Gibbs measure, generator, and curvature

### D.1 Wilson plaquette potential and action
- Trace defect (proxy and action density):
\[
\widetilde z(g):=1-\frac1n\Re\mathrm{Tr}(\rho(g))\in[0,2].
\]
- Wilson plaquette potential:
\[
\Phi_\beta(g):=\beta\,\widetilde z(g).
\]
- Plaquette holonomy: \(U_p(U)=\prod_{b\in\partial p} U_b^{\pm 1}\).
- Wilson action:
\[
S_W(U)=\sum_{p\in P(\Lambda)}\Phi_\beta(U_p(U)).
\]

### D.2 Gibbs measure and reversible generator
- Gibbs measure:
\[
d\mu_{\Lambda,\beta}(U)=Z_{\Lambda,\beta}^{-1}\,e^{-S_W(U)}\,d\mathrm{vol}_{g_\Lambda}(U).
\]
- Reversible diffusion generator:
\[
L_\Lambda f:=\Delta_\Lambda f-\langle\nabla S_W,\nabla f\rangle_{g_\Lambda}.
\]
- Carré du champ:
\[
\Gamma_\Lambda(f,g):=\langle\nabla f,\nabla g\rangle_{g_\Lambda},
\qquad \Gamma_\Lambda(f):=\Gamma_\Lambda(f,f).
\]
- Dirichlet form:
\[
\mathcal E_\Lambda(f):=\int_{M_\Lambda}\Gamma_\Lambda(f)\,d\mu_{\Lambda,\beta}.
\]

### D.3 Bakry–Émery curvature matrix and Haar/Ricci mass
- Bakry–Émery curvature matrix:
\[
\mathrm{Ric}_{\mu_{\Lambda,\beta}}(U)
:=\mathrm{Ric}_{g_\Lambda}(U)+\nabla^2 S_W(U).
\]
- \(c_H\ge 0\): uniform Haar/Ricci lower bound for the product metric:
\[
\mathrm{Ric}_{g_\Lambda}(U)\succeq c_H\,I
\quad\text{for all }U,\text{ uniformly in }\Lambda.
\]
For semisimple \(G\), \(c_H>0\); for groups with abelian factors, \(c_H\) may be \(0\).

This constant is the “scalar mass” term in the matrix hinge (§5.4) and ultimately determines \(m^2=c_H/2\) in the massive Maxwell operator.

---

## E. Small-field region and Hessian stability constants (Part 5)

### E.1 Canonical linkwise small-field region
For \(0<r\le r_{\mathrm{sf}}\):
\[
K_\Lambda(r):=\{U\in M_\Lambda:\ d_G(U_b,\mathbf 1)<r\ \forall b\in E(\Lambda)\}
=\prod_{b\in E(\Lambda)}B_r^G(\mathbf 1).
\]

### E.2 Third derivative constant for one plaquette
Define the single-plaquette smooth function \(F:G^4\to\mathbb R\) by
\[
F(g_1,g_2,g_3,g_4)
:=\Re\mathrm{Tr}\!\big(\mathbf 1-g_1g_2g_3^{-1}g_4^{-1}\big).
\]
For \(r_\star\) as above, define
\[
M_3(r_\star):=
\sup_{(g_1,\dots,g_4)\in(\overline{B_{r_\star}^G(\mathbf 1)})^4}
\big\|D^3F(g_1,\dots,g_4)\big\|_{\mathrm{op}}<\infty.
\]
This constant feeds the Lipschitz control of the single‑plaquette Hessian and hence the global Hessian stability (Lemma 5.19).

### E.3 Wilson Hessian remainder on \(K_\Lambda(r)\)
The perturbation size is
\[
R_W(r)
:=\Big(\frac{\beta}{n}\Big)\,(2\nu\,M_3(r_\star))\,r.
\]
The key operator inequality on \(K_\Lambda(r)\) is
\[
\nabla^2 S_W(U)\ \succeq\ \nabla^2 S_W(U^{(0)})\ -\ R_W(r)\,I.
\]

### E.4 Vacuum Hessian coefficient (Maxwell identity)
At the vacuum,
\[
\nabla^2 S_W(U^{(0)})=\frac{\beta}{n\lambda_\rho}\,d_1^\*d_1.
\]
This identifies the structured PSD part of the curvature hinge.

### E.5 Hinge smallness condition
A typical clean choice of \(r\) is any value such that
\[
R_W(r)\le \frac{c_H}{2},
\]
so that on \(K_\Lambda(r)\),
\[
\mathrm{Ric}_{\mu_{\Lambda,\beta}}(U)\ \succeq\ \frac{c_H}{2}\,I\ +\ \frac{\beta}{n\lambda_\rho}\,d_1^\*d_1.
\]

---

## F. Massive Maxwell operator and its parameters (Part 6)

### F.1 Parameters
Define
\[
m^2:=\frac{c_H}{2},
\qquad
\alpha:=\frac{\beta}{n\lambda_\rho}.
\]
These are the “mass” and “Maxwell stiffness” parameters.

### F.2 Operator on 1‑cochains
\[
M:=m^2 I+\alpha\,d_1^\*d_1
\quad\text{on }\mathcal C^1(\Lambda;\mathfrak g).
\]
On the vacuum horizontal space \(H^{(0)}=\ker(d_0^\*)\) we use the restriction
\[
M_H:=M\big|_{H^{(0)}}.
\]
When \(m^2>0\), \(M\succ0\) and \(M_H\succ0\), and
\[
\|M^{-1}\|,\ \|M_H^{-1}\| \le \frac{1}{m^2}.
\]

### F.3 Kernel notation
For oriented links \(b,b'\in E(\Lambda)\),
\[
(M_H^{-1}\eta)_b=\sum_{b'\in E(\Lambda)} (M_H^{-1})_{b,b'}\,\eta_{b'},
\qquad (M_H^{-1})_{b,b'}\in\mathrm{End}(\mathfrak g),
\]
and
\[
\|(M_H^{-1})_{b,b'}\|_{\mathrm{op}}
:=\sup_{|v|_{\mathfrak g}=1}|(M_H^{-1})_{b,b'}v|_{\mathfrak g}.
\]

---

## G. Combes–Thomas constants for inverse decay (Part 9)

In the abstract lemma (Part 9.1), for a self-adjoint finite-range operator \(A\) on \(\ell^2(V;\mathsf H_0)\):

- \(a_0>0\): positivity gap \(A\succeq a_0 I\).
- \(R\in\mathbb N\): interaction range (with respect to the chosen graph distance).
- \(B\): off-diagonal row-sum constant
  \[
  B:=\sup_{x\in V}\sum_{y\neq x}\|A_{xy}\|_{\mathrm{op}}.
  \]
- \(\eta\): Combes–Thomas decay rate
  \[
  \eta:=\frac{1}{R}\log\!\Bigl(1+\frac{a_0}{2B}\Bigr).
  \]

Applied to the massive Maxwell operator on the link graph:

- \(V=E(\Lambda)\), distance \(\mathrm{dist}=\mathrm{dist}_E\).
- \(A=M_H\) (or \(M\), depending on the analysis block; physically relevant is \(M_H\)).
- Positivity: \(a_0=m^2\).
- Range: \(R=1\) for \(\alpha d_1^\*d_1\) in \(\mathrm{dist}_E\) (the \(m^2I\) term is diagonal).
- Row-sum: \(B\) is bounded by a dimension-only constant times \(\alpha\) (because \(d_1^\*d_1\) has bounded-degree couplings).

The abstract bound yields
\[
\|(M_H^{-1})_{b,b'}\|_{\mathrm{op}}
\le \frac{2}{m^2}\,e^{-\eta\,\mathrm{dist}_E(b,b')},
\qquad
\eta=\log\!\Bigl(1+\frac{m^2}{2B}\Bigr)
\ \ \text{(since }R=1\text{)}.
\]

---

## H. Lyapunov/drift constants (Part 7)

### H.1 Proxy and aggregates
- Proxy on \(G\): \(\widetilde z(g)=1-\frac1n\Re\mathrm{Tr}(\rho(g))\).
- Plaquette lift: \(\widetilde z_p(U):=\widetilde z(U_p(U))\).
- “Badness total”:
\[
\mathcal D_\Lambda(U):=\sum_{p\in P(\Lambda)}\widetilde z_p(U).
\]
- Lyapunov functional:
\[
V_\Lambda(U):=\sum_{p}\widetilde z_p(U)^2,
\qquad
W_\Lambda(U):=\exp(\kappa V_\Lambda(U)).
\]

### H.2 Global \(C^2\) proxy constants on \(G\)
- \(C^{(1)}_{\widetilde z}:=\sup_{g\in G}|\nabla_G\widetilde z(g)|\).
- \(C^{(2)}_{\widetilde z}:=\sup_{g\in G}\|\nabla_G^2\widetilde z(g)\|_{\mathrm{op}}\).
- \(C_\Delta:=\sup_{g\in G}|\Delta_G\widetilde z(g)|\) (finite by compactness).
- \(C_\nabla:=\sup_{g\neq \mathbf 1}\frac{|\nabla_G\widetilde z(g)|^2}{\widetilde z(g)}<\infty\),
  so that \(|\nabla_G\widetilde z|^2\le C_\nabla\,\widetilde z\) globally.

These constants depend only on \((G,g_G)\) and \(\rho\), not on \(\Lambda\).

### H.3 Volume-uniform drift bookkeeping constants (for \(\Phi(s)=s^2\))
From §7.2, one can take
\[
A_1=8C_\Delta,\qquad A_2=8C_\nabla,\qquad A_3=64\,\nu\,C_\nabla,
\]
and define
\[
C_V:=A_1+A_2,\qquad C_\Gamma:=A_3.
\]
They enter the drift upper bound
\[
\frac{L_\Lambda W_\Lambda}{W_\Lambda}
\le (\kappa C_V+\kappa^2 C_\Gamma)\,\mathcal D_\Lambda
-2\kappa\sum_{p}\widetilde z_p\langle\nabla S_\Lambda,\nabla \widetilde z_p\rangle.
\]

### H.4 Pairing coercivity constants (open input)
Assumption (to be proved for the chosen action family \(\{S_\Lambda\}\)):
\[
\sum_{p}\widetilde z_p\,\langle\nabla S_\Lambda,\nabla \widetilde z_p\rangle
\ge c_{\mathrm{pair}}\,\mathcal D_\Lambda - C_{\mathrm{pair}},
\]
with \(c_{\mathrm{pair}}>0\), \(C_{\mathrm{pair}}\ge 0\) **uniform in \(\Lambda\)**.

### H.5 Foster–Lyapunov constants
A drift inequality is written as
\[
L_\Lambda W_\Lambda \le -\lambda W_\Lambda + b\,\mathbf 1_{K_\Lambda}.
\]
The local-to-global Poincaré patching theorem yields the global Poincaré constant
\[
C_P=\frac{1+b\,\kappa_K}{\lambda},
\]
where \(\kappa_K\) is a local Poincaré constant on the core set \(K_\Lambda\).

---

## I. Localization constants (Part 8)

### I.1 Averaged badness functional and good set
Given a conjugation-invariant \(\vartheta\in C^1(G)\) with \(\|\nabla_G\vartheta\|_\infty<\infty\), define
\[
\mathcal B_\Lambda(U):=\frac{1}{|P(\Lambda)|}\sum_{p\in P(\Lambda)}\vartheta(U_p(U)),
\qquad
K_\Lambda(\varepsilon):=\{\mathcal B_\Lambda\le \varepsilon\}.
\]

### I.2 Lipschitz constant scaling
There exists \(L_0<\infty\) (uniform in \(\Lambda\)) such that
\[
\sup_U |\nabla \mathcal B_\Lambda(U)| \le \frac{L_0}{\sqrt{|P(\Lambda)|}},
\qquad
L_0:=\sqrt{C_{E/P}}\,\nu\,\|\nabla_G\vartheta\|_\infty.
\]
This is the geometric input for Gaussian concentration once a volume-uniform LSI (or equivalent) is available.

### I.3 Localization error coefficient
The covariance decomposition across \(K\) yields a raw bound
\[
|\mathrm{Cov}_{\mu_\Lambda}(F,G)|
\le |\mathrm{Cov}_{\mu_{\Lambda,K}}(F,G)| + 8\|F\|_\infty\|G\|_\infty\,\mu_\Lambda(K^c).
\]
Thus the “typicality target” is a bound on \(\mu_\Lambda(K_\Lambda(\varepsilon)^c)\) strong enough not to spoil distance decay.

---

## J. Clustering and OS mass-gap conversion constants (Parts 10–12)

### J.1 Euclidean clustering exponent
- \(\eta(a)\): exponential decay rate **in lattice time steps** obtained at fixed lattice spacing \(a\):
\[
|\mathrm{Cov}_\mu(F,\tau_n G)| \le C(F,G)\,e^{-\eta(a)\,n}.
\]
In the chain, \(\eta(a)\) comes from inserting the kernel decay of \(M_H^{-1}\) (Part 9) into the Helffer–Sjöstrand bound (Part 6) and then running localization (Part 8).

### J.2 OS Hamiltonian gap at fixed cutoff
OS reconstruction yields a Hamiltonian \(H\ge 0\) with transfer matrix \(T=e^{-aH}\).  
Time-direction Euclidean decay with exponent \(\eta(a)\) implies the Hamiltonian gap bound
\[
\mathrm{gap}(H)\ \ge\ \frac{\eta(a)}{a}.
\]
(§11.3.)

### J.3 Continuum scaling trajectory condition
Along a scaling trajectory \(a_n\downarrow 0\), the “physical mass” condition is
\[
\eta(a_n)\ \ge\ m_0\,a_n
\]
for some \(m_0>0\). This is the exact interface assumption used in the continuum passage (Part 12).

---

## K. Quick index: where the big constants enter

- \(\nu\): bounded overlap / plaquettes per link — used in
  - Hessian stability remainder \(R_W(r)\) (Part 5.4),
  - drift bookkeeping \(A_3=64\nu C_\nabla\) (Part 7.2),
  - Lipschitz constant of \(\mathcal B_\Lambda\) (Part 8.2).

- \(c_H\): uniform Ricci lower bound — used in
  - matrix hinge mass term (Part 5.4),
  - defines \(m^2=c_H/2\) in \(M\) (Part 6.5),
  - determines inverse prefactor \(2/m^2\) and decay exponent via Combes–Thomas (Part 9).

- \(M_3(r_\star)\): single-plaquette third-derivative bound — used in
  - \(R_W(r)=(\beta/n)(2\nu M_3(r_\star))r\) (Part 5.4),
  - smallness condition \(R_W(r)\le c_H/2\) (Part 5.4 / Part 6).

- \(\lambda_\rho\): representation constant — used in
  - vacuum Hessian \(\nabla^2 S_W(U^{(0)})=(\beta/(n\lambda_\rho))d_1^\*d_1\) (Part 5.2),
  - Maxwell stiffness \(\alpha=\beta/(n\lambda_\rho)\) (Part 6.5),
  - gradient-domination limit value \(2/(n\lambda_\rho)\) (Part 7.2).

- \(\eta(a)\): clustering exponent in lattice steps — used in
  - OS mass gap \(m(a)\ge \eta(a)/a\) (Part 11.3),
  - continuum condition \(\eta(a_n)\ge m_0a_n\) (Part 12.3).

---

**Maintenance note.** Any time a new constant appears in the manuscript, add it here with:
1) a precise definition, 2) its dependency set \((G,\rho,d,\beta,a,\dots)\), and 3) the exact inequality (lemma/proposition) where it is used.
