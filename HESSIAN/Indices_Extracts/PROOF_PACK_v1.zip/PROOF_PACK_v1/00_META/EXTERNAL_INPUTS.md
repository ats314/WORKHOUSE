# EXTERNAL_INPUTS.md

This note collects every result that the unified draft **uses but does not (currently) reprove in full**, together with:

- the **exact form** in which it is invoked,
- the **hypotheses** we require,
- where it is used in the manuscript, and
- whether it is **core** (hard dependency) or **optional** (only needed along a chosen route).

It is intentionally referee-facing: the point is not to be encyclopedic, but to make it easy to audit what is assumed.

---

## 0. Conventions

- “Finite volume” means a periodic hypercubic torus lattice \(\Lambda\) in \(d=4\); configuration space \(M_\Lambda = G^{E(\Lambda)}\) is compact.
- “Infinite volume at fixed cutoff” means \(\Lambda\uparrow\mathbb Z^4\) with **fixed** lattice spacing \(a>0\).
- “OS” = Osterwalder–Schrader (reflection positivity + reconstruction).
- “SPI” = super-Poincaré inequality; “LSI” = log-Sobolev inequality.

**Status labels.**
- **[CORE]** = required to state and prove the fixed-cutoff OS gap result (Part 11).
- **[OPTIONAL]** = only needed if we take the route that uses it.
- **[CONDITIONAL]** = continuum-level assumptions (Part 12); the draft explicitly flags these as open architecture inputs.

---

## 1. [CORE] OS reconstruction theorem (transfer matrix / Hamiltonian)

### EI-OS-REC (external theorem)

**Where used.**
- Stated as external in §4.4 and used in §11.3 to convert Euclidean time decay into an OS Hamiltonian spectral gap.

**Input data (hypotheses).**
Let \(\mu\) be a probability measure on a Euclidean configuration space \(\Omega\) (finite or infinite volume) and fix a time direction (0th coordinate). Assume:

1. **Time translation invariance (H1):** \(\mu\circ\tau_n^{-1}=\mu\) for all integer time shifts \(n\ge0\).
2. **Reflection invariance (H2):** \(\mu\circ\Theta^{-1}=\mu\) for the time reflection \(\Theta\) about a reflection plane.
3. **Reflection positivity (H3):** for the induced antilinear involution \((\theta F)(U):=\overline{F(\Theta U)}\) and the positive-time algebra \(\mathcal A_+\),
   \[
   \mu\big((\theta F)\,F\big)\ \ge\ 0\qquad\forall\,F\in\mathcal A_+.
   \]
4. (Routine regularity) \(\mathcal A_+\) is an algebra of bounded cylinder functions dense enough to generate the OS Hilbert space.

**Conclusion (what we use).**
There exist:
- an OS Hilbert space \(\mathcal H_{\mathrm{OS}}\) obtained by completing \(\mathcal A_+\) under the positive semidefinite sesquilinear form
  \(\langle F,G\rangle_{\mathrm{OS}} := \mu((\theta F)G)\),
- a cyclic vector \(\Omega=[1]\),
- a positive contraction \(T\) implementing one time-step,
  \[
  T[F] := [\tau_1 F],\qquad 0\le T\le I,
  \]
- a self-adjoint Hamiltonian \(H\ge 0\) with \(T=e^{-aH}\),

and, crucially, the **transfer-matrix identity** for all \(F,G\in\mathcal A_+\) and all \(n\ge 0\):
\[
\langle [F],\,T^n[G]\rangle_{\mathrm{OS}}
=
\mu\big((\theta F)\,(\tau_n G)\big).
\]
This identity is the only part of reconstruction actually used in §11.3; once it is granted, the spectral-measure argument proving \(\mathrm{gap}(H)\ge \eta(a)/a\) is internal.

**Standard references.**
Osterwalder–Schrader (original axioms and reconstruction); lattice/transfer-matrix formulations appear in many texts (e.g. Glimm–Jaffe; Fröhlich; Seiler). The draft will cite a small number of primary sources in the main bibliography.

---

## 2. [CORE] Reflection positivity for Wilson lattice gauge theory

### EI-RP-WILSON (external if not reproved)

**Where used.**
- Needed to justify hypothesis (H3) for the lattice Euclidean Gibbs measures in Part 4, hence to invoke EI-OS-REC in Part 11.

**Status in the unified draft.**
- The draft **intends to present a proof in §4.2** using the Osterwalder–Seiler “square root / SOS factorization” mechanism on a reflection plane.
- If a referee prefers not to re-check that proof, EI-RP-WILSON is the standard standalone theorem in the literature.

**Informal statement (what we need).**
For compact \(G\), Wilson action \(S_W\) built from plaquette holonomies, and Gibbs measure
\[
d\mu_{\Lambda,\beta}(U)\ \propto\ e^{-S_W(U)}\,d\mathrm{Haar}(U),
\]
the measure is reflection positive with respect to a time reflection \(\Theta\) (plane between time slices) and the corresponding \(\mathcal A_+\).

**Key structural mechanism.**
Osterwalder–Seiler factorization: the Boltzmann weight can be written as a product of terms each of which factors into a positive-time and reflected negative-time part, yielding positivity by Cauchy–Schwarz.

**References.**
Osterwalder–Seiler and subsequent expositions in lattice gauge theory texts.

---

## 3. [CORE, as needed] Existence of infinite-volume Gibbs measures at fixed cutoff

### EI-DLR-EXIST (external theorem / compactness-DLR package)

**Where used.**
- In Part 11 (especially §11.1) to pass \(\Lambda\uparrow\mathbb Z^4\) at fixed \(a\), obtain infinite-volume limit points, and argue permanence of OS properties and clustering bounds.

**Why this is “as needed.”**
At fixed lattice spacing and compact spin space, finite-volume Gibbs measures are probability measures on compact spaces, so subsequential limits exist by tightness/compactness. The *DLR identification* and translation invariance of limit points can be treated as standard.

**Hypotheses (our setting satisfies them).**
- Single-site (here: single-link) state space \(G\) is compact.
- Interaction is finite range and uniformly bounded below (Wilson plaquette action is bounded and local).
- Boundary conditions are taken in a standard way (periodic tori, or fixed boundary on boxes); the existence theorem is robust to these choices.

**Conclusion (what we use).**
- There exist subsequential infinite-volume Gibbs measures \(\mu\) on \(\Omega=G^{E(\mathbb Z^4)}\) which satisfy the DLR equations for the Wilson specification.
- Any such \(\mu\) is invariant under the symmetries preserved by the finite-volume measures (time translations, reflections) provided the limiting procedure is symmetry-respecting.
- Uniform-in-volume covariance decay bounds pass to limits for cylinder observables by dominated convergence / standard compactness arguments.

**References.**
DLR theory for finite-range interactions on compact single-site spaces (Georgii’s Gibbs measures text is a standard reference); for lattice gauge models, see standard lattice constructive QFT references.

---

## 4. [OPTIONAL / FLAGGED] SPI → LSI conversion (only if the localization/typicality route uses it)

### EI-SPI-LSI (optional external theorem)

**Where used (only on the LSI-concentration route).**
- In Part 8.3 to convert a global super-Poincaré inequality (SPI) produced by drift machinery into a global LSI, which then gives Gaussian concentration for the averaged badness \(\mathcal B_\Lambda\).

**Status in the unified draft.**
- The outline explicitly flags SPI→LSI as a potential missing conversion step; if the manuscript chooses a route that uses it, it must either:
  - supply a complete proof under verifiable hypotheses, or
  - cite a theorem with a profile that matches exactly what is proved in Part 7.
- If instead we redesign localization using capacity/drift methods requiring only a global Poincaré inequality, EI-SPI-LSI can be removed from the dependency list.

**Representative statement (schematic).**
If \(\mu\) satisfies an SPI
\[
\mathrm{Var}_\mu(f)\ \le\ s\,\mathcal E(f)+\beta(s)\,\|f\|_{L^1(\mu)}^2
\quad\text{for all }s>0,
\]
with a profile \(\beta(s)\) of sufficiently “fast growth” as \(s\downarrow 0\) (typically \(\log\beta(s)\lesssim 1/s\)), then \(\mu\) satisfies an LSI with a constant depending on the SPI profile and the Poincaré constant.

**References.**
Work of Wang and others on SPI/LSI equivalences and related functional-inequality conversion theorems (precise theorem and hypotheses to be finalized once the Part 8.3 route is fixed).

---

## 5. [CONDITIONAL] Continuum-level architecture inputs (Part 12)

These are not “theorems we forgot to prove”; they are the explicitly isolated continuum-level assumptions/inputs in the outline.

### EI-RG-RP (reflection positivity permanence under the continuum limiting architecture)

**Where used.**
- §12.1–§12.4, to ensure the OS structure persists along a scaling trajectory \(a_n\downarrow 0\).

**What is assumed.**
A reflection-equivariant coarse-graining / projective limit (or RG) framework in which:
- reflection positivity and time translations are preserved,
- cylinder observables embed consistently along scales.

This is recorded as part of the conditions (C1)–(C3) in the main theorem statement.

### EI-HAM-COMP (continuum Hamiltonian comparison)

**Where used.**
- §12.2–§12.4: compare the OS Hamiltonian obtained from the continuum Euclidean theory with the target continuum YM Hamiltonian.

**What is assumed.**
A functional-analytic comparison principle (e.g. via quadratic forms) that transports a spectral gap lower bound through the comparison map.

### EI-PHYS-SCALE (uniform physical lower bound along the scaling trajectory)

**Where used.**
- §12.3: to upgrade a fixed-cutoff gap \(\eta(a)/a\) into a strictly positive continuum mass gap, we need a uniform lower bound in physical units along \(a\downarrow 0\), i.e.
\[
\eta(a_n)\ \ge\ m_0\,a_n
\quad\text{along }a_n\downarrow 0.
\]
This is the explicit “physical scaling” input in the conditional continuum theorem.

---

## 6. “External vs internal” sanity check

To prevent the “everything is external” failure mode, here is what the unified draft **does** prove internally (in its current plan):

- Discrete cochain calculus, Hodge decompositions on the lattice, bounded-overlap constants (Part 3).
- Vacuum Hessian identity and matrix hinge on the small-field region (Part 5).
- Bochner/Γ₂ with drift, Witten Laplacian structure, matrix HS covariance identity (Part 6).
- Combes–Thomas finite-range inverse decay lemma and its application to the massive Maxwell operator (Part 9).
- Localization algebra (law of total covariance) and Lipschitz scaling of \(\mathcal B_\Lambda\) (Part 8.1–8.2).
- The Euclidean-time-decay ⇒ Hamiltonian-gap spectral-measure argument (Part 11.3), **once** EI-OS-REC is granted.

What remains open/flagged is listed in DEPENDENCY_LEDGER.md under **[GAP]** and is deliberately kept separate from the “external theorem” list above.

