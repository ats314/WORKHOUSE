# PROOF PACK — Pass 1 Index (generated 2025-12-21)

This file is an **index + sort map** for the current project bundle. It does **not** rewrite proofs yet; it just:
- classifies each file (core proof / appendix / external / gap / numerics),
- assigns it to a target Proof Pack folder,
- flags immediate hygiene issues (duplicate files, mixed content).

## Top-level status
- **Core fixed-cutoff analytic chain is present** (Parts 3–12 + Appendices B–D, J).  
- **Open blockers are explicitly isolated**: pairing-term coercivity + typicality/localization.  
- **Numerics are quarantined** (PDF run logs + code snippets) for Pass 2 extraction.

## Known open inputs (from the DAG)
- Pairing-term coercivity (Lyapunov drift mechanism)
- Typicality/localization: quantitative control of μ(K^c)
- Continuum architecture beyond fixed cutoff (Part 12)

---

## 00_META

| file | title | status |
|---|---|---|
| DEPENDENCY_LEDGER(1).md | DEPENDENCY_LEDGER.md | CORE_PROOF |
| EXTERNAL_INPUTS.md | EXTERNAL_INPUTS.md | EXTERNAL_CATALOG |
| NOTATION_AND_CONSTANTS.md | NOTATION_AND_CONSTANTS.md | CORE_PROOF |


## 01_FOUNDATION

| file | title | status |
|---|---|---|
| ### 3.1 Product Lie-group manifold.txt | 3.1 Product Lie-group manifold and right-invariant trivialization | CORE_PROOF |
| ### 4.1 OS reflection plane, induced involution on configurations, positive-time algebra.txt | 4.1 OS reflection plane, induced involution on configurations, positive-time … | CORE_PROOF |
| 001_Proposition_Tubular_neighborhood.md | Proposition (Tubular neighborhood). | CORE_PROOF |


## 02_LOCAL_GEOMETRY

| file | title | status |
|---|---|---|
| ## 5.1 Vacuum configuration and linearization.txt | 5.1 Vacuum configuration and linearization | CORE_PROOF |
| 002_Lemma_Local_Hodge_stiffness_from_exactness_gauge_term.md | Lemma (Local Hodge stiffness from exactness + gauge term). | CORE_PROOF |


## 03_ANALYTIC_ENGINE

| file | title | status |
|---|---|---|
| ## 6.1 Bochner Γ_2 identity with drift and the Bakry–Émery curvature matrix.txt | 6.1 Bochner/Γ_2 identity with drift and the Bakry–Émery curvature matrix | CORE_PROOF |
| ## 7. Lyapunov drift and uniform-in-volume functional inequalities.txt | 7. Lyapunov drift and uniform-in-volume functional inequalities | CORE_PROOF |
| APPENDIX_J.md | Appendix J — Smooth plaquette proxy and uniform second-derivative control (re… | CORE_PROOF |


## 04_KERNEL_DECAY

| file | title | status |
|---|---|---|
| ### 9.1 Abstract finite-range inverse decay lemma via Combes–Thomas conjugation.txt | 9.1 Abstract finite-range inverse decay lemma via Combes–Thomas conjugation | CORE_PROOF |
| 003_Proposition_9_X_Davies_type_decay_for_the_massive_Maxwell_Green_kernel.md | Proposition 9.X (Davies‑type decay for the massive Maxwell Green kernel). | CORE_PROOF |
| 004_Remark_9_Y_relation_to_Prop_9_6.md | Remark 9.Y (relation to Prop. 9.6). | CORE_PROOF |
| 005_Definition_row_sum_constants_for_Delta_1.md | Definition (row‑sum constants for \Delta_1) | CORE_PROOF |
| 006_Proposition_9_X_Davies_decay_with_C_0_in_place_of_D_E.md | Proposition 9.X′ (Davies decay with C_0 in place of D_E) | CORE_PROOF |
| 007_Definition_boundary_row_sum_constant.md | Definition (boundary row‑sum constant) | CORE_PROOF |
| 008_Corollary_9_X_Davies_decay_with_C_partial.md | Corollary 9.X′′ (Davies decay with C_\partial) | CORE_PROOF |


## 05_LOCALIZATION_CLUSTERING

| file | title | status |
|---|---|---|
| ## 8.1 Covariance decomposition across an event (K).txt | 8.1 Covariance decomposition across an event (K) | CORE_PROOF |
| ### 10.1 Exponential clustering at fixed cutoff statement.txt | 10.1 Exponential clustering at fixed cutoff: statement | CORE_PROOF |


## 06_OS_AND_GAP

| file | title | status |
|---|---|---|
| ## 11.1 Thermodynamic limit at fixed cutoff existence of limit points and permanence of OS structure.txt | 11.1 Thermodynamic limit (\Lambda\uparrow\mathbb Z^4) at fixed cutoff existen… | CORE_PROOF |
| APPENDIX_B.md | Appendix B. Reflection positivity for Wilson lattice gauge theory | CORE_PROOF |
| APPENDIX_C(1).md | Appendix C. Osterwalder–Schrader axioms and reconstruction at fixed cutoff | EXTERNAL_BRIDGE |
| APPENDIX_D.md | Appendix D. Boundary compression and the one-step transfer kernel | CORE_PROOF |


## 07_CONTINUUM_ARCH

| file | title | status |
|---|---|---|
| ## 12.1 Reflection positivity permanence under reflection-equivariant coarse graining and under projective limits on cylinder observables.txt | 12.1 Reflection positivity permanence under reflection-equivariant coarse gra… | CONDITIONAL_ARCH |


## 08_GAPS

| file | title | status |
|---|---|---|
| 12-20-25 PULSE.txt | 12-20-25 PULSE | OPEN_INPUT |
| APPENDIX_I.md | Appendix I. The remaining coercive input for Lyapunov drift | OPEN_INPUT |


## 09_NUMERICS

| file | title | status |
|---|---|---|
| 12-21-25 GEMINI CODE.txt | yes | NUMERIC_ARTIFACT |
| 12-21-25 SIM.txt | 12/21/2025, 4:15 PM | NUMERIC_ARTIFACT |
| 12-21-25 SIMS LATEE.pdf | Untitled127.ipynb - Colab https://colab.research.google.com/drive/1pr68AzfiJa… | NUMERIC_ARTIFACT |
| 127.pdf | Untitled127.ipynb - Colab https://colab.research.google.com/drive/1pr68AzfiJa… | NUMERIC_ARTIFACT |
| 128.pdf | Untitled128.ipynb - Colab https://colab.research.google.com/drive/1YYxm453ywN… | NUMERIC_ARTIFACT |
| 129.pdf | Untitled129.ipynb - Colab https://colab.research.google.com/drive/1cUg1gigxYo… | NUMERIC_ARTIFACT |
| 130.pdf | Untitled130.ipynb - Colab https://colab.research.google.com/drive/1naKS-iEg_n… | NUMERIC_ARTIFACT |
| MAXWELL SIMS.txt | import math | NUMERIC_ARTIFACT |
| RUN 124.pdf | Untitled124.ipynb - Colab https://colab.research.google.com/drive/1BYuZw_FlID… | NUMERIC_ARTIFACT |
| RUN 125.pdf | Untitled125.ipynb - Colab https://colab.research.google.com/drive/1Z2NRwMaGiM… | NUMERIC_ARTIFACT |
| RUN 126.pdf | Untitled126.ipynb - Colab https://colab.research.google.com/drive/13x0cELH3ZH… | NUMERIC_ARTIFACT |


## 99_SCRATCH

| file | title | status |
|---|---|---|
| ## 6.1 BochnerΓ_2 identity with drift and the Bakry–Émery curvature matrix.txt | 6.1 Bochner/Γ_2 identity with drift and the Bakry–Émery curvature matrix | DUPLICATE/SCRATCH |



## Immediate hygiene flags
- Duplicate: `## 6.1 BochnerΓ_2 ...` duplicates the spaced-name 6.1 file → move to `99_SCRATCH/` and delete later.
- Mixed-content: `12-20-25 PULSE.txt` contains both a globalization gameplan and Maxwell-bound code comments → split into `08_GAPS/` + `09_NUMERICS/`.

## Next pass (what I will do next, deterministically)
Pass 2 will **mine 09_NUMERICS** (RUN 124–130 PDFs + SIM logs) into a structured list:
- each run’s *computed quantity*,
- what it *verifies* (exact identity vs inequality check vs fit),
- what lemma it can be attached to (or “standalone diagnostic only”).

