# DEPENDENCY_LEDGER.md

Referee-facing **proof DAG** for the unified draft: *what depends on what*, plus explicit **external** and **open** inputs.

**Legend.** `A → B` means “B uses A.”  **[EXT]** external theorem.  **[GAP]** open input.

---

## A. Logical spine

**Curvature hinge (matrix)  
→ local LSI/Poincaré on a good set \(K\)  
→ Helffer–Sjöstrand covariance (matrix inverse)  
→ massive Maxwell inverse \(M_H^{-1}\)  
→ Green kernel exponential decay (Combes–Thomas)  
→ conditional clustering on \(K\)  
→ localization (typicality + covariance decomposition)  
→ full clustering at fixed cutoff  
→ OS reconstruction \([EXT]\)  
→ Hamiltonian gap \(m(a)\gtrsim \eta(a)/a\)  
→ continuum limit (conditional) → continuum OS mass gap.**

---

## B. Part-by-part dependency map

### (2) Lattice YM + Euclidean measure
Defs: \(\Lambda\), links/plaquettes, holonomy \(U_p(U)\), Wilson action \(S_W\), Gibbs measure \(\mu_{\Lambda,eta}\), local observables/supports.  
Used by: all later parts.

### (3) Geometry + cochains
Defs: product metric/right-trivialization \(T_UM_\Lambda\simeq \mathcal C^1\), operators \(d_0,d_1\) and adjoints, horizontals \(H^{(0)}=\ker d_0^*\), overlap constants \((m_\partial,\nu)\), generator \(L\), carré du champ \(\Gamma\).  
Used by: Parts 5–6–9.

### (4) OS axioms (reflection positivity)
Reflection plane/involution \(	heta\), positive-time algebra \(\mathcal A_+\), time translations.  
Reflection positivity for Wilson \([EXT or internal]\).  
OS reconstruction theorem \([EXT]\) (transfer matrix \(T=e^{-aH}\), correlation identity).  
Used by: Part 11 (Euclidean→Hamiltonian).

---

## C. The analytic engine: Parts 5–10

### (5) Wilson Hessian + matrix hinge on \(K_\Lambda(r)\)
- (5.1) Vacuum linearization: plaquette holonomy linearizes to \(d_1\); trace potential is quadratic at \(\mathbf 1\).
- (5.2) Vacuum Hessian identity: \(
abla^2 S_W(U^{(0)})=\alpha\,d_1^*d_1\), \(\alpha=\beta/(n\lambda_\rho)\).
- (5.3) Small-field region \(K_\Lambda(r)\): uniform exponential coordinates and plaquette smallness.
- (5.4) Local stability + overlap bookkeeping: on \(K_\Lambda(r)\),
  \(
abla^2 S_W(U)\succeq \nabla^2 S_W(U^{(0)})-R_W(r)I\),
  hence (with Haar/Ricci \(c_H\)) the **matrix hinge**
  \(\mathrm{Ric}_\mu(U)\succeq m^2 I + \alpha d_1^*d_1\) on \(K\), \(m^2=c_H/2\).
- (5.5) Matrix-not-scalar principle: keep \(d_1^*d_1\succeq0\) intact.

### (6) Local functional inequalities + HS covariance
- (6.1) Bochner/Γ₂ identity with drift (Bakry–Émery curvature matrix \(\mathrm{Ric}_\mu\)).
- (6.2) Local curvature ⇒ local LSI/Poincaré on \(K\) (reflecting/Neumann localization device).
- (6.3) Helffer–Sjöstrand (HS) identity:
  \(\mathrm{Cov}(F,G)=\langle \nabla F,(\mathcal L^{(1)})^{-1}\nabla G\rangle\),
  \(\mathcal L^{(1)}=(-L)\otimes I+\mathrm{Ric}_\mu\).
- (6.4) On \(K\): \(\mathcal L^{(1)}\succeq M:=m^2I+\alpha d_1^*d_1\) ⇒ \((\mathcal L^{(1)})^{-1}\preceq M^{-1}\).
- (6.5) Restrict to horizontals: invert \(M_H:=M|_{H^{(0)}}\); define kernel \((M_H^{-1})_{bb'}\) and link-distance \(\mathrm{dist}_E\).

### (9) Green kernel decay for \(M_H^{-1}\)
- (9.1) Combes–Thomas lemma (proved): positivity gap + finite range ⇒ exponential inverse decay.
- (9.2–9.3) Apply to \(M_H\): identify \(a_0=m^2\), range \(R\) in \(\mathrm{dist}_E\), row-sum bound \(B\lesssim \alpha\times(\text{bounded degree})\); constants uniform in \(|\Lambda|\).
- (9.4) Insert kernel decay into HS bound ⇒ **conditional exponential clustering on \(K\)**.

### (8) Localization (upgrade \(K\)-bounds to full measure)
- (8.1) Law of total covariance across \(K\): full covariance = conditional covariances + explicit error \(\propto \mu(K^c)\).
- (8.2) Canonical gauge-invariant averaged-badness event \(K_\Lambda(\varepsilon)=\{\mathcal B_\Lambda\le\varepsilon\}\), with Lipschitz constant \(O(|P|^{-1/2})\).
- (8.3) **[GAP] Typicality:** bound \(\mu(K_\Lambda(\varepsilon)^c)\) strongly enough not to spoil the distance exponent (plan: global LSI concentration, or drift/capacity redesign).

### (10) Fixed-cutoff clustering
(6)+(9) give conditional clustering on \(K\); (8) upgrades to full clustering.  
Output: exponential decay with exponent \(\eta(a)\) (in lattice steps), uniform in volume.

---

## D. Thermodynamic limit + OS gap

### (11) Infinite volume and OS Hamiltonian gap at fixed \(a\)
- (11.1) Infinite-volume limit and permanence of OS axioms \([EXT as needed]\).
- (11.2) Uniform-in-volume clustering ⇒ infinite-volume clustering.
- (11.3) OS reconstruction \([EXT]\) + time-direction decay ⇒ Hamiltonian gap
  \(\mathrm{gap}(H)\ge \eta(a)/a\).
- (11.4) Optional alternate bridge.

---

## E. Continuum limit (conditional)

### (12) Continuum passage and final theorem
- (12.1) Reflection positivity permanence under RG/projective limits **[GAP/EXT]**.
- (12.2) Monotone quadratic-form limit ⇒ gap persistence (functional-analytic permanence lemma).
- (12.3) Scaling trajectory condition: need \(\eta(a_n)\ge m_0 a_n\) along \(a_n\downarrow0\).
- (12.4) Final theorem (conditional): (C1)–(C3) ⇒ continuum OS mass gap.

---

## F. Open inputs (flagged gaps)

1. **[GAP] Pairing-term coercivity (Part 7.3):** “term II dominates term I.”  
2. **[GAP] Typicality/localization (Part 8.3):** quantitative control of \(\mu(K^c)\) (ideally \(\exp(-c|P|)\)).  
   If using the LSI route: **[GAP] SPI→LSI conversion** with verified hypotheses.  
3. **[GAP] Continuum architecture (Part 12):** reflection-equivariant RG/projective framework + Hamiltonian comparison + uniform physical lower bound along scaling.

---

## G. External inputs (used but not reproved)

- **[EXT] OS reconstruction theorem** for lattice gauge theories.  
- **[EXT] Reflection positivity** for Wilson lattice gauge theory (Osterwalder–Seiler factorization framework).  
- **[EXT?] Infinite-volume Gibbs existence/permanence** (DLR etc.) as needed.  
- **[EXT?] SPI→LSI conversion theorem** (only if invoked by Part 8.3).
