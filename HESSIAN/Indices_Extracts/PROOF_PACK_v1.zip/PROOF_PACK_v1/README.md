# PROOF_PACK_v1

Deterministic sort of the current project files into an LLM-readable proof packet.

- **Core proof chain**: 01_FOUNDATION → 05_LOCALIZATION_CLUSTERING → 06_OS_AND_GAP.
- **Continuum architecture**: 07_CONTINUUM_ARCH.
- **Explicit open items**: 08_GAPS.
- **Empirical / verification artifacts**: 09_NUMERICS.
- **Quarantined/untrusted** (duplicates, placeholder runs): 99_SCRATCH.

Start with `00_META/PROOF_PACK_INDEX.md` and `00_META/DEPENDENCY_LEDGER(1).md`.
