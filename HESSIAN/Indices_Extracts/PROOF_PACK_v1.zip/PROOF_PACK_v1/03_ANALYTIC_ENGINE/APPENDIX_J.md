# Appendix J — Smooth plaquette proxy and uniform second-derivative control (removing the “second-derivative obstruction”)

This appendix consolidates (and slightly generalizes) the *smooth proxy* and *uniform-constant* bookkeeping that underlies the Lyapunov/globalization strategy in Part 7.

It addresses a very specific technical snag that repeatedly appears if one tries to run Foster–Lyapunov drift estimates on lattice gauge configuration space using a **non-smooth** notion of “distance from the vacuum,” such as the squared Riemannian distance
\[
g\ \longmapsto\ d_G(g,\mathbf 1)^2
\]
on plaquette holonomies. While \(d_G(\cdot,\mathbf 1)^2\) is perfectly reasonable geometrically, it is generally **not \(C^2\) globally** on a compact Lie group (it fails at the cut locus). Consequently, the generator \(L_\Lambda\) produces second-derivative terms that cannot be bounded uniformly in the lattice volume, and the Lyapunov drift computation leaks an \(\mathrm O(|P(\Lambda)|)\) constant.

The fix is twofold:

1. **Replace distance by a globally smooth, conjugation-invariant proxy** \(\widetilde z:G\to[0,\infty)\) that is \(C^\infty\) on all of \(G\) and still behaves quadratically near \(\mathbf 1\).

2. **Choose an outer profile \(\Phi\) with \(\Phi'(0)=0\)** (e.g. \(\Phi(s)=s^2\)). This forces all potentially dangerous Laplacian/Hessian contributions coming from \(L_\Lambda\) to be weighted by \(\widetilde z_p\), so sums over plaquettes become \(\mathrm O(\sum_p \widetilde z_p)\) rather than \(\mathrm O(|P(\Lambda)|)\).

Everything in this appendix is volume-uniform: constants depend only on \((G,g_G)\), the representation \(\rho\), and the dimension-dependent overlap constant \(\nu\), but **not** on \(|\Lambda|\).

---

## J.1 Setup and notation

We keep the standing lattice/gauge conventions of the main text.

- \(G\) is a compact Lie group with a fixed bi-invariant Riemannian metric \(g_G\), Lie algebra \(\mathfrak g\), and \(\mathrm{Ad}\)-invariant inner product \(\langle\cdot,\cdot\rangle_{\mathfrak g}\).
- \(\Lambda\) is a finite periodic \(4\)-torus lattice.
- \(E(\Lambda)\) and \(P(\Lambda)\) denote the oriented link and plaquette sets.
- The configuration manifold is the product
  \[
  M_\Lambda \;=\; G^{E(\Lambda)}
  \]
  with product bi-invariant metric \(g_\Lambda\).
- The (reversible) generator associated to a Gibbs potential \(S_\Lambda\) is
  \[
  L_\Lambda f \;=\; \Delta_\Lambda f - \langle \nabla S_\Lambda,\nabla f\rangle_{g_\Lambda},
  \]
  and the carré du champ is
  \[
  \Gamma_\Lambda(f,g)=\langle\nabla f,\nabla g\rangle_{g_\Lambda},\qquad \Gamma_\Lambda(f)=\Gamma_\Lambda(f,f).
  \]

We use the linkwise orthonormal frame \(\{X_\ell^a\}_{\ell\in E(\Lambda),\,a=1,\dots,\dim\mathfrak g}\) defined by right multiplication in the \(\ell\)-coordinate (as in §7.2). In particular,
\[
\Gamma_\Lambda(f)=\sum_{\ell,a}(X_\ell^a f)^2,\qquad
\Delta_\Lambda f=\sum_{\ell,a}X_\ell^aX_\ell^a f.
\]

We also keep the bounded-overlap constant \(\nu\) from §3.4: each link \(\ell\) lies in the boundary of at most \(\nu\) plaquettes; in \(d=4\) one may take \(\nu\le 6\). Each plaquette has perimeter \(m_\partial=4\).

---

## J.2 The smooth proxy and its global derivative bounds

### J.2.1 Canonical choice: the trace-defect proxy

Fix a faithful unitary representation \(\rho:G\to U(n)\) (the same one used in the Wilson action). Define the *trace defect*
\[
\widetilde z(g)\;:=\;1-\frac1n\Re\mathrm{Tr}(\rho(g)),\qquad g\in G.
\]
This is globally smooth and conjugation-invariant.

For each plaquette \(p\in P(\Lambda)\), define its lift
\[
\widetilde z_p(U)\;:=\;\widetilde z\!\big(U_p(U)\big),
\]
where \(U_p(U)\in G\) is the oriented plaquette holonomy.

### J.2.2 Elementary range/nondegeneracy facts

**Lemma J.1 (range and unique minimum).**  
For all \(g\in G\),
\[
0\le \widetilde z(g)\le 2,
\qquad\text{and}\qquad
\widetilde z(g)=0 \iff g=\mathbf 1.
\]

*Proof.* Since \(\rho(g)\in U(n)\), its eigenvalues lie on the unit circle, so \(\Re\mathrm{Tr}(\rho(g))\le n\) and \(\Re\mathrm{Tr}(\rho(g))\ge -n\). This gives \(0\le \widetilde z\le 2\). If \(\widetilde z(g)=0\), then \(\Re\mathrm{Tr}(\rho(g))=n\), which forces \(\rho(g)=I_n\) and hence \(g=\mathbf 1\) by faithfulness. ∎

### J.2.3 Global \(C^2\) bounds by compactness

**Lemma J.2 (uniform \(C^2\) bounds on \(G\)).**  
There exist finite constants \(C^{(1)}_{\widetilde z},C^{(2)}_{\widetilde z}\) such that
\[
\sup_{g\in G}|\nabla_G\widetilde z(g)|\le C^{(1)}_{\widetilde z},
\qquad
\sup_{g\in G}\big\|\nabla_G^2\widetilde z(g)\big\|_{\mathrm{op}}\le C^{(2)}_{\widetilde z}.
\]
In particular, if \(C_\Delta:=\sup_{g\in G}|\Delta_G\widetilde z(g)|\), then \(C_\Delta<\infty\).

*Proof.* \(\widetilde z\in C^\infty(G)\), so \(\nabla_G\widetilde z\) and \(\nabla_G^2\widetilde z\) are continuous tensor fields. Since \(G\) is compact, their pointwise norms attain finite maxima. The Laplacian bound follows since \(\Delta_G\widetilde z=\mathrm{tr}(\nabla_G^2\widetilde z)\) and the trace is controlled by the operator norm. ∎

### J.2.4 Global gradient domination

The next inequality is the *key* replacement for “\(|\nabla \widetilde z|\le \mathrm{const}\)” when summing over plaquettes: it upgrades \(\sum_p\Gamma(\widetilde z_p)\) from \(\mathrm O(|P|)\) to \(\mathrm O(\sum_p\widetilde z_p)\).

**Lemma J.3 (global gradient domination).**  
There exists \(C_\nabla<\infty\) such that for all \(g\in G\),
\[
|\nabla_G\widetilde z(g)|^2 \;\le\; C_\nabla\,\widetilde z(g).
\]
Moreover, the ratio \(|\nabla\widetilde z|^2/\widetilde z\) extends continuously to \(g=\mathbf 1\).

*Proof.* Define \(Q(g)=|\nabla_G\widetilde z(g)|^2/\widetilde z(g)\) on \(G\setminus\{\mathbf 1\}\). By Lemma J.1, \(\widetilde z(g)>0\) there, and \(Q\) is continuous. We must show \(Q\) remains bounded as \(g\to\mathbf 1\).

Work in normal coordinates at \(\mathbf 1\): \(g=\exp(Y)\) with \(Y\in\mathfrak g\) small. The Taylor expansion of \(\widetilde z(\exp Y)\) at \(Y=0\) has no linear term (since \(\mathbf 1\) is a minimum), and its quadratic term is positive definite. Concretely, the Hessian computation used in §5.1–§5.2 shows
\[
\widetilde z(\exp Y)=\frac{1}{2n\lambda_\rho}|Y|^2 + O(|Y|^3),
\qquad
\nabla_G\widetilde z(\exp Y)=\frac{1}{n\lambda_\rho}Y + O(|Y|^2),
\]
hence
\[
\frac{|\nabla_G\widetilde z(\exp Y)|^2}{\widetilde z(\exp Y)} \longrightarrow \frac{2}{n\lambda_\rho}
\quad\text{as }Y\to 0.
\]
Thus \(Q\) extends continuously to \(g=\mathbf 1\). By compactness of \(G\), the continuous extension attains a finite supremum \(C_\nabla\), and the inequality follows. ∎

---

## J.3 Lifting bounds to plaquettes: locality + isometries

The plaquette lift \(\widetilde z_p(U)=\widetilde z(U_p(U))\) depends only on the four boundary link variables, and dependence on a single link coordinate is by composition with an isometry of \(G\) (left/right multiplication and inversion), because the metric on \(G\) is bi-invariant. This is the mechanism that preserves derivative bounds without introducing volume factors.

Fix a plaquette \(p\) with ordered boundary \(\partial p=(b_1,b_2,b_3,b_4)\). For a link \(\ell\), let \(\nabla_\ell\) denote the gradient in the \(\ell\)-coordinate.

**Lemma J.4 (support and one-link factorization).**  
If \(\ell\notin\partial p\), then \(\nabla_\ell \widetilde z_p\equiv 0\) and \(\Delta_\ell \widetilde z_p\equiv 0\).  
If \(\ell\in\partial p\), then for fixed values of the other three boundary links, the map \(g:=U_\ell\mapsto \widetilde z_p(U)\) has the form
\[
g\ \longmapsto\ \widetilde z(A\,g^\sigma\,B)
\]
for some \(A,B\in G\) and \(\sigma\in\{+1,-1\}\). In particular, \(g\mapsto Ag^\sigma B\) is an isometry of \((G,g_G)\).

*Proof.* Immediate from the plaquette word \(U_p=U_{b_1}U_{b_2}U_{b_3}^{-1}U_{b_4}^{-1}\) and bi-invariance of \(g_G\). ∎

**Lemma J.5 (uniform linkwise derivative bounds for \(\widetilde z_p\)).**  
With constants from Lemmas J.2–J.3, for every \(p\), every link \(\ell\), and every configuration \(U\),
\[
|\nabla_\ell \widetilde z_p(U)| \le C^{(1)}_{\widetilde z}\,\mathbf 1_{\{\ell\in\partial p\}},
\]
\[
\big\|\nabla_\ell^2 \widetilde z_p(U)\big\|_{\mathrm{op}} \le C^{(2)}_{\widetilde z}\,\mathbf 1_{\{\ell\in\partial p\}},
\]
and the linkwise gradient domination holds:
\[
|\nabla_\ell \widetilde z_p(U)|^2 \le C_\nabla\,\widetilde z_p(U)\,\mathbf 1_{\{\ell\in\partial p\}}.
\]
Moreover, the full product Laplacian obeys
\[
|\Delta_\Lambda \widetilde z_p(U)| \le m_\partial\,C_\Delta = 4C_\Delta.
\]

*Proof.* If \(\ell\notin\partial p\), all derivatives vanish. If \(\ell\in\partial p\), then \(\widetilde z_p\) is \(\widetilde z\circ\Psi\) where \(\Psi(g)=Ag^\sigma B\) is an isometry (Lemma J.4). Composition with an isometry preserves the gradient norm, Hessian operator norm, and Laplacian. Summing over the at most \(m_\partial=4\) contributing links gives the Laplacian bound. ∎

As a direct corollary:

**Corollary J.6 (plaquette carré du champ bound).**  
For all \(p\) and \(U\),
\[
\Gamma_\Lambda(\widetilde z_p)(U)\le m_\partial\,C_\nabla\,\widetilde z_p(U)=4C_\nabla\,\widetilde z_p(U).
\]

*Proof.* Only the four boundary links contribute, and each contributes at most \(C_\nabla\widetilde z_p\) by Lemma J.5. ∎

---

## J.4 Why \(\Phi'(0)=0\) is the magic switch

Let \(\Phi\in C^2([0,\infty))\) and consider the “badness potential”
\[
V_\Lambda(U)\;:=\;\sum_{p\in P(\Lambda)} \Phi(\widetilde z_p(U)).
\]
In drift computations one expands \(L_\Lambda V_\Lambda\) using the diffusion chain rule
\[
L_\Lambda(\Phi\circ f)=\Phi'(f)L_\Lambda f+\Phi''(f)\Gamma_\Lambda(f).
\]

The dangerous term is \(\sum_p \Phi'(\widetilde z_p)\,\Delta_\Lambda \widetilde z_p\). If \(\Phi'\) does not vanish at \(0\), then on configurations where many plaquettes are near the vacuum (so \(\widetilde z_p\approx 0\)), the factor \(\Phi'(\widetilde z_p)\approx \Phi'(0)\) is essentially constant, and the uniform bound \(|\Delta_\Lambda \widetilde z_p|\le 4C_\Delta\) yields
\[
\left|\sum_p \Phi'(\widetilde z_p)\Delta_\Lambda \widetilde z_p\right|
\lesssim |\Phi'(0)|\,|P(\Lambda)|,
\]
which is exactly the volume leak.

If instead \(\Phi'(0)=0\) and \(\Phi'\) grows at most linearly near \(0\), then \(\Phi'(\widetilde z_p)\) forces a weight \(\widetilde z_p\) (or stronger), converting the sum into \(\mathrm O(\sum_p\widetilde z_p)\).

This is why the concrete choice \(\Phi(s)=s^2\) is so robust: \(\Phi'(s)=2s\) and \(\Phi''(s)\equiv 2\).

---

## J.5 Uniform closure of all diffusion-generated terms for \(\Phi(s)=s^2\)

We now spell out the “no hidden \(|P|\)” estimates that are used in §7.3. The point is not sophistication; it is **constant hygiene**.

Define
\[
\mathcal D_\Lambda(U)\;:=\;\sum_{p\in P(\Lambda)}\widetilde z_p(U),
\qquad
V_\Lambda(U)\;:=\;\sum_{p}\widetilde z_p(U)^2.
\]

**Proposition J.7 (uniform control of diffusion terms by \(\mathcal D_\Lambda\)).**  
There exist constants \(A_1,A_2,A_3<\infty\), depending only on \((G,g_G)\), \(\rho\), and \(\nu\) (not on \(\Lambda\)), such that for all \(U\in M_\Lambda\),
\[
\Big|\sum_{p} 2\widetilde z_p(U)\,\Delta_\Lambda \widetilde z_p(U)\Big|
\le A_1\,\mathcal D_\Lambda(U),
\]
\[
2\sum_{p}\Gamma_\Lambda(\widetilde z_p)(U) \le A_2\,\mathcal D_\Lambda(U),
\]
\[
\Gamma_\Lambda(V_\Lambda)(U)\le A_3\,\mathcal D_\Lambda(U).
\]
One explicit choice is
\[
A_1=8C_\Delta,\qquad A_2=8C_\nabla,\qquad A_3=64\,\nu\,C_\nabla.
\]

*Proof.*  

1. **Laplacian/Hessian term.** By Lemma J.5,
\[
|\Delta_\Lambda \widetilde z_p|\le 4C_\Delta.
\]
Hence
\[
\Big|\sum_{p} 2\widetilde z_p\,\Delta_\Lambda \widetilde z_p\Big|
\le \sum_p 2\widetilde z_p\cdot 4C_\Delta
=8C_\Delta\sum_p \widetilde z_p
= A_1\,\mathcal D_\Lambda.
\]

2. **Chain-rule \(\Gamma\)-term.** By Corollary J.6,
\[
2\sum_p \Gamma_\Lambda(\widetilde z_p)\le 2\sum_p 4C_\nabla\widetilde z_p
=8C_\nabla \mathcal D_\Lambda,
\]
so \(A_2=8C_\nabla\).

3. **Exponential carré du champ term.** For each link \(\ell\),
\[
\nabla_\ell V_\Lambda = \sum_{p:\,\ell\in\partial p} \nabla_\ell(\widetilde z_p^2)
= \sum_{p:\,\ell\in\partial p} 2\widetilde z_p\,\nabla_\ell\widetilde z_p.
\]
Cauchy–Schwarz over the finite set of plaquettes meeting \(\ell\) gives
\[
|\nabla_\ell V_\Lambda|^2
\le \Big(\#\{p:\ell\in\partial p\}\Big)\sum_{p:\,\ell\in\partial p} 4\widetilde z_p^2\,|\nabla_\ell\widetilde z_p|^2
\le 4\nu \sum_{p:\,\ell\in\partial p}\widetilde z_p^2\,|\nabla_\ell\widetilde z_p|^2.
\]
Sum over links and swap sums:
\[
\Gamma_\Lambda(V_\Lambda)=\sum_\ell |\nabla_\ell V_\Lambda|^2
\le 4\nu \sum_p \widetilde z_p^2\sum_{\ell\in\partial p}|\nabla_\ell\widetilde z_p|^2
=4\nu\sum_p \widetilde z_p^2\,\Gamma_\Lambda(\widetilde z_p).
\]
Use Corollary J.6: \(\Gamma_\Lambda(\widetilde z_p)\le 4C_\nabla \widetilde z_p\), so
\[
\Gamma_\Lambda(V_\Lambda)\le 16\nu C_\nabla\sum_p \widetilde z_p^3.
\]
Finally, since \(0\le \widetilde z_p\le 2\) (Lemma J.1), we have \(\widetilde z_p^3\le 4\widetilde z_p\), giving
\[
\Gamma_\Lambda(V_\Lambda)\le 16\nu C_\nabla\sum_p 4\widetilde z_p
=64\nu C_\nabla\,\mathcal D_\Lambda.
\]
Thus \(A_3=64\nu C_\nabla\). ∎

---

## J.6 Drift identity for \(W_\Lambda=\exp(\kappa V_\Lambda)\) and what remains open

Define
\[
W_\Lambda(U):=\exp(\kappa V_\Lambda(U)),\qquad V_\Lambda(U)=\sum_p \widetilde z_p(U)^2.
\]
A standard diffusion computation (carried out in §7.3) yields the exact identity
\[
\frac{L_\Lambda W_\Lambda}{W_\Lambda}
=\kappa\,L_\Lambda V_\Lambda + \kappa^2\,\Gamma_\Lambda(V_\Lambda),
\]
and
\[
L_\Lambda V_\Lambda
=
2\sum_{p}\widetilde z_p\,\Delta_\Lambda \widetilde z_p
\;-\;
2\sum_{p}\widetilde z_p\,\langle\nabla S_\Lambda,\nabla \widetilde z_p\rangle
\;+\;
2\sum_{p}\Gamma_\Lambda(\widetilde z_p).
\]

Insert Proposition J.7 to control all diffusion-generated terms by \(\mathcal D_\Lambda\):
\[
\frac{L_\Lambda W_\Lambda}{W_\Lambda}(U)
\;\le\;
\big(\kappa(A_1+A_2)+\kappa^2A_3\big)\,\mathcal D_\Lambda(U)
\;-\;
2\kappa\sum_{p}\widetilde z_p(U)\,\langle\nabla S_\Lambda(U),\nabla \widetilde z_p(U)\rangle.
\]

**What is “solved” here:** all terms coming from \(\Delta_\Lambda\) and \(\Gamma_\Lambda\) are closed with volume-uniform constants.

**What is *not* solved here:** the *pairing term*
\[
\mathcal P_\Lambda(U)
:=\sum_{p}\widetilde z_p(U)\,\langle\nabla S_\Lambda(U),\nabla \widetilde z_p(U)\rangle
\]
still requires a coercive lower bound of the schematic form
\[
\mathcal P_\Lambda(U)\ \ge\ c_{\mathrm{pair}}\mathcal D_\Lambda(U)-C_{\mathrm{pair}},
\]
with constants independent of \(\Lambda\). This is exactly the “term II dominates term I” inequality isolated in Appendix I.

---

## J.7 Generalizations and interface notes

1. **Other smooth proxies.**  
   The entire argument goes through for any conjugation-invariant \(C^2\) function \(\vartheta:G\to[0,\infty)\) satisfying:
   - \(\vartheta(\mathbf 1)=0\), \(\vartheta>0\) on \(G\setminus\{\mathbf 1\}\);
   - \(\|\nabla_G\vartheta\|_\infty<\infty\), \(\|\nabla_G^2\vartheta\|_\infty<\infty\);
   - a gradient domination inequality \(|\nabla\vartheta|^2\le C\,\vartheta\) (this holds for many “heat-kernel smoothed” distances, not just trace defect).

2. **Other profiles \(\Phi\).**  
   What really matters for “no \(|P|\)” is that \(\Phi'\) vanishes at \(0\) and that \(\Phi',\Phi''\) are controlled on the range of \(\vartheta\). The choice \(\Phi(s)=s^2\) is simply the cleanest.

3. **Compatibility with the canonical localization set.**  
   In Part 8 we localize using the averaged badness functional
   \[
   \mathcal B_\Lambda(U)=\frac{1}{|P(\Lambda)|}\sum_p \vartheta(U_p(U)).
   \]
   For \(\vartheta=\widetilde z\), \(\mathcal B_\Lambda\) is the Wilson action density (up to \(\beta\)). The derivative bounds above are also what yield the \(|P|^{-1/2}\) Lipschitz scaling of \(\mathcal B_\Lambda\), which is the right normalization for concentration estimates once a volume-uniform functional inequality is available.

---

## J.8 Summary: what Appendix J guarantees

- A **globally smooth** plaquette proxy \(\widetilde z_p\) avoids cut-locus singularities and makes \(\Delta_\Lambda \widetilde z_p\) uniformly bounded.
- A **gradient domination** inequality \(|\nabla\widetilde z|^2\lesssim \widetilde z\) ensures \(\Gamma(\widetilde z_p)\) is weighted by \(\widetilde z_p\).
- With \(\Phi(s)=s^2\), **every diffusion-generated term** in the Lyapunov drift computation is controlled by \(\mathcal D_\Lambda=\sum_p \widetilde z_p\), with constants independent of \(|\Lambda|\).
- The **only remaining model-dependent obstruction** is the coercive pairing estimate (Appendix I).
