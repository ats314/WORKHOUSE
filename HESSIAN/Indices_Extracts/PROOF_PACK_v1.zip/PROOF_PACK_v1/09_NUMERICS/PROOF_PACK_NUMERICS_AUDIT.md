# PROOF PACK — Pass 2: Numerics / Run Audit

Scope: extract only *concrete computed outputs* from the attached run artifacts, label what they validate, and quarantine anything code-only or placeholder-based.

## Executive summary (what is actually usable)

- **Usable validation A (Maxwell / Prop 9.X):** exact Fourier-space computation of the 1-form Green kernel and a shell-by-shell DG/Davies envelope check passes with a comfortable margin; directional decay fits are consistent and typically much faster than the conservative DG exponent.

- **Usable validation B (drift dataset algebra):** on the `decomp_Lsweep_results.npz` dataset, the identity `lap - gip - LV ≈ 0` holds to roundoff (`max|.|≈3.2e-14`).

- **Usable validation C (drift certificate strength, empirical):** per-L certificates at `(L,beta)=(8,6),(12,6),(16,6)` show `d_max(tau*)` strongly negative with ~83–85% holdout coverage, yielding `lambda*≈10–11` (empirical, not a proof).

- **Not usable as evidence:** anything that explicitly says “placeholder” / injects random noise (129.pdf), and any script-only artifacts with no printed results.

## Run table (one row per artifact)

| artifact | timestamp | what | key_outputs | supports | status |
|---|---|---|---|---|---|
| RUN 124.pdf | 12/20/2025 7:21 PM | Integrated notebook: (A) exact 1-form Maxwell Green kernel + DG shell bound + directional decay fits; (B) Gaussian Wilson loop perimeter vs area; (C) Compact U(1) Langevin harness; (D) SU(2) local-anatomy Hessian/min-... | Maxwell: PASS=True with max_shell_ratio=1.411852e-01 at n=0; eta_DG=0.129010; envelope-fit eta_obs_env≈0.338367. Direction fits (examples): axis same eta=1.456954 (R2=0.9939, max_ratio_vs_etaDG=1.014e-02); diag3 same ... | Prop 9.X / 9.X' numeric validation (Maxwell inverse + DG bound); sanity baseline for Wilson loop scaling (Gaussian). Local anatomy: diagnostic only; compact U(1): incomplete evidence. | VALID for Maxwell/DG validation + Gaussian sanity; PARTIAL for compact U(1); WARNING for local-anatomy (FD mismatch). |
| RUN 125.pdf | 12/20/2025 7:20 PM | Standalone Maxwell verifier + Gaussian Wilson loop check + exploratory quartic deformation; then starts SU(2) stress-test script. | Contains same Maxwell/Gaussian numbers as RUN 124 (DG shell PASS; directional fit table; perimeter-vs-area R2 numbers). Output is redundant; SU(2) stress-test section appears as code only (no run outputs). | Same as RUN 124 (redundant). | REDUNDANT (keep one of RUN124/RUN125); SU(2) part = code-only. |
| 12-21-25 SIMS LATEE.pdf | 12/21/2025 8:12 PM | SU(2) drift dataset L-sweep and “proof gallery” style certificate reporting built from sampled configs; writes summary NPZ/CSV. | L_LIST=[8,12,16], beta=6.0, K_total=2048 per L (fit=1024, holdout=1024), eps_fd=0.005, mc=256. Outlier microscope per L: L=8 tau*=0.213802 lambda*=11.001160 coverage=84.8% with d_max=-11.001160, c_min=11.385200; L=12 ... | Empirical support for the drift/certificate mechanism on sampled SU(2) configs; specifically: negative d_max gives a per-L ‘lambda*’ drift strength; coverage quantifies how often holdout configs satisfy the certificat... | VALID as a *diagnostic/validation report* (has concrete numeric outputs). |
| 127.pdf | 12/21/2025 9:45 PM | Drift proof-report builder reading decomp_Lsweep_results.npz, plus a separate ‘uniform-in-L ratio certificate’ check over a tau grid; also includes production-run scaffolding. | Loaded decomp_Lsweep_results.npz: total rows 6144 with L=[8,12,16]. Identity check: [decomp check] lap - gip - LV max|.|=3.197e-14 (rms 5.498e-15). Uniform-in-L attempt: best-margin tau0=0.994350; c_min_all(tau0)=13.4... | Hard evidence that the algebraic decomposition is exact-to-roundoff on that dataset, and that the chosen global target C_TARGET=20 is currently missed by ~6.53 at the selected tau0, while the negative-drift side is st... | VALID diagnostic; highlights a concrete constant shortfall for the uniform-in-L goal. |
| RUN 126.pdf | 12/20/2025 7:21 PM | SU(2) 4D ‘counterexample hunt’ and SGLD sampler script (hunt configs with large Bavg + high alignment + small force). | Code only in captured PDF (prints defined but no observed ‘BEST HIT’ results recorded). | Tooling for searching K^c / metastable configs; no results in artifact. | CODE-ONLY (no admissible findings). |
| 128.pdf | 12/21/2025 9:45 PM | Scalar-field spectral sandbox / stochastic quantization script (correlator + effective mass extraction). | Code only; no run outputs captured. | Tooling; no evidence. | CODE-ONLY. |
| 129.pdf | 12/21/2025 9:45 PM | ‘Local anatomy’ / defect-basin narrative notebook. | Contains explicit placeholders and injected random noise for defects (not a physical computation). Prints ‘PASSED/FAILED’ strings based on the placeholder pipeline. | None (invalid as evidence). | INVALID (placeholders / random injection). |
| 130.pdf | 12/21/2025 9:44 PM | SU(2) 4D drift single-pass beta sweep script. | Mostly code; no computed report/cert numbers captured in extracted text. | Tooling; no evidence. | CODE-ONLY. |
| 12-20-25 PULSE.txt | 12/20/2025 | Analytic gameplan note: uniform Poincaré/LSI via block Gibbs / finite-range Hessian control. | Not a run; design note for the main remaining GAP (typicality/globalization). | GAP planning; not evidence. | NOTE (keep in 08_GAPS). |
| 12-21-25 SIM.txt | 12/21/2025 | Code dump for streamed SU(2) drift + certificate building (no outputs). | No concrete run outputs embedded (as text). | Tooling. | CODE-ONLY. |
| 12-21-25 GEMINI CODE.txt | 12/21/2025 | Alternate code draft (Gemini) for parts of the pipeline. | No outputs. | Tooling draft. | CODE-ONLY. |
| MAXWELL SIMS.txt | 12/20/2025 | Standalone Maxwell verifier script (project-aligned). | Script only; outputs live in RUN124/RUN125 PDF captures. | Tooling (numerics). | CODE-ONLY. |

## Evidence excerpts (page-local)

### RUN 124.pdf — Maxwell verifier outputs (p77–p78)

```
device=cuda | L=16 d=4 | m2=0.3 alpha=1.0
RUN_INTERACTING=True (lambda=1.0)
[1] Building link-graph distances dist_E ...
    done in 6.893s | D_E=18 | maxdist=32
    eta_DG(D_E) = 0.129010
[2] Computing exact 1-form Green kernel G_{mu,nu}(x) ...
    done in 0.006s | G shape = (4, 4, 16, 16, 16, 16)
[3] DG bound verification (shell envelope) ...
    max_shell_ratio = 1.411852e-01 at n=0
    ratio_shell[0]  = 1.411852e-01
    ratio_shell[32] = 6.478291e-06
    PASS = True
    eta_obs_env (fit n=2..15) ≈ 0.338367 (vs eta_DG=0.129010)Untitled124.ipynb - Colab https://colab.research.google.com/drive/1BYuZw_FlIDBxFKjdv8Tbq...
77 of 100 12/20/2025, 7:21 PM
```

```
[4] Directional decay fits (project-relevant diagnostics) ...    Columns: dir | mode | points | dist_range | eta_obs | R2 | max_ratio_vs_etaDG    axis  | same |  5 | 3.. 7 | 1.456954 | 0.9939 | 1.014e-02
    axis  | max  |  5 | 3.. 7 | 0.532101 | 0.6800 | 1.014e-02
    diag2 | same |  5 | 4..12 | 0.794335 | 0.8118 | 3.623e-04
    diag2 | max  |  5 | 4..12 | 0.222442 | 0.1460 | 4.989e-03
    diag3 | same |  5 | 6..18 | 0.368841 | 0.9962 | 6.105e-05
    diag3 | max  |  5 | 6..18 | 0.491844 | 0.9849 | 2.540e-04
    diag4 | same |  5 | 8..24 | 0.330409 | 0.9853 | 1.078e-04
    diag4 | max  |  5 | 8..24 | 0.337573 | 0.9815 | 1.244e-04
[5] Gaussian Wilson-loop screening check (Feynman gauge scalar) ...
    scalar propagator computed in 0.000s | G0(0)=0.143868
    Fit E≈a*Perim+b: a=0.103903, b=-0.184013, R2=0.999959
    Fit E≈a*Area +b: a=0.056948, b=0.406915, R2=0.959999    (Massive Gaussian
```

### 12-21-25 SIMS LATEE.pdf — L-sweep drift certificate summary (p66, p77)

```
L_LIST={L_LIST}\n")for L in L_LIST:    summ, payload = run_L(L)    all_summaries.append(summ)
# pack for npz
for k, v in payload.items():        npz_dict[f"L{L}_{k}"] = v# ----------------------------# Final cross-L summary table# ----------------------------print("\n" + "="*40)print("L-SWEEP SUMMARY (key structural checks)")print("="*40)hdr = f"{'L':>3} | {'lap_a':>10} {'lap_b':>10} {'R2':>10} | {'max|lap-hyp|':>12print(hdr)print("-"*len(hdr))for s in all_summaries:
print(f"{s['L']:3d} | {s['lap_a']:10.6f} {s['lap_b']:10.6f} {s['lap_r2']:10.6f# ----------------------------# Save NPZ# ----------------------------out_path = "/content/decomp_Ls
```

```
OUTLIER MICROSCOPE (worst configs for certificate at tau*)
========================================
--- file=decomp_Lsweep_results.npz  L=8  beta=nan ---
  tau0=0.213802   tau*=0.213802   lambda*=11.001160   coverage=84.8%
  d_max(tau*)=-11.001160   c_min(tau*)=11.385200  [argmax d_max]   {'Bavg': 0.969392889231684, 'LV': -13.355594077250533, 'LV_se': 1.34557381387  [argmin c_min]   {'Bavg': 0.969392889231684, 'LV': -13.355594077250533, 'LV_se': 1.34557381387--- file=decomp_Lsweep_results.npz  L=12  beta=nan ---
  tau0=0.215191   tau*=0.215191   lambda*=10.545743   coverage=83.3%
  d_max(tau*)=-10.545743   c_min(tau*)=10.718741  [argmax d_max]   {'Bavg': 0.21537389895820522, 'LV': -4.9327547079639835, 'LV_se': 1.330738444  [argmin c_min]   {'Bavg': 1.0006899190186855, 'LV': -13.479517811755848, 'LV_se': 1.3745549611--- file=decomp_Lsweep_results.npz  L=16  beta=nan ---
  tau0=0.215730   tau*=0.215730   lambda*=10.979932   coverage=82.6%
```

### 127.pdf — decomposition + uniform-in-L attempt (p109)

```
[keys] ['Bavg', 'L', 'LV', 'Vbar', 'gip', 'kind', 'lap', 'sigma']
[n] total rows: 6144
[Lvals] [8, 12, 16]
[counts per L] {8: 2048, 12: 2048, 16: 2048}
[decomp check] lap - gip - LV: max|.|=3.197e-14  rms=5.498e-15[L=8] holdout n=1024  Bavg q=[min,0.1,0.5,0.9,max]=[0.         0.         0.64274764 1.00087712 [L=8] gip/Bavg: median=20.6731  min=14.1611  max=127.9036[L=12] holdout n=1024  Bavg q=[min,0.1,0.5,0.9,max]=[0.         0.         0.6417043  1.00053027[L=12] gip/Bavg: median=20.3715  min=13.4659  max=121.5276[L=16] holdout n=1024  Bavg q=[min,0.1,0.5,0.9,max]=[0.         0.         0.96321833 1.00020987[L=16] gip/Bavg: median=20.0912  min=13.8417  max=123.6833[tau grid] [0.         0.05846597 0.21622332 0.3883     0.64287354 0.99434973 0.99870124 1.00041557 1.00128105 1.00199346 1.00241897 1.00361295
 1.00506541 1.00647557 1.00728518 1.00753258 1.00977785]
[tau0] best-margin (margin=-6.534080): tau0=0.994350
=== UNIFORM-IN-L RATI
```

### RUN 124.pdf — local anatomy Hessian/min-eig diagnostic (p12 parameters, p6 outputs)

```
lat = Lattice(L=4, d=4)
    beta = 6.0
    burn = 300
    n_samples = 12
    between = 50
    step = 5e-4
    noise = 5e-3
# constants (diagnostic placeholders)
    kappa_star = 0.5
    V = lat.all_sites(torch.device(device)).shape[0]
    U = qrand((V, lat.d), device=device)
    lam_fft = laplace_eigs(lat, device=torch.device(device), dtype=U.dtype)Untitled124.ipynb - Colab https://colab.research.google.com/drive/1BYuZw_FlIDBxFKjdv8Tbq...
12 of 100 12/20/2025, 7:21 PM
```

```
fd check: v^T Hess v ≈ 59.3028, finite-diff ≈ 29.2736, diff=3.003e+01
[000] lambda_min≈8.65603  defect≈0
[001] lambda_min≈11.0356  defect≈0
[002] lambda_min≈12.7857  defect≈0
[003] lambda_min≈15.5436  defect≈0
[004] lambda_min≈17.5278  defect≈0
[005] lambda_min≈20.2795  defect≈0
[006] lambda_min≈4.46566  defect≈0
[007] lambda_min≈0.173797  defect≈0.326203
[008] lambda_min≈0.00558326  defect≈0.494417
[009] lambda_min≈0.000508259  defect≈0.499492
[010] lambda_min≈7.82515e-05  defect≈0.499922
[011] lambda_min≈3.54798e-05  defect≈0.499965
Summary
E[lambda_min]≈7.53948
Phi_proxy≈0.193333  (kappa*=0.5)
Start coding or generate with AI.
Start coding or generate with AI.
Start coding or generate with AI.
# phi_obstruction_su2_4d_a100_PIphys_block2x.py
#
# Standalone diagnostic harness:
#   (1) rep
```

Interpretation: the FD mismatch means this local-anatomy Hessian codepath is not yet trustworthy; treat its lambda_min values as *diagnostic only* until the FD check closes.

### 129.pdf — explicit placeholder / random injection (invalid evidence)

```
revity)            term1 = su2_mul(U_mu, U_nu_x_mu)            term2 = su2_mul(U_mu_x_nu, U_nu)# This needs proper conjugation in full code# ... Assuming your standard plaquette function exists ...
# Placeholder for exact local defect calculation:            defect = torch.rand(U.shape[:-2], device=U.device)# Replace with real calc()Untitled129.ipynb - Colab https://colab.research.google.com/drive/1cUg1gigxYotkoocV3Pd2tjC-...
2 of 41 12/21/2025, 9:45 PM
```
