# Pass 2 — Numerics Run Table (extracted from project artifacts)

This table is *evidence bookkeeping*: what each run computed, what it can certify, and what it cannot.

## 127.pdf — Massive Maxwell inverse decay / DG exponent calibration

- Date: 2025-12-21

- Status: **PASS (bound check; ratio<<1)**

- Computed: Computed C0(Δ1) (row-sum bound) for 4D torus L∈{64,96,128}; derived η_DG(C0); checked worst-case bound ratio at dist=0 (max_ratio_dist0).

- Key results (full row table):

```text
 idx   L backend  m2         C0  eta_DG_C0  max_ratio_dist0  kappa_expected
   0  64    cuda 0.1  87.298902   0.033843         0.130643        0.314925
   1  64    cuda 0.2  87.298902   0.047860         0.136024        0.443568
   2  64    cuda 0.3  87.298902   0.058613         0.141185        0.541097
   3  96    cuda 0.1 103.673226   0.031056         0.130643        0.314925
   4  96    cuda 0.2 103.673226   0.043918         0.136024        0.443568
   5  96    cuda 0.3 103.673226   0.053787         0.141185        0.541097
   6 128     cpu 0.1 116.282985   0.029324         0.130643        0.314925
   7 128     cpu 0.2 116.282985   0.041469         0.136024        0.443568
   8 128     cpu 0.3 116.282985   0.050787         0.141185        0.541097
```
- Summary by L:

  - L=64 (cuda): C0=87.298902, η_DG(C0)∈[0.033843,0.058613], max_ratio_dist0∈[0.130643,0.141185]
  - L=96 (cuda): C0=103.673226, η_DG(C0)∈[0.031056,0.053787], max_ratio_dist0∈[0.130643,0.141185]
  - L=128 (cpu): C0=116.282985, η_DG(C0)∈[0.029324,0.050787], max_ratio_dist0∈[0.130643,0.141185]

Interpretation: `max_ratio_dist0 < 1` indicates the tested exponential bound is satisfied with slack at the hardest distance bucket (dist=0).

- Proof-pack linkage:

  - 006_Proposition_9_X_Davies_decay_with_C_0_in_place_of_D_E.md
  - 005_Definition_row_sum_constants_for_Delta_1.md
  - 008_Corollary_9_X_Davies_decay_with_C_partial.md (indirect, constants pathway)
  - ### 9.1 Abstract finite-range inverse decay lemma via Combes–Thomas conjugation.txt (context)


## 12-21-25 SIM.txt — Lyapunov drift inequality + correlations + beta scan (SU(2) Wilson gradient)

- Date: 2025-12-21

- Status: **MIXED (holdout fit needed 5σ margin to eliminate violations; beta scan shows λ>0 increasing with β)**

- Computed: Two things: (i) one-sided drift fit LV + k·SE ≤ -λ V + b with fit/holdout split; (ii) full-physics beta scan at L=12 estimating drift slope λ(β) and ceiling b(β).

- Drift fit + holdout (reported at k=5σ line):

```text
 margin  lam       b  viol  tot  pct  worst_diff
    0.0  0.0 12.0053   125 1024 12.2    0.012877
    2.0  0.0 12.0105    98 1024  9.6    0.007682
    5.0  0.0 12.0183     0 1024  0.0   -0.000155
```
- Full-physics beta scan (L=12, K=512):

```text
 beta    slope  lambda_       b
  2.0 -25.0206  25.0206 16.4690
  4.0 -38.3390  38.3390 18.0662
  6.0 -51.0220  51.0220 19.5769
  8.0 -61.8271  61.8271 21.2106
 10.0 -73.5213  73.5213 22.8461
```
- Correlation excerpt: printed 9×9 corr matrix; strongest entries include corr(Vbar,Bavg)≈-0.871, corr(Bavg,lap)≈-0.939, corr(lap,||gV||)≈0.988, corr(||gS||,||gV||)≈-0.673, corr(||gV||,alignment)≈0.73


- Proof-pack linkage:

  - ## 7. Lyapunov drift and uniform-in-volume functional inequalities.txt (numeric evidence for drift-shape/monotonicity)
  - ## 6.1 Bochner Γ_2 identity with drift and the Bakry–Émery curvature matrix.txt (uses LV structure)
  - APPENDIX_I.md (targets the missing coercivity; these runs probe it)
- Cautions:

  - The holdout-fit section reports λ=0 (after one-sided fit), while the beta scan reports large positive λ(β). This is a definition/pipeline mismatch until you enforce identical definitions of (V,LV,SE) and identical sampling.


## 12-21-25 GEMINI CODE.txt — Residual diagnostics for a fitted 'lap law' (likely lap vs proxy) + stability threshold check

- Date: 2025-12-21

- Status: **DIAGNOSTIC (some checks fail; fit residuals are small but model being fit is not uniquely identified from this file alone)**

- Computed: Printed residual stats (max|res|, mean, rms) for L=8,12,16; also printed a FAIL message for a strict threshold test ('domain too noisy').

- Residual summary (as printed):

```text
L= 8 : max|res|=1.9225e-02  mean=-1.2991e-04  rms=4.2384e-03
L=12 : max|res|=8.3439e-03  mean=-2.8577e-04  rms=1.9985e-03
L=16 : max|res|=5.1037e-03  mean=-3.1734e-04  rms=1.1238e-03
```
- Threshold check: RESULT: FAIL. The domain is still too noisy at this threshold.


- Proof-pack linkage:

  - None directly (needs explicit link: which lemma's hypothesis is being numerically tested?).


## 128.pdf — Interacting φ^4 Langevin decay extraction (sandbox)

- Date: 2025-12-21

- Status: **FAIL (OOM / incomplete)**

- Computed: Attempted to simulate φ^4, compute correlation decay, fit η and effective mass plateau.

- Notes:

  - observed: OutOfMemoryError during run; no stable output table captured.

- Proof-pack linkage:

  - None (sandbox)


## 129.pdf — Local anatomy / stability audit (SU(2) local stiffness map)

- Date: 2025-12-21

- Status: **UNTRUSTED (placeholder contamination)**

- Computed: Intended: local energy density proxy + local stiffness ratio map; drift-crossing audit.

- Notes:

  - printed: [PASSED] GLOBALLY STABLE (No crossing found). Drift negative for all tested energies.
  - red_flag: File contains an explicit '# Placeholder for exact local defect calculation' (random defect).

- Proof-pack linkage:

  - None (must redo without placeholders)


## 130.pdf — Bulk data generation for drift fit (NPZ writer) on L4 / A100

- Date: 2025-12-21

- Status: **INCOMPLETE (no saved output observed here)**

- Computed: Script to generate arrays Vbar,Bavg,lap and per-beta LV,gip with Monte Carlo finite differences; saves to NPZ.

- Notes:

  - observed: Progress prints up to ~1856/2048 configs; no final saved path captured in extracted text.

- Proof-pack linkage:

  - Potentially supports Lyapunov drift numerics once NPZ confirmed.


## RUN 124.pdf — Projected Hessian λ_min diagnostic + 2× blocking harness

- Date: 2025-12-20

- Status: **INCOMPLETE (no numeric output in artifact text)**

- Computed: Code to compute λ_min_phys(U) via Lanczos on a gauge/Hodge-projected Hessian; defines φ_proxy=max(0,κ*−λ_min).

- Notes:

  - observed: Only code + symmetry-check prints visible; no actual λ_min sequence recorded in extracted pages.

- Proof-pack linkage:

  - Targets APPENDIX_I.md obstruction proxy, but needs actual outputs.


## RUN 126.pdf — A100 SU(2) stress test: counterexample hunt + SGLD mode

- Date: 2025-12-20

- Status: **ABORTED**

- Computed: Two modes: hunt for configs with large Bavg & alignment & small force_norm; or manifold SGLD sampling.

- Notes:

  - observed: Run ended with KeyboardInterrupt during backward pass.

- Proof-pack linkage:

  - None (until completed)

