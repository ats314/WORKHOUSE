#!/usr/bin/env python3

"""
pass3_drift_probe_su2.py

Single-file, runnable drift probe for SU(2) link fields on a 4D periodic lattice.
Aligned to §7 / Appendix I numerics:

- Smooth truncated plaquette defect z -> \tilde z
- D = sum_p \tilde z_p
- V = sum_p \tilde z_p^2
- Hutchinson/finite-difference estimators for:
    lap = Tr Hess(V)
    gip = <∇S, ∇V>
    LV  = lap - gip
  with standard errors from MC directions
- Canonical reporting: lambda_OLS and one-sided b(σ) ceilings + holdout violations.

This is diagnostic code: it does NOT prove the coercive pairing inequality.

Authoring notes:
- SU(2) elements stored as quaternions q=(a,b,c,d) with ||q||=1.
- ReTr(U)/2 = a.
- exp(v) maps v in R^3 (Lie algebra coords) to quaternion.

Defaults are chosen to be small and safe; scale up intentionally on an A100.

"""
import argparse
import math
import time
from dataclasses import dataclass

import numpy as np
import torch


# ---------------------------
# SU(2) quaternion ops
# ---------------------------
def su2_normalize(q: torch.Tensor) -> torch.Tensor:
    return q / q.norm(dim=-1, keepdim=True).clamp_min(1e-12)

def su2_mul(q1: torch.Tensor, q2: torch.Tensor) -> torch.Tensor:
    a1, b1, c1, d1 = q1.unbind(-1)
    a2, b2, c2, d2 = q2.unbind(-1)
    return torch.stack([
        a1*a2 - b1*b2 - c1*c2 - d1*d2,
        a1*b2 + b1*a2 + c1*d2 - d1*c2,
        a1*c2 - b1*d2 + c1*a2 + d1*b2,
        a1*d2 + b1*c2 - c1*b2 + d1*a2,
    ], dim=-1)

def su2_conj(q: torch.Tensor) -> torch.Tensor:
    a, b, c, d = q.unbind(-1)
    return torch.stack([a, -b, -c, -d], dim=-1)

def su2_exp(v: torch.Tensor) -> torch.Tensor:
    # v: (...,3) interpreted as theta * n, map to (cos theta, n sin theta)
    theta = v.norm(dim=-1, keepdim=True)
    a = torch.cos(theta)
    s_over_theta = torch.where(theta > 1e-12, torch.sin(theta) / theta, 1.0 - theta*theta/6.0)
    return torch.cat([a, v * s_over_theta], dim=-1)


# ---------------------------
# Smooth truncation: identity below z0, flat at z0 above z1
# ---------------------------
def smooth_truncate(z: torch.Tensor, z0: float, z1: float) -> torch.Tensor:
    if not (0.0 < z0 < z1):
        raise ValueError("Need 0<z0<z1 for truncation window.")
    z0t = torch.as_tensor(z0, device=z.device, dtype=z.dtype)
    z1t = torch.as_tensor(z1, device=z.device, dtype=z.dtype)
    t = (z - z0t) / (z1t - z0t)
    t = torch.clamp(t, 0.0, 1.0)
    # smoothstep s(t)=t^2(3-2t): s(0)=0, s(1)=1
    s = t*t*(3.0 - 2.0*t)
    # blend: at t=0 -> z; at t=1 -> z0
    z_blend = z0t + (z - z0t) * (1.0 - s)
    return torch.where(z <= z0t, z, torch.where(z >= z1t, z0t, z_blend))


# ---------------------------
# Lattice and plaquettes
# ---------------------------
@dataclass
class Lattice:
    L: int
    d: int = 4

def shift(arr: torch.Tensor, axis: int, s: int) -> torch.Tensor:
    return torch.roll(arr, shifts=s, dims=axis)

def plaquette(U: torch.Tensor, mu: int, nu: int) -> torch.Tensor:
    # U: (B,L,L,L,L,d,4)
    # P(x;mu,nu)=U_mu(x) U_nu(x+mu) U_mu(x+nu)^{-1} U_nu(x)^{-1}
    U_mu = U[..., mu, :]
    U_nu = U[..., nu, :]
    U_nu_x_plus_mu = shift(U_nu, axis=mu, s=-1)
    U_mu_x_plus_nu = shift(U_mu, axis=nu, s=-1)
    return su2_mul(su2_mul(U_mu, U_nu_x_plus_mu), su2_mul(su2_conj(U_mu_x_plus_nu), su2_conj(U_nu)))

@torch.no_grad()
def defects_and_sums(U: torch.Tensor, beta: float, z0: float, z1: float, action_use_tilde: bool):
    # returns: S, D, V, Bavg (mean defect), plus per-config counts
    B, L = U.shape[0], U.shape[1]
    d = U.shape[-2]
    defect_sum = torch.zeros((B,), device=U.device, dtype=U.dtype)
    tdef_sum = torch.zeros((B,), device=U.device, dtype=U.dtype)
    tdef2_sum = torch.zeros((B,), device=U.device, dtype=U.dtype)
    count = 0
    for mu in range(d):
        for nu in range(mu+1, d):
            P = plaquette(U, mu, nu)
            z = 1.0 - P[..., 0]  # ReTr/2 = a component
            z = torch.clamp(z, min=0.0)  # numerical guard
            defect_sum += z.mean(dim=(1,2,3,4)) * (L**d)  # sum over sites for this (mu,nu)
            tz = smooth_truncate(z, z0=z0, z1=z1)
            tdef_sum += tz.mean(dim=(1,2,3,4)) * (L**d)
            tdef2_sum += (tz*tz).mean(dim=(1,2,3,4)) * (L**d)
            count += 1
    # total plaquettes = count * L^d
    Bavg = (defect_sum / (count * (L**d))).detach()
    if action_use_tilde:
        S = beta * tdef_sum
    else:
        S = beta * defect_sum
    D = tdef_sum
    V = tdef2_sum
    return S, D, V, Bavg, count * (L**d)


# ---------------------------
# LV estimator (Hutchinson + finite differences)
# ---------------------------
@torch.no_grad()
def estimate_LV(U: torch.Tensor, beta: float, eps_fd: float, mc: int, mc_chunk: int,
                z0: float, z1: float, action_use_tilde: bool, seed: int,
                xi_dtype=torch.float32):
    """
    Returns dict with per-config estimates:
      V, D, Bavg, lap, gip, LV, and standard errors LV_se, lap_se, gip_se.
    """
    assert mc >= 2
    B, L = U.shape[0], U.shape[1]
    d = U.shape[-2]
    device = U.device
    dtype = U.dtype
    eps = float(eps_fd)

    S0, D0, V0, Bavg0, Pcount = defects_and_sums(U, beta=beta, z0=z0, z1=z1, action_use_tilde=action_use_tilde)
    V0 = V0.detach()

    def zvec():
        return torch.zeros((B,), device=device, dtype=dtype)

    sum_lap, sum_lap2 = zvec(), zvec()
    sum_gip, sum_gip2 = zvec(), zvec()
    sum_lv,  sum_lv2  = zvec(), zvec()

    g = torch.Generator(device=device)
    g.manual_seed(int(seed))

    processed = 0
    while processed < mc:
        c = int(min(mc_chunk, mc - processed))
        # Xi: (B,c,L,L,L,L,d,3)
        Xi = torch.randn((B, c, L, L, L, L, d, 3), device=device, dtype=xi_dtype, generator=g)
        exp_p = su2_exp(eps * Xi)
        U_base = U.unsqueeze(1)
        U_p = su2_mul(U_base, exp_p).to(dtype)
        S_p, D_p, V_p, _, _ = defects_and_sums(U_p.flatten(0,1), beta=beta, z0=z0, z1=z1, action_use_tilde=action_use_tilde)
        S_p = S_p.view(B, c)
        V_p = V_p.view(B, c)
        # exp(-eps Xi) = conj(exp(+eps Xi))
        exp_m = su2_conj(exp_p)
        U_m = su2_mul(U_base, exp_m).to(dtype)
        S_m, D_m, V_m, _, _ = defects_and_sums(U_m.flatten(0,1), beta=beta, z0=z0, z1=z1, action_use_tilde=action_use_tilde)
        S_m = S_m.view(B, c)
        V_m = V_m.view(B, c)

        V0c = V0.view(B, 1)
        lap = (V_p + V_m - 2.0 * V0c) / (eps * eps)
        dS  = (S_p - S_m) / (2.0 * eps)
        dV  = (V_p - V_m) / (2.0 * eps)
        gip = dS * dV
        lv  = lap - gip

        def acc(sum_, sum2_, x):
            sum_  += x.sum(dim=1)
            sum2_ += (x*x).sum(dim=1)
            return sum_, sum2_

        sum_lap, sum_lap2 = acc(sum_lap, sum_lap2, lap)
        sum_gip, sum_gip2 = acc(sum_gip, sum_gip2, gip)
        sum_lv,  sum_lv2  = acc(sum_lv,  sum_lv2,  lv)

        processed += c
        del Xi, exp_p, exp_m, U_p, U_m, S_p, S_m, V_p, V_m, lap, dS, dV, gip, lv

    mc_f = float(mc)
    lap_mean = sum_lap / mc_f
    gip_mean = sum_gip / mc_f
    lv_mean  = sum_lv  / mc_f

    # unbiased variance estimate
    def se_from(sum_, sum2_):
        mean = sum_ / mc_f
        var = (sum2_ / mc_f) - mean*mean
        var = torch.clamp(var, min=0.0)
        se = torch.sqrt(var / mc_f)
        return mean, se

    lap_mean, lap_se = se_from(sum_lap, sum_lap2)
    gip_mean, gip_se = se_from(sum_gip, sum_gip2)
    lv_mean,  lv_se  = se_from(sum_lv,  sum_lv2)

    return dict(
        V=V0.detach(),
        D=D0.detach(),
        Bavg=Bavg0.detach(),
        lap=lap_mean.detach(),
        lap_se=lap_se.detach(),
        gip=gip_mean.detach(),
        gip_se=gip_se.detach(),
        LV=lv_mean.detach(),
        LV_se=lv_se.detach(),
        P_hat=(0.5*gip_mean).detach(),  # Appendix I pairing proxy if V = sum \tilde z^2
        P_se=(0.5*gip_se).detach(),
        plaquettes=int(Pcount),
    )


# ---------------------------
# Fit + holdout reports
# ---------------------------
def fit_lambda_ols(V: torch.Tensor, LV: torch.Tensor):
    # LV ≈ a V + b, with a ≈ -lambda
    Vc = V.detach().double().cpu().numpy()
    LVc = LV.detach().double().cpu().numpy()
    A = np.vstack([Vc, np.ones_like(Vc)]).T
    coef, *_ = np.linalg.lstsq(A, LVc, rcond=None)
    a, b = float(coef[0]), float(coef[1])
    lam = max(0.0, -a)
    return lam, b

@torch.no_grad()
def ceiling_b(V, LV, SE, lam, sigma):
    # b(sigma)=max (LV + lam V + sigma SE)
    return float((LV + float(lam)*V + float(sigma)*SE).max().item())

@torch.no_grad()
def holdout_stats(V, LV, SE, lam, b, sigma):
    diff = (LV + float(sigma)*SE) + float(lam)*V - float(b)
    viol = diff > 0.0
    return dict(
        violations=int(viol.sum().item()),
        total=int(viol.numel()),
        worst=float(diff.max().item()),
    )


# ---------------------------
# Sampling families (diagnostic)
# ---------------------------
@torch.no_grad()
def sample_haar(B, L, d, device, dtype, seed):
    g = torch.Generator(device=device)
    g.manual_seed(int(seed))
    q = torch.randn((B, L, L, L, L, d, 4), device=device, dtype=dtype, generator=g)
    return su2_normalize(q)

@torch.no_grad()
def sample_sigma_near_identity(B, L, d, device, dtype, seed, sigma):
    g = torch.Generator(device=device)
    g.manual_seed(int(seed))
    Xi = torch.randn((B, L, L, L, L, d, 3), device=device, dtype=dtype, generator=g)
    U = su2_exp(float(sigma) * Xi)
    return su2_normalize(U)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--L", type=int, default=8)
    ap.add_argument("--K_total", type=int, default=256)
    ap.add_argument("--K_fit", type=int, default=128)
    ap.add_argument("--beta", type=float, default=6.0)
    ap.add_argument("--eps_fd", type=float, default=5e-3)
    ap.add_argument("--mc", type=int, default=64)
    ap.add_argument("--mc_chunk", type=int, default=8)
    ap.add_argument("--z0", type=float, default=0.05)
    ap.add_argument("--z1", type=float, default=0.08)
    ap.add_argument("--action_use_tilde", action="store_true")
    ap.add_argument("--frac_haar", type=float, default=0.5)
    ap.add_argument("--sigma_list", type=str, default="0.02,0.04,0.06")
    ap.add_argument("--dtype", type=str, default="float64", choices=["float32","float64"])
    ap.add_argument("--device", type=str, default="cuda")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    if args.device == "cuda" and not torch.cuda.is_available():
        args.device = "cpu"
    device = torch.device(args.device)
    dtype = torch.float64 if args.dtype == "float64" else torch.float32

    L = int(args.L)
    d = 4
    K_total = int(args.K_total)
    K_fit = int(args.K_fit)
    if not (1 <= K_fit < K_total):
        raise ValueError("Need 1 <= K_fit < K_total.")

    # Build a diagnostic dataset (NOT a Gibbs sampler):
    # mixture of Haar and small sigma perturbations near identity
    frac_haar = float(args.frac_haar)
    K_haar = int(round(frac_haar * K_total))
    K_non = K_total - K_haar
    sigma_list = [float(x) for x in args.sigma_list.split(",") if x.strip()]
    if len(sigma_list) < 1:
        raise ValueError("sigma_list must be non-empty.")
    counts = [K_non // len(sigma_list)] * len(sigma_list)
    for i in range(K_non - sum(counts)):
        counts[i] += 1

    t0 = time.perf_counter()
    blocks = []
    labels = []
    # non-haar blocks
    base_seed = int(args.seed)
    sseed = base_seed + 1000
    for sigma, k in zip(sigma_list, counts):
        if k <= 0:
            continue
        U = sample_sigma_near_identity(k, L, d, device=device, dtype=dtype, seed=sseed, sigma=sigma)
        blocks.append(U)
        labels += [("sigma", float(sigma))] * k
        sseed += 1
    # haar block
    if K_haar > 0:
        U = sample_haar(K_haar, L, d, device=device, dtype=dtype, seed=base_seed + 2000)
        blocks.append(U)
        labels += [("haar", 0.0)] * K_haar
    U_all = torch.cat(blocks, dim=0)
    # shuffle
    g = torch.Generator(device=device)
    g.manual_seed(base_seed + 3000)
    perm = torch.randperm(U_all.shape[0], device=device, generator=g)
    U_all = U_all[perm]
    labels = [labels[i] for i in perm.detach().cpu().tolist()]

    if device.type == "cuda":
        torch.cuda.synchronize()
    print(f"[dataset] U.shape={tuple(U_all.shape)} built in {time.perf_counter()-t0:.2f}s on {device}", flush=True)

    # Estimate drift objects
    t1 = time.perf_counter()
    stats = estimate_LV(
        U_all, beta=float(args.beta), eps_fd=float(args.eps_fd), mc=int(args.mc), mc_chunk=int(args.mc_chunk),
        z0=float(args.z0), z1=float(args.z1), action_use_tilde=bool(args.action_use_tilde),
        seed=base_seed + 4000, xi_dtype=torch.float32,
    )
    if device.type == "cuda":
        torch.cuda.synchronize()
    print(f"[drift] computed in {time.perf_counter()-t1:.2f}s", flush=True)

    V = stats["V"]
    LV = stats["LV"]
    SE = stats["LV_se"]
    Dv = stats["D"]
    Ph = stats["P_hat"]
    print(f"[ranges] V:[{float(V.min()):.6g},{float(V.max()):.6g}]  LV:[{float(LV.min()):.6g},{float(LV.max()):.6g}]  SE:[{float(SE.min()):.3g},{float(SE.max()):.3g}]", flush=True)
    print(f"[ranges] D:[{float(Dv.min()):.6g},{float(Dv.max()):.6g}]  P_hat:[{float(Ph.min()):.6g},{float(Ph.max()):.6g}]  plaquettes={stats['plaquettes']}", flush=True)

    # Fit/holdout split
    V_fit, LV_fit, SE_fit = V[:K_fit], LV[:K_fit], SE[:K_fit]
    V_te,  LV_te,  SE_te  = V[K_fit:], LV[K_fit:], SE[K_fit:]

    lam_ols, b_ols = fit_lambda_ols(V_fit, LV_fit)
    print("\n============================", flush=True)
    print("CANONICAL DRIFT REPORT", flush=True)
    print("============================", flush=True)
    print(f"beta={args.beta}  L={L}  K_total={K_total}  K_fit={K_fit}  eps_fd={args.eps_fd}  mc={args.mc}  z0={args.z0}  z1={args.z1}  action_use_tilde={args.action_use_tilde}", flush=True)
    print(f"lambda_OLS = {lam_ols:.6g}   (b_OLS intercept = {b_ols:.6g})", flush=True)

    for sigma in (0.0, 2.0, 5.0):
        b_sig = ceiling_b(V_fit, LV_fit, SE_fit, lam=lam_ols, sigma=sigma)
        rep = holdout_stats(V_te, LV_te, SE_te, lam=lam_ols, b=b_sig, sigma=sigma)
        print(f"[sigma={sigma:>3.1f}] b={b_sig:.6g}  holdout_viol={rep['violations']}/{rep['total']}  worst_diff={rep['worst']:.6g}", flush=True)

    # Optional: quick diagnostic for the pairing proxy vs D (not a proof)
    # Fit P_hat ≈ c * D + C, report slope c and worst residual on TEST.
    D_fit = Dv[:K_fit].double().cpu().numpy()
    P_fit = Ph[:K_fit].double().cpu().numpy()
    A = np.vstack([D_fit, np.ones_like(D_fit)]).T
    coef, *_ = np.linalg.lstsq(A, P_fit, rcond=None)
    c_pair, C_pair = float(coef[0]), float(coef[1])
    D_te = Dv[K_fit:].double().cpu().numpy()
    P_te = Ph[K_fit:].double().cpu().numpy()
    resid = P_te - (c_pair * D_te + C_pair)
    print("\n[pairing proxy] least-squares fit on FIT:  P_hat ≈ c*D + C", flush=True)
    print(f"  c={c_pair:.6g}  C={C_pair:.6g}   (diagnostic only)", flush=True)
    print(f"  TEST worst_resid (P - (cD+C)) = {float(resid.min()):.6g}   (negative means below fitted line)", flush=True)


if __name__ == "__main__":
    main()
