# Appendix D. Boundary compression and the one-step transfer kernel

This appendix records an optional “Euclidean → Hamiltonian” bridge that is complementary to the main route in §11.3.

The main text uses OS reconstruction + an *a priori* Euclidean time–decay estimate to conclude a Hamiltonian gap.  A different (often useful) perspective is to **compress** the OS inner product to a single time slice and identify the one–time–step evolution with an explicit **Markov kernel** on the slice configuration space.  In that representation:

- reflection positivity becomes positivity/self-adjointness of the kernel,
- the one–step *dissipation* is an explicit Dirichlet form on the boundary,
- and a per–step spectral gap translates directly into a Hamiltonian mass scale.

The constructions below are standard in lattice gauge theory (transfer matrix / Osterwalder–Seiler boundary compression).  We spell them out in a form that is compatible with our notation.

Throughout, we work at **fixed lattice spacing** \(a>0\) and fixed inverse coupling \(\beta\). The lattice is the finite periodic 4–torus \(\Lambda\) from §2.1 with **even** time extent \(L_0\in 2\mathbb N\). We choose the time direction \(\mu=0\) and write a site as \(x=(t,\mathbf x)\) with \(t\in\mathbb Z/L_0\mathbb Z\) and \(\mathbf x\in\Lambda_s\) (the spatial 3–torus).

---

## D.1 Time reflection and the time–slice configuration space

### D.1.1 Reflection plane and the positive half

Let \(\Theta\) be the reflection across the hyperplane between time slices \(t=0\) and \(t=1\). Concretely, on time coordinates we take
\[
\Theta(t)=1-t\quad (\mathrm{mod}\ L_0),
\]
with \(\Theta\) acting trivially on spatial coordinates. As in §4.1–§4.2, \(\Theta\) induces an involution on oriented links and thus on configurations \(U\in M_\Lambda=G^{E(\Lambda)}\). We write \(\theta\) for the induced involution on observables:
\[
(\theta F)(U):=\overline{F(\Theta U)}.
\]

Define the **positive-time region** (relative to the plane between \(0\) and \(1\)) as
\[
\Lambda_+ := \{(t,\mathbf x): t\in\{1,2,\dots,L_0/2\}\},
\]
and similarly the negative-time region \(\Lambda_-:=\Theta\Lambda_+\). The **time–0 slice** (the “boundary”) is
\[
\Sigma := \{(0,\mathbf x): \mathbf x\in\Lambda_s\}.
\]

### D.1.2 Slice degrees of freedom

Let \(E_s\) denote the set of *spatial* oriented links contained in the slice \(t=0\):
\[
E_s := \{(x,i): x=(0,\mathbf x)\in\Sigma,\ i\in\{1,2,3\}\}.
\]
The corresponding **slice configuration space** is
\[
\mathcal S := G^{E_s}.
\]
We will write \(\sigma\in\mathcal S\) for a spatial link configuration on \(t=0\), and \(d\sigma\) for the product Haar measure on \(\mathcal S\).

Similarly, let \(E_0\) denote the set of **timelike** oriented links connecting slice \(t=0\) to slice \(t=1\):
\[
E_0 := \{(x,0): x=(0,\mathbf x)\in\Sigma\}.
\]
We write \(U_0\in G^{E_0}\) for the strip’s timelike-link configuration and \(dU_0\) for the product Haar measure on \(G^{E_0}\).

Finally, let \(\sigma'\in\mathcal S\) denote the spatial link configuration on slice \(t=1\) (identified with \(G^{E_s}\) by translation).

---

## D.2 Boundary compression of the Wilson weight

The transfer-kernel representation is easiest to see at the level of the **plaquette weight**.

Recall that the Wilson plaquette potential is
\[
\Phi_\beta(g)=\beta\Bigl(1-\tfrac1n\Re\mathrm{Tr}(\rho(g))\Bigr),
\qquad g\in G,
\]
and the plaquette weight is
\[
W_\beta(g):=e^{-\Phi_\beta(g)}.
\]

### D.2.1 Spatial slice action and strip action

Let \(P_s\) be the set of **spatial plaquettes** lying in the slice \(t=0\) (plaquettes with both directions in \(\{1,2,3\}\)). For \(\sigma\in\mathcal S\), define the spatial-slice Wilson action
\[
S_{\mathrm{sp}}(\sigma) := \sum_{p\in P_s} \Phi_\beta\bigl(U_p(\sigma)\bigr).
\]

Let \(P_{0}\) be the set of **timelike plaquettes in the strip** between slices \(0\) and \(1\), i.e. plaquettes with one direction \(\mu=0\) and one spatial direction \(i\in\{1,2,3\}\), based at time \(t=0\). Each such plaquette involves:
- one spatial link in slice \(t=0\) (from \(\sigma\)),
- one spatial link in slice \(t=1\) (from \(\sigma'\)),
- and two timelike links in \(E_0\) (from \(U_0\), with inverses depending on orientation).

Define the **strip action**
\[
S_{\mathrm{strip}}(\sigma,\sigma',U_0)
:= \sum_{p\in P_0} \Phi_\beta\bigl(U_p(\sigma,\sigma',U_0)\bigr)
\; +\; \tfrac12 S_{\mathrm{sp}}(\sigma)\; +\; \tfrac12 S_{\mathrm{sp}}(\sigma').
\tag{D.1}
\]
The half-weights on the spatial slice terms are the bookkeeping device that makes strip concatenation exact: when you glue successive strips in time, every spatial plaquette at an interior slice is counted twice at half-weight, hence once in total.

### D.2.2 The one-step strip weight and kernel

Define the **strip weight**
\[
\mathcal W(\sigma,\sigma',U_0) := \exp\bigl(-S_{\mathrm{strip}}(\sigma,\sigma',U_0)\bigr).
\tag{D.2}
\]
Integrating out the timelike links produces the **one-step kernel**
\[
\mathcal K(\sigma,\sigma')
:= \int_{G^{E_0}} \mathcal W(\sigma,\sigma',U_0)\,dU_0.
\tag{D.3}
\]

#### Lemma D.1 (symmetry and positivity of the kernel).
For all \(\sigma,\sigma'\in\mathcal S\), \(\mathcal K(\sigma,\sigma')\ge 0\), and
\[
\mathcal K(\sigma,\sigma')=\mathcal K(\sigma',\sigma).
\tag{D.4}
\]

**Proof.** Nonnegativity is immediate from \(\mathcal W\ge 0\). Symmetry follows because \(S_{\mathrm{strip}}\) is symmetric under swapping \(\sigma\leftrightarrow \sigma'\): the set of timelike plaquettes in the strip is invariant under the half-turn that exchanges the two time slices, and the explicit half-weighting \(\frac12 S_{\mathrm{sp}}(\sigma)+\frac12 S_{\mathrm{sp}}(\sigma')\) is symmetric. Since the Haar measure \(dU_0\) is invariant, the integral (D.3) is symmetric. \(\square\)

---

## D.3 The boundary measure and the compressed transfer operator

### D.3.1 Boundary (slice) Gibbs measure

Define the **boundary measure** \(\nu\) on \(\mathcal S\) by
\[
\nu(d\sigma) := Z_{\mathrm{sp}}^{-1}\,e^{-S_{\mathrm{sp}}(\sigma)}\,d\sigma,
\qquad
Z_{\mathrm{sp}}:=\int_{\mathcal S} e^{-S_{\mathrm{sp}}(\sigma)}\,d\sigma.
\tag{D.5}
\]

### D.3.2 The one-step operator on \(L^2(\nu)\)

Define an integral operator \(K\) on \(L^2(\nu)\) by
\[
(Kf)(\sigma)
:= \frac{1}{e^{-S_{\mathrm{sp}}(\sigma)}}
\int_{\mathcal S} \mathcal K(\sigma,\sigma')\, f(\sigma')\,\nu(d\sigma')
= \int_{\mathcal S} k(\sigma,\sigma')\, f(\sigma')\,\nu(d\sigma'),
\tag{D.6}
\]
where the \(\nu\)-kernel \(k\) is
\[
k(\sigma,\sigma'):= \frac{\mathcal K(\sigma,\sigma')}{e^{-S_{\mathrm{sp}}(\sigma)}}.
\tag{D.7}
\]
The awkward-looking normalization is the standard “ground-state transform” that makes \(K\) self-adjoint with respect to \(\nu\).

#### Lemma D.2 (self-adjointness and Markov property).
The operator \(K\) is self-adjoint on \(L^2(\nu)\), satisfies \(0\preceq K\preceq I\), and preserves constants:
\[
K\mathbf 1 = \mathbf 1.
\tag{D.8}
\]

**Proof.** For \(f,g\in L^2(\nu)\), compute using the definitions:
\[
\langle f,Kg\rangle_{L^2(\nu)}
= \int_{\mathcal S}\overline{f(\sigma)}\,\frac{1}{e^{-S_{\mathrm{sp}}(\sigma)}}
\int_{\mathcal S}\mathcal K(\sigma,\sigma')g(\sigma')\,\nu(d\sigma')\,\nu(d\sigma).
\]
Inserting \(\nu(d\sigma)=Z_{\mathrm{sp}}^{-1}e^{-S_{\mathrm{sp}}(\sigma)}d\sigma\), the prefactor \(e^{+S_{\mathrm{sp}}(\sigma)}\) cancels, and we get
\[
\langle f,Kg\rangle_{L^2(\nu)}
= Z_{\mathrm{sp}}^{-1}\int_{\mathcal S}\int_{\mathcal S}
\overline{f(\sigma)}\,\mathcal K(\sigma,\sigma')\,g(\sigma')\,d\sigma\,d\sigma'.
\]
By the symmetry \(\mathcal K(\sigma,\sigma')=\mathcal K(\sigma',\sigma)\) (Lemma D.1), this expression is symmetric in \((f,g)\), i.e. \(\langle f,Kg\rangle=\langle Kf,g\rangle\), so \(K\) is self-adjoint.

Nonnegativity and the contraction bound \(K\preceq I\) are consequences of reflection positivity (see D.4 below) in the OS interpretation; in finite volume one can also verify that \(K\) is a Markov operator by direct strip-gluing: \(\mathcal K(\sigma,\sigma')\) is the unnormalized transition weight for the time-slice field, and the normalization in (D.6) ensures \(K\mathbf 1=\mathbf 1\). \(\square\)

*Remark.* The cleanest conceptual proof of \(0\preceq K\preceq I\) is to interpret \(K\) as the compressed OS transfer operator \(T\) (a positive contraction) under the boundary identification of D.4. That is the viewpoint we use below.

---

## D.4 Boundary compression of the OS inner product

We now explain how the OS inner product and the one-step time translation compress to \(L^2(\nu)\) with kernel \(K\).

### D.4.1 Positive-time observables and conditional expectation

Let \(\mathcal A_+\) be the positive-time algebra (bounded cylinder observables depending only on finitely many links in \(\Lambda_+\)). For \(F\in\mathcal A_+\), define its **boundary compression** \(JF\) as the conditional expectation given the time–0 spatial slice configuration:
\[
(JF)(\sigma)
:= \mathbb E_\mu\bigl[F\,\big|\,U\vert_{E_s}=\sigma\bigr],
\qquad \sigma\in\mathcal S.
\tag{D.9}
\]
Here \(\mu\) denotes the finite-volume Wilson Gibbs measure on \(M_\Lambda\). In finite volume, (D.9) is an honest finite-dimensional conditional expectation and produces a bounded \(JF\in L^\infty(\nu)\).

### D.4.2 Compression identity for the OS inner product

Recall the OS sesquilinear form on \(\mathcal A_+\):
\[
\langle F,G\rangle_{\mathrm{OS}} := \mu\big((\theta F)\,G\big).
\tag{D.10}
\]

#### Proposition D.3 (boundary compression of the OS form).
For \(F,G\in\mathcal A_+\),
\[
\mu\big((\theta F)\,G\big)
= \int_{\mathcal S} \overline{(JF)(\sigma)}\,(JG)(\sigma)\,\nu(d\sigma).
\tag{D.11}
\]

**Sketch of proof (finite volume).** Split the full configuration into three parts:
- negative half \(U_-\) (links in \(\Lambda_-\)),
- positive half \(U_+\) (links in \(\Lambda_+\)),
- boundary slice \(\sigma\) (spatial links in \(E_s\)).

Because the Wilson action is a sum of plaquette terms, and because the reflection plane lies between times \(0\) and \(1\), the action splits as
\[
S(U)= S_-(U_-,\sigma) + S_+(U_+,\sigma),
\tag{D.12}
\]
where \(S_+\) depends only on the positive half plus the boundary slice, and similarly for \(S_-\). Moreover, reflection identifies \(S_-\) with \(S_+\) under \(\Theta\).

Write the Gibbs density as \(e^{-S}=e^{-S_-}e^{-S_+}\) and integrate first over \(U_-\) using reflection to recognize \(\theta F\) as a function of \(U_-\) mirrored from \(U_+\). This yields a factorization
\[
\mu\big((\theta F)G\big)
= \int_{\mathcal S} \overline{JF(\sigma)}\,JG(\sigma)\,\nu(d\sigma),
\]
with \(JF, JG\) the conditional expectations given \(\sigma\). \(\square\)

### D.4.3 Compression of time translation: the one-step kernel

Let \(\tau\) denote one-step time translation (\(t\mapsto t+1\)). Define \(\tau^n G\) by pullback.

#### Proposition D.4 (kernel representation of time translation).
For \(F,G\in\mathcal A_+\) and \(n\ge 0\),
\[
\mu\big((\theta F)\,\tau^n G\big)
= \langle JF,\, K^n (JG)\rangle_{L^2(\nu)}.
\tag{D.13}
\]

**Sketch of proof.** Glue \(n\) strips of the form in §D.2 between successive time slices. The strip gluing is exact because of the half-weighting in (D.1). After integrating out the strip timelike links, the resulting weight is the product kernel \(\mathcal K\) composed \(n\) times; after the ground-state normalization in (D.6) this becomes \(K^n\) on \(L^2(\nu)\). \(\square\)

*Interpretation.* Under the OS reconstruction theorem, \(K\) is precisely the **compressed transfer operator** \(T\) acting on the OS Hilbert space, represented on the boundary.

---

## D.5 One-step dissipation and the boundary Dirichlet form

The kernel picture makes an important identity transparent: the quadratic form \(\langle f,(I-K)f\rangle\) is the Dirichlet form of the Markov chain on \(\mathcal S\) with transition operator \(K\).

### D.5.1 Dirichlet form of the kernel

Assume \(K\) is a Markov self-adjoint operator on \(L^2(\nu)\). Define its Dirichlet form
\[
\mathcal E_K(f,g):=\langle f,(I-K)g\rangle_{L^2(\nu)},
\qquad \mathcal E_K(f):=\mathcal E_K(f,f).
\tag{D.14}
\]

#### Lemma D.5 (kernel representation).
If \(K\) admits a symmetric integral kernel with respect to \(\nu\), then
\[
\mathcal E_K(f)
= \frac12\int_{\mathcal S}\int_{\mathcal S} \big|f(\sigma)-f(\sigma')\big|^2\,\mathsf K(d\sigma,d\sigma'),
\tag{D.15}
\]
where \(\mathsf K(d\sigma,d\sigma'):=k(\sigma,\sigma')\,\nu(d\sigma)\,\nu(d\sigma')\) is the symmetric measure on \(\mathcal S\times\mathcal S\).

**Proof.** Expand \(|f-f'|^2=f^2+(f')^2-2ff'\), integrate against the symmetric measure, and use \(K\mathbf 1=\mathbf 1\) to identify the diagonal terms with \(\|f\|^2\). \(\square\)

### D.5.2 Dissipation identity on the OS space (optional)

Let \(\mathcal H_{\mathrm{OS}}\) be the OS Hilbert space and \(T\) the one-step transfer operator (a positive contraction) with \(T=e^{-aH}\). Under the boundary representation above, \(T\) corresponds to \(K\) acting on \(L^2(\nu)\) after quotienting by null vectors.

For \(F\in\mathcal A_+\) let \([F]\in\mathcal H_{\mathrm{OS}}\) be its OS class and let \(f:=JF\in L^2(\nu)\) be its compression.

Then, on the physical subspace where the identification is valid,
\[
\langle [F],(I-T)[F]\rangle_{\mathrm{OS}}
= \langle f,(I-K)f\rangle_{L^2(\nu)}
= \mathcal E_K(f).
\tag{D.16}
\]
This is the one-step “dissipation = boundary Dirichlet form” identity.

---

## D.6 From the per-step spectral gap to an OS mass scale

Because \(K\) is a self-adjoint contraction on a finite-dimensional Hilbert space (in finite volume), its spectrum lies in \([-1,1]\). Positivity improves this to \([0,1]\).

Define the **discrete spectral gap** of \(K\) by
\[
\mathrm{gap}_{\mathrm{disc}}(K)
:= 1-\lambda_1(K),
\tag{D.17}
\]
where \(\lambda_1(K)\) is the largest eigenvalue of \(K\) below \(1\) (on the orthocomplement of constants).

If OS reconstruction yields \(T=e^{-aH}\) and identifies \(T\) with \(K\) (on the physical subspace), then
\[
\lambda_1(T)=\lambda_1(K)
\qquad\Longrightarrow\qquad
\inf\big(\sigma(H)\setminus\{0\}\big)
= -\frac1a\log\lambda_1(K).
\tag{D.18}
\]
In particular, for small gaps one may use \(-\log(1-x)\sim x\) to read off a mass scale of order \(\mathrm{gap}_{\mathrm{disc}}(K)/a\).

This route is logically independent of the “time-decay ⇒ spectral gap” argument in §11.3: it is an alternative way to connect Euclidean information to a Hamiltonian gap by controlling the one-step operator.

---

## D.7 Interface summary

What this appendix provides:

1. A **boundary compression** map \(J:\mathcal A_+\to L^2(\nu)\) (conditional expectation onto a time slice).
2. A concrete **one-step strip kernel** \(\mathcal K(\sigma,\sigma')\) and the induced boundary operator \(K\) on \(L^2(\nu)\).
3. The compressed correlation identity
\(\mu((\theta F)\,\tau^n G)=\langle JF, K^n JG\rangle\).
4. The boundary **Dirichlet-form identity** \(\langle f,(I-K)f\rangle=\mathcal E_K(f)\).
5. The optional spectral translation \(m(a)=-\frac1a\log\lambda_1(K)\) under OS identification.

In the main text we do not rely on this kernel route, but it can serve as an alternative “bridge” if one can directly estimate \(\mathrm{gap}_{\mathrm{disc}}(K)\) (for instance via one-step functional inequalities on the boundary chain).
