# Appendix B. Reflection positivity for Wilson lattice gauge theory

This appendix supplies a self-contained proof of **reflection positivity** for the Wilson lattice gauge theory measure (compact gauge group, Wilson plaquette action) via the **Osterwalder–Seiler sum-of-squares (SOS) factorization** mechanism.

The proof is written at a level compatible with the unified outline:

- §4.1–§4.2 (reflection plane, involution, reflection positivity),
- Part 11 (thermodynamic limit and OS reconstruction as an external theorem).

We treat OS reconstruction separately (Appendix C / §11.3); here we focus on the Euclidean reflection-positivity input.

---

## B.1 Reflection geometry and the OS form on a finite periodic lattice

### B.1.1 The lattice and the reflection

Let
\[
\Lambda \;=\; (\mathbb Z/L_0\mathbb Z)\times(\mathbb Z/L_1\mathbb Z)\times(\mathbb Z/L_2\mathbb Z)\times(\mathbb Z/L_3\mathbb Z)
\]
be the periodic lattice (a discrete four-torus), and assume **the time length \(L_0\) is even** so that the reflection plane below is compatible with periodicity.

We fix the Euclidean time direction \(\mu=0\). Write a vertex as \(x=(x_0,x_1,x_2,x_3)\).

Define the **link-reflection** on vertices by
\[
r(x) := (-x_0+1,\;x_1,\;x_2,\;x_3)\quad \text{mod }(L_0,L_1,L_2,L_3).
\tag{B.1}
\]
Geometrically, \(r\) is reflection across the hyperplane \(x_0=\tfrac12\).

Let \(\widetilde E(\Lambda)\) denote the set of **oriented** nearest-neighbor edges (so each unoriented edge appears in both orientations). For \(b=(x\to y)\in\widetilde E(\Lambda)\) define the reflected oriented edge
\[
\Theta b := (r(y)\to r(x)).
\tag{B.2}
\]
Then \(\Theta^2=\mathrm{id}\) on \(\widetilde E(\Lambda)\).

### B.1.2 Configurations, involution, positive-time algebra

Let \(G\) be a compact Lie group. A gauge field configuration is a map
\[
U:\widetilde E(\Lambda)\to G,\qquad U_{y\to x}=U_{x\to y}^{-1},
\]
equivalently an element of \(M_\Lambda=G^{E(\Lambda)}\) after choosing an orientation set \(E(\Lambda)\subset\widetilde E(\Lambda)\).

Define the **reflected configuration** \(\Theta U\) by
\[
(\Theta U)_b := U_{\Theta b}^{-1},
\qquad b\in\widetilde E(\Lambda).
\tag{B.3}
\]
This makes \(\Theta\) an involution on configuration space.

Let \(\mathcal A\) be the algebra of bounded cylinder observables on \(M_\Lambda\) (bounded functions depending on finitely many links). Define the antilinear involution
\[
(\theta F)(U) := \overline{F(\Theta U)}.
\tag{B.4}
\]
This is the standard OS involution.

Define the **positive-time half** (for the link-reflection at \(x_0=\tfrac12\)) by the vertex set
\[
\Lambda_+ := \{x\in\Lambda:\ x_0\in\{1,2,\dots,L_0/2\}\},
\qquad
\Lambda_- := r(\Lambda_+).
\tag{B.5}
\]
Let \(\widetilde E_+\) be the set of oriented links whose *midpoint* has time coordinate \(>1/2\); equivalently, links that lie entirely in the half-space \(x_0\ge 1\). Let \(\mathcal A_+\subset\mathcal A\) be the algebra of bounded cylinder functions depending only on links in \(\widetilde E_+\). Then \(\theta\mathcal A_+=\mathcal A_-\) depends only on links in \(\widetilde E_-:=\Theta(\widetilde E_+)\).

### B.1.3 Reflection positivity

Let \(\mu\) be a probability measure on \(M_\Lambda\). We say \(\mu\) is **reflection positive (RP)** with respect to \((\Theta,\mathcal A_+)\) if
\[
\mu\big((\theta F)\,F\big) \;\ge\; 0
\qquad \text{for all }F\in\mathcal A_+.
\tag{B.6}
\]
The corresponding OS sesquilinear form is
\[
\langle F,G\rangle_{\mathrm{OS}} := \mu\big((\theta F)\,G\big),
\qquad F,G\in\mathcal A_+.
\tag{B.7}
\]

Our goal in this appendix is to verify (B.6) for the Wilson lattice gauge theory measure.

---

## B.2 The Wilson measure and the key positivity kernel

### B.2.1 Wilson plaquette weight

Fix a faithful unitary representation \(\rho:G\to U(n)\). The Wilson plaquette potential is
\[
\Phi_\beta(g) := \beta\Bigl(1-\frac1n\Re\mathrm{Tr}(\rho(g))\Bigr),
\qquad g\in G,
\]
so the plaquette weight is
\[
e^{-\Phi_\beta(g)} = e^{-\beta}\,\exp\!\Bigl(\frac{\beta}{n}\Re\mathrm{Tr}(\rho(g))\Bigr).
\tag{B.8}
\]
The constant factor \(e^{-\beta}\) plays no role in positivity, so we introduce the **reduced plaquette weight**
\[
w_\beta(g) := \exp\!\Bigl(\frac{\beta}{n}\Re\mathrm{Tr}(\rho(g))\Bigr).
\tag{B.9}
\]
This is a continuous conjugation-invariant function on \(G\) with \(w_\beta(g)=w_\beta(g^{-1})>0\).

The finite-volume Wilson measure on \(M_\Lambda\) is
\[
d\mu_{\Lambda,\beta}(U)
= Z_{\Lambda,\beta}^{-1}\Big(\prod_{p\in P(\Lambda)} e^{-\Phi_\beta(U_p(U))}\Big)\,d\nu_\Lambda(U),
\tag{B.10}
\]
where \(d\nu_\Lambda\) is the product Haar measure and \(U_p(U)\) is the plaquette holonomy.

Up to an overall constant,
\[
\prod_{p} e^{-\Phi_\beta(U_p)} \;\propto\; \prod_{p} w_\beta(U_p).
\tag{B.11}
\]

### B.2.2 Positive-definite class functions and SOS expansions

A standard criterion for reflection positivity is the existence of a **sum-of-squares kernel expansion** for the coupling across the reflection plane.

We recall two equivalent notions.

**Definition B.1 (positive-definite class function).**  
A continuous function \(w:G\to\mathbb C\) is **positive definite** if for every finite choice \(g_1,\dots,g_m\in G\) and \(c_1,\dots,c_m\in\mathbb C\),
\[
\sum_{i,j=1}^m \overline{c_i}\,c_j\, w(g_i^{-1}g_j)\;\ge\; 0.
\tag{B.12}
\]
Equivalently, the kernel \(K(g,h):=w(g^{-1}h)\) is positive semidefinite.

**Lemma B.2 (SOS expansion from nonnegative Fourier coefficients).**  
Let \(w:G\to\mathbb R\) be continuous, conjugation invariant, and admit a Peter–Weyl expansion
\[
w(g)=\sum_{\pi\in\widehat G} a_\pi\,\chi_\pi(g),
\qquad a_\pi\ge 0,
\tag{B.13}
\]
where \(\widehat G\) is the set of unitary irreducible representations, \(\chi_\pi\) is the character, and the series converges uniformly. Then for all \(g,h\in G\),
\[
w(g^{-1}h)=\sum_{\pi\in\widehat G}\;a_\pi\sum_{i,j=1}^{d_\pi}\overline{\pi_{ij}(g)}\,\pi_{ij}(h)
=\sum_\alpha \overline{f_\alpha(g)}\,f_\alpha(h),
\tag{B.14}
\]
for a family of functions \(\{f_\alpha\}\subset L^2(G)\), and in particular \(w\) is positive definite.

*Proof.* For each unitary irrep \(\pi\),
\[
\chi_\pi(g^{-1}h)=\mathrm{Tr}(\pi(g)^\*\pi(h))=\sum_{i,j}\overline{\pi_{ij}(g)}\,\pi_{ij}(h).
\]
Insert into (B.13) to get (B.14) with \(f_{\pi,i,j}(g):=\sqrt{a_\pi}\,\pi_{ij}(g)\). Positivity (B.12) follows because (B.14) expresses \(K(g,h)=w(g^{-1}h)\) as a Gram kernel. \(\square\)

Thus, for reflection positivity we are led to verify that the Wilson weight \(w_\beta\) has **nonnegative Fourier coefficients**.

### B.2.3 Positivity of the Wilson plaquette weight

The following lemma is the key input: \(w_\beta\) is a positive combination of characters.

**Lemma B.3 (the Wilson plaquette weight is positive definite).**  
Let \(\rho:G\to U(n)\) be unitary. Then for every \(\beta\ge 0\), the class function
\[
w_\beta(g)=\exp\!\Bigl(\frac{\beta}{n}\Re\mathrm{Tr}(\rho(g))\Bigr)
\]
is positive definite. Equivalently, \(w_\beta\) has a Peter–Weyl character expansion with nonnegative coefficients.

*Proof.* Write \(\chi(g):=\mathrm{Tr}(\rho(g))\). Since \(\rho\) is unitary, \(\overline{\chi(g)}=\chi(g^{-1})\). Hence
\[
\Re\chi(g)=\frac12\big(\chi(g)+\chi(g^{-1})\big).
\]
Set \(t:=\beta/n\ge 0\). Then
\[
w_\beta(g)=\exp\!\Big(\frac{t}{2}\chi(g)\Big)\,\exp\!\Big(\frac{t}{2}\chi(g^{-1})\Big).
\]
Expand each exponential into its power series and multiply:
\[
w_\beta(g)=\sum_{m,n\ge 0}\frac{(t/2)^{m+n}}{m!\,n!}\,\chi(g)^m\,\chi(g^{-1})^n.
\tag{B.15}
\]
Now observe:
- \(\chi(g)^m\) is the character of the tensor power representation \(\rho^{\otimes m}\), since \(\chi_{\rho^{\otimes m}}(g)=\chi(g)^m\).
- \(\chi(g^{-1})^n\) is the character of \((\rho^\*)^{\otimes n}\), since \(\chi_{\rho^\*}(g)=\overline{\chi(g)}=\chi(g^{-1})\).

Therefore the product \(\chi(g)^m\chi(g^{-1})^n\) is the character of
\[
\rho^{\otimes m}\otimes (\rho^\*)^{\otimes n},
\]
a finite-dimensional unitary representation. Every such character decomposes into irreducible characters with **nonnegative integer multiplicities**. Because all coefficients \((t/2)^{m+n}/(m!\,n!)\) in (B.15) are nonnegative, summing over \(m,n\) yields a character expansion of \(w_\beta\) with nonnegative coefficients.

Uniform convergence follows from absolute convergence of the series and the bound \(|\chi(g)|\le n\). Hence Lemma B.2 applies and \(w_\beta\) is positive definite. \(\square\)

Combining Lemmas B.2–B.3, we may (and will) use an SOS decomposition of \(w_\beta(g^{-1}h)\).

---

## B.3 Osterwalder–Seiler factorization across the reflection plane

We now explain how the plaquette product \(\prod_{p}w_\beta(U_p)\) factors into “purely positive”, “purely negative”, and “crossing” pieces, and how the crossing piece is SOS.

### B.3.1 Plaquette splitting

Partition the plaquettes into three sets:
- \(P_+\): plaquettes entirely contained in the positive half (\(\widetilde E_+\)),
- \(P_-:=\Theta(P_+)\): plaquettes entirely in the negative half,
- \(P_0\): plaquettes that intersect both sides (the **reflection-plane crossing plaquettes**).

Then
\[
\prod_{p\in P(\Lambda)} w_\beta(U_p)
=\Big(\prod_{p\in P_+} w_\beta(U_p)\Big)\Big(\prod_{p\in P_-} w_\beta(U_p)\Big)\Big(\prod_{p\in P_0} w_\beta(U_p)\Big).
\tag{B.16}
\]
Moreover, because \(w_\beta\) is conjugation invariant and \(w_\beta(g)=w_\beta(g^{-1})\), one checks
\[
\prod_{p\in P_-} w_\beta(U_p) \;=\; \prod_{p\in P_+} w_\beta\big(U_{\Theta p}(\Theta U)\big)
\]
so the negative-half factor is the reflected counterpart of the positive-half factor.

### B.3.2 Half-plaquette holonomies for a crossing plaquette

Fix \(p\in P_0\). By construction, \(p\) crosses the hyperplane \(x_0=\tfrac12\) exactly once in the time direction. Its boundary contains two links on the positive side and two links on the negative side (with the time-like links meeting the plane).

One can choose a **cut** of the plaquette boundary so that the plaquette holonomy can be written as
\[
U_p(U)=V_p^-(U)^{-1}\,V_p^+(U),
\tag{B.17}
\]
where
- \(V_p^+(U)\in G\) depends only on the positive-side links of \(\partial p\) (and possibly on the time-like boundary link on the plane),
- \(V_p^-(U)\in G\) depends only on the negative-side links of \(\partial p\) (and the same boundary link).

Concretely, in the standard hypercubic orientation conventions, a time-oriented plaquette crossing the plane can be written as a product of a “positive half-path” and a “negative half-path”, sharing endpoints on the plane; (B.17) is the group-theoretic expression of that geometric cut.

Crucially, the reflection maps these halves into each other:
\[
V_p^-(U) = V_{\Theta p}^+(\Theta U),
\tag{B.18}
\]
up to the natural identification of the cut.

We do not need a particular closed-form expression for \(V_p^\pm\); only the existence of (B.17)–(B.18), which follows from the locality of plaquette holonomy and the definition of \(\Theta\).

### B.3.3 SOS for the crossing weight

Apply Lemma B.2 to \(w_\beta\). There exist functions \(f_\alpha:G\to\mathbb C\) such that
\[
w_\beta(g^{-1}h)=\sum_\alpha \overline{f_\alpha(g)}\,f_\alpha(h)
\qquad \forall g,h\in G.
\tag{B.19}
\]
Insert (B.17) into (B.19) to obtain for each crossing plaquette \(p\in P_0\),
\[
w_\beta\big(U_p(U)\big)
=
w_\beta\big(V_p^-(U)^{-1}V_p^+(U)\big)
=
\sum_\alpha \overline{f_\alpha\big(V_p^-(U)\big)}\,f_\alpha\big(V_p^+(U)\big).
\tag{B.20}
\]
Because products of SOS kernels remain SOS (take tensor products of index sets), the full crossing product satisfies
\[
\prod_{p\in P_0} w_\beta\big(U_p(U)\big)
=
\sum_{\boldsymbol\alpha\in\mathcal I^{P_0}}
\overline{F_{\boldsymbol\alpha}^-(U)}\;F_{\boldsymbol\alpha}^+(U),
\tag{B.21}
\]
where \(\boldsymbol\alpha=(\alpha_p)_{p\in P_0}\) is a multi-index and
\[
F_{\boldsymbol\alpha}^+(U):=\prod_{p\in P_0} f_{\alpha_p}\big(V_p^+(U)\big),
\qquad
F_{\boldsymbol\alpha}^-(U):=\prod_{p\in P_0} f_{\alpha_p}\big(V_p^-(U)\big).
\tag{B.22}
\]

---

## B.4 Reflection positivity theorem for the Wilson measure

We now combine the factorization above with Haar invariance to complete the Osterwalder–Seiler proof.

### B.4.1 The statement

**Theorem B.4 (reflection positivity of the Wilson lattice gauge measure).**  
Let \(G\) be compact and \(\rho:G\to U(n)\) unitary. Fix \(\beta\ge 0\). Let \(\mu_{\Lambda,\beta}\) be the finite-volume Wilson measure (B.10) on the periodic lattice with even \(L_0\), and let \((\Theta,\theta,\mathcal A_+)\) be as in §B.1. Then \(\mu_{\Lambda,\beta}\) is reflection positive:
\[
\mu_{\Lambda,\beta}\big((\theta F)\,F\big)\ \ge\ 0
\qquad\forall F\in\mathcal A_+.
\tag{B.23}
\]

### B.4.2 Proof

*Proof.* Fix \(F\in\mathcal A_+\). We compute
\[
\mu_{\Lambda,\beta}\big((\theta F)\,F\big)
=
Z_{\Lambda,\beta}^{-1}\int_{M_\Lambda}\overline{F(\Theta U)}\,F(U)\,\prod_{p\in P(\Lambda)}e^{-\Phi_\beta(U_p(U))}\,d\nu_\Lambda(U).
\]
Discard the irrelevant global constant \(e^{-\beta|P|}\) and use \(e^{-\Phi_\beta}\propto w_\beta\). With the plaquette split (B.16) and the crossing SOS (B.21),
\[
\prod_{p\in P(\Lambda)} w_\beta(U_p)
=
\Big(\prod_{p\in P_+} w_\beta(U_p)\Big)\Big(\prod_{p\in P_-} w_\beta(U_p)\Big)
\sum_{\boldsymbol\alpha}\overline{F_{\boldsymbol\alpha}^-(U)}\,F_{\boldsymbol\alpha}^+(U).
\]
Insert this into the integral:
\[
\mu_{\Lambda,\beta}\big((\theta F)\,F\big)
\propto
\sum_{\boldsymbol\alpha}\int \overline{F(\Theta U)}\,\overline{F_{\boldsymbol\alpha}^-(U)}\,
F(U)\,F_{\boldsymbol\alpha}^+(U)\,
\Big(\prod_{p\in P_+} w_\beta(U_p)\Big)\Big(\prod_{p\in P_-} w_\beta(U_p)\Big)\,d\nu_\Lambda(U).
\tag{B.24}
\]

Now use the factorization of variables. Write the configuration as \(U=(U_+,U_0,U_-)\), where:
- \(U_+\) are the link variables in \(\widetilde E_+\),
- \(U_-\) are the link variables in \(\widetilde E_-\),
- \(U_0\) are the boundary links that meet the plane.

Because \(d\nu_\Lambda\) is the product Haar measure, it factorizes:
\[
d\nu_\Lambda(U)=d\nu_+(U_+)\,d\nu_0(U_0)\,d\nu_-(U_-).
\tag{B.25}
\]
Also, by construction:
- \(F(U)=F(U_+)\) depends only on \(U_+\),
- \(F(\Theta U)\) depends only on \(U_-\) (and possibly \(U_0\)), hence \(\overline{F(\Theta U)}\) is a function of \(U_-\),
- \(\prod_{p\in P_+}w_\beta(U_p)\) depends only on \((U_+,U_0)\),
- \(\prod_{p\in P_-}w_\beta(U_p)\) depends only on \((U_-,U_0)\),
- \(F_{\boldsymbol\alpha}^+(U)\) depends only on \((U_+,U_0)\),
- \(F_{\boldsymbol\alpha}^-(U)\) depends only on \((U_-,U_0)\).

Therefore, for each \(\boldsymbol\alpha\), the integrand in (B.24) is a product of a function of \((U_+,U_0)\) and a function of \((U_-,U_0)\), and we may integrate out \(U_+\) and \(U_-\) separately.

Define
\[
\mathcal G_{\boldsymbol\alpha}(U_0)
:=
\int \! F(U_+)\,F_{\boldsymbol\alpha}^+(U_+,U_0)\,\Big(\prod_{p\in P_+}w_\beta(U_p(U_+,U_0))\Big)\,d\nu_+(U_+).
\tag{B.26}
\]
Similarly, define
\[
\mathcal H_{\boldsymbol\alpha}(U_0)
:=
\int \! \overline{F(\Theta U_-)}\,\overline{F_{\boldsymbol\alpha}^-(U_-,U_0)}\,
\Big(\prod_{p\in P_-}w_\beta(U_p(U_-,U_0))\Big)\,d\nu_-(U_-).
\tag{B.27}
\]
Then (B.24) becomes
\[
\mu_{\Lambda,\beta}\big((\theta F)\,F\big)\propto
\sum_{\boldsymbol\alpha}\int \mathcal H_{\boldsymbol\alpha}(U_0)\,\mathcal G_{\boldsymbol\alpha}(U_0)\,d\nu_0(U_0).
\tag{B.28}
\]

At this point we use reflection invariance to identify \(\mathcal H_{\boldsymbol\alpha}\) as the complex conjugate of \(\mathcal G_{\boldsymbol\alpha}\). More precisely, the change of variables \(U_-\mapsto \Theta U_-\) preserves Haar measure (because Haar is invariant under inversion and translation) and maps the negative-half plaquette product \(\prod_{p\in P_-}w_\beta(U_p)\) to the positive-half product \(\prod_{p\in P_+}w_\beta(U_p)\) under the reflected configuration, and it maps \(F(\Theta U_-)\) to \(F(U_+)\). With (B.18) identifying \(V_p^-\) as the reflected \(V_{\Theta p}^+\), one obtains
\[
\mathcal H_{\boldsymbol\alpha}(U_0)=\overline{\mathcal G_{\boldsymbol\alpha}(U_0)}.
\tag{B.29}
\]
(Conceptually: the negative half is a reflected copy of the positive half, and \(\theta\) is complex conjugation after reflection.)

Insert (B.29) into (B.28):
\[
\mu_{\Lambda,\beta}\big((\theta F)\,F\big)
\propto
\sum_{\boldsymbol\alpha}\int \big|\mathcal G_{\boldsymbol\alpha}(U_0)\big|^2\,d\nu_0(U_0)
\;\ge\;0.
\]
Restoring the positive normalization constants yields (B.23). \(\square\)

---

## B.5 Permanence lemmas (optional but useful downstream)

The reflection positivity inequality is robust under the basic operations that appear later (coarse graining/pushforwards, limits). We record two elementary permanence statements.

### B.5.1 Pushforward under reflection-equivariant maps

**Lemma B.5 (reflection positivity is preserved under reflection-equivariant pushforward).**  
Let \((\Omega,\mu)\) be reflection positive with respect to \((\Theta,\mathcal A_+)\). Let \(\pi:\Omega\to\Omega'\) be measurable, and suppose \(\Omega'\) has a reflection \(\Theta'\) such that
\[
\pi\circ\Theta = \Theta'\circ\pi.
\tag{B.30}
\]
Let \(\mu':=\pi_\*\mu\). Then \(\mu'\) is reflection positive with respect to \((\Theta',\mathcal A_+'),\) where \(\mathcal A_+'\) is the algebra of bounded functions depending only on \(\pi\)-images of positive-side coordinates. In particular, for all bounded \(F'\in\mathcal A_+'\),
\[
\mu'\big((\theta'F')F'\big)\ge 0,\qquad (\theta'F')(\omega'):=\overline{F'(\Theta'\omega')}.
\tag{B.31}
\]

*Proof.* For \(F'\in\mathcal A_+'\), define \(F:=F'\circ\pi\in\mathcal A_+\). Then
\[
\mu'\big((\theta'F')F'\big)
=
\mu\big(\overline{F'(\Theta'\pi(\cdot))}\,F'(\pi(\cdot))\big)
=
\mu\big(\overline{F'(\pi(\Theta\cdot))}\,F'(\pi(\cdot))\big)
=
\mu\big((\theta F)F\big)\ge 0.
\]
\(\square\)

This lemma is the minimal formal input behind “reflection positivity survives reflection-equivariant coarse graining”.

### B.5.2 Closedness under weak limits

**Lemma B.6 (reflection positivity is closed under weak convergence).**  
Let \(\mu_k\) be a sequence of reflection-positive probability measures on a compact configuration space \(\Omega\), all with respect to the same \((\Theta,\mathcal A_+)\). If \(\mu_k\Rightarrow \mu\) weakly, then \(\mu\) is reflection positive.

*Proof.* Fix \(F\in\mathcal A_+\). The function \((\theta F)F\) is bounded and continuous (for cylinder \(F\) on a compact product group). Hence
\[
\mu\big((\theta F)F\big)=\lim_{k\to\infty}\mu_k\big((\theta F)F\big)\ge 0.
\]
\(\square\)

---

## B.6 Summary

- The Wilson plaquette weight \(w_\beta(g)=\exp((\beta/n)\Re\mathrm{Tr}(\rho(g)))\) is a **positive definite** central function (Lemma B.3), hence has an SOS kernel expansion (Lemma B.2).
- Crossing plaquettes across the reflection plane can be written in the form \(U_p=V_-^{-1}V_+\), so their weights are SOS kernels in the variables \((V_-,V_+)\).
- This yields the Osterwalder–Seiler SOS factorization and proves reflection positivity for the full Wilson measure (Theorem B.4).
- Reflection positivity is stable under the basic operations used later (pushforward under reflection-equivariant maps and weak limits; Lemmas B.5–B.6).

This completes the reflection-positivity input used in Part 4 and in the fixed-cutoff OS mass-gap bridge.
