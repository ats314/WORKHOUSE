# Appendix C. Osterwalder–Schrader axioms and reconstruction at fixed cutoff

This appendix records the Osterwalder–Schrader (OS) framework in the form used in the main text: a *reflection-positive* Euclidean Gibbs state at fixed lattice spacing defines a Hilbert space, a positive self-adjoint time-translation operator (“transfer matrix”), and hence a Hamiltonian. Euclidean *time-direction decay* of correlations then becomes a *spectral gap* statement for the reconstructed Hamiltonian.

Nothing here is new; the goal is simply to make the hypotheses and the one identity we use fully explicit and referee-trackable.

Throughout, we work at **fixed cutoff** (fixed lattice spacing \(a>0\)). Time is the \(0\)-th coordinate and space is \((1,2,3)\). We write \(\tau_n\) for time translations by \(n\hat e_0\). The configuration space \(\Omega\) is a compact product of copies of a compact gauge group \(G\) over oriented links (finite volume) or cylinder limits (infinite volume). The measure \(\mu\) is a probability measure on \((\Omega,\mathcal F)\) (finite volume: the Wilson Gibbs measure; infinite volume: a limit point).

---

## C.1 Reflection, the involution on configurations, and the positive-time algebra

### C.1.1 Reflection across a time hyperplane

Fix a time reflection \(\Theta\) across a hyperplane between two time slices. On the infinite lattice it is convenient to take the hyperplane \(\{x_0=\tfrac12\}\), i.e.
\[
(\Theta x)_0 := 1-x_0,\qquad (\Theta x)_i:=x_i \ (i=1,2,3),
\]
and extend periodically in finite volume if needed.

On *link variables* \(U_b\in G\) (with \(b\) an oriented link), \(\Theta\) acts by reflecting the basepoint and reversing the time direction. A standard (and convenient) convention is:

- If \(b=(x,i)\) is a **spatial** link (\(i\in\{1,2,3\}\)), set
\[
(\Theta U)_{x,i} := U_{\Theta x,i}.
\]
- If \(b=(x,0)\) is a **time** link, then reflection reverses time orientation, so
\[
(\Theta U)_{x,0} := U_{\Theta x-\hat e_0,0}^{-1}.
\]

With the orientation convention \(U_{b^{-1}}=U_b^{-1}\), the above is simply “reflect the geometric link and then re-express it in the positively oriented link set.” One checks that \(\Theta\) is an involution: \(\Theta^2=\mathrm{Id}\).

The precise formula is not important for most abstract arguments. What matters is that:

1. \(\Theta\) is a measurable involution \(\Omega\to\Omega\);
2. \(\Theta\) exchanges the positive and negative time halves;
3. time translations satisfy \(\Theta\circ\tau_n=\tau_{-n}\circ\Theta\).

### C.1.2 The antilinear involution on observables

For any (complex-valued) observable \(F:\Omega\to\mathbb C\), define the OS involution
\[
(\theta F)(U) \;:=\; \overline{F(\Theta U)}.
\tag{C.1}
\]
This is antilinear and satisfies \(\theta^2=\mathrm{Id}\).

### C.1.3 Positive-time algebra

Let \(\mathcal A_+\) be the algebra of bounded **positive-time cylinder observables**, i.e. bounded functions depending only on finitely many link variables with basepoints in the nonnegative-time half-space (and, depending on convention, including links that start at time \(0\)). The only structural requirements we need are:

- \(\mathcal A_+\) is an algebra (closed under products and linear combinations),
- \(\theta(\mathcal A_+)\subseteq \mathcal A_-\) (negative-time observables),
- \(\tau_n(\mathcal A_+)\subseteq \mathcal A_+\) for \(n\ge 0\).

---

## C.2 OS axioms at fixed cutoff

The main text uses the following three OS hypotheses (often called (H1)–(H3)).

**Assumption C.1 (OS hypotheses).** The probability measure \(\mu\) on \((\Omega,\mathcal F)\) satisfies:

1. **Time-translation invariance**: \(\mu(\tau_n F)=\mu(F)\) for all bounded measurable \(F\) and all \(n\in\mathbb Z\).
2. **Reflection invariance**: \(\mu(\theta F)=\overline{\mu(F)}\) for all bounded measurable \(F\). (Equivalently \(\mu\circ\Theta^{-1}=\mu\).)
3. **Reflection positivity**: for all \(F\in\mathcal A_+\),
\[
\mu\big((\theta F)\,F\big)\ \ge\ 0.
\tag{C.2}
\]

In lattice gauge theory with Wilson action, reflection positivity is proved by the Osterwalder–Seiler factorization mechanism (Section 4.2 in the main text and the reflection-positivity appendix in the project map). Time-translation and reflection invariance are immediate from the action and Haar measure symmetries.

---

## C.3 OS Hilbert space and transfer operator

### C.3.1 The OS pre-Hilbert form and null space

Define a sesquilinear form on \(\mathcal A_+\) by
\[
\langle F,G\rangle_{\mathrm{OS}} \;:=\; \mu\big((\theta F)\,G\big),\qquad F,G\in\mathcal A_+.
\tag{C.3}
\]
Reflection positivity (C.2) says \(\langle F,F\rangle_{\mathrm{OS}}\ge 0\).

Define the null space
\[
\mathcal N \;:=\;\{F\in\mathcal A_+:\ \langle F,F\rangle_{\mathrm{OS}}=0\}.
\tag{C.4}
\]
It is a subspace, and in fact a left ideal in \(\mathcal A_+\) (standard).

### C.3.2 The OS Hilbert space and vacuum

Define the OS Hilbert space as the completion
\[
\mathcal H_{\mathrm{OS}} \;:=\; \overline{\mathcal A_+/\mathcal N}^{\ \|\cdot\|_{\mathrm{OS}}}.
\tag{C.5}
\]
Write \([F]\in\mathcal H_{\mathrm{OS}}\) for the class of \(F\in\mathcal A_+\). The constant function \(1\) lies in \(\mathcal A_+\), and we define the vacuum vector
\[
\Omega \;:=\; [1].
\tag{C.6}
\]
By construction, \(\|\Omega\|_{\mathrm{OS}}^2=\mu(1)=1\).

### C.3.3 Time translations as a contraction semigroup

Define, for \(n\ge 0\),
\[
T^n[F] \;:=\; [\tau_n F],\qquad F\in\mathcal A_+.
\tag{C.7}
\]
This is well-defined on the quotient because if \(F\in\mathcal N\), then reflection positivity plus invariance show \(\tau_n F\in\mathcal N\). Moreover, using time-translation invariance and reflection invariance one checks the *transfer matrix identity*
\[
\langle [F],\,T^n[G]\rangle_{\mathrm{OS}}
\;=\;
\mu\big((\theta F)\,\tau_n G\big),
\qquad F,G\in\mathcal A_+,\ n\ge 0.
\tag{C.8}
\]
A standard argument then yields:

- \(T^n\) extends to a bounded operator on \(\mathcal H_{\mathrm{OS}}\),
- \(\|T^n\|\le 1\) (contraction),
- \(T^n\) is self-adjoint and positive (as an operator),
- \(T^{n+m}=T^nT^m\) (semigroup property).

We summarize this as an external theorem, since the details are classical and can be found in standard references.

---

## C.4 Reconstruction theorem in the form used in the manuscript

**Theorem C.2 (OS reconstruction, lattice/Euclidean time version; external input).**  
Assume \(\mu\) satisfies Assumption C.1. Then there exists a Hilbert space \(\mathcal H_{\mathrm{OS}}\), a unit vector \(\Omega\in\mathcal H_{\mathrm{OS}}\), and a positive self-adjoint contraction \(T\) on \(\mathcal H_{\mathrm{OS}}\) such that:

1. \(\mathcal H_{\mathrm{OS}}\) is the completion of \(\mathcal A_+/\mathcal N\) with inner product (C.3), and \(\Omega=[1]\).
2. \(T\) implements one Euclidean time-step: \(T[F]=[\tau_1F]\), and \(T^n[F]=[\tau_nF]\) for \(n\ge 0\).
3. For all \(F,G\in\mathcal A_+\) and all \(n\ge 0\),
\[
\langle [F],\,T^n[G]\rangle_{\mathrm{OS}}
\;=\;
\mu\big((\theta F)\,\tau_n G\big).
\tag{C.9}
\]

If the lattice spacing is \(a>0\), then there exists a self-adjoint operator \(H\ge 0\) on \(\mathcal H_{\mathrm{OS}}\) such that
\[
T \;=\; e^{-aH}
\qquad\text{(functional calculus).}
\tag{C.10}
\]

*Remarks.*  
1. The operator \(T\) is often called the **transfer matrix**, and \(H\) the **OS Hamiltonian**.  
2. In gauge theory, one can either reconstruct from the full algebra \(\mathcal A_+\) or restrict to gauge-invariant observables (which yields the physical Hilbert space). The main text only uses (C.9) for gauge-invariant observables.

---

## C.5 Mass gap criterion from Euclidean time decay

We now record the conversion used in Section 11.3: exponential decay in lattice time steps implies a spectral gap of the OS Hamiltonian of size (decay exponent)/\(a\).

Let \(H\ge 0\) be self-adjoint on a Hilbert space \(\mathcal H\). For \(\psi\in\mathcal H\), let \(\nu_\psi\) be the spectral measure of \(H\) associated to \(\psi\), i.e.
\[
\langle\psi, e^{-tH}\psi\rangle = \int_{[0,\infty)} e^{-t\lambda}\,d\nu_\psi(\lambda),\qquad t\ge 0.
\tag{C.11}
\]

### C.5.1 A discrete-time spectral support lemma

**Lemma C.3 (spectral-measure gap from discrete-time decay).**  
Fix \(a>0\) and \(m>0\). If there exists \(C_\psi<\infty\) such that for all integers \(n\ge 0\),
\[
\langle \psi, e^{-naH}\psi\rangle \ \le\ C_\psi\,e^{-mna},
\tag{C.12}
\]
then \(\nu_\psi([0,m))=0\), equivalently \(E_H([0,m))\psi=0\).

*Proof.* This is Lemma 11.1 in the main text; we reproduce the short argument for completeness.  
If \(\nu_\psi([0,m))>0\), then some \(\delta:=\nu_\psi([0,m-\varepsilon])>0\) for a small \(\varepsilon\in(0,m)\). Hence
\[
\langle \psi,e^{-naH}\psi\rangle
=\int e^{-na\lambda}\,d\nu_\psi(\lambda)
\ge \delta\,e^{-(m-\varepsilon)na},
\]
which contradicts (C.12) for large \(n\) because \(\delta e^{\varepsilon na}\to\infty\). \(\square\)

### C.5.2 Apply to OS correlations

Let \(\mu\) satisfy Assumption C.1 and let \((\mathcal H_{\mathrm{OS}},\Omega,T=e^{-aH})\) be the reconstruction from Theorem C.2. Fix \(F\in\mathcal A_+\) and set the centered observable \(F^\circ:=F-\mu(F)\). Then \([F^\circ]\perp\Omega\) and
\[
\langle [F^\circ],\,T^n[F^\circ]\rangle_{\mathrm{OS}}
=
\mu\big((\theta F^\circ)\,\tau_n F^\circ\big)
=
\mathrm{Cov}_\mu\big(\theta F,\,\tau_n F\big),
\qquad n\ge 0,
\tag{C.13}
\]
by (C.9) and the definition of covariance.

Therefore, if one has an exponential time-direction decay estimate
\[
\big|\mathrm{Cov}_\mu(\theta F,\tau_n F)\big|
\ \le\ C(F)\,e^{-\eta n},
\qquad n\ge 0,
\tag{C.14}
\]
then (since the left-hand side is nonnegative when \(F=G\) and \(T\ge 0\)), we obtain
\[
\langle [F^\circ], e^{-naH}[F^\circ]\rangle_{\mathrm{OS}}
\le C(F)\,e^{-(\eta/a)\,na}.
\tag{C.15}
\]
Lemma C.3 then implies that \([F^\circ]\) has no spectral weight below \(\eta/a\). If \(\{[F^\circ]:F\in\mathcal A_+\}\) is dense in \(\mathcal H_{\mathrm{OS}}\ominus\mathbb C\Omega\) (true under mild irreducibility/cyclicity conditions), this yields the Hamiltonian gap statement.

This is exactly the bridge used in Section 11.3.

---

## C.6 What is (and is not) proved here

- This appendix *does not* re-prove OS reconstruction or reflection positivity for gauge theory; those are treated as external inputs and/or proved elsewhere in the project appendices (see `EXTERNAL_INPUTS.md` and the file map).
- The appendix *does* pin down the algebraic objects (the OS inner product, transfer operator, and the one identity (C.9)) so that later “Euclidean \(\Rightarrow\) Hamiltonian” steps are purely functional analysis once exponential time decay is established.

