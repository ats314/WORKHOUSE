# Haar Jacobian \(\Rightarrow\) geometric “mass term” (lattice YM in exponential coordinates)

## 0. The punchline

For a compact gauge group (e.g. \(SU(N)\)), if you write a link variable near the identity as
\[
U = \exp(A), \qquad A\in\mathfrak{su}(N),
\]
then the Haar measure in these coordinates is
\[
d\mathrm{Haar}(U) = J(A)\,dA,
\]
where the Jacobian is given by the Lie-group formula
\[
\boxed{\;J(A)=\det\left( \frac{\sinh(\mathrm{ad}_A/2)}{(\mathrm{ad}_A/2)}\right).\;}
\]
Expanding at \(A=0\), one finds
\[
-\log J(A)= c_0\,\mathrm{Tr}(A^\dagger A) + O(\|A\|^4), \qquad c_0>0.
\]
So the measure itself contributes a strictly positive quadratic term (a “mass-like curvature”) in \(A\)-coordinates.

This is a **finite-dimensional, group-theoretic** statement; it does **not** depend on the Wilson action.

---

## 1. Lattice configuration space

On a lattice with oriented bonds \(\mathcal{B}\), a configuration is
\[
U=(U_b)_{b\in\mathcal{B}} \in G^{\mathcal{B}},\qquad G=SU(N),
\]
with product Haar measure
\[
\mu_0(dU)=\prod_{b\in\mathcal{B}} d\mathrm{Haar}(U_b).
\]
In exponential coordinates near the identity (for each bond)
\[
U_b=\exp(A_b),\qquad A_b\in\mathfrak{su}(N),
\]
the measure becomes
\[
\mu_0(dU)=\prod_{b\in\mathcal{B}} J(A_b)\,dA_b,
\]
so the induced “measure potential” is
\[
S_{\mathrm{Haar}}(A):=-\sum_{b\in\mathcal{B}}\log J(A_b).
\]

---

## 2. Jacobian of the exponential map

A standard Lie-group identity gives
\[
J(A)=\det\left( \frac{\sinh(\mathrm{ad}_A/2)}{(\mathrm{ad}_A/2)}\right),
\qquad \mathrm{ad}_A(X):=[A,X].
\]
Key properties for compact semisimple groups:

- \(\mathrm{ad}_A\) is skew-adjoint w.r.t. an invariant inner product.
- The spectrum of \(\mathrm{ad}_A\) is purely imaginary.
- The function \(x\mapsto \sinh(x/2)/(x/2)\) is even, so the first nontrivial term in \(\log J(A)\) is quadratic.

---

## 3. Quadratic expansion and positivity

Use the scalar series
\[
\frac{\sinh(x/2)}{(x/2)} = 1 + \frac{x^2}{24}+O(x^4).
\]
By functional calculus,
\[
\frac{\sinh(\mathrm{ad}_A/2)}{(\mathrm{ad}_A/2)}
= I + \frac{(\mathrm{ad}_A)^2}{24} + O(\|\mathrm{ad}_A\|^4).
\]
Then
\[
\log J(A)=\mathrm{Tr}\log\left(I+\frac{(\mathrm{ad}_A)^2}{24}+O(A^4)\right)
=\frac{1}{24}\mathrm{Tr}((\mathrm{ad}_A)^2)+O(\|A\|^4),
\]
so
\[
S_{\mathrm{Haar}}(A):=-\log J(A)= -\frac{1}{24}\mathrm{Tr}((\mathrm{ad}_A)^2)+O(\|A\|^4).
\]
Now
\[
\mathrm{Tr}((\mathrm{ad}_A)^2)
= -\sum_k \|[A,X_k]\|^2\le 0
\]
for any orthonormal basis \(\{X_k\}\) of \(\mathfrak{g}\). Therefore the quadratic term
\(
-\frac{1}{24}\mathrm{Tr}((\mathrm{ad}_A)^2)
\)
is **nonnegative** and is strictly positive unless \(A\) lies in the center.

For \(SU(N)\), one can rewrite
\[
\mathrm{Tr}((\mathrm{ad}_A)^2)= -c_{\mathrm{ad}}\,\mathrm{Tr}(A^\dagger A)
\]
for a group-dependent constant \(c_{\mathrm{ad}}>0\), yielding
\[
S_{\mathrm{Haar}}(A)=c_0\,\mathrm{Tr}(A^\dagger A)+O(\|A\|^4),\qquad c_0>0.
\]

---

## 4. Combining with Wilson action

The Wilson action is
\[
S_W(U)=\beta\sum_{p}\left(1-\frac{1}{N}\Re\mathrm{Tr}(U_p)\right).
\]
In \(A\)-coordinates (near the identity)
\[
S_{\mathrm{eff}}(A) \equiv S_W(\exp(A))+S_{\mathrm{Haar}}(A).
\]
At quadratic order, the Haar term contributes an explicit strictly positive local curvature floor; the Wilson term contributes the usual kinetic piece (in a continuum expansion), plus higher nonlinearities.

---

## 5. A crucial subtlety (do not skip this)

The exponential map \(\exp:\mathfrak{su}(N)\to SU(N)\) is **not globally one-to-one**. A-coordinate formulations are strictly local unless you either:

1. Restrict \(A\) to a fundamental domain / principal branch, *or*
2. Implement the exact Jacobian and the correct identification of multiple preimages.

So the statement “Haar induces a quadratic mass term” should be read as:

> In a small-field chart around the identity, the Haar density has strictly positive quadratic curvature.

That is still a powerful input for any program that tries to prove a gap by showing the measure concentrates in a convex chart.
