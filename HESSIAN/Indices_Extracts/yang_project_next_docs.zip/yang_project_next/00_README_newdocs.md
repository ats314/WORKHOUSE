
# New Docs Generated (Referee-proof lemma + Certification pipeline)

This folder contains two core documents intended to give the project *teeth*:

1. **Doc07_uniform_wilson_hessian_bound_SU3.tex**  
   A fully self-contained, referee-proof lemma establishing a **field-independent, volume-independent**
   operator-norm bound
   \[
   \|\nabla^2 S_W(A)\|_{\mathrm{op}}\le C_W\,\beta
   \]
   for the SU(3) Wilson action in exponential coordinates, using the Hilbert–Schmidt norm and unitarity.

2. **Doc05_certificate_pipeline_L2.md**  
   A concrete plan to turn your existing JAX Hessian scans on small lattices (starting with L=2)
   into **validated** and eventually **rigorous** convexity certificates using:
   - net coverings (grid),
   - verified eigenvalue lower bounds (Gershgorin / verified Cholesky / Ritz+residual),
   - Lipschitz control of the Hessian via third derivative bounds.

## Intended use

- **Doc07** becomes a real analytic lemma you can cite (and build on for strong-coupling convexity).
- **Doc05** becomes the bridge from “pretty plots” to “certified claims” on small lattices.

## Next analytic target
To make the pipeline fully rigorous, prove a uniform bound on the third Fréchet derivative of the exponential map
in HS norm for anti-Hermitian matrices:
\[
\|D^3 e^A[H,K,L]\|_{HS}\le C_3 \|H\|_{HS}\|K\|_{HS}\|L\|_{HS},
\quad A\in\mathfrak{su}(3).
\]
Then propagate through plaquette product rules to obtain a computable Lipschitz constant \(L_H\) for the Hessian
on a per-link ball \(\|A_\ell\|_{HS}\le R\).

