# Doc 05 (Certificate Pipeline): Validated Convexity Regions on Small SU(3) Lattices (L=2)

This document is a *protocol* for turning your existing SU(3) Hessian scans (JAX/AD + Lanczos) into **validated** (and eventually **rigorous**) convexity certificates on small lattices.

The goal is to produce a referee-checkable statement of the form:

> For fixed lattice size **L=2**, parameters \((\beta,c_0)\), and radius \(R>0\):  
> \[
> \nabla^2 S_{\beta}(A) \succeq \rho I\quad\forall A:\ \|A_\ell\|_{HS}\le R\ \text{for all links }\ell,
> \]
> with explicit \(\rho>0\).

Here \(S_\beta(A)=S_{\text{mass}}(A)+S_W(A)\), where (for certification purposes) we use the **Haar-surrogate mass**
\[
S_{\text{mass}}(A)=c_0\sum_{\ell}\|A_\ell\|_{HS}^2,
\]
and \(S_W\) is the Wilson action in exponential coordinates \(U_\ell=\exp(A_\ell)\).

---

## 0) What you already have (usable as the non-rigorous engine)

From the December 2025 code logs / PDFs you already have:

- an SU(3) exponential map `su3_exp_pade22`,
- Wilson action on \(L^4\) lattice via plaquettes,
- a mass term `haar_mass(params, c0)` used as a convexifying surrogate,
- Hessian-vector products via JAX `jvp`,
- Lanczos estimation of \(\lambda_{\min}\).

This is the correct *exploration* engine and is ideal for locating a candidate convexity window \((R,\rho)\).

What it is **not** yet: a proof.

---

## 1) Two-layer strategy: *find* a window fast, then *certify* it

### Phase A — Find a candidate convexity window (fast, non-rigorous)

1. Fix \(L=2\) and a grid of \(\beta\) values.
2. For each \(\beta\), sample random configurations:
   \[
   A_\ell \sim \sigma\,\mathcal{N}(0,I_{8}),
   \]
   and record the minimum observed \(\lambda_{\min}\big(\nabla^2 S_\beta(A)\big)\).
3. For each \((\beta,\sigma)\), estimate:
   - leakage probability \(\mathbb{P}(\lambda_{\min}<0)\),
   - margin \(\widehat\rho(\beta,\sigma) := \min\lambda_{\min}\) across samples.

This gives a **candidate**: choose \(\sigma\) so that \(\widehat\rho\) is comfortably positive.

> Output of Phase A should be a table:  
> \((\beta,\sigma)\mapsto \widehat\rho\) and leakage fraction.

### Phase B — Certify a window (validated numerics → rigorous numerics)

To certify a ball (not just random samples), you need three ingredients:

1. **Grid / net covering** of the ball.
2. **Verified lower bounds on \(\lambda_{\min}\)** at net points.
3. **A Lipschitz bound** on the Hessian to extend bounds off-grid.

The core inequality is:
\[
\lambda_{\min}\big(\nabla^2 S(A)\big)\ \ge\ 
\lambda_{\min}\big(\nabla^2 S(A_k)\big)\ -\ \|\nabla^2 S(A)-\nabla^2 S(A_k)\|_{\mathrm{op}}.
\]
If you have a Lipschitz constant \(L_H\) on the region,
\[
\|\nabla^2 S(A)-\nabla^2 S(A_k)\|_{\mathrm{op}}\le L_H\,\|A-A_k\|_{\mathcal X},
\]
then for an \(\varepsilon\)-net:
\[
\lambda_{\min}(A)\ge \min_k \lambda_{\min}(A_k)\ -\ L_H\varepsilon.
\]
So if \(\min_k \lambda_{\min}(A_k)\ge 2\rho\) and \(L_H\varepsilon\le \rho\), you get \(\lambda_{\min}(A)\ge \rho\) on the entire ball.

---

## 2) The analytic input you should use (Doc 07)

**Use the uniform Wilson Hessian bound**:

\[
\|\nabla^2 S_W(A)\|_{\mathrm{op}}\le C_W\,\beta
\quad\forall A,
\]
with explicit \(C_W\) (no dependence on \(A\) and no dependence on volume).

This gives you immediately:

- **Strong-coupling global convexity** for small \(\beta\):  
  \(\nabla^2 S_{\text{mass}} = 2c_0 I\), so  
  \(\nabla^2 S_\beta \succeq (2c_0 - C_W\beta)I\).

- A clean upper bound on how bad Wilson can be inside any ball.

**But** to certify a *finite radius ball* at larger \(\beta\) you still need a **third derivative** bound to control Lipschitz continuity of the Hessian in that ball.

---

## 3) The missing analytic bound for certification: a third-derivative (Lipschitz) constant

To compute \(L_H\) you want a bound like:

\[
\|\nabla^3 S_W(A)\|_{\mathrm{op}}\le M_3(R)\quad\text{for }\|A_\ell\|_{HS}\le R.
\]

Then \(L_H \le M_3(R)\).

### Why this is plausibly doable
For \(A\in\mathfrak{su}(3)\), \(e^{tA}\) is unitary. The HS norm invariance plus integral formulas (Duhamel) let you bound \(D^3 e^A\) with constants depending at most on the matrix size (3) and not on \(\|A\|\). The only new technical step is careful control of products like \(HUKVL\) in HS norm using \(\|M\|_{op}\le \|M\|_{HS}\).

**Recommendation:** prove a general lemma:

> \(\|D^k e^A[H_1,\dots,H_k]\|_{HS}\le C_k \prod_i\|H_i\|_{HS}\) for all \(A\in\mathfrak{su}(3)\).

Then propagate through the plaquette product rule to get a usable \(M_3(R)\).

You do *not* need a sharp constant; you need a finite explicit one.

---

## 4) Verified eigenvalue lower bounds at grid points: three options

### Option 1 (cheap but conservative): Gershgorin
If you explicitly form the Hessian matrix \(H(A)\in\mathbb{R}^{n\times n}\) in a fixed coordinate basis,
\[
\lambda_{\min}(H)\ \ge\ \min_i \left(H_{ii}-\sum_{j\neq i}|H_{ij}|\right).
\]
Pros: easy, rigorous with interval arithmetic.  
Cons: can be too conservative.

### Option 2 (better): Verified Cholesky for \(H-\rho I\)
To prove \(H\succeq \rho I\), show \(H-\rho I\) is positive definite.
Attempt Cholesky factorization with directed rounding / interval arithmetic.

Pros: strong and clean certificate.  
Cons: requires interval arithmetic tooling (Arb/MPFI/Intlab).

### Option 3 (sharp): Ritz value + residual (validated numerics)
Compute an approximate minimal eigenpair \((\widehat\lambda,\widehat v)\) (Lanczos).
Compute residual \(r=\|H\widehat v - \widehat\lambda \widehat v\|\).
Then for symmetric \(H\),
\[
\mathrm{dist}(\widehat\lambda,\mathrm{spec}(H))\le r.
\]
If you *also* know \(\widehat\lambda\) is the smallest Ritz value (and your Krylov subspace is sufficiently rich), you can get:
\[
\lambda_{\min}(H)\ge \widehat\lambda - r.
\]

Pros: sharp, scales to \(n=512\).  
Cons: to make it fully rigorous you must bound floating error in computing \(r\), or compute \(r\) in high precision / intervals.

---

## 5) Practical blueprint for L=2 (what to actually implement)

### Step A — Fix conventions
- Fix a basis \(T_a\) for \(\mathfrak{su}(3)\) with \(\mathrm{Tr}(T_a^\dagger T_b)=\delta_{ab}\).
- Represent each link as coordinates \(a_\ell\in\mathbb{R}^8\) and \(A_\ell=\sum_a a_{\ell,a}T_a\).

### Step B — Define the certified region
Pick per-link HS-radius \(R\) and define:
\[
\mathcal{B}(R)=\{A:\ \|A_\ell\|_{HS}\le R\ \forall \ell\}.
\]
Note: per-link \(\ell^\infty\) balls are easier to cover than global \(\ell^2\) balls.

### Step C — Build an \(\varepsilon\)-net
Construct a deterministic net for each link coordinate ball; for feasibility, start with:
- a 1D net per coordinate (coarse), then refine,
- or a random net + covering argument (not fully rigorous),
- or certify only a **smaller** sub-ball initially.

### Step D — At each net point, certify \(\lambda_{\min}\ge 2\rho\)
Use Option 2 or 3 above.

### Step E — Use Lipschitz to extend to all of \(\mathcal{B}(R)\)
Pick \(\varepsilon \le \rho/L_H\).

### Step F — Output the certificate
A certificate is a small artifact containing:
- lattice size \(L\), parameters \(\beta,c_0\),
- region \(R\),
- net spacing \(\varepsilon\),
- proven \(L_H\),
- proven grid-point lower bounds,
- final \(\rho\).

A referee can check it by re-running a deterministic script.

---

## 6) Minimal deliverable that already “has teeth”

Even before full interval arithmetic, you can produce a **validated-numerics** result:

- Use double precision to compute \(\widehat\lambda\).
- Use *quadruple / mp* to compute the residual \(r\) and Gershgorin bound as a cross-check.
- Report the margin \(\widehat\lambda - r\).

This is not a theorem yet, but it is a serious, quantitative step toward a theorem and will catch many failure modes early.

---

## 7) Suggested companion scripts (next)

If you want, the next immediate engineering step is to produce two scripts:

1. `build_hessian_matrix_L2.py`  
   Explicitly forms the Hessian matrix at a given configuration using AD with fixed basis.

2. `certify_convexity_ball_L2.py`  
   Implements: net → per-point certificate → Lipschitz extension → report.

Those scripts are straightforward to write once you choose whether to certify via Gershgorin, verified Cholesky, or Ritz+residual.

---
