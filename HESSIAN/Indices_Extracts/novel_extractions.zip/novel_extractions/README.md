# Novel Extractions — README

This folder contains **five** Markdown documents (with LaTeX math) that extract and reorganize the pieces of the project that seem the most *exportable* and *theory-generating*.

They are not intended to replace the full draft; they are meant as:
- modular inserts into a larger proof manuscript,
- and/or standalone notes suitable for polishing into a paper.

## Files

1. `EXTRACT_01_Horizontal_Bakry_Emery_for_Gauge_Invariant_Sectors.md`  
   Horizontal \(\Gamma_2\) calculus: gauge invariance ⇒ gradients are horizontal ⇒ only horizontal Bakry–Émery curvature matters.

2. `EXTRACT_02_Haar_Mass_Mechanism_on_Compact_Groups.md`  
   Haar Jacobian expansion in exponential coordinates and its interpretation as a local quadratic confinement proportional to Ricci.

3. `EXTRACT_03_Wilson_Hessian_as_Discrete_Hodge_Laplacian.md`  
   Wilson Hessian at the vacuum equals \(2c_W d_1^\*d_1\) and the Hodge decomposition of modes.

4. `EXTRACT_04_Core_Local_Horizontal_Curvature_Theorem_for_Lattice_Yang_Mills.md`  
   A clean local theorem: positive horizontal Bakry–Émery curvature near the vacuum with volume-uniform constants (under explicit hypotheses).

5. `EXTRACT_05_From_Functional_Inequalities_to_Mass_Gaps_OS_vs_Diffusion.md`  
   A programmatic comparison between configuration diffusion gaps and OS Hamiltonian mass gaps, with explicit conjectures and conditional lemmas.

## Converting to PDF (optional)

Using `pandoc` (example):

```bash
pandoc EXTRACT_01_Horizontal_Bakry_Emery_for_Gauge_Invariant_Sectors.md -o extract01.pdf
```

(Any LaTeX template should work; these files stick to standard math environments.)

