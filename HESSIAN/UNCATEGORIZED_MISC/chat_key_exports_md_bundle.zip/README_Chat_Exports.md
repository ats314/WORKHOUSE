# Chat Export Index

This folder contains Markdown files capturing the most important technical artifacts produced in the chat.

## Files

- `Corpus_Map_and_Clean_Document_Set.md`  
  Clean extracted corpus map: definitions, interfaces, proved results, conditional hypotheses, dependency graph.

- `Foundations_Theorem_E.md`  
  Draft of Theorem E: existence, uniqueness, and closability (manuscript-style LaTeX).

- `Lemma_M2_Uniqueness.md`  
  PBH-free uniqueness lemma for the continuum measure.

- `Theorem_Uniqueness_Scaling_Limit_Wilson_Loops.md`  
  Conservative uniqueness theorem defining continuum Wilson expectations by lattice limits.

- `Lemma_M3_Closability.md`  
  Non-circular closability lemma for the continuum Dirichlet form.

- `Theorem_H2_Gauge_Fixing_Independence.md`  
  Gauge-fixing independence theorem for gauge-invariant observables.

- `Lemma_H3_OffDiagonal_Hessian_Decay.md`  
  Finite-range locality lemma giving off-diagonal Hessian decay under refinement.

- `Theorem_IR_Topology_Decoupling.md`  
  Rewritten infrared decoupling theorem using H3.

- `Standing_Assumptions_Block.md`  
  Referee-facing assumptions/hypotheses block (as drafted earlier in the chat).

- `Clay_Submission_Checklist.md`  
  Proof-stack audit and a practical checklist of “tighten/cite” items.

