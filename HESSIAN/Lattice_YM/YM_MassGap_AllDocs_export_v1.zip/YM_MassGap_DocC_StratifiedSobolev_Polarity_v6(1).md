# Stratified Sobolev Space and Polarity of Reducible Connections

_Derived from the master white paper on Yang–Mills mass gap (v3.6)._  


## Context

## Executive Summary

This white paper lays out a **dynamic and constructive program** for the Yang–Mills Existence and Mass Gap problem, combining:

- A **convex scalar prototype** (lattice \(\phi^4_4\)) where the Bakry–\u00c9mery curvature condition yields a uniform log–Sobolev inequality and spectral gap, providing a fully rigorous test case for the dynamic route.
- A **stochastic/dynamic formulation** of Yang–Mills via Langevin (stochastic quantization), focusing on **spectral gaps of the generator** and their relation to the physical mass gap.
- A **UV “Log–Forest” hypothesis** for gradient norms of gauge-invariant observables (Wilson loops), ensuring that the Dirichlet form is not destroyed by uncontrolled UV roughness.
- A **toy RG–Hessian / curvature-flow picture**, where the trace anomaly acts as a positive curvature source in a viscous Hamilton–Jacobi flow for the effective action.
- A **stratified Sobolev framework** on the singular gauge quotient \(\mathcal{A}/\mathcal{G}\), including a rigorous definition of \(W^{1,2}(\mathcal{A}/\mathcal{G})\) and a Gaussian-reference polarity theorem (plus Conjecture C for the full YM measure) showing that reducible strata can be treated as capacity-zero.
- A **constructive lattice YM component** (in the spirit of Faria da Veiga & O’Carroll) where:
  - the Hilbert space is rigorously decomposed into **charge-conjugation (“polarity”) sectors** \(\mathcal{H} = \mathcal{H}^+ \oplus \mathcal{H}^-\) for \(SU(N>2)\),
  - the **Haar measure** is shown to generate an effective local mass term (“mass from geometry”),
  - and **two positive mass gaps** \(\Delta^\pm\) are established at finite lattice spacing.

The program does **not** claim a full Clay-level proof. Instead it:

1. Makes explicit which steps are **formal** and which are **conjectural**.  
2. Identifies a precise **local-sector spectral gap** that should correspond to the physical mass gap, separating it from ultra-slow topological modes.  
3. States a set of named conjectures (A, B, C, IR–1/2, D) whose resolution would turn this architecture into a rigorous solution.

---



# Part V – Stratified Sobolev Space and Polarity of Reducible Connections (Conjecture C)

## 5.1. Configuration Space and Gauge Quotient

Let \(P\to M\) be a principal \(G\)-bundle over a compact 4D Riemannian manifold \(M\), \(G\) compact (e.g. \(SU(3)\)). The space of smooth connections is
\[
\mathcal{A} \cong A_0 + \Omega^1(M,\mathrm{ad}\,P),
\]
an affine space modeled on a Sobolev space.

The gauge group \(\mathcal{G}\) acts by
\[
A^g = g^{-1}Ag + g^{-1}dg.
\]
The gauge-orbit space is
\[
\mathcal{M} = \mathcal{A}/\mathcal{G}.
\]

\(\mathcal{M}\) is **stratified**:

- The **principal (regular) stratum** \(\mathcal{M}_{\mathrm{reg}}\): irreducible connections whose stabilizer is exactly the center \(Z(G)\). This is an infinite-dimensional smooth manifold.
- The **singular set** \(\Sigma\): reducible connections with larger stabilizers; this is a union of lower-dimensional strata.

We equip \(\mathcal{M}\) with a metric induced from \(\mathcal{A}\) via orbital distance, and a probability measure \(\mu\) arising from the YM action (e.g. a continuum limit of lattice measures).

## 5.2. Horizontal Gradient and Sobolev Space \(W^{1,2}(\mathcal{M})\)

Let \(\mathcal{F}_{\mathrm{cyl}}\) be the algebra of **gauge-invariant cylindrical functionals** \(F\) that depend on finitely many holonomies, Wilson loops, or smeared fields.

Each \(F\in\mathcal{F}_{\mathrm{cyl}}\) lifts to a function on \(\mathcal{A}\) satisfying
\[
F(A^g) = F(A)\quad \forall g\in\mathcal{G}.
\]

The usual gradient \(\nabla_{\mathcal{A}} F(A)\) decomposes into:

- Vertical component tangent to the gauge orbit:
  \[
  V_A = \{D_A \omega\mid \omega\in \mathrm{Lie}(\mathcal{G})\},
  \]
- Horizontal component orthogonal to \(V_A\) in \(L^2(M,\mathrm{ad}\,P)\).

Gauge invariance implies \(\nabla_{\mathcal{A}} F(A)\) is orthogonal to \(V_A\) for all \(A\), i.e. it is **horizontal**. We define the **horizontal gradient**
\[
\nabla_H F(A) := \nabla_{\mathcal{A}} F(A),
\]
viewed as a vector in a chosen horizontal complement to \(V_A\).

We then define the Sobolev norm
\[
\|F\|_{W^{1,2}(\mathcal{M},\mu)}^2
:= \int_{\mathcal{A}} |F(A)|^2\,d\mu(A)
   + \int_{\mathcal{A}} \|\nabla_H F(A)\|^2\,d\mu(A),
\]
and take the closure of \(\mathcal{F}_{\mathrm{cyl}}\) under this norm to obtain \(W^{1,2}(\mathcal{M},\mu)\).

The associated Dirichlet form is
\[
\mathcal{E}(F,F) = \int_{\mathcal{A}} \|\nabla_H F(A)\|^2\,d\mu(A),
\]
which is the infinite-dimensional analogue of \(\int |\nabla f|^2 d\mu\) in Part IV.

## 5.3. Reducible Connections and Infinite Codimension

A connection \(A\) is **reducible** if its stabilizer
\[
\Gamma_A = \{g\in\mathcal{G} \mid A^g = A\}
\]
is larger than \(Z(G)\). Infinitesimally, there exists a nonzero \(\xi\in\Omega^0(M,\mathrm{ad}\,P)\) such that
\[
D_A \xi = 0,
\]
i.e. \(\xi\) is **covariantly constant**.

Applying \(D_A\) again and using \([D_\mu,D_\nu] = \mathrm{ad}_{F_{\mu\nu}}\), we obtain
\[
[F_{\mu\nu}(x),\xi(x)] = 0 \quad \forall x\in M.
\]

Thus, at each point, the curvature \(F_{\mu\nu}(x)\) lies in the **centralizer** of \(\xi(x)\), a proper Lie subalgebra of \(\mathfrak{g}\).

For each fixed nonzero \(\xi\), define
\[
\Sigma_\xi = \{A\in \mathcal{A} \mid D_A\xi=0\},
\quad
\Sigma = \bigcup_{\xi\neq 0}\Sigma_\xi.
\]

Heuristically:

- \(D_A\xi=0\) is a first-order linear PDE in \(A\) with infinitely many independent constraints (at each Fourier mode).
- The solution space \(\Sigma_\xi\) is a **Fréchet submanifold of infinite codimension** in \(\mathcal{A}\).
- Thus \(\Sigma\) is a countable union of infinite-codimension submanifolds.

In loose terms: asking a non-Abelian 4D field to have a covariantly constant adjoint direction everywhere forces it to behave like an Abelian field along \(\xi\) at all points, losing infinitely many degrees of freedom.



> **Lemma 5.3.1 ((H_{\xi\xi}) infinite-rank commutator map).**  
> Let \(M\) be a compact 4‑manifold, \(P\to M\) a principal \(G\)–bundle with \(G\) compact semisimple (e.g. \(SU(N)\)), and let
> \[
> H := L^2_k\big(M, T^*M\otimes\mathrm{ad}\,P\big),\qquad
> H' := L^2_{k-1}\big(M, T^*M\otimes\mathrm{ad}\,P\big),
> \]
> with \(k>2\). Let \(\xi\in L^2_k(M,\mathrm{ad}\,P)\) be nonzero and covariantly constant with respect to a background connection \(A_0\), i.e. \(D_{A_0}\xi=0\). Consider the bounded linear map
> \[
>   T_\xi : H \to H',\qquad a\mapsto [a,\xi],
> \]
> where the bracket is taken fiberwise in \(\mathrm{ad}\,P\) and extended to \(T^*M\otimes\mathrm{ad}\,P\) by bilinearity. Then \(T_\xi\) has infinite rank; in particular, its kernel has infinite codimension in \(H\).
>
> *Proof.* Because \(k>2\) in four dimensions, Sobolev embedding gives a continuous injection
> \[
> L^2_k(M,\mathrm{ad}\,P)\hookrightarrow C^0(M,\mathrm{ad}\,P),
> \]
> so \(\xi\) has a continuous representative. In particular, there exists a point \(x_0\in M\) with \(\xi(x_0)\neq 0\).
>
> Let \(\mathfrak{g}=\mathrm{Lie}(G)\), and consider \(\mathrm{ad}_{\xi(x_0)}:\mathfrak{g}\to\mathfrak{g}\), \(Y\mapsto [Y,\xi(x_0)]\). Since \(\mathfrak{g}\) is semisimple, its center is zero, so any nonzero element is noncentral. In particular, \(\xi(x_0)\neq 0\) implies \(\mathrm{ad}_{\xi(x_0)}\neq 0\), so there exists \(Y_0\in\mathfrak{g}\) with \([Y_0,\xi(x_0)]\neq 0\).
>
> Using the adjoint bundle \(\mathrm{ad}\,P\to M\), choose a smooth section \(Y\in C^\infty(M,\mathrm{ad}\,P)\) such that \(Y(x_0)=Y_0\). Define
> \[
> Z := [Y,\xi]\in C^0(M,\mathrm{ad}\,P).
> \]
> This is well defined because both \(Y\) and \(\xi\) are continuous and the bracket is bilinear and continuous fiberwise. At the point \(x_0\) we have
> \[
> Z(x_0) = [Y(x_0),\xi(x_0)] = [Y_0,\xi(x_0)]\neq 0.
> \]
> By continuity, there exists an open neighbourhood \(U\subset M\) of \(x_0\) such that \(Z(x)\neq 0\) for all \(x\in U\); shrinking \(U\) if necessary, we may assume \(|Z(x)|\ge c>0\) on \(U\).
>
> Since \(U\subset M\) is a nonempty open set, we can find infinitely many pairwise disjoint open subsets inside \(U\). Fix a Riemannian metric on \(M\). Choose radii \(0<r_{n+1}<r_n\) with \(r_n\downarrow 0\), small enough that the closed ball \(\overline{B(x_0,r_1)}\) is contained in \(U\). For each \(n\), set
> \[
> U_n := \{x\in M : r_{n+1} < d(x,x_0) < r_n\}.
> \]
> Then each \(U_n\) is open, \(U_n\subset U\), and the family \((U_n)_{n\ge 1}\) is pairwise disjoint.
>
> Because each \(U_n\) is a nonempty open set, we can choose a smooth 1‑form \(\alpha_n\in C_c^\infty(M,T^*M)\) such that \(\mathrm{supp}\,\alpha_n\subset U_n\) and \(\alpha_n\not\equiv 0\). Rescaling if needed, we may assume \(\|\alpha_n\|_{L^2_k(M)}=1\).
>
> Define
> \[
> a_n := \alpha_n\otimes Y \in C_c^\infty\big(M,T^*M\otimes\mathrm{ad}\,P\big)\subset H.
> \]
> Each \(a_n\) is smooth with compact support in \(U_n\), hence belongs to \(H=L^2_k(M,T^*M\otimes\mathrm{ad}\,P)\).
>
> Compute the image under \(T_\xi\):
> \[
> T_\xi(a_n) = [a_n,\xi]
> = [\alpha_n\otimes Y,\xi]
> = \alpha_n\otimes [Y,\xi]
> = \alpha_n\otimes Z.
> \]
> Two properties are immediate:
>
> 1. **Support:** \(\mathrm{supp}\,T_\xi(a_n) \subset \mathrm{supp}\,\alpha_n\subset U_n\). Thus the supports of the family \(\{T_\xi(a_n)\}\) are pairwise disjoint.
> 2. **Nonvanishing:** On \(U_n\subset U\) we have \(Z(x)\neq 0\), and by construction \(\alpha_n\not\equiv 0\), so \(T_\xi(a_n)=\alpha_n\otimes Z\not\equiv 0\). Hence each \(T_\xi(a_n)\) is a nonzero element of \(H'\).
>
> Equip \(H'\) with the \(L^2_{k-1}\) inner product induced by the Riemannian metric on \(T^*M\) and the \(G\)–invariant inner product on \(\mathfrak{g}\). Because the supports of distinct \(T_\xi(a_n)\) are disjoint, we have
> \[
> \langle T_\xi(a_m), T_\xi(a_n)\rangle_{L^2}
> = \int_M \langle \alpha_m\otimes Z,\ \alpha_n\otimes Z\rangle\,\mathrm{dvol}
> = 0\quad\text{for }m\neq n.
> \]
> Thus \(\{T_\xi(a_n)\}_{n\ge 1}\) is an infinite family of pairwise orthogonal, nonzero vectors in \(H'\). In particular, the (algebraic) span of \(\{T_\xi(a_n)\}\) is infinite dimensional, so \(\dim(\mathrm{Ran}\,T_\xi)=\infty\). That is, \(T_\xi\) has infinite rank.
>
> Finally, in a Hilbert space \(H\) the quotient \(H/\ker T_\xi\) is isomorphic to the closure of \(\mathrm{Ran}\,T_\xi\). Since \(\overline{\mathrm{Ran}\,T_\xi}\) is infinite dimensional, we have
> \[
> \dim(H/\ker T_\xi) = \dim\overline{\mathrm{Ran}\,T_\xi} = \infty,
> \]
> i.e. \(\ker T_\xi\) has infinite codimension in \(H\). ∎


Each reducibility type \(H\) gives rise to a stratum \(\Sigma_H\) of connections whose holonomy reduces to \(H\), and stratification theory shows that
\[
  \Sigma = igcup_H \Sigma_H
  \subset igcup_H ig(A_0 + S_Hig),
\]
with each \(S_H\) of infinite codimension in the ambient Hilbert space \(H\). This provides a structural realization of Assumption H.4: reducible connections live in a countable union of affine subspaces that miss infinitely many directions, consistent with the infinite-rank commutator lemma above.



## 5.4. Capacity and Polarity (Conjecture C)

For a Dirichlet form \((\mathcal{E},\mathcal{D}(\mathcal{E}))\) on a measure space \((\mathcal{X},\mu)\), the **capacity** of a set \(E\subset\mathcal{X}\) is
\[
\mathrm{Cap}(E)
= \inf\Big\{
  \mathcal{E}(u,u) + \int u^2 d\mu\;\Big|\;
  u\in\mathcal{D}(\mathcal{E}),\ u\ge 1\ \text{on an open set containing }E
\Big\}.
\]

A set \(E\) is **polar** if \(\mathrm{Cap}(E)=0\). For the associated Markov process \(X_t\), polar sets are almost surely avoided.

In finite dimensions, for Brownian/OU processes:

- Affine subspaces of codimension \(\ge 3\) have zero capacity.
- Codimension-1 hypersurfaces have positive capacity.

In infinite dimensions, infinite-codimension sets are not automatically polar; polarity depends delicately on the specific Dirichlet form and measure.
For Gaussian reference measures, many natural infinite-codimension linear subspaces are polar, but there are important counterexamples in more general settings.

For the YM Dirichlet form on \(\mathcal{A}\) (or \(\mathcal{M}\)), we therefore formulate polarity of \(\Sigma\) as a conjecture rather than a consequence of codimension alone:

> **Conjecture C (Polarity of Reducibles and Singular Strata).**  
> The set of reducible connections \(\Sigma\subset\mathcal{A}\) (and its projection in \(\mathcal{M}\)) has capacity zero with respect to the YM Dirichlet form:
> \[
> \mathrm{Cap}(\Sigma)=0.
> \]
> Hence, the Langevin process almost surely never hits \(\Sigma\), and the singular strata of \(\mathcal{M}\) are dynamically and analytically negligible.

A plausible proof strategy:

1. Prove polarity for \(\Sigma\) relative to a Gaussian reference measure \(\mu_0\) (OU process on \(\mathcal{A}\)).  
2. Show that the YM measure \(\mu\) is absolutely continuous with respect to \(\mu_0\) with a density in a suitable Kato/Novikov class.  
3. Use general results on quasi-regular Dirichlet forms to transfer the capacity-zero property from \(\mu_0\) to \(\mu\).

This is nontrivial and currently heuristic; it is one of the key analytic gaps to be filled.

---



# Appendix H – Polarity of Reducible Connections: Gaussian and Capacity Lemmas

**Objective.**  
Show that the set of reducible connections \(\Sigma\) is polar (capacity zero) for a suitable reference Dirichlet form, and isolate precise hypotheses under which this polarity transfers to the Yang–Mills Dirichlet form. This justifies ignoring \(\Sigma\) in the Dirichlet domain and working on the regular stratum \(\mathcal{M}_{\mathrm{reg}}\) without boundary conditions.

We proceed in three steps:

1. Correct finite-dimensional intuition (codimension vs polarity).  
2. Infinite-dimensional Gaussian result: infinite-codimension linear subspaces are polar.  
3. Capacity comparison under change of measure.

## H.1 Finite-Dimensional Warm-up: Subspaces vs Polarity

Let \((B_t)_{t\ge 0}\) be standard Brownian motion in \(\mathbb{R}^n\). Let \(S\subset \mathbb{R}^n\) be a linear subspace of codimension \(m\):
\[
\dim S = n-m,\qquad \dim S^\perp = m.
\]

Decompose \(B_t = (Y_t,Z_t)\) with \(Y_t\in S\), \(Z_t\in S^\perp\simeq \mathbb{R}^m\). Then
\[
\{B_t\in S\} \iff \{Z_t = 0\}.
\]

For Brownian motion in \(\mathbb{R}^m\), the hitting probability of a point obeys:

- \(m = 1\): a fixed point is hit with probability 1.  
- \(m \ge 3\): a fixed point is hit with probability 0.

Thus:

> **Lemma H.1.**  
> Let \(S\subset\mathbb{R}^n\) be a linear subspace of codimension \(m\). Then
> - If \(m \le 2\), Brownian motion hits \(S\) with positive probability.  
> - If \(m \ge 3\), Brownian motion almost surely never hits \(S\); \(S\) has capacity zero for the Brownian Dirichlet form.

The correct finite-dimensional rule is therefore:

> Linear subspaces of codimension \(\ge 3\) are polar; codimension 0, 1, or 2 is not enough.

This will serve as the template for the infinite-dimensional case, where “infinite codimension” plays the role of “\(\ge 2\)”.

## H.2 Infinite-Dimensional Gaussian OU Polarity

Let \(H\) be a separable real Hilbert space with inner product \(\langle\cdot,\cdot\rangle_H\). Let \(\gamma\) be a centered, nondegenerate Gaussian measure on \(H\), and let \((X_t)_{t\ge 0}\) be the Ornstein–Uhlenbeck process
\[
dX_t = -X_t\,dt + \sqrt{2}\,dW_t,
\]
with invariant law \(\gamma\). The associated Dirichlet form is
\[
\mathcal{E}_0(f,f)
= \int_H \|\nabla f(x)\|_H^2\,d\gamma(x),
\quad
f\in W^{1,2}(H,\gamma).
\]

We say a set \(E\subset H\) is *polar* (for \(\gamma\) and \(\mathcal{E}_0\)) if, for \(\gamma\)-a.e. starting point \(x\),
\[
\mathbb{P}_x\big(\exists t>0 : X_t\in E\big) = 0.
\]

> **Proposition H.2 (Gaussian OU polarity for linear subspaces).**  
> Let \(S\subset H\) be a closed linear subspace.
> 1. If \(\operatorname{codim}(S) = m < \infty\), then:
>    - for \(m \le 1\), \(S\) is nonpolar (hit with positive probability);  
>    - for \(m \ge 2\), \(S\) is polar (almost surely never hit).
> 2. If \(\operatorname{codim}(S) = \infty\), then \(S\) is polar.

*Sketch of proof.*

**Finite codimension.**  
Assume \(\operatorname{codim}(S) = m < \infty\). Then \(H = S \oplus N\) with \(N\simeq \mathbb{R}^m\). Under \(\gamma\), the components in \(S\) and \(N\) are independent Gaussians; the OU process decomposes
\[
X_t = Y_t + Z_t,
\quad
Y_t\in S,\quad Z_t\in N.
\]
As in the warm-up,
\[
\{X_t\in S\} \iff \{Z_t=0\}.
\]
The process \(Z_t\) is an \(m\)-dimensional OU process; its hitting behavior of \(0\) is identical to Brownian’s up to drift, giving positive hitting probability for \(m\le 1\) and zero for \(m\ge 2\).

**Infinite codimension.**  
Assume \(\operatorname{codim}(S)=\infty\). Choose an orthonormal basis \((e_j)_{j\ge 1}\) of \(S^\perp\), and define
\[
N_N := \mathrm{span}\{e_1,\dots,e_N\},
\quad
S_N := (N_N)^\perp.
\]
Then:
- \(\operatorname{codim}(S_N) = N\),
- \(S \subset S_{N+1} \subset S_N\) for all \(N\),
- \(\bigcap_{N\ge 1} S_N = S\).

By the finite-codimension case, each \(S_N\) with \(N\ge 3\) is polar for OU:
\[
\mathbb{P}_x\big(\exists t>0: X_t\in S_N\big) = 0.
\]
If a path hits \(S\), it also lies in every \(S_N\):
\[
\{\exists t>0: X_t\in S\}
\subseteq
\{\exists t>0: X_t\in S_N\}.
\]
Thus for all \(N\ge 2\),
\[
\mathbb{P}_x\big(\exists t>0: X_t\in S\big)
\le
\mathbb{P}_x\big(\exists t>0: X_t\in S_N\big)
= 0,
\]
so \(\mathbb{P}_x(\exists t>0: X_t\in S)=0\) for \(\gamma\)-a.e. \(x\). ∎

**Interpretation.**  
Any closed linear subspace that “misses infinitely many directions” (infinite codimension) is invisible to the Gaussian OU process: trajectories almost surely never lie exactly in it. This is the rigorous version of the heuristic “infinite codimension ⇒ capacity zero” for the Gaussian reference model.

## H.3 Capacity under Change of Measure

We now recall a general principle from the theory of (quasi-)regular Dirichlet forms: **capacity is stable under sufficiently integrable changes of measure**. This allows us to transfer polarity results from a Gaussian reference measure to the Yang–Mills measure without requiring unrealistically strong pointwise bounds on the density.

Let \((X,\mathcal{B})\) be a measurable space, and \(\mu_0,\mu\) two probability measures with
\[
  
rac{d\mu}{d\mu_0} = 
ho.
\]
Assume:

- \(
ho \in L^p(\mu_0)\) and \(
ho^{-1} \in L^q(\mu_0)\) for some Hölder conjugate pair \(p,q>1\) (\(1/p+1/q=1\));  
- The two Dirichlet forms share the same carré du champ \(\Gamma\), but are integrated against different reference measures:
  \[
    \mathcal{E}_0(f,f) = \int_X \Gamma(f)\,d\mu_0,
    \qquad
    \mathcal{E}(f,f) = \int_X \Gamma(f)\,d\mu.
  \]
- Both \((\mathcal{E}_0,\mu_0)\) and \((\mathcal{E},\mu)\) are quasi-regular.

Define the (1,2)-capacity associated with \((\mathcal{E}_0,\mu_0)\) and \((\mathcal{E},\mu)\) by
\[
  \mathrm{Cap}_{\mu_0}(E)
  = \inf\Big\{
    \mathcal{E}_0(u,u) + \int u^2\,d\mu_0
    \,\Big|\,
    u\in\mathcal{D}(\mathcal{E}_0),\ u\ge 1\ 	ext{on an open set containing }E
  \Big\},
\]
and similarly for \(\mathrm{Cap}_\mu\) with \((\mathcal{E},\mu)\).

> **Lemma H.3 (Capacity equivalence under \(L^p\) density).**  
> Under the assumptions above, there exist constants \(0<c_1\le c_2<\infty\) such that for all Borel sets \(E\subset X\),
> \[
>   c_1\,\mathrm{Cap}_{\mu_0}(E)
>   \;\le\; \mathrm{Cap}_\mu(E)
>   \;\le\; c_2\,\mathrm{Cap}_{\mu_0}(E).
> \]
> In particular, a set \(E\) is polar for \((\mathcal{E}_0,\mu_0)\) if and only if it is polar for \((\mathcal{E},\mu)\).

*Sketch of proof.*  
This is a standard consequence of the general perturbation theory for Dirichlet forms (e.g. Ma–Röckner). The \(L^p\) and \(L^q\) assumptions imply that \(\mu\) and \(\mu_0\) are mutually absolutely continuous and that the norms
\[
  \|u\|_{1,2,\mu_0}^2 := \mathcal{E}_0(u,u)+\int u^2\,d\mu_0,
  \qquad
  \|u\|_{1,2,\mu}^2 := \mathcal{E}(u,u)+\int u^2\,d\mu
\]
are equivalent on a common core \(\mathcal{D}\subset\mathcal{D}(\mathcal{E}_0)\cap\mathcal{D}(\mathcal{E})\). Equivalence of these norms implies equivalence of capacities defined by taking infima of \(\|u\|_{1,2,\mu_0}^2\) and \(\|u\|_{1,2,\mu}^2\) over the same admissible class \(u\ge 1\) on an open neighbourhood of \(E\). The polar set equivalence follows immediately. ∎

**Interpretation.**  
Polarity is therefore stable under **integrable** changes of measure: the YM measure can differ from a Gaussian reference by an interaction weight \(
ho\) that is only \(L^p\)-integrable (and whose reciprocal is \(L^q\)-integrable), as expected in constructive QFT. Uniform pointwise bounds on \(
ho\) are not needed. This is the analytic mechanism behind Conjecture C once suitable \(L^p\)-control on the YM interaction relative to the Gaussian reference is established.
## H.4 Application to Reducible Connections

Let \(\mathcal{A}\) be a Sobolev completion of the space of gauge potentials, and model it as a Hilbert space \(H\). Let \(\gamma\) be a Gaussian reference measure on \(H\) (e.g. free-field Gaussian), with OU process and Dirichlet form \((\mathcal{E}_0,\gamma)\) as in Section H.2. Let \(\mu\) be the Euclidean YM measure (once constructed), with Dirichlet form \((\mathcal{E},\mu)\) corresponding to the YM Langevin generator.

Denote by \(\Sigma\subset H\) the set of reducible connections, i.e. those admitting a nontrivial covariantly constant adjoint field:
\[
\Sigma
:= \{A\in H : \exists\,\xi\neq 0\ \text{with } D_A\xi = 0\}.
\]

We now state a geometric embedding assumption and its analytic consequences.

> **Assumption H.4 (Infinite-codimension embedding of reducibles).**  
> For each reducibility type (e.g. each nontrivial stabilizer \(H\subset G\)), there exists a closed linear subspace \(S_H\subset H\) such that:
> 1. The subset of connections with stabilizer \(H\) is contained in an affine translate:
>    \[
>    \Sigma_H \subset A_0 + S_H,
>    \]
>    for some fixed \(A_0\).  
> 2. \(\operatorname{codim}(S_H) = \infty\).
> 
> Then
> \[
> \Sigma = \bigcup_H \Sigma_H \subset \bigcup_H (A_0 + S_H).
> \]
> 
> In words: each reducible stratum lies inside an affine subspace that misses infinitely many directions.

This is a geometric claim about the solution set of \(D_A\xi = 0\) in a given Sobolev gauge model; verifying it is the nontrivial PDE step in the Polarity program.

> **Corollary H.5 (Polarity of \(\Sigma\) for the Gaussian reference).**  
> Under Assumption H.4, the reducible set \(\Sigma\) has capacity zero with respect to the Gaussian OU Dirichlet form \((\mathcal{E}_0,\gamma)\):
> \[
> \mathrm{Cap}_\gamma(\Sigma) = 0.
> \]

*Proof.*  
Each affine translate \(A_0+S_H\) has the same codimension as \(S_H\). By Assumption H.4, \(\operatorname{codim}(S_H) = \infty\), so Proposition H.2 implies that each \(A_0+S_H\) is polar for OU. A countable union of polar sets is polar, so \(\mathrm{Cap}_\gamma(\Sigma)=0\). ∎

> **Corollary H.6 (Polarity for the Yang–Mills Dirichlet form).**  
> Assume in addition that the YM measure \(\mu\) is absolutely continuous with respect to \(\gamma\) with a density \(\rho\) satisfying \(0<c_1 \le \rho \le c_2 <\infty\) on the relevant Sobolev configuration space, and that the carré du champ is the same for \(\mathcal{E}_0\) and \(\mathcal{E}\). Then
> \[
> \mathrm{Cap}_\mu(\Sigma) = 0.
> \]

*Proof.*  
By Corollary H.5, \(\mathrm{Cap}_\gamma(\Sigma) = 0\). By Lemma H.3 (capacity comparison), \(\mathrm{Cap}_\mu(\Sigma)=0\) if and only if \(\mathrm{Cap}_\gamma(\Sigma)=0\). ∎

**Conclusion.**  
Under Assumption H.4 and a controlled change-of-measure condition between a Gaussian reference and the YM measure, the reducible set \(\Sigma\) is polar for the YM Dirichlet form. In particular:

- The YM Langevin process almost surely never reaches \(\Sigma\).  
- \(\Sigma\) can be removed from the state space without affecting the Dirichlet form or its self-adjointness.  
- All functional inequalities and spectral properties may be formulated on the regular stratum \(\mathcal{M}_{\mathrm{reg}}\) without boundary conditions at \(\Sigma\).

This is the precise form of the Polarity Condition in the Dirichlet-form framework: reducible connections are too thin (in infinite codimension, relative to a Gaussian reference) to matter for the stochastic analysis.

---

## 6. Finite-Cutoff Lattice Polarity (Summary)

In the finite-cutoff (lattice) setting, the analogue of Conjecture C is now rigorously established.

For a finite hypercubic lattice \(\Lambda\subset\mathbb{Z}^4\) with gauge group \(SU(N)\), configuration space \(\Omega = SU(N)^{\mathcal{B}}\), and product Haar measure \(\mu_H\), the set \(\Sigma_\Lambda\) of reducible configurations:

- Lies in a countable union of smooth embedded submanifolds of \(\Omega\) of codimension \(\ge 2\).

For the product Brownian/OU diffusion on \(\Omega\), with generator \(L_0 = \sum_{b\in\mathcal{B}}\Delta_{G,b}\) and invariant measure \(\mu_H\), standard diffusion potential theory implies that any smooth submanifold of codimension \(\ge 3\) is polar. Using subadditivity of capacity, one concludes
\[
\mathrm{Cap}_{\mu_H}(\Sigma_\Lambda)=0.
\]

The lattice Yang–Mills Gibbs measure \(\mu_{\Lambda,\mathrm{YM}}\) with Wilson action is absolutely continuous w.r.t. \(\mu_H\) with a bounded density. A one-sided capacity comparison then yields
\[
\mathrm{Cap}_{\mu_{\Lambda,\mathrm{YM}}}(\Sigma_\Lambda)=0
\]
as well. Thus, at finite cutoff, reducible configurations are polar for both the Haar-OU and lattice YM Dirichlet forms.

A detailed finite-dimensional proof, including codimension estimates and the explicit construction of the relevant submanifolds, is given in the separate lattice polarity note
`Rigorous Proof_ Polarity of Reducible Connections in Lattice Yang-Mills.md`
and summarized analytically in `YM_MassGap_DocC_ConjectureC_Extended_v3.md`.