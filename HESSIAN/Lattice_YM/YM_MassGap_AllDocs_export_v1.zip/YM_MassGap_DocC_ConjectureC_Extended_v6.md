# Extended Derivations for Conjecture C (Polarity of Reducible Connections)

**Document:** YM\_MassGap\_DocC\_ConjectureC\_Extended  
**Role:** Complete technical note on Conjecture C, consolidating and extending the polarity analysis around Doc C.

This document integrates:

- A refined Gaussian polarity theorem (including codimension \(m=3\) threshold).
- A minimal capacity‑transfer theorem for YM‑type measures.
- Holonomy‑based discussion of Assumption H.4.
- Finite‑cutoff and lattice variants.
- An explicit list of lemma‑level tasks for LLM work.

It is designed to be read alongside `YM_MassGap_DocC_StratifiedSobolev_Polarity_v3.md`, but is self‑contained as far as possible.

---

## A. Gaussian Polarity Recap (Refined)

### A.1. Configuration space, Gaussian reference, and Dirichlet form

- \(M\): compact 4‑manifold.
- \(P\to M\): principal \(G\)–bundle, \(G\) compact, e.g. \(SU(N)\).
- Sobolev configuration space:
  \[
  \mathcal{A} \cong A_0 + \Omega^1_k(M,\mathrm{ad}P),
  \quad k>2.
  \]
  Denote the model Hilbert space by
  \[
  H := \Omega^1_k(M,\mathrm{ad}P).
  \]

Let \(\mu_0\) be a centered, nondegenerate Gaussian measure on \(H\), typically with covariance a negative power of an elliptic operator (e.g. \((1+\Delta)^{-r}\)). The associated Ornstein–Uhlenbeck (OU) Dirichlet form on \(L^2(\mathcal{A},\mu_0)\) is
\[
\mathcal{E}_0(f,f) = \int_\mathcal{A} \|\nabla f(A)\|_H^2\,d\mu_0(A),
\]
initially on smooth cylindrical functionals.

The OU process \(X_t\) on \(H\) with invariant law \(\mu_0\) is quasi‑regular and symmetric.

### A.2. Reducible set and linearization

Define the reducible set
\[
\Sigma := \{A\in\mathcal{A} : \exists\,0\neq\xi\in \Omega^0(M,\mathrm{ad}P)\ \text{s.t.}\ D_A\xi=0\}.
\]

For each nonzero \(\xi\), define
\[
\Sigma_\xi := \{A\in\mathcal{A} : D_A\xi=0\}, \quad \Sigma = \bigcup_{\xi\neq 0} \Sigma_\xi.
\]

Linearize near a smooth background \(A_0\). Setting \(A = A_0 + a\),
\[
D_A\xi = D_{A_0}\xi + [a,\xi] = 0.
\]
For a fixed covariantly constant \(\xi\) with \(D_{A_0}\xi=0\), this reduces to
\[
[a,\xi] = 0.
\]

Define the commutator map
\[
T_\xi : H\to H', \quad T_\xi(a) = [a,\xi],
\]
where \(H' := \Omega^1_{k-1}(M,\mathrm{ad}P)\). The key geometric lemma (proved in Doc C and expanded here) is:


> **Lemma A.1 (Infinite rank of \(T_\xi\)).**  
> Let \(M\) be a compact 4‑manifold, \(P\to M\) a principal \(G\)–bundle with \(G\) compact and semisimple (e.g. \(SU(N)\)), and let
> \[
> H := L^2_k\big(M, T^*M\otimes\mathrm{ad}\,P\big),\qquad
> H' := L^2_{k-1}\big(M, T^*M\otimes\mathrm{ad}\,P\big),
> \]
> with \(k>2\). Let \(\xi\in L^2_k(M,\mathrm{ad}\,P)\) be nonzero and covariantly constant with respect to a background connection \(A_0\), i.e. \(D_{A_0}\xi=0\). Consider the bounded linear map
> \[
> T_\xi : H \to H',\qquad a\mapsto [a,\xi],
> \]
> where the bracket is taken fiberwise in \(\mathrm{ad}\,P\) and extended to \(T^*M\otimes\mathrm{ad}\,P\) by bilinearity. Then \(T_\xi\) has infinite rank; in particular, its kernel has infinite codimension in \(H\).
>
> *Proof.* Because \(k>2\) in four dimensions, Sobolev embedding gives a continuous injection
> \[
> L^2_k(M,\mathrm{ad}\,P)\hookrightarrow C^0(M,\mathrm{ad}\,P),
> \]
> so \(\xi\) has a continuous representative. In particular, there exists a point \(x_0\in M\) with \(\xi(x_0)\neq 0\).
>
> Let \(\mathfrak{g}=\mathrm{Lie}(G)\), and consider \(\mathrm{ad}_{\xi(x_0)}:\mathfrak{g}\to\mathfrak{g}\), \(Y\mapsto [Y,\xi(x_0)]\). Since \(\mathfrak{g}\) is semisimple, its center is zero, so any nonzero element is noncentral. In particular, \(\xi(x_0)\neq 0\) implies \(\mathrm{ad}_{\xi(x_0)}\neq 0\), so there exists \(Y_0\in\mathfrak{g}\) with \([Y_0,\xi(x_0)]\neq 0\).
>
> Using the adjoint bundle \(\mathrm{ad}\,P\to M\), choose a smooth section \(Y\in C^\infty(M,\mathrm{ad}\,P)\) such that \(Y(x_0)=Y_0\). Define
> \[
> Z := [Y,\xi]\in C^0(M,\mathrm{ad}\,P).
> \]
> This is well defined because both \(Y\) and \(\xi\) are continuous and the bracket is bilinear and continuous fiberwise. At the point \(x_0\) we have
> \[
> Z(x_0) = [Y(x_0),\xi(x_0)] = [Y_0,\xi(x_0)]\neq 0.
> \]
> By continuity, there exists an open neighbourhood \(U\subset M\) of \(x_0\) such that \(Z(x)\neq 0\) for all \(x\in U\); shrinking \(U\) if necessary, we may assume \(|Z(x)|\ge c>0\) on \(U\).
>
> Since \(U\subset M\) is a nonempty open set, we can find infinitely many pairwise disjoint open subsets inside \(U\). Fix a Riemannian metric on \(M\). Choose radii \(0<r_{n+1}<r_n\) with \(r_n\downarrow 0\), small enough that the closed ball \(\overline{B(x_0,r_1)}\) is contained in \(U\). For each \(n\), set
> \[
> U_n := \{x\in M : r_{n+1} < d(x,x_0) < r_n\}.
> \]
> Then each \(U_n\) is open, \(U_n\subset U\), and the family \((U_n)_{n\ge 1}\) is pairwise disjoint.
>
> Because each \(U_n\) is a nonempty open set, we can choose a smooth 1‑form \(\alpha_n\in C_c^\infty(M,T^*M)\) such that \(\mathrm{supp}\,\alpha_n\subset U_n\) and \(\alpha_n\not\equiv 0\). Rescaling if needed, we may assume \(\|\alpha_n\|_{L^2_k(M)}=1\).
>
> Define
> \[
> a_n := \alpha_n\otimes Y \in C_c^\infty\big(M,T^*M\otimes\mathrm{ad}\,P\big)\subset H.
> \]
> Each \(a_n\) is smooth with compact support in \(U_n\), hence belongs to \(H=L^2_k(M,T^*M\otimes\mathrm{ad}\,P)\).
>
> Compute the image under \(T_\xi\):
> \[
> T_\xi(a_n) = [a_n,\xi]
> = [\alpha_n\otimes Y,\xi]
> = \alpha_n\otimes [Y,\xi]
> = \alpha_n\otimes Z.
> \]
> Two properties are immediate:
>
> 1. **Support:** \(\mathrm{supp}\,T_\xi(a_n) \subset \mathrm{supp}\,\alpha_n\subset U_n\). Thus the supports of the family \(\{T_\xi(a_n)\}\) are pairwise disjoint.
> 2. **Nonvanishing:** On \(U_n\subset U\) we have \(Z(x)\neq 0\), and by construction \(\alpha_n\not\equiv 0\), so \(T_\xi(a_n)=\alpha_n\otimes Z\not\equiv 0\). Hence each \(T_\xi(a_n)\) is a nonzero element of \(H'\).
>
> Equip \(H'\) with the \(L^2_{k-1}\) inner product induced by the Riemannian metric on \(T^*M\) and the \(G\)–invariant inner product on \(\mathfrak{g}\). Because the supports of distinct \(T_\xi(a_n)\) are disjoint, we have
> \[
> \langle T_\xi(a_m), T_\xi(a_n)\rangle_{L^2}
> = \int_M \langle \alpha_m\otimes Z,\ \alpha_n\otimes Z\rangle\,\mathrm{dvol}
> = 0\quad\text{for }m\neq n.
> \]
> Thus \(\{T_\xi(a_n)\}_{n\ge 1}\) is an infinite family of pairwise orthogonal, nonzero vectors in \(H'\). In particular, the (algebraic) span of \(\{T_\xi(a_n)\}\) is infinite dimensional, so \(\dim(\mathrm{Ran}\,T_\xi)=\infty\); i.e. \(T_\xi\) has infinite rank.
>
> Finally, in a Hilbert space \(H\) the quotient \(H/\ker T_\xi\) is isomorphic to the closure of \(\mathrm{Ran}\,T_\xi\). Since \(\overline{\mathrm{Ran}\,T_\xi}\) is infinite dimensional, we have
> \[
> \dim(H/\ker T_\xi) = \dim\overline{\mathrm{Ran}\,T_\xi} = \infty,
> \]
> i.e. \(\ker T_\xi\) has infinite codimension in \(H\). ∎


Thus, for each \(\xi\), the solution set of \([a,\xi]=0\) lies in an affine subspace parallel to \(\ker T_\xi\) of infinite codimension.

### A.3. Abstract infinite‑codimension embedding (Assumption H.4)

Holonomy considerations imply that reducible connections correspond to reductions of structure group to a proper subgroup \(H\subsetneq G\). For each such subgroup \(H\), one expects a closed linear subspace
\[
S_H\subset H
\]
of infinite codimension such that the corresponding reducible locus \(\Sigma_H\) satisfies
\[
\Sigma_H \subset A_0 + S_H.
\]

Assumption H.4 in Doc C summarises this:

> **Assumption H.4.**  
> For each conjugacy class of proper closed subgroup \(H\subsetneq G\), there exists a closed linear subspace \(S_H\subset H\) with infinite codimension such that the reducible stratum \(\Sigma_H\) lies in the affine subspace \(A_0+S_H\). Moreover,
> \[
> \Sigma \subset \bigcup_H (A_0+S_H).
> \]

This is a geometric/PDE statement about the space of covariantly constant sections, and it is logically independent of any mass‑gap assumptions.

### A.4. Gaussian OU polarity for linear subspaces

Let \(S\subset H\) be a closed linear subspace and \(\gamma:=\mu_0\). Consider the OU process \(X_t\) with invariant \(\gamma\).

> **Proposition A.2 (Polarity threshold for linear subspaces).**  
> Let \(m = \mathrm{codim}(S)\).
> 
> 1. If \(m=0\) or \(m=1\), then \(S\) is nonpolar: for \(\gamma\)-a.e. starting point, the hitting probability \(\mathbb{P}_x(\tau_S<\infty)>0\).  
> 2. If \(m\ge 3\) or \(m=\infty\), then \(S\) is polar: for \(\gamma\)-a.e. starting point, \(\mathbb{P}_x(\tau_S<\infty)=0\).

*Proof sketch.*  

Decompose \(H = S\oplus N\) with \(\dim N = m\). The OU process decomposes as
\[
X_t = Y_t + Z_t,
\]
where:

- \(Y_t\) is OU on \(S\),
- \(Z_t\) is OU on \(N\simeq\mathbb{R}^m\),
- these components are independent.

Hitting \(S\) is equivalent to \(Z_t=0\) at some time. In \(\mathbb{R}^m\), standard Brownian (and OU) potential theory gives:

- In \(m=1\), the origin is hit with probability 1 (nonpolar).  
- In \(m\ge 3\), the origin is hit with probability 0 (polar).

Thus, for finite codimension, the threshold is \(m=3\). For \(m=\infty\), approximate \(S\) by a decreasing sequence of subspaces \(S_N\) of finite codimension \(N\ge 3\), observe that each \(S_N\) is polar, and use monotonicity of hitting events plus tightness to conclude \(S\) is polar.

### A.5. Capacity interpretation and reducible set

Let \(\mathrm{Cap}_{\mu_0}\) be the capacity associated with \((\mathcal{E}_0,\mu_0)\). For a Borel set \(E\subset H\),
\[
\mathrm{Cap}_{\mu_0}(E)
= \inf\Big\{\mathcal{E}_0(u,u)+\int u^2\,d\mu_0 : u\in\mathcal{D}(\mathcal{E}_0),\ u\ge 1\text{ on a nbhd of }E\Big\}.
\]

From Dirichlet form theory (Fukushima–Oshima–Takeda), we know that a set \(E\) is polar iff \(\mathrm{Cap}_{\mu_0}(E)=0\). Combining with Proposition A.2 and Assumption H.4:

> **Theorem A.3 (Gaussian polarity of reducibles).**  
> Under Assumption H.4, the reducible set \(\Sigma\) is polar for the Gaussian OU Dirichlet form:
> \[
> \mathrm{Cap}_{\mu_0}(\Sigma) = 0.
> \]

*Proof.*  
Each affine subspace \(A_0+S_H\) has infinite codimension, hence is polar by Proposition A.2. A countable union of polar sets is polar by subadditivity and monotonicity of capacity:
\[
\mathrm{Cap}_{\mu_0}\Big(\bigcup_n E_n\Big)
\le \sum_n 2^{-n}\mathrm{Cap}_{\mu_0}(E_n).
\]
Thus \(\Sigma\), being contained in such a union, has capacity zero. ∎

This is the Gaussian polarity theorem already used in the program.

---

## B. Conjecture C (YM Version) and Minimal Capacity Transfer

### B.1. Yang–Mills measure as a perturbation

Formally, the YM measure is defined as
\[
\mu_{\mathrm{YM}}(dA) = Z^{-1}e^{-S_{\mathrm{YM}}(A)}\,\mu_0(dA),
\]
with \(S_{\mathrm{YM}}(A)\ge 0\), and further renormalization understood.

Let the horizontal Dirichlet form be
\[
\mathcal{E}_{\mathrm{YM}}(F,F)
:= \int \|\nabla_H F(A)\|^2\,d\mu_{\mathrm{YM}}(A),
\]
defined on a core of gauge‑invariant cylindrical functionals.

The YM polarity conjecture is:

> **Conjecture C (YM Polarity of Reducibles).**  
> The reducible set \(\Sigma\subset\mathcal{A}\) is polar for \((\mathcal{E}_{\mathrm{YM}},\mu_{\mathrm{YM}})\), i.e.
> \[
> \mathrm{Cap}_{\mu_{\mathrm{YM}}}(\Sigma) = 0.
> \]

### B.2. One‑sided capacity domination under bounded density

We do not need full equivalence of Gaussian and YM capacities; one‑sided domination is enough.

> **Lemma B.1 (One‑sided capacity domination).**  
> Let \((\mathcal{E}_0,\mu_0)\) and \((\mathcal{E},\mu)\) be quasi‑regular Dirichlet forms with the same carré du champ \(\Gamma\) and core. Assume \(\mu\ll\mu_0\) with density \(\rho=\frac{d\mu}{d\mu_0}\) satisfying
> \[
> 0\le \rho\le C<\infty\quad \mu_0\text{-a.e.}
> \]
> Then
> \[
> \mathrm{Cap}_\mu(E) \le C\,\mathrm{Cap}_{\mu_0}(E)
> \]
> for all Borel sets \(E\).

*Proof.*  
For any \(u\in\mathcal{D}\) (common core),
\[
\mathcal{E}(u,u) = \int\Gamma(u)\,d\mu
= \int\Gamma(u)\rho\,d\mu_0
\le C\int\Gamma(u)\,d\mu_0 = C\,\mathcal{E}_0(u,u),
\]
and
\[
\int u^2\,d\mu = \int u^2\rho\,d\mu_0
\le C\int u^2\,d\mu_0.
\]
Thus for any admissible \(u\ge 1\) near \(E\),
\[
\mathcal{E}(u,u)+\int u^2\,d\mu
\le C\Big(\mathcal{E}_0(u,u)+\int u^2\,d\mu_0\Big).
\]
Taking the infimum over such test functions proves the claim. ∎

### B.3. Minimal YM capacity‑transfer theorem

> **Theorem B.2 (Minimal YM polarity transfer).**  
> Assume:
> 1. \(S_{\mathrm{YM}}\ge 0\) and \(\mu_{\mathrm{YM}}(dA) = Z^{-1}e^{-S_{\mathrm{YM}}(A)}\mu_0(dA)\) with \(Z\in(0,1]\).  
> 2. \(\Sigma\) is polar for \((\mathcal{E}_0,\mu_0)\).  
> 3. \(\mathcal{E}_{\mathrm{YM}}\) is closable and quasi‑regular.
> 
> Then \(\Sigma\) is polar for \((\mathcal{E}_{\mathrm{YM}},\mu_{\mathrm{YM}})\).

*Proof.*  
The Radon–Nikodym derivative is
\[
\rho(A) = \frac{d\mu_{\mathrm{YM}}}{d\mu_0}(A) = Z^{-1}e^{-S_{\mathrm{YM}}(A)}.
\]
Since \(S_{\mathrm{YM}}\ge 0\), \(0<e^{-S_{\mathrm{YM}}}\le 1\), hence
\[
0<\rho(A)\le Z^{-1}=:C.
\]
Apply Lemma B.1 to deduce
\[
\mathrm{Cap}_{\mu_{\mathrm{YM}}}(\Sigma)
\le C\,\mathrm{Cap}_{\mu_0}(\Sigma) = 0.
\]
Thus \(\Sigma\) is YM‑polar. ∎

This establishes Conjecture C at any scale where:

- A YM Gibbs measure with nonnegative action exists and is absolutely continuous w.r.t. a Gaussian reference.
- Gaussian polarity has been proved.
- The Dirichlet form is well‑defined and closable.

Finite‑cutoff models (e.g. lattice YM at fixed spacing) satisfy these hypotheses.

---

## C. Holonomy‑Based Discussion of Assumption H.4

Here we sketch why Assumption H.4 is geometrically plausible.

Let \(G\) be compact and simple, and \(P\to M\) a principal \(G\)–bundle. Fix a background connection \(A_0\). A connection \(A\) is reducible if there exists a reduction of structure group:
\[
P|_U \simeq P_H \times_H G
\]
on some open set \(U\subseteq M\), where \(H\subsetneq G\) is a proper subgroup and \(A\) preserves this reduction.

Equivalently, the holonomy group of \(A\) at some basepoint lies in a proper subgroup of \(G\). This condition can be expressed as an infinite system of linear constraints on the curvature and parallel transport operators.

In the Sobolev space \(H=\Omega^1_k(M,\mathrm{ad}P)\), these constraints can be encoded by:

- Fixing a basepoint and loops \(\gamma_n\) generating \(\pi_1(M)\).
- Requiring that the holonomy of \(A\) around each \(\gamma_n\) lies in a fixed \(H\), which can be expressed in terms of \(\exp\int_{\gamma_n} A\).

Linearizing at \(A_0\), the condition that all holonomies lie in \(H\) gives an infinite family of linear constraints on \(a\), which can be shown (in simple cases) to have infinite codimension in \(H\).

A full proof in the general setting requires:

1. Sobolev control of holonomy maps: differentiability and continuity of the map
   \[
   a\mapsto \mathcal{P}\exp\left(\int_\gamma(A_0+a)\right)
   \]
   from \(H\) to \(G\).

2. Identification of the linearized constraints as a family of independent functionals on \(H\).

This is a nontrivial but local geometric PDE problem, independent of mass‑gap considerations.

---

## D. Finite‑Cutoff and Lattice Variants

At finite cutoff (e.g., lattice YM on a finite lattice \(\Lambda\) with spacing \(a>0\)), the configuration space is finite‑dimensional and compact.

- The reference measure may be a product Haar measure on bonds, or a product Gaussian on a Lie algebra parameterization.
- The YM Gibbs measure has a strictly positive, bounded density with respect to this reference.
- Reducible configurations correspond to link variables lying in proper subgroups \(H\subsetneq G\) along some nontrivial subcomplex.

Under mild geometric assumptions, these reducible sets form unions of submanifolds of sufficiently high codimension inside the configuration space. From the finite‑dimensional Brownian/OU polarity result, any submanifold of codimension \(\ge 3\) is polar.

Thus, for the finite‑cutoff Dirichlet forms, one expects:

> **Finite‑cutoff Conjecture C\(_{\text{cutoff}}\).**  
> For each lattice and cutoff, the reducible set \(\Sigma^{(a,\Lambda)}\) is polar with respect to the YM Dirichlet form \((\mathcal{E}^{(a,\Lambda)},\mu_{\mathrm{YM}}^{(a,\Lambda)})\). Moreover, the associated Langevin dynamics almost surely never hits \(\Sigma^{(a,\Lambda)}\).

This is within reach using only finite‑dimensional stochastic analysis and Lie‑group geometry.

---

## E. LLM‑Friendly Task Decomposition

This document suggests several concrete tasks that can be assigned to an LLM or a human‑LLM pair:

1. **Task C1 (Coordinate‑free proof of Lemma A.1).**  
   Write a fully coordinate‑free, gauge‑invariant proof of the infinite‑rank property of \(T_\xi\), starting from Lie algebra representation theory and Sobolev embedding, avoiding local trivializations as much as possible.

2. **Task C2 (Holonomy‑Sobolev lemma).**  
   Prove that for \(k>2\), the holonomy map \(A\mapsto \mathrm{Hol}_A(\gamma)\) is Fréchet differentiable as a map from \(\Omega^1_k(M,\mathrm{ad}P)\) to \(G\), and compute its derivative explicitly.

3. **Task C3 (Finite‑dimensional cutoff polarity).**  
   In a toy lattice model (e.g., U(1) or SU(2) on a small lattice), explicitly describe the set of reducible configurations and compute its codimension, then verify polar/nonpolar status using known Brownian potential theory.

4. **Task C4 (Capacity transfer under Mosco convergence).**  
   Investigate whether capacity zero is stable under Mosco convergence of Dirichlet forms in the general setting: if \(\mathrm{Cap}_{\mu_n}(E)=0\) for all \(n\), does it imply \(\mathrm{Cap}_\mu(E)=0\) for the limit form?

5. **Task C5 (Local‑cylindrical polarity).**  
   For a finite set of gauge‑invariant cylindrical observables \(F_1,\dots,F_n\), study the image of \(\Sigma\) under the map \(A\mapsto(F_1(A),\dots,F_n(A))\) and show that this image has capacity zero in \(\mathbb{R}^n\) with respect to the induced Dirichlet form.

The goal is to gradually upgrade Conjecture C from a formal assumption to a theorem, first in finite‑cutoff settings and then, with additional constructive machinery, in the continuum.

---

## F. Finite-Cutoff Lattice Polarity (Rigorous \(C_{\text{cutoff}}\))

In the finite-cutoff (lattice) setting, the polarity of reducible configurations can be proved rigorously and completely. This resolves the lattice version of Conjecture C.

We consider a finite 4D lattice \(\Lambda\subset\mathbb{Z}^4\) with oriented bonds \(\mathcal{B}\), gauge group \(G=SU(N)\), and configuration space
\[
\Omega = G^{\mathcal{B}},
\]
with product Haar measure \(\mu_H\). The lattice Yang–Mills Gibbs measure with Wilson action is
\[
d\mu_{\Lambda,\mathrm{YM}}(U)
= Z_\Lambda^{-1} e^{-S_W(U)}\,d\mu_H(U),
\quad
S_W(U) = \frac{1}{g^2}\sum_p \Re\operatorname{Tr}(I-U_p).
\]

A configuration \(U\in\Omega\) is **reducible** if there exists a nonzero covariantly constant adjoint field \(\{\xi_x\}_{x\in\Lambda}\), i.e.
\[
\xi_{y(b)} = \mathrm{Ad}(U_b)\,\xi_{x(b)}
\quad\text{for all bonds }b=(x(b),y(b)).
\]
Equivalently, the holonomy representation \(\rho_U:\pi_1(\Lambda)\to G\) preserves a nontrivial subspace of \(\mathfrak{g}\), so \(\rho_U(\pi_1(\Lambda))\) lies in a proper closed subgroup \(H\subsetneq G\). Let \(\Sigma_\Lambda\subset\Omega\) be the set of such reducible configurations.

### F.1. Geometry and codimension

For each proper closed subgroup \(H\subsetneq G\) and each finite “pattern” \(\mathcal{P}\) specifying a nontrivial set of holonomy or link constraints, define
\[
\Omega_{H,\mathcal{P}}\subset\Omega
\]
to be the set of configurations whose holonomy (or specified links) lie in a conjugate of \(H\) according to \(\mathcal{P}\). One shows:

- Each \(\Omega_{H,\mathcal{P}}\) is a finite union of smooth embedded submanifolds of \(\Omega\).
- For \(G=SU(N)\), every proper closed subgroup \(H\subsetneq G\) has \(\dim H \le \dim G - 2\), so
  \[
  \mathrm{codim}_\Omega(\Omega_{H,\mathcal{P}})\ \ge\ \dim G - \dim H\ \ge\ 2.
  \]
- The reducible set is contained in a countable union:
  \[
  \Sigma_\Lambda \subset \bigcup_{(H,\mathcal{P})} \Omega_{H,\mathcal{P}}.
  \]

A detailed algebraic–geometric version of this codimension analysis is given in  
`Rigorous Proof_ Polarity of Reducible Connections in Lattice Yang-Mills.md`.

### F.2. Polarity for the Haar-OU Dirichlet form

On \(\Omega\), consider the product Brownian/OU diffusion with generator
\[
L_0 = \sum_{b\in\mathcal{B}} \Delta_{G,b},
\]
where \(\Delta_{G,b}\) is the Laplace–Beltrami operator on the \(b\)-th \(G\)-factor. It is uniformly elliptic, symmetric, and has invariant measure \(\mu_H\). The associated Dirichlet form on \(L^2(\Omega,\mu_H)\) is
\[
\mathcal{E}_0(f,f) = \int_\Omega \sum_{b\in\mathcal{B}} \|\nabla_b f\|^2\,d\mu_H.
\]

General potential theory for diffusions on smooth compact manifolds implies:

> If \(M\) is a compact Riemannian manifold, \(L\) a uniformly elliptic diffusion generator with smooth strictly positive invariant density, and \(S\subset M\) a smooth embedded submanifold of codimension \(\ge 3\), then \(S\) has capacity zero for the Dirichlet form associated with \(L\). Equivalently, the diffusion almost surely never hits \(S\), starting from almost every initial point.

Applying this to \(M=\Omega\), \(L=L_0\), and each \(\Omega_{H,\mathcal{P}}\) yields
\[
\mathrm{Cap}_{\mu_H}(\Omega_{H,\mathcal{P}})=0
\quad\text{for all }(H,\mathcal{P}).
\]

From subadditivity of capacity (and a standard \(2^{-n}\) weighting argument), we obtain
\[
\mathrm{Cap}_{\mu_H}(\Sigma_\Lambda)
= \mathrm{Cap}_{\mu_H}\Big(\bigcup_{(H,\mathcal{P})} \Omega_{H,\mathcal{P}}\Big)
= 0.
\]

### F.3. Extension to the lattice YM Gibbs measure

The lattice YM measure \(\mu_{\Lambda,\mathrm{YM}}\) is absolutely continuous w.r.t. \(\mu_H\), with density
\[
\rho(U) = \frac{d\mu_{\Lambda,\mathrm{YM}}}{d\mu_H}(U)
= Z_\Lambda^{-1}e^{-S_W(U)}.
\]
On compact \(\Omega\), the Wilson action \(S_W(U)\) is bounded and nonnegative, so
\[
0<\rho(U)\le Z_\Lambda^{-1}=:C<\infty.
\]

Let \(\mathcal{E}_{\mathrm{YM}}(f,f)=\int\Gamma_0(f)\,d\mu_{\Lambda,\mathrm{YM}}\) be the Dirichlet form with the same carré du champ as \(\mathcal{E}_0\) and invariant measure \(\mu_{\Lambda,\mathrm{YM}}\). The one-sided capacity domination lemma then gives:
\[
\mathrm{Cap}_{\mu_{\Lambda,\mathrm{YM}}}(E)
\le C\,\mathrm{Cap}_{\mu_H}(E)
\quad\text{for all Borel }E\subset\Omega.
\]
In particular,
\[
\mathrm{Cap}_{\mu_{\Lambda,\mathrm{YM}}}(\Sigma_\Lambda)
\le C\,\mathrm{Cap}_{\mu_H}(\Sigma_\Lambda) = 0.
\]

Therefore the finite-cutoff version of Conjecture C holds rigorously on the lattice: \(\Sigma_\Lambda\) is polar for both the Haar-OU and lattice YM Dirichlet forms.


### F.4. Explicit SU(2) star-graph example (Task C3)

As a concrete illustration of the finite-cutoff polarity mechanism, consider the simplest nontrivial lattice geometry: a "star" with a single vertex and \(L\) incident links, with gauge group \(G=SU(2)\).

- Configuration space:
  \[
  \Omega = G^L = \underbrace{SU(2)\times\cdots\times SU(2)}_{L\ \text{factors}},
  \]
  with product Haar measure and the corresponding Brownian/OU diffusion as in §F.2.
- Dimension: \(\dim SU(2)=3\), so
  \[
  \dim(\Omega) = 3L.
  \]

A configuration \(U=(U_1,\dots,U_L)\in\Omega\) is **reducible** if the holonomy subgroup generated by the \(U_i\) lies in a proper closed subgroup of \(G\). For \(SU(2)\), any proper closed connected subgroup is conjugate to a maximal torus \(T\cong U(1)\). Thus \(U\) is reducible iff there exists \(g\in SU(2)\) such that
\[
g U_i g^{-1}\in T
\quad\text{for all }i=1,\dots,L.
\]

This reducible set \(\Sigma_\Lambda\) can be parameterized by a smooth map
\[
\Psi:(G/T)\times T^L \to G^L,\qquad
\Psi([g],h_1,\dots,h_L) = (g h_1 g^{-1},\dots,g h_L g^{-1}),
\]
where \(G/T\cong S^2\) encodes the choice of axis (orientation of \(T\)) and \(h_i\in T\) encode the angles on each link.

- The coset \(G/T\) has dimension
  \[
  \dim(G/T) = \dim G - \dim T = 3-1 = 2.
  \]
- The torus part has
  \[
  \dim(T^L) = L\cdot\dim T = L.
  \]

Ignoring lower-dimensional degeneracies (e.g. center elements), \(\Psi\) is a smooth covering map onto the reducible set \(\Sigma_\Lambda\), so generically
\[
\dim(\Sigma_\Lambda) = \dim(G/T) + \dim(T^L) = 2 + L.
\]

Thus the codimension of \(\Sigma_\Lambda\) in \(\Omega\) is
\[
k := \mathrm{codim}_\Omega(\Sigma_\Lambda)
= \dim(\Omega) - \dim(\Sigma_\Lambda)
= 3L - (2+L) = 2L - 2.
\]

In particular:

- For \(L=1\), \(k=0\): every single link is conjugate into some maximal torus, so "reducible" is trivial.
- For \(L=2\), \(k=2\): commuting pairs form a 4-dimensional submanifold in the 6-dimensional configuration space.
- For \(L\ge 3\), \(k\ge 4\).

For the product Brownian/OU diffusion on the compact manifold \(\Omega\), classical manifold potential theory implies that any smooth embedded submanifold of codimension \(k\ge 2\) is polar: the diffusion almost surely never hits it. In our SU(2) star-graph example, the reducible set \(\Sigma_\Lambda\) therefore has capacity zero as soon as \(L\ge 2\).

This explicit finite-dimensional model is consistent with, and concretely realizes, the general finite-cutoff polarity result of §F.1–F.3: in any nontrivial lattice with at least two incident links at a vertex, the reducible set has codimension at least 2 (and in practice much larger), and is polar for the natural diffusions considered here.

