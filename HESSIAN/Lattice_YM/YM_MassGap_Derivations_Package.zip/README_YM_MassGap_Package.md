# Finite-Cutoff Yang–Mills Mass Gap – Documentation Package

This folder contains a self-contained set of LaTeX documents that a researcher can use
to understand and extend the finite–cutoff Yang–Mills mass gap program.

The documents are written as ordinary LaTeX articles; no external project files are required.

---

## 1. Main Monograph

**File:** `YM_FiniteCutoff_MassGap_GeometricSpectral.tex`

**Role:**  
This is the primary “one-stop” document. It assembles all the core components into a single,
coherent narrative:

- Convex scalar prototype and Bakry–Émery curvature.
- Viscous Hamilton–Jacobi (vHJ) flow and Hessian/Riccati evolution.
- Haar-measure mass term and global horizontal Hessian lower bound on `SU(N)^{|B|}`.
- Strong–coupling transfer-matrix spectral gap.
- Polarity of reducible configurations (capacity zero).
- A final “Geometric–Spectral Stability” conjecture connecting finite–cutoff convexity
  and topological effects to the continuum limit.

Suggested starting point for any reader.

---

## 2. Component Papers (Modular Pillars)

Each of these files focuses on one pillar of the argument and can be read independently.
They are suitable as standalone references or appendices.

### 2.1 Scalar Convex Prototype

**File:** `Scalar_Convex_Prototype_BE_MassGap.tex`

Content:

- Definition of a strictly convex scalar lattice action in 4D.
- Uniform Hessian lower bound.
- Bakry–Émery curvature condition `CD(ρ_*, ∞)`.
- Volume–uniform Poincaré and log–Sobolev inequalities.
- Existence of a dynamic mass gap in the thermodynamic limit.

Use this as the canonical “warm-up” model.

---

### 2.2 vHJ Flow and Riccati Bounds

**File:** `Dynamic_Hessian_Riccati_Flow.tex`

Content:

- Derivation of the viscous Hamilton–Jacobi equation for `S_t` from the heat equation
  for `ρ_t ∝ e^{-S_t}` in finite dimensions.
- Evolution equation for the Hessian `H_t = ∇^2 S_t`:
  `∂_t H_t = Δ_L H_t - 2 H_t^2 + curvature`.
- Pointwise Riccati–type inequality for the smallest eigenvalue of `H_t`.
- Scalar comparison ODE and long-time behaviour: persistence of a positive lower bound.

Use this when you need the “curvature flow” mechanism in an abstract setting.

---

### 2.3 Haar Mass and Lattice Hessian

**File:** `YM_Lattice_Haar_Hessian_MassGap.tex`

Content:

- Configuration space `𝒞 = SU(N)^{|B|}` and exponential coordinates on links.
- Expansion of the Haar measure Jacobian:
  `S_Haar(A) = (c_0/2) Tr(A^2) + O(‖A‖^4)` with `c_0 = (N^2 - 1)/(2N)`.
- Decomposition of the effective action Hessian:
  `H_eff(U) = β Δ_latt - β V(U) + c_0 I`, with `V(U)` bounded uniformly.
- Uniform horizontal eigenvalue lower bound on `T_U^{hor} 𝒞`:
  `λ_min ≥ c_0 - β C_V > 0` under `c_0 > β C_V`.
- Dynamic mass-gap statement at fixed cutoff via Bakry–Émery in the horizontal directions.

This is the main finite–cutoff geometric pillar for Yang–Mills.

---

### 2.4 Transfer Matrix Spectral Gap

**File:** `YM_Lattice_Transfer_Matrix_Gap.tex`

Content:

- Construction of the transfer matrix `T` in anisotropic lattice YM.
- Perron–Frobenius property for `T` (unique positive vacuum state).
- Strong–coupling character expansion using Wilson loops.
- Bound on the second eigenvalue:
  `λ_1(β_t) ≤ λ_0(β_t) (c β_t)^L` for minimal non–contractible loop length `L`.
- Resulting finite–volume Hamiltonian mass gap
  `Δ(a_t) = -(1/a_t) log(λ_1/λ_0) > 0` in the strong–coupling regime.

Use this when you want the Hamiltonian / transfer–matrix picture explicitly.

---

### 2.5 Polarity of Reducible Configurations

**File:** `YM_Lattice_Polarity_of_Reducibles.tex`

Content:

- Definition of reducible configurations on the lattice (non-minimal stabiliser).
- Algebraic-variety description of the reducible set `Σ`.
- Codimension ≥ 2 lemma for reducible strata.
- Capacity theory on compact manifolds.
- Proof that `Σ` is polar (capacity zero) for the Yang–Mills Dirichlet form.

This justifies ignoring reducible connections in spectral and functional-inequality
analyses: they are invisible to the diffusion almost surely.

---

## 3. How to Hand This to a Researcher

If you’re passing this package on:

1. Give them **`YM_FiniteCutoff_MassGap_GeometricSpectral.tex`** as the main document.
2. Mention that **all auxiliary proofs** (scalar prototype, vHJ/Riccati, Haar Hessian,
   transfer-matrix gap, polarity) are available as separate LaTeX articles listed above.
3. If they want to dig into one piece (e.g. Bakry–Émery curvature, or the Haar–mass
   coefficient), they can open the corresponding component file directly.

The documents are written for a mathematically literate QFT audience; nothing depends
on unpublished external notes, and all symbols and constructions are defined inside
this package.
