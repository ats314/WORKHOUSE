# Geometric–Spectral Stability Program (Pillar L Perspective)

**Date:** \today

This document summarises the **finite–cutoff Pillar L module** and
places it inside a conjectural **Geometric–Spectral Stability Mechanism**
for the Yang–Mills mass gap.

---

## 1. Pillar L: Finite–Cutoff Lattice Module

We work with lattice \(SU(N)\) Yang–Mills on a finite hypercubic
lattice \(\Lambda\), configuration space
\(\mathcal{C}_\Lambda = SU(N)^{|\mathcal{B}|}\), and effective action
\[
S_{\mathrm{eff}} = S_W + S_{\mathrm{Haar}}.
\]

### 1.1 Proven / Validated Results

1. **Haar Mass Term (Local).**  
   In exponential coordinates \(U_b = \exp(iagA_b)\), the Haar measure
   induces a quadratic term
   \[
   S_{\mathrm{Haar}}(A)
     = c_0 a^2 g^2 \sum_b \mathrm{Tr}(A_b^2) + O(a^4\|A\|^4),
   \quad c_0>0,
   \]
   with \(c_0\) depending only on \(N\).

2. **Global Horizontal Hessian Gap.**  
   Restricting to the irreducible sector
   \(\mathcal{C}_\Lambda^{\mathrm{irr}}\) (gauge orbits with stabiliser
   equal to the center), the horizontal Hessian of \(S_{\mathrm{eff}}\)
   admits a uniform lower bound:
   \[
   \lambda_{\min}(U) \ge c_* > 0
   \]
   for all \(U\in \mathcal{C}_\Lambda^{\mathrm{irr}}\), independent of
   the lattice volume.

3. **Polarity of Reducible Configurations.**  
   The set of reducible configurations
   \(\Sigma_\Lambda = \mathcal{C}_\Lambda\setminus\mathcal{C}_\Lambda^{\mathrm{irr}}\)
   has zero capacity for the Dirichlet form associated with
   \(S_{\mathrm{eff}}\).  It is negligible for Poincaré / log–Sobolev
   inequalities and spectral gaps.

4. **Bakry–Émery Curvature Bound.**  
   The compact product manifold \(SU(N)^{|\mathcal{B}|}\) has strictly
   positive Ricci curvature, and combined with the Hessian gap one
   obtains
   \[
   \mathrm{Ric} + \nabla^2 S_{\mathrm{eff}} \ge \rho_* g,
   \quad \rho_* > 0,
   \]
   on \(\mathcal{C}_\Lambda^{\mathrm{irr}}\), with \(\rho_*\) uniform in
   the volume.

5. **Functional Inequalities and Langevin Spectral Gap.**  
   The Bakry–Émery bound implies Poincaré and log–Sobolev inequalities
   for the effective measure and a spectral gap \(\ge \rho_*\) for the
   associated Langevin generator, uniform in the volume.

6. **Strong–Coupling Transfer Matrix Gap.**  
   For sufficiently small plaquette couplings, the transfer matrix has a
   unique positive maximal eigenvalue and a non–zero gap, with first
   excitations created by Wilson loops.  The gap scale is tied to an
   induced string tension.

---

## 2. Abstract Hessian / Riccati Picture

On a Riemannian manifold \((M,g)\), consider densities
\(\rho_t \propto e^{-S_t}\) evolving under the heat equation
\(\partial_t \rho_t = \Delta \rho_t\).  The effective action \(S_t\)
satisfies a viscous Hamilton–Jacobi equation
\[
\partial_t S_t = \Delta S_t - \|\nabla S_t\|^2.
\]

The Hessian \(H_t = \nabla^2 S_t\) then obeys a reaction–diffusion
equation of the schematic form
\[
\partial_t H_t = \Delta_L H_t - 2H_t^2 + \mathcal{R}_t,
\]
where \(\Delta_L\) is a Lichnerowicz Laplacian on symmetric tensors and
\(\mathcal{R}_t\) encodes curvature and higher derivatives of \(S_t\).

Under suitable assumptions and a tensor maximum principle, one expects
the minimal eigenvalue \(\lambda_{\min}(t)\) to satisfy a scalar
Riccati–type inequality
\[
\dot\lambda(t) \ge -2\lambda(t)^2 + \sigma_{\mathrm{geom}},
\]
with a **geometric source term** \(\sigma_{\mathrm{geom}}>0\).  The
comparison ODE
\[
\dot\ell = -2\ell^2 + \sigma_{\mathrm{geom}},\qquad \ell(0)=0,
\]
has solution
\[
\ell(t) = \sqrt{\frac{\sigma_{\mathrm{geom}}}{2}}\,
          \tanh\big(\sqrt{2\sigma_{\mathrm{geom}}}\,t\big),
\]
which increases to a positive limit \(\ell_*\).  This suggests that
convexity can become **self–sustaining**: once \(\lambda(0)\ge 0\),
eventually \(\lambda(t)\ge\ell_*>0\) regardless of the initial mass
scale.

In the finite–cutoff lattice theory, the role of the source term is
played initially by the Haar mass coefficient \(c_0\).  The conjecture
is that the RG flow generates an effective, cutoff–independent
\(\sigma_{\mathrm{geom}}\) in the continuum.

---

## 3. Geometric–Spectral Stability Mechanism

We can now state the programmatic mechanism as three phases.

### 3.1 Priming (Finite Cutoff)

- Haar measure on \(SU(N)^{|\mathcal{B}|}\) provides a uniform,
  volume–independent quadratic term with coefficient \(c_0>0\).
- Together with group curvature, this yields a global horizontal Hessian
  gap and a Bakry–Émery curvature bound at each fixed lattice spacing
  \(a>0\).
- The Langevin generator and, in the strong–coupling regime, the
  transfer matrix both exhibit a non–zero spectral gap.

**Interpretation:** geometry of the gauge group + Haar measure prevent
the theory from exploring flat directions; they place the system in a
gapped phase at finite cutoff.

### 3.2 Sustaining (Riccati Hand–Off)

- Under RG, the effective action \(S_t\) (on a sequence of lattices or
  in a continuum limit) evolves via a viscous Hamilton–Jacobi–type flow.
- The Hessian \(H_t\) obeys a matrix reaction–diffusion equation whose
  minimal eigenvalue satisfies a Riccati inequality with source
  \(\sigma_{\mathrm{geom}}\).
- The initial contribution to \(\sigma_{\mathrm{geom}}\) comes from the
  Haar mass \(c_0\), but as degrees of freedom are integrated out, an
  **anomaly–like** geometric term is expected to emerge that does not
  vanish as \(a\to 0\).

**Interpretation:** the explicit \(a^2\)-scaled Haar mass is the
\emph{initiator} of convexity; intrinsic geometry and anomalies become
the \emph{sustainers}.

### 3.3 Locking (Wilson Loops and Topology)

- In the Hamiltonian picture, the mass gap in the strong–coupling regime
  is tied to the energy cost of non–trivial Wilson loop excitations and
  an induced string tension.
- If the confining phase is analytically connected to the continuum
  limit, the Wilson–loop sector cannot be trivialised without a phase
  transition.
- A non–zero string tension then `locks in` a mass scale even if bare
  coupling parameters are tuned.

**Interpretation:** once the system is in a confining phase with
non–trivial Wilson loops, the mass gap is topologically protected; it
cannot decay smoothly to zero along the RG trajectory.

---

## 4. Status: Proven vs Working Hypotheses

### 4.1 Proven / Constructed (Finite Cutoff)

- Haar mass coefficient \(c_0>0\) and its independence of the volume.
- Polarity of reducible configurations and global Hessian gap on the
  irreducible sector.
- Bakry–Émery curvature bound and associated functional inequalities.
- Strong–coupling transfer matrix spectral gap with Wilson–loop
  excitations.

### 4.2 Working Hypotheses / Conjectures (Continuum)

- Existence of a well–defined RG flow for the effective action on an
  infinite–dimensional configuration space, preserving a positive
  Bakry–Émery parameter.
- A rigorous Hessian evolution equation with a Riccati inequality and a
  strictly positive, cutoff–independent geometric source term.
- Analytic connection of the confining, gapped phase from strong
  coupling to the continuum limit without a phase transition.
- Identification of the lattice–scale spectral gap with the physical
  mass gap in the continuum Minkowski theory.

---

## 5. Open Technical Targets

This program reduces the continuum Yang–Mills mass gap problem to a
small set of sharp analytic tasks:

1. **Uniform Curvature Control in the Continuum Limit.**  
   Show that the Bakry–Émery curvature bound for the finite lattices
   passes to the limit and yields a strictly positive curvature
   parameter in the continuum.

2. **Infinite–Dimensional Riccati Inequality.**  
   Derive an RG–time Hessian equation for \(S_t\) on an appropriate
   infinite–dimensional configuration space and prove a Riccati–type
   inequality for the minimal horizontal eigenvalue.

3. **Phase–Diagram Control.**  
   Prove that the confining, gapped phase of lattice \(SU(N)\) Yang–Mills
   extends to the continuum limit along a renormalisation trajectory,
   with no intervening phase transition.

4. **Spectral Identification.**  
   Relate the spectral gap of the Euclidean transfer matrix to the
   physical mass gap in the Minkowski Hamiltonian of the continuum
   theory, completing the Osterwalder–Schrader reconstruction chain.

Pillar L provides a rigorously constructed starting point: a finite–
cutoff world where group geometry directly generates a spectral gap.
The Geometric–Spectral Stability Mechanism is the proposed bridge from
that world to the continuum Yang–Mills mass gap.
