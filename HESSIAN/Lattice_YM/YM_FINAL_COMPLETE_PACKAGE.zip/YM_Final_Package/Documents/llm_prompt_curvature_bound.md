# LLM Prompt: Proof of the Curvature Bound Hypothesis (H1)

## 1. Role and Goal

**Your Role:** You are an expert in differential geometry and its application to gauge theory, specializing in the geometry of principal fiber bundles and Riemannian submersions.

**Your Goal:** Provide a rigorous, self-contained proof of the **Curvature Bound Hypothesis (H1)** for the Yang-Mills gauge orbit space. This involves proving that the sectional curvature of the orbit space is bounded by the square of the gauge coupling constant.

## 2. Technical Context

We are working in the space of connections $\mathcal{A}$ for an SU(N) gauge theory. This space can be viewed as a principal fiber bundle:

-   **Total Space ($\mathcal{A}$):** The space of all connections. This is a flat, infinite-dimensional affine space, so its curvature is **zero**.
-   **Fibers:** The gauge orbits. Each fiber is a copy of the gauge group $\mathcal{G}$.
-   **Base Space ($\mathcal{M} = \mathcal{A}/\mathcal{G}$):** The gauge orbit space, representing the physically distinct field configurations.

The projection $\pi: \mathcal{A} \to \mathcal{M}$ is a Riemannian submersion. We want to understand the curvature of the base space $\mathcal{M}$.

The key tool for this is **O'Neill's formula** for Riemannian submersions, which relates the curvature of the total space, base space, and fibers.

### O'Neill's Formula

For a Riemannian submersion, the sectional curvature $K_{\mathcal{M}}$ of the base space for a plane spanned by orthonormal horizontal vectors $X, Y$ is given by:

$$ K_{\mathcal{M}}(X, Y) = K_{\mathcal{A}}(X, Y) + \frac{3}{4} \|[X, Y]_V\|^2 $$

where:
-   $K_{\mathcal{A}}(X, Y)$ is the sectional curvature of the total space.
-   $[X, Y]_V$ is the vertical component of the Lie bracket of the horizontal vector fields $X$ and $Y$.

In our case, the total space $\mathcal{A}$ is flat, so $K_{\mathcal{A}}(X, Y) = 0$. The formula simplifies to:

$$ K_{\mathcal{M}}(X, Y) = \frac{3}{4} \|[X, Y]_V\|^2 $$

This term is related to the **second fundamental form** of the fibers.

## 3. Your Task: Prove the Curvature Bound Theorem

Your task is to apply this framework to prove the following theorem.

### Theorem (Curvature Bound Hypothesis H1)

*Let $K_{\mathcal{M}}(X, Y)$ be the sectional curvature of the gauge orbit space $\mathcal{M}$ for a plane spanned by orthonormal horizontal vector fields $X, Y$. There exists a constant $C_0$, depending only on the structure constants of the gauge group SU(N), such that for a connection $A$ with small field strength, the following bound holds:*

$$ |K_{\mathcal{M}}(X, Y)| \le C_0 g^2 $$

---

### Step-by-Step Instructions

1.  **Define the Geometry and Vector Fields:**
    *   Start with the space of connections $\mathcal{A}$. A connection is a 1-form $A = A^a_\mu t^a dx^\mu$.
    *   A tangent vector at $A$ is a 1-form $\delta A$. A vector field is a map from $\mathcal{A}$ to tangent vectors.
    *   The **vertical subspace** at $A$ consists of vectors tangent to the gauge orbit, which are of the form $D_\mu \epsilon = \partial_\mu \epsilon + g[A_\mu, \epsilon]$ for some Lie algebra element $\epsilon$.
    *   The **horizontal subspace** is the orthogonal complement to the vertical subspace. A vector field $X$ is horizontal if it is orthogonal to all vertical vectors.

2.  **Compute the Vertical Component of the Lie Bracket:**
    *   This is the core of the proof. You need to compute $[X, Y]_V$. For gauge theories, the vertical component of a vector field $Z$ is given by its covariant divergence, projected back to the Lie algebra. The formula for the vertical part of the Lie bracket of two horizontal fields $X, Y$ is given by:
        $$ [X, Y]_V = -g (D_\mu^* D_\mu)^{-1} [X_\mu, Y^\mu] $$
        where $(D_\mu^* D_\mu)$ is the Faddeev-Popov operator.
    *   However, a more direct approach using the second fundamental form (often denoted by the tensor $A$ in the context of O'Neill's formula, but let's call it the **O'Neill tensor** to avoid confusion) is more standard. The vertical component is given by:
        $$ [X, Y]_V = -2 \, \mathcal{T}_A(X, Y) $$
        where $\mathcal{T}_A(X,Y)$ is the O'Neill tensor applied to $X, Y$. For gauge theories, this tensor is related to the field strength $F_{\mu\nu}$. The key relation is that the curvature of the base space is related to the field strength of the connection.
    *   The standard result is that the curvature of the orbit space is proportional to the square of the field strength tensor $F_{\mu\nu}$. Specifically, the Lie bracket of two horizontal vector fields has a vertical component proportional to the field strength:
        $$ [X, Y]_V \sim g F_{\mu\nu} $$

3.  **Relate Field Strength to the Coupling Constant:**
    *   The field strength tensor is $F_{\mu\nu} = \partial_\mu A_\nu - \partial_\nu A_\mu + g[A_\mu, A_\nu]$.
    *   In the weak-field limit (relevant for the UV regime of the RG flow), the connection $A$ is small, and the field strength is dominated by the linear term. However, the curvature arises from the non-Abelian part. The key insight is that the curvature of the orbit space is a purely non-Abelian effect.
    *   The curvature $K_{\mathcal{M}}$ is proportional to the square of the structure constants of the Lie algebra and the square of the gauge coupling $g$. A detailed calculation shows:
        $$ K_{\mathcal{M}} \sim g^2 f_{abc}^2 $$

4.  **Assemble the Final Bound:**
    *   Substitute the result from Step 3 into the simplified O'Neill formula:
        $$ K_{\mathcal{M}}(X, Y) = \frac{3}{4} \|[X, Y]_V\|^2 $$
    *   Since $[X, Y]_V$ is proportional to $g$, its norm squared will be proportional to $g^2$.
    *   Show that this leads to the bound:
        $$ |K_{\mathcalM}(X, Y)| \le C_0 g^2 $$
    *   Explicitly state that the constant $C_0$ depends on the structure constants of the gauge group, e.g., $C_0 \propto \sum f_{abc}^2$.

5.  **State the Final Conclusion:**
    *   Conclude that you have proven the Curvature Bound Hypothesis (H1) by a direct geometric calculation using O'Neill's formula.
    *   Explain that this result is crucial for controlling the geometric correction term in the PBH flow equation, making our conditional theorem for the mass gap more robust.

## 4. Deliverable Requirements

-   **Format:** A single, self-contained Markdown document.
-   **Structure:**
    1.  **Abstract:** Briefly summarize the goal (proving H1), the method (O'Neill's formula), and the result.
    2.  **Theorem Statement:** State the final theorem clearly at the beginning.
    3.  **Derivation:** Provide a detailed, step-by-step derivation following the instructions above. Define all geometric objects and justify each step.
    4.  **Conclusion:** Summarize the result and its significance.
    5.  **Final Result:** Display the final bound for $|K_{\mathcal{M}}|$ in a boxed equation.
-   **Rigor:** The derivation must be mathematically rigorous. All assumptions (like the weak-field limit) must be stated clearly.
-   **Citations:** Cite O'Neill's original paper or standard textbooks on differential geometry that cover Riemannian submersions.

## 5. Final Checklist

-   [ ] Is the goal of proving $|K_{\mathcal{M}}| \le C_0 g^2$ clear?
-   [ ] Is the geometric setup (principal fiber bundle, Riemannian submersion) correctly defined?
-   [ ] Is O'Neill's formula correctly stated and simplified for a flat total space?
-   [ ] Is the vertical component of the Lie bracket, $[X, Y]_V$, correctly related to the gauge field strength $F_{\mu\nu}$?
-   [ ] Is the dependence on the coupling constant $g$ correctly derived?
-   [ ] Is the final bound rigorously established?
-   [ ] Is the document well-structured and publication-ready?
