# Extended Derivations for the MFIP and Dynamic Yang–Mills

**Document:** YM\_MassGap\_DocB\_DynamicYM\_MFIP – Extended Derivations  
**Role:** Technical backbone for the dynamic route and the Multiscale Functional Inequality Program (MFIP).

This document deepens the derivations in Doc B, focusing on:

- The viscous Hamilton–Jacobi (vHJ) ansatz for effective actions.
- The Hessian evolution equation and its reaction–diffusion structure.
- The MFIP RG‑step inequalities for Log–Sobolev and Poincaré constants.
- The variance decomposition into local vs topological contributions.

---

## 1. Finite‑Dimensional Viscous Hamilton–Jacobi Derivation

We start in \(\mathbb{R}^n\) to keep notation transparent. Let \(\rho_t:\mathbb{R}^n\to(0,\infty)\) solve the pure heat equation
\[
\partial_t \rho_t = \Delta \rho_t,
\]
with suitable regularity and normalization \(\int\rho_t\,dx=1\).

Assume there exists a smooth function \(S_t:\mathbb{R}^n\to\mathbb{R}\) and normalizing factor \(Z_t>0\) such that
\[
\rho_t(x) = Z_t^{-1} e^{-S_t(x)}.
\]

### 1.1. Chain rule computation

Compute \(\partial_t \rho_t\) in terms of \(S_t\):
\[
\partial_t\rho_t
= -Z_t^{-1}(\partial_t S_t)e^{-S_t} - Z_t^{-2}(\partial_t Z_t)e^{-S_t}
= -(\partial_tS_t)\rho_t - (\partial_t\log Z_t)\rho_t.
\]

Compute \(\Delta\rho_t\):
\[
\Delta\rho_t
= \Delta(e^{-S_t})
= e^{-S_t}(-\Delta S_t + |\nabla S_t|^2).
\]

Equating \(\partial_t\rho_t=\Delta\rho_t\) and dividing by \(\rho_t>0\) gives
\[
-(\partial_t S_t) - (\partial_t\log Z_t)
= -\Delta S_t + |\nabla S_t|^2.
\]
Thus
\[
\partial_t S_t + \partial_t\log Z_t = \Delta S_t - |\nabla S_t|^2.
\]

Since \(\partial_t\log Z_t\) is independent of \(x\), we can absorb it into \(S_t\) by defining
\[
\tilde S_t := S_t - \log Z_t.
\]
This does not change \(\rho_t\), because
\[
\rho_t = Z_t^{-1}e^{-S_t} = e^{-\tilde S_t}.
\]
Then \(\tilde S_t\) satisfies
\[
\partial_t \tilde S_t = \Delta \tilde S_t - |\nabla \tilde S_t|^2.
\]

We drop the tilde and write:
\[
\boxed{\partial_t S_t = \Delta S_t - |\nabla S_t|^2.}
\]

### 1.2. Adding drift and anomaly

For the YM‑motivated setting, one expects:

- A drift term corresponding to a reference Gaussian measure (or bare action).
- An anomaly term from renormalization.

At an effective RG time \(t\), this suggests
\[
\partial_t S_t = \Delta S_t - |\nabla S_t|^2 + J_t,
\]
where:

- \(\Delta\) is a field‑space Laplacian (with respect to a chosen reference metric on \(\mathcal{A}/\mathcal{G}\)).
- \(J_t\) encodes deviations from the pure heat flow, including anomaly contributions and changes of the reference Gaussian.

This is the viscous Hamilton–Jacobi (vHJ) ansatz used in Doc B, now derived in finite dimension. In infinite dimensions it should be understood as a heuristic representation of a Wilsonian RG flow on effective actions.

---

## 2. Hessian Flow: Detailed Computation

We now derive the Hessian evolution equation. Let
\[
b_t := \nabla S_t, \quad
h_t := \nabla^2 S_t.
\]
We write component indices \(i,j,k\) for clarity.

Start from the vHJ equation
\[
\partial_t S_t = \Delta S_t - |b_t|^2 + J_t.
\]

### 2.1. Gradient evolution

Differentiate once:
\[
\partial_t b_{t,i}
= \partial_i\partial_t S_t
= \partial_i\Delta S_t - \partial_i(|b_t|^2) + \partial_i J_t.
\]
We have \(\partial_i\Delta S_t = \Delta b_{t,i}\) by commutativity of derivatives, and
\[
\partial_i(|b_t|^2)
= \partial_i\left(\sum_j b_{t,j}^2\right)
= 2\sum_j b_{t,j}\partial_i b_{t,j}.
\]
Thus
\[
\partial_t b_{t,i}
= \Delta b_{t,i} - 2\sum_j b_{t,j}\partial_i b_{t,j} + \partial_i J_t.
\]

### 2.2. Hessian evolution

Differentiate again:
\[
\partial_t h_{t,ik}
= \partial_k\partial_t b_{t,i}
= \partial_k\Delta b_{t,i}
  - 2\partial_k\Big(\sum_j b_{t,j}\partial_i b_{t,j}\Big)
  + \partial_{ik}^2 J_t.
\]

We compute term by term.

1. \(\partial_k\Delta b_{t,i} = \Delta h_{t,ik}\).

2. For the nonlinear term:
   \[
   \partial_k(b_{t,j}\partial_i b_{t,j})
   = (\partial_k b_{t,j})(\partial_i b_{t,j}) + b_{t,j}(\partial_{ik}^2 b_{t,j}).
   \]
   Recognize:
   \[
   \partial_k b_{t,j} = h_{t,jk},
   \quad
   \partial_{ik}^2 b_{t,j} = \partial_i h_{t,jk}.
   \]
   So
   \[
   \partial_k(b_{t,j}\partial_i b_{t,j})
   = h_{t,jk}h_{t,ij} + b_{t,j}\partial_i h_{t,jk}.
   \]

Putting this in:
\[
\partial_t h_{t,ik}
= \Delta h_{t,ik}
  - 2\sum_j\big(h_{t,jk}h_{t,ij} + b_{t,j}\partial_i h_{t,jk}\big)
  + \partial_{ik}^2 J_t.
\]

In matrix notation:

- The quadratic term \(\sum_j h_{t,jk}h_{t,ij}\) is \((h_t^2)_{ik}\).
- The drift term \(\sum_j b_{t,j}\partial_i h_{t,jk}\) is \((\nabla S_t\cdot\nabla h_t)_{ik}\).

Thus we can write
\[
\boxed{
\partial_t h_t
= \Delta h_t - 2(\nabla S_t\cdot\nabla h_t) - 2h_t^2 + \nabla^2 J_t.
}
\]

This is a matrix‑valued reaction–diffusion equation:

- **Diffusion:** \(\Delta h_t\).
- **Drift:** \(-2(\nabla S_t\cdot\nabla h_t)\).
- **Nonlinear flattening:** \(-2h_t^2\).
- **Source:** \(\nabla^2 J_t\), which we interpret as anomaly‑driven curvature injection.

---

## 3. Bakry–Émery Curvature and MFIP

We recall the core connection between curvature and functional inequalities, then explain how MFIP tracks these quantities across scales.

### 3.1. Bakry–Émery curvature and LSI

For a diffusion generator on \(\mathbb{R}^n\)
\[
L f = \Delta f - \nabla S\cdot\nabla f,
\]
the associated carré du champ and \(\Gamma_2\) satisfy
\[
\Gamma(f) = |\nabla f|^2,
\quad
\Gamma_2(f)
= \|\nabla^2 f\|^2_{\text{HS}} + \langle\nabla^2 S\nabla f,\nabla f\rangle.
\]

If for some \(\rho>0\) we have
\[
\langle\nabla^2 S(x)v,v\rangle \ge \rho|v|^2
\quad\text{for all }x,v,
\]
then
\[
\Gamma_2(f)\ge \rho\Gamma(f)
\]
and the Bakry–Émery theory yields:

- A spectral gap \(\lambda_{\text{spec}}\ge\rho\).
- A Log–Sobolev constant \(\alpha\ge \rho\).

This motivates tracking \(\nabla^2 S_t\) (or its horizontal projection in YM) along RG time \(t\).

### 3.2. MFIP constants and RG steps

In the MFIP, at each scale \(j\) we have:

- An effective measure \(\mu_j\) on coarse fields.
- An associated Dirichlet form \(\mathcal{E}_j(f,f)\).
- A horizontal LSI constant \(\alpha_j\) and Poincaré constant \(\lambda_j\).

An RG step from scale \(j\) to \(j+1\) is decomposed schematically as:

1. **Block decomposition:** Partition space into blocks \(\{B\}\). Fields inside a block are split into a coarse variable \(X_B\) and fluctuations \(Y_B\).

2. **Conditional measures:** For each \(B\), consider the conditional law of \(Y_B\) given \(X_B\) under \(\mu_j\). Denote it \(\mu_{j,B}^{Y\mid X}\).

3. **Effective measure:** Integrate out all \(Y_B\) to define \(\mu_{j+1}\) on \(\{X_B\}\).

The MFIP aims to prove inequalities of the form
\[
\alpha_{j+1} \ge c_1\alpha_j - \varepsilon_j,
\qquad
\lambda_{j+1} \ge c_2\lambda_j - \varepsilon_j,
\]
with \(c_1,c_2>0\) and \(\varepsilon_j\) small.

### 3.3. Tensorization and perturbation

Let us outline a typical argument in finite dimension:

- Suppose a reference product measure \(\nu = \bigotimes_B \nu_B\) satisfies an LSI with constant \(\alpha_{\mathrm{ref}}\).
- Suppose the conditional measures \(\mu_{j,B}^{Y\mid X}\) also satisfy LSI with constants \(\alpha_{j,B}\ge c\alpha_{\mathrm{ref}}\), uniformly in \(X\) and \(B\).

Tensorization then implies that the product measure \(\bigotimes_B \mu_{j,B}^{Y\mid X}\) has an LSI constant \(\ge c\alpha_{\mathrm{ref}}\).

If the actual \(\mu_j\) is a perturbation of such a product structure with controlled interaction range and small non‑convexity (measured via a Log–Sobolev perturbation theorem, such as those by Holley–Stroock, Bobkov–Götze, Barthe–Cattiaux–Roberto), one can conclude that \(\mu_j\) also has an LSI with a constant bounded below by something like
\[
\alpha_j\ge c\alpha_{\mathrm{ref}} - \varepsilon_j,
\]
where \(\varepsilon_j\) depends on the interaction strength and range.

Applying the RG step then consists of:

1. Using tensorization plus BE curvature control to show that the conditional measures \(Y_B\mid X_B\) have LSI constants \(\ge c\alpha_j\) (up to a small error encoded by Conjecture A).

2. Showing that integrating out \(Y_B\) defines an effective measure whose density relative to a reference product measure on \(X_B\) has second derivatives controlled by the Hessian flow (Conjecture B).

3. Applying a perturbation theorem to obtain an inequality
   \[
   \alpha_{j+1} \ge c_1\alpha_j - \varepsilon_j,
   \]
   where \(c_1\) reflects curvature propagation and \(\varepsilon_j\) comes from UV divergences controlled by Conjecture A.

A similar scheme applies to Poincaré constants \(\lambda_j\), with the caveat that Poincaré is weaker than LSI.

The specificity for YM is that:

- We work in a **horizontal** subspace, to avoid gauge directions.
- UV divergences in the Dirichlet form (gradient norms) must be controlled by the Log–Forest hypothesis, ensuring that the perturbation at each RG step is small in the sense relevant to functional inequalities.

---

## 4. Variance Decomposition: Local vs Topological Modes

A key conceptual point is that the “physical” mass gap should be encoded in a **local‑sector spectral gap** rather than in the full global gap, which is polluted by slow topological tunneling.

Let \((\Omega,\mathcal{F},\mu)\) be a probability space generated by the YM path measure. Suppose \(\mathcal{F}\) is generated by:

- Local fields (e.g. smeared Wilson loops in a bounded region).
- A discrete topological variable \(Q\in\mathbb{Z}\) (instantons/charge).

We can write \(\mu\) as a mixture of conditional measures:
\[
\mu = \sum_{q\in\mathbb{Z}} \pi_q \mu_q,
\]
where \(\mu_q\) is \(\mu\) conditioned on \(Q=q\), and \(\pi_q = \mu(Q=q)\).

For any \(f\in L^2(\mu)\),
\[
\operatorname{Var}_\mu(f)
= \mathbb{E}_\mu\big[(f-\mathbb{E}_\mu f)^2\big]
= \sum_q\pi_q\mathbb{E}_{\mu_q}\big[(f-\mathbb{E}_\mu f)^2\big].
\]
Add and subtract \(\mathbb{E}_{\mu_q}f\):
\[
f-\mathbb{E}_\mu f = (f-\mathbb{E}_{\mu_q}f) + (\mathbb{E}_{\mu_q}f - \mathbb{E}_\mu f).
\]
Then
\[
\operatorname{Var}_\mu(f)
= \sum_q\pi_q\operatorname{Var}_{\mu_q}(f)
+ \sum_q\pi_q(\mathbb{E}_{\mu_q}f - \mathbb{E}_\mu f)^2.
\]

The first term is the **within‑topological‑sector variance**, the second term is the **between‑sectors variance**.

The MFIP aims to control the first term via functional inequalities for each \(\mu_q\), while acknowledging that the second term may be large and associated with slow topology‑changing modes. The local‑sector spectral gap is essentially the infimum spectral gap across the \(\mu_q\), ignoring the between‑sector contributions.

This decomposition is algebraic and does not depend on the existence of a mass gap; it is purely a property of variance.

---

## 5. LLM‑Friendly Task Decomposition

To make this document maximally useful for LLM‑based derivations, here is a list of focused tasks:

1. **Task B1 (HJ derivation in infinite dimensions).**  
   Starting from a formal Fokker–Planck equation on an abstract Wiener space, derive a formal vHJ equation for a field‑theoretic effective action, carefully tracking which steps rely on finite‑dimensional identities.

2. **Task B2 (Hessian flow with gauge projection).**  
   Extend the Hessian evolution equation to the YM setting, where \(S_t\) is defined on the **horizontal** subspace and includes gauge‑fixing terms. Derive the projected evolution for the horizontal Hessian.

3. **Task B3 (Curvature perturbation theorem).**  
   Prove a perturbative result of the form: if a measure \(\nu\) satisfies \(\mathrm{CD}(\rho,\infty)\) and \(\mu\) has density \(e^{-V}\) relative to \(\nu\) with \(\|\nabla^2 V\|_{L^\infty}\le \delta\), then \(\mu\) satisfies \(\mathrm{CD}(\rho-\delta,\infty)\).

4. **Task B4 (Concrete MFIP step for a toy model).**  
   Implement a single RG step for a block‑spin transformation of a Gaussian measure with a small quartic perturbation and show explicitly how \(\alpha_{j+1}\) relates to \(\alpha_j\).

5. **Task B5 (Variance decomposition in a lattice model).**  
   For a lattice U(1) gauge theory with a simple topological charge (e.g. twisted boundary conditions), write the explicit variance decomposition between topological sectors and identify the contribution of slow tunneling to the global spectral gap.

These tasks are structured so that an LLM can work on them with this document as context, step by step, without needing the entire YM program at once.