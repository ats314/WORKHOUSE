# Usage Instructions for LLM Prompt: Perturbative Anomaly Source Bound

**Date:** November 21, 2025

---

## What This Prompt Does

This prompt instructs an LLM to derive a rigorous perturbative proof that the anomaly source term in Yang-Mills theory is strictly positive in the UV regime. This is **Prong B** of our three-pronged strategy to prove Hypothesis (Anom) of our conditional theorem.

---

## How to Use This Prompt

### Option 1: Direct Copy-Paste

1. Open the file `llm_prompt_anomaly_source.md`
2. Copy the entire contents (everything between the triple quotes)
3. Paste into your LLM interface (Claude, GPT-4, etc.)
4. Submit and wait for the derivation

### Option 2: Iterative Refinement

If the LLM's first attempt is incomplete or has errors:

1. Review the output carefully
2. Identify specific issues (e.g., "The expansion of the logarithm is incorrect")
3. Ask follow-up questions like:
   - "Can you redo step 2 more carefully, showing all terms in the expansion?"
   - "The momentum-space operator should be a matrix. Can you write it out explicitly?"
   - "What is the explicit form of the eigenvalues?"

### Option 3: Guided Collaboration

Work through the derivation step-by-step with the LLM:

1. Start with: "Let's work through this step by step. First, explain the background field method."
2. After each step, ask: "Is this correct? What comes next?"
3. Request explicit calculations: "Show me the full calculation of the field strength expansion."

---

## Expected Output

The LLM should produce a document with:

### 1. Theorem Statement
```
Theorem (Perturbative Anomaly Source Bound):
For sufficiently small coupling g, the anomaly source satisfies:
σ_A ≥ c · g² k² > 0
where c = c(N, β₀) is an explicit positive constant.
```

### 2. Key Steps in Derivation

- **Background field expansion:** $A_\mu = \bar{A}_\mu + a_\mu$
- **Field strength expansion:** $F_{\mu\nu} = \bar{F}_{\mu\nu} + D_\mu a_\nu - D_\nu a_\mu + O(a^2)$
- **Forcing term expansion:** $J[A] = J^{(0)} + J^{(1)}[a] + J^{(2)}[a] + \ldots$
- **Quadratic action:** $S_{\text{anom}}^{(2)}[a] = \frac{1}{2} \int a \cdot \mathcal{O} \cdot a$
- **Momentum space:** $\tilde{\mathcal{O}}(k) = $ (explicit matrix)
- **Eigenvalues:** $\lambda_i(k) = $ (explicit formulas)
- **Minimal eigenvalue:** $\sigma_A = \min_i \lambda_i(k) = c \cdot g^2 k^2$

### 3. Final Boxed Result
```
┌─────────────────────────────────────────────┐
│  σ_A ≥ (11N)/(48π²) · g² k² > 0            │
└─────────────────────────────────────────────┘
```

---

## Quality Checks

Before accepting the LLM's output, verify:

### Mathematical Rigor
- [ ] All expansions are justified (e.g., small field approximation)
- [ ] Gauge choice is stated and used consistently
- [ ] All indices are contracted correctly
- [ ] Dimensional analysis is correct

### Completeness
- [ ] Field strength is expanded to the correct order
- [ ] The logarithm is handled correctly (this is tricky!)
- [ ] The Hessian operator is explicitly written
- [ ] Momentum-space transformation is shown
- [ ] Eigenvalue calculation is complete

### Physical Correctness
- [ ] The bound is positive (not negative!)
- [ ] The bound scales correctly with $g$ and $k$
- [ ] The coefficient depends on $N$ as expected
- [ ] The result makes physical sense (mass term in UV)

---

## Common Issues and Solutions

### Issue 1: "The logarithm expansion is divergent"

**Solution:** The logarithm $\log(F^2/\mu^4)$ should be expanded around a non-zero background or regulated. The LLM should:
- Use dimensional regularization
- Or work with $\log(F^2/\mu^4 + \epsilon)$ and take $\epsilon \to 0$ at the end
- Or use a background field with $\bar{F}^2 \neq 0$

### Issue 2: "The operator has zero eigenvalues"

**Solution:** This likely means:
- Gauge modes are not properly fixed (use Landau gauge)
- Or the LLM is looking at the wrong component of the operator
- Ask: "What happens when you project onto the transverse (gauge-fixed) subspace?"

### Issue 3: "The bound is negative"

**Solution:** This is a sign error. The LLM should:
- Check the sign of the beta function ($\beta_0 > 0$ for asymptotic freedom)
- Check the sign in the definition of $J[A]$ (there's a minus sign)
- Verify the sign of the Hessian (second derivative)

### Issue 4: "The calculation is too complicated"

**Solution:** Simplify by:
- Working at one-loop order only
- Using Landau gauge to eliminate longitudinal modes
- Evaluating at zero background field ($\bar{A} = 0$)
- Focusing on the leading order in $g$

---

## Integration with Existing Work

Once you have the LLM's output:

1. **Review for correctness** using the quality checks above
2. **Save as a new document:** `Perturbative_Anomaly_Source_Bound_Proof.md`
3. **Cross-reference with lattice proof:** The lattice bound was $\sigma_A^{\text{lattice}} = \frac{N g_0^2 a^2}{12}$. The perturbative bound should be consistent in the UV limit.
4. **Update the conditional theorem:** Add a remark that Hypothesis (Anom) is now proven in two settings:
   - Lattice (Prong A): $\sigma_A \geq \frac{N g_0^2 a^2}{12}$
   - Perturbative UV (Prong B): $\sigma_A \geq c \cdot g^2 k^2$

---

## Expected Timeline

- **LLM generation:** 5-10 minutes
- **Review and verification:** 1-2 hours
- **Refinement (if needed):** 2-4 hours
- **Integration:** 1 hour

**Total:** 4-8 hours of work to complete Prong B.

---

## Next Steps After Prong B

Once Prong B is complete, proceed to:

**Prong C:** Functional inequality proof using Bakry-Émery calculus
- Use the Bakry-Émery $\Gamma_2$ calculus framework
- Prove the curvature-dimension condition $CD(\rho, \infty)$
- Show $\rho = \sigma_A > 0$

This will give us **three independent proofs** of the anomaly source bound:
1. ✅ Lattice (Prong A) - **COMPLETED**
2. ⏳ Perturbative UV (Prong B) - **IN PROGRESS**
3. ⏳ Functional inequality (Prong C) - **NEXT**

---

## Recommended LLMs for This Task

Based on the complexity of the calculation:

1. **Claude 3.5 Sonnet** (Recommended)
   - Excellent at mathematical derivations
   - Good at following complex instructions
   - Can handle multi-step calculations

2. **GPT-4** (Alternative)
   - Strong physics knowledge
   - May need more guidance on technical details

3. **Gemini 1.5 Pro** (Alternative)
   - Good at long-context tasks
   - May need more prompting for rigor

---

## Final Note

This derivation is a standard perturbative QFT calculation, but it requires care with signs, indices, and gauge fixing. The LLM should be able to complete it, but you may need to iterate 2-3 times to get a fully rigorous result.

**Good luck!**
