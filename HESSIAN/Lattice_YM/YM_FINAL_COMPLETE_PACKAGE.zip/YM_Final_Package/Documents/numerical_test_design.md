# Numerical Test for the Yang-Mills Mass Gap

## Objective
Compute the mass gap Δ(a) for a sequence of lattice spacings and determine if it vanishes as a → 0.

## Method: Wilson Loop Correlation
The mass gap can be extracted from the exponential decay of large Wilson loops:

⟨W(R,T)⟩ ~ exp(-σ R T) for T >> R

where σ is the string tension. The mass gap is Δ ~ √σ.

## Simplified 2D Test (Proof of Concept)
We'll start with 2D Yang-Mills (which is exactly solvable) to validate the method, then extend to 4D.

### Algorithm:
1. Generate SU(2) lattice configurations using Metropolis Monte Carlo
2. Measure Wilson loops of size R×T for various R,T
3. Extract the string tension σ(a) for different lattice spacings
4. Plot σ(a) vs a and extrapolate to a→0

## Implementation Plan
- Use Python with NumPy for matrix operations
- SU(2) group: 2×2 unitary matrices with det=1
- Lattice sizes: 8×8, 16×16, 32×32, 64×64
- Monte Carlo sweeps: 10,000 thermalization + 100,000 measurement
