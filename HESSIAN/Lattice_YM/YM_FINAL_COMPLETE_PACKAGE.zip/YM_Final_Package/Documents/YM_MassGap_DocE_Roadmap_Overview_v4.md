# Dynamic and Constructive Yang–Mills Mass Gap Program: Roadmap Overview

_High-level summary derived from the master white paper (v3.6)._  



## Executive Summary

This white paper lays out a **dynamic and constructive program** for the Yang–Mills Existence and Mass Gap problem, combining:

- A **convex scalar prototype** (lattice \(\phi^4_4\)) where the Bakry–\u00c9mery curvature condition yields a uniform log–Sobolev inequality and spectral gap, providing a fully rigorous test case for the dynamic route.
- A **stochastic/dynamic formulation** of Yang–Mills via Langevin (stochastic quantization), focusing on **spectral gaps of the generator** and their relation to the physical mass gap.
- A **UV “Log–Forest” hypothesis** for gradient norms of gauge-invariant observables (Wilson loops), ensuring that the Dirichlet form is not destroyed by uncontrolled UV roughness.
- A **toy RG–Hessian / curvature-flow picture**, where the trace anomaly acts as a positive curvature source in a viscous Hamilton–Jacobi flow for the effective action.
- A **stratified Sobolev framework** on the singular gauge quotient \(\mathcal{A}/\mathcal{G}\), including a rigorous definition of \(W^{1,2}(\mathcal{A}/\mathcal{G})\) and a Gaussian-reference polarity theorem (plus Conjecture C for the full YM measure) showing that reducible strata can be treated as capacity-zero.
- A **constructive lattice YM component** (in the spirit of Faria da Veiga & O’Carroll) where:
  - the Hilbert space is rigorously decomposed into **charge-conjugation (“polarity”) sectors** \(\mathcal{H} = \mathcal{H}^+ \oplus \mathcal{H}^-\) for \(SU(N>2)\),
  - the **Haar measure** is shown to generate an effective local mass term (“mass from geometry”),
  - and **two positive mass gaps** \(\Delta^\pm\) are established at finite lattice spacing.

The program does **not** claim a full Clay-level proof. Instead it:

1. Makes explicit which steps are **formal** and which are **conjectural**.  
2. Identifies a precise **local-sector spectral gap** that should correspond to the physical mass gap, separating it from ultra-slow topological modes.  
3. States a set of named conjectures (A, B, C, IR–1/2, D) whose resolution would turn this architecture into a rigorous solution.

---



# Part VII – Named Conjectures and Roadmap

For clarity, the program is summarized in terms of the following conjectures and implications:

- **Conjecture A (Log–Forest UV Control).**  
  Renormalized gradient norms of gauge-invariant composite operators (Wilson loops, smeared fields) have at most polylogarithmic UV divergences, controlled by BPHZ forest structures, with no new power divergences beyond perimeter/contact terms.

- **Conjecture B (Horizontal Anomaly Source Positivity).**  
  In the RG–Hessian flow, the anomaly contribution \(\mathbf{S}_{\mathrm{anom}}\) restricted to the horizontal, gauge-invariant subspace is local and provides a positive curvature source.

- **Conjecture C (Polarity of Reducible Strata).**  
  The singular set of reducible connections \(\Sigma\subset\mathcal{A}\) is of capacity zero for the YM Dirichlet form; the Langevin dynamics and all relevant functional inequalities can be formulated on \(\mathcal{M}_{\mathrm{reg}}\) without boundary conditions at \(\Sigma\).

- **Conjecture E (Stratified Parabolic Maximum Principle).**  
  The evolution inequality for the smallest curvature eigenvalue on the regular stratum obeys a maximum principle that is not spoiled by the polar singular set; positivity at one scale propagates along the RG (parabolic) flow.

- **Conjecture IR–1 / IR–2 (Curvature-Driven Local Gap and Non-Dominant Topology).**  
  Within each topological sector, curvature controls a local-observable spectral gap \(\lambda_{\mathrm{loc}}>0\), and global topological modes do not dominate the decay rate of local Schwinger functions in the infinite-volume limit.

- **Conjecture D (Local-Sector Spectral Gap ⇒ Physical Mass Gap).**  
  Under OS/cluster hypotheses, a Poincaré/LSI inequality with constant \(\lambda_{\mathrm{loc}}>0\) on the local-observable sector implies a positive mass gap for the reconstructed Wightman theory.

## Logical Dependency Chain

The intended implication chain is:

1. **UV & Geometry:**  
   Conjecture A (Log–Forest) + Conjecture C (Polarity of singular strata)  
   ⇒ well-defined Dirichlet form and controlled UV behavior on \(\mathcal{M}_{\mathrm{reg}}\).

2. **RG Curvature:**  
   Conjecture B (Anomaly source positivity)  
   ⇒ positive curvature fixed point in the RG–Hessian flow.

3. **IR & Topology:**  
   Conjectures IR–1/2 (local curvature gap, topology non-dominant)  
   ⇒ a positive local-sector spectral gap \(\lambda_{\mathrm{loc}}>0\) for \(-L\) acting on local observables.

4. **Mass Gap:**  
   Conjecture D (functional inequality ⇒ mass gap)  
   ⇒ physical mass gap \(\Delta>0\) in the sense of Clay.

The constructive lattice YM module (F&O) provides **independent support** for:

- The relevance of the Haar measure for mass generation,  
- The robustness and importance of polarity sectors,  
- The existence of positive mass gaps at each finite lattice spacing.

Bridging these constructive results with the dynamic, curvature-based architecture in the continuum is the long-term objective of this program.

---

---

## 7. Status update (finite-cutoff polarity and lattice pillar)

Relative to earlier versions of this roadmap, two important updates are now in place:

- **Finite-cutoff polarity \(C_{\text{cutoff}}\) is proved.**  
  On any finite lattice, the reducible set \(\Sigma_\Lambda\) is polar for both the Haar-OU and lattice YM Dirichlet forms. This is established in the lattice polarity note
  `Rigorous Proof_ Polarity of Reducible Connections in Lattice Yang-Mills.md`
  and summarized analytically in `YM_MassGap_DocC_ConjectureC_Extended_v3.md`. The only remaining polarity conjecture is the continuum YM version of Conjecture C.

- **Lattice pillar L is fully rigorous at finite cutoff.**  
  The lattice module now consists of:

  1. Finite-cutoff polarity (as above),
  2. An explicit Haar-induced mass term with coefficient \(c_0=(N^2-1)/(2N)\),
  3. A lattice Hessian formula and eigenvalue gap \(\lambda_{\min}\ge c_0\) leading to sector-wise mass gaps \(\Delta^\pm(a)\gtrsim \sqrt{c_0}/a\).

  These pieces are detailed in
  `Package 2_ Lattice Foundation - Complete Summary.md`
  and
  `Rigorous Derivation_ Lattice Hessian Formula and Eigenvalue Analysis.md`,
  and integrated into `YM_MassGap_DocD_ConstructiveLatticeYM_Extended_v1.md` and `YM_MassGap_DocD_ConstructiveLatticeYM_v4.md`.

In the global dependency graph, node **L** should now be regarded as a fully rigorous finite-cutoff pillar, and Conjecture C should be understood as concerning the **continuum** YM measure and Dirichlet form, not the lattice regularizations.
