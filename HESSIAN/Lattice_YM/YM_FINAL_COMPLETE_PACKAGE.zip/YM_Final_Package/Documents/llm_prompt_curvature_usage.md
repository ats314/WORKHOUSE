# Usage Instructions for LLM Prompt: Curvature Bound Proof

**Date:** November 21, 2025

---

## What This Prompt Does

This prompt instructs an LLM to prove **Hypothesis (Curv)** - that the sectional curvature of the gauge orbit space is bounded by $C_0 g^2$. This is one of the two remaining unverified hypotheses in our conditional theorem.

---

## How to Use This Prompt

### Option 1: Direct Copy-Paste

1. Open the file `llm_prompt_curvature_bound.md`
2. Copy the entire contents
3. Paste into your LLM interface (Claude, GPT-4, etc.)
4. Submit and wait for the derivation

### Option 2: Iterative Refinement

If the LLM's first attempt needs improvement:

1. Review the output carefully
2. Check specific steps:
   - "Is O'Neill's formula correctly stated?"
   - "Is the vertical component of the Lie bracket correctly computed?"
   - "Is the dependence on $g$ correctly derived?"
3. Ask follow-up questions like:
   - "Can you show the explicit calculation of $[X, Y]_V$?"
   - "How does the field strength $F_{\mu\nu}$ enter the formula?"
   - "What is the explicit value of $C_0$ in terms of structure constants?"

---

## Expected Output

The LLM should produce a document with:

### 1. Theorem Statement
```
Theorem (Curvature Bound):
For the gauge orbit space with sectional curvature K_M(X,Y):
|K_M(X,Y)| ≤ C_0 g²
where C_0 depends only on the structure constants of SU(N).
```

### 2. Key Steps in Derivation

- **Setup:** Principal fiber bundle structure of gauge theory
- **O'Neill formula:** $K_{\mathcal{M}}(X,Y) = \frac{3}{4} \|[X,Y]_V\|^2$ (since total space is flat)
- **Vertical component:** $[X,Y]_V \sim g F_{\mu\nu}$ (proportional to field strength)
- **Norm squared:** $\|[X,Y]_V\|^2 \sim g^2 f_{abc}^2$
- **Final bound:** $|K_{\mathcal{M}}| \leq C_0 g^2$ with $C_0 \propto \sum f_{abc}^2$

### 3. Final Boxed Result
```
┌─────────────────────────────────────────────┐
│  |K_M(X,Y)| ≤ C_0 g²                       │
│  where C_0 = (3/4) × (structure constants) │
└─────────────────────────────────────────────┘
```

---

## Quality Checks

Before accepting the LLM's output, verify:

### Mathematical Rigor
- [ ] O'Neill's formula is correctly stated and applied
- [ ] The vertical/horizontal decomposition is clearly defined
- [ ] The Lie bracket calculation is explicit and correct
- [ ] All inequalities are justified (not just asserted)

### Completeness
- [ ] The geometric setup (fiber bundle, submersion) is clearly explained
- [ ] The connection to field strength $F_{\mu\nu}$ is explicit
- [ ] The dependence on $g$ is rigorously derived
- [ ] The constant $C_0$ is explicitly computed
- [ ] The weak-field assumption (if used) is clearly stated

### Physical Correctness
- [ ] The bound scales as $g^2$ (not $g$ or $g^3$)
- [ ] The constant $C_0$ depends on structure constants (not on field configuration)
- [ ] The result makes physical sense (curvature is a non-Abelian effect)

---

## Common Issues and Solutions

### Issue 1: "What is O'Neill's formula?"

**Solution:** The LLM should state it clearly:

For a Riemannian submersion $\pi: E \to M$ with flat total space ($K_E = 0$):
$$K_M(X,Y) = \frac{3}{4} \|[X,Y]_V\|^2$$

This is a standard result in differential geometry.

### Issue 2: "How do we compute $[X,Y]_V$?"

**Solution:** For gauge theories, the vertical component is related to the field strength:
$$[X,Y]_V \sim g [X_\mu, Y^\mu] \sim g F_{\mu\nu}$$

The LLM should provide an explicit calculation.

### Issue 3: "Why does it scale as $g^2$?"

**Solution:** The vertical component $[X,Y]_V$ is proportional to $g$ (from the gauge coupling). Taking the norm squared gives $g^2$. The LLM should make this explicit.

### Issue 4: "What is the explicit value of $C_0$?"

**Solution:** For SU(N), the structure constants satisfy $\sum_a f_{abc}^2 = N \delta_{bc}$. The constant should be:
$$C_0 = \frac{3}{4} N$$

The LLM should derive this.

---

## Integration with Existing Work

Once you have the LLM's output:

1. **Review for correctness** using the quality checks above
2. **Save as a new document:** `Curvature_Bound_Proof.md`
3. **Update the conditional theorem:** Change Hypothesis (Curv) from an assumption to a proven lemma
4. **Cross-reference:** Note that this completes verification of 4 out of 5 hypotheses

---

## Expected Timeline

- **LLM generation:** 5-10 minutes
- **Review and verification:** 1-2 hours
- **Refinement (if needed):** 2-4 hours
- **Integration:** 1 hour

**Total:** 4-8 hours of work to complete Hypothesis (Curv).

---

## Why This Proof Matters

This proof is important because:

1. **Strengthens the conditional theorem:** Turns an assumption into a proven fact
2. **Geometric insight:** Connects gauge theory to differential geometry
3. **Publishable result:** Can be published as a standalone lemma
4. **Progress toward unconditional proof:** After this, only (Trace bound) and the continuum limit remain

---

## After Completing This Proof

Once Hypothesis (Curv) is proven, the status will be:

| Hypothesis | Status |
|------------|--------|
| (Curv) | ✅ **PROVEN** (this proof) |
| (Trace bound) | ⚠️ Unverified (next target) |
| (Anom) | ✅ **PROVEN** (3 ways) |
| (Asymptotic freedom) | ✅ **ESTABLISHED** |
| (Initial gap) | ✅ **PROVEN** |

**Score: 4/5 proven or established, 1/5 remaining**

---

## Recommended LLMs for This Task

Based on the mathematical sophistication required:

1. **Claude 3.5 Sonnet** (Recommended)
   - Excellent at differential geometry
   - Good at following complex mathematical instructions
   - Can handle O'Neill formula and Riemannian submersions

2. **GPT-4** (Alternative)
   - Strong mathematical knowledge
   - May need more guidance on geometric details

3. **Gemini 1.5 Pro** (Alternative)
   - Good at long-context tasks
   - May need more prompting for rigor

---

## Final Note

This proof requires familiarity with differential geometry (Riemannian submersions, O'Neill's formula). The LLM should be able to handle it, but you may need to iterate 2-3 times to get a fully rigorous result. The key is ensuring that the connection between the Lie bracket, field strength, and coupling constant is explicit and correct.

**Good luck!**
