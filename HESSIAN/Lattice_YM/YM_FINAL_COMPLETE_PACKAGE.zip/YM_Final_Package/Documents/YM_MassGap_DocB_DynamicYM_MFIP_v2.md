# Dynamic Yang–Mills and the Multiscale Functional Inequality Program

_Derived from the master white paper on Yang–Mills mass gap (v3.6)._  


## Executive Overview

## Executive Summary

This white paper lays out a **dynamic and constructive program** for the Yang–Mills Existence and Mass Gap problem, combining:

- A **convex scalar prototype** (lattice \(\phi^4_4\)) where the Bakry–\u00c9mery curvature condition yields a uniform log–Sobolev inequality and spectral gap, providing a fully rigorous test case for the dynamic route.
- A **stochastic/dynamic formulation** of Yang–Mills via Langevin (stochastic quantization), focusing on **spectral gaps of the generator** and their relation to the physical mass gap.
- A **UV “Log–Forest” hypothesis** for gradient norms of gauge-invariant observables (Wilson loops), ensuring that the Dirichlet form is not destroyed by uncontrolled UV roughness.
- A **toy RG–Hessian / curvature-flow picture**, where the trace anomaly acts as a positive curvature source in a viscous Hamilton–Jacobi flow for the effective action.
- A **stratified Sobolev framework** on the singular gauge quotient \(\mathcal{A}/\mathcal{G}\), including a rigorous definition of \(W^{1,2}(\mathcal{A}/\mathcal{G})\) and a Gaussian-reference polarity theorem (plus Conjecture C for the full YM measure) showing that reducible strata can be treated as capacity-zero.
- A **constructive lattice YM component** (in the spirit of Faria da Veiga & O’Carroll) where:
  - the Hilbert space is rigorously decomposed into **charge-conjugation (“polarity”) sectors** \(\mathcal{H} = \mathcal{H}^+ \oplus \mathcal{H}^-\) for \(SU(N>2)\),
  - the **Haar measure** is shown to generate an effective local mass term (“mass from geometry”),
  - and **two positive mass gaps** \(\Delta^\pm\) are established at finite lattice spacing.

The program does **not** claim a full Clay-level proof. Instead it:

1. Makes explicit which steps are **formal** and which are **conjectural**.  
2. Identifies a precise **local-sector spectral gap** that should correspond to the physical mass gap, separating it from ultra-slow topological modes.  
3. States a set of named conjectures (A, B, C, IR–1/2, D) whose resolution would turn this architecture into a rigorous solution.

---



# Part I – Dynamic Route to the Mass Gap

## 1. Problem Definition and OS Framework

The Clay Millennium problem asks for a rigorous, Poincaré-invariant quantum Yang–Mills theory on \(\mathbb{R}^4\) with gauge group \(G\) (e.g. \(SU(3)\)), satisfying:

1. **Existence:** A Wightman or OS-compatible Euclidean field theory with reflection positivity, locality, and covariance.
2. **Mass Gap:** The Hamiltonian \(H\) has spectrum
   \[
   \mathrm{Spec}(H) = \{0\} \cup [\Delta,\infty),\quad \Delta>0,
   \]
   i.e. all excitations above the vacuum \(\Omega\) have energy at least \(\Delta\).

In the **Euclidean OS framework**, one typically:

- Constructs a Euclidean measure \(\mu\) on a suitable configuration space (e.g. lattice or continuum fields).
- Uses OS reflection positivity and translation invariance to reconstruct a Hilbert space \(\mathcal{H}\), vacuum \(\Omega\), and Hamiltonian \(H\).
- Reads off the mass spectrum from exponential decay of Schwinger functions.

Our program rephrases the mass gap in **dynamic language**: via **stochastic quantization**.

## 2. Stochastic Quantization and the Langevin Generator

Formally, consider a (gauge-fixed or quotient) configuration space \(\mathcal{X}\) with coordinates \(A\), and define the Langevin dynamics
\[
\partial_\tau A = -\nabla S_{\text{YM}}[A] + \eta(\tau),
\]
where:

- \(S_{\text{YM}}\) is the Euclidean action,
- \(\eta\) is Gaussian noise (white in \(\tau\)) respecting gauge invariance / quotient structure.

This defines a Markov semigroup
\[
P_\tau = e^{\tau L}
\]
on \(L^2(\mu)\), where:

- \(\mu\) is the invariant measure,
- \(L\) is the generator
  \[
  L f = \Delta f - \nabla S_{\text{YM}} \cdot \nabla f
  \]
  in a suitable Sobolev sense.

The associated **Dirichlet form** is
\[
\mathcal{E}(f,f) = \int |\nabla f|^2\,d\mu,
\]
and the Markov process \(A(\tau)\) is reversible with respect to \(\mu\).

The dynamic route aims to:

1. Prove **functional inequalities** (Poincaré, log–Sobolev) with respect to \((\mu,\mathcal{E})\) for relevant classes of observables.
2. Deduce a **spectral gap** for \(-L\).
3. Transfer this spectral gap to exponential decay of Euclidean correlation functions, and hence to a physical **mass gap**.

The subtlety is **which spectral gap** controls the physical mass.

## 3. Local-Sector Spectral Gap vs Topological Modes

Topological sectors (instanton number, Chern–Simons number, etc.) can induce extremely slow modes: tunneling between sectors may produce very small eigenvalues of \(-L\) that are **not** associated with light particle excitations. We therefore distinguish:

- The **global spectral gap**:
  \[
    \lambda_{\mathrm{glob}} := \inf\left\{ \frac{\mathcal{E}(f,f)}{\|f\|^2_{L^2(\mu)}}\; \middle|\; f\perp \mathbf{1} \right\},
  \]
  which may be dominated by topological tunneling.

- The **local-observable sector**:
  \[
    \mathcal{H}_{\mathrm{loc}} := \overline{\mathrm{span}\left\{ F(A)\;\middle|\;F\text{ gauge-invariant, local/cylindrical, compact support in spacetime}\right\}}^{L^2(\mu)}.
  \]
  This is essentially the OS space generated by local fields.

The **target spectral gap** for the mass problem is:

> **Local-sector spectral gap**
> \[
>   \lambda_{\mathrm{loc}}
>   := \inf\left\{ \frac{\mathcal{E}(f,f)}{\|f\|^2_{L^2(\mu)}}\; \middle|\;
>     f \in \mathcal{H}_{\mathrm{loc}},\ \int f\,d\mu = 0
>   \right\}.
> \]

Topological modes may produce \(\lambda_{\mathrm{glob}} \ll \lambda_{\mathrm{loc}}\), but the lowest nonzero eigenvalue **relevant for local Schwinger functions** is controlled by \(\lambda_{\mathrm{loc}}\).

We package this into a central dynamic conjecture:

> **Conjecture D (Local-Sector Spectral Gap ⇒ Mass Gap).**  
> Assume:
> 1. Existence of an OS-compatible Euclidean measure \(\mu\) for YM on \(\mathbb{R}^4\) with reflection positivity, Euclidean covariance, and cluster properties.
> 2. A Poincaré or log–Sobolev inequality with constant \(\lambda_{\mathrm{loc}}>0\) holds on the local-observable subspace \(\mathcal{H}_{\mathrm{loc}}\).
> 
> Then the reconstructed Wightman theory has a mass gap \(\Delta \ge c\,\sqrt{\lambda_{\mathrm{loc}}} > 0\) for some universal \(c>0\).

Making this precise in finite volume and then passing to the thermodynamic and continuum limits is a long-term goal, but it clarifies **what spectral gap we actually need**.

## 4. Architectural Overview (Layers A–E)

The program is organized into five layers:

- **Layer A (UV – Log–Forest Regularity).**  
  Perturbative control of gradient norms of composite operators (e.g. \(\nabla W(C)\)) via **forest-structured renormalization**. Output: at most logarithmic UV divergences in \(W^{1,2}\) norms after renormalization ⇒ UV roughness is “mild”.

- **Layer B (RG–Hessian / Curvature Flow).**  
  A toy RG picture where the Hessian of the effective action obeys a **reaction–diffusion equation**, roughly
  \[
  \partial_t h = \Delta h - 2(\nabla S_t\cdot\nabla h) - 2 h^2 + \mathbf{S}_{\mathrm{anom}},
  \]
  indicating how coarse-graining and anomaly can generate a **positive curvature fixed point**.

- **Layer C (Anomaly Source & Curvature Fixed Point).**  
  The trace anomaly acts as a positive curvature source (\(\mathbf{S}_{\mathrm{anom}}\)) in the Hessian flow, stabilizing a **dimensionless curvature** \(\tilde\lambda_* > 0\) that sets a mass scale \(\sim \tilde\lambda_*^{1/2}\Lambda_{\mathrm{QCD}}\).

- **Layer D (Stratified Sobolev Geometry & Polarity).**  
  Construction of \(W^{1,2}(\mathcal{A}/\mathcal{G})\) via horizontal gradients of gauge-invariant cylindrical functionals; argument that the singular set \(\Sigma\) (reducible connections) has **infinite codimension** and **zero capacity**, so it can be ignored in functional inequalities.

- **Layer E (Functional Inequalities ⇒ Local Spectral Gap ⇒ Mass Gap).**  
  Application of Bakry–Émery theory and related tools to obtain Poincaré/LSI inequalities on the regular stratum, and thus a **local-sector spectral gap** \(\lambda_{\mathrm{loc}}\) leading to a mass gap by Conjecture D.

Later sections add a **constructive lattice YM module** (Faria da Veiga & O’Carroll) that provides:

- Rigorous lattice Hilbert space,
- Charge-conjugation polarity decomposition,
- Haar-measure-induced mass term,
- and explicit two-sector mass gaps at finite lattice spacing.

---



# Part II – UV Layer: Log–Forest Regularity (Conjecture A)

## 2.1. Lattice Gauge Setup and Wilson Loops

We work on a 4D hypercubic lattice \(\Lambda\) with spacing \(a\), gauge group \(G=SU(3)\) (or \(SU(N)\)). Fundamental variables:

- Link fields \(U_\ell \in SU(N)\) on oriented edges \(\ell\).
- Plaquettes \(U_p\) are oriented products around minimal squares.

The Wilson plaquette action is
\[
S_{\Lambda}(U)
= \frac{\beta}{N} \sum_{p\subset\Lambda} \mathrm{Re}\,\mathrm{Tr}(I-U_p),
\quad \beta = \frac{2N}{g_0^2},
\]
with bare coupling \(g_0\).

Gauge-invariant observables include:

- Wilson loops \(W(C) = \frac{1}{N}\mathrm{Re}\,\mathrm{Tr}\prod_{\ell\in C} U_\ell\),
- Smeared field-strength operators, etc.

We introduce Lie-algebra coordinates
\[
U_\ell = \exp(g_0 A_\ell),\quad A_\ell \in \mathfrak{su}(N),
\]
in a suitable gauge (e.g. maximal tree gauge), so that the lattice action admits a perturbative expansion.

## 2.2. Gradients and UV Roughness

Define the Lie-algebra gradient of an observable \(O(U)\) by
\[
(\nabla_\ell^a O)(U)
:= \left.\frac{d}{dt}\right|_{t=0}
  O(\dots, e^{t T^a} U_\ell, \dots),
\]
and the global gradient norm
\[
\|\nabla O\|^2_{L^2(\mu_\Lambda)}
:= \sum_{\ell,a}\int |\nabla_\ell^a O(U)|^2\,d\mu_\Lambda(U),
\]
where \(\mu_\Lambda\) is the normalized lattice YM measure.

Bare derivatives of Wilson loops have:

- **Perimeter divergences** (power-like in \(1/a\)),
- **Contact divergences** when links in the loop fuse.

These appear already in perturbation theory and are absorbed into:

- Perimeter counterterms for the test charge,
- Contact renormalizations (local operator mixings).

The **nontrivial question** is: after renormalizing these power divergences, what is the UV behavior of the **residual** \(W^{1,2}\) norm?

## 2.3. Conjecture A: Log–Forest W^{1,2} Control

The UV layer is organized around:

> **Conjecture A (Log–Forest UV Control).**  
> For each gauge-invariant polynomial observable \(O\) (e.g. Wilson loops with finitely many insertions), there exists a renormalized composite operator \([O]_{\mathrm{ren}}\) such that:
> 
> 1. All power divergences in \(\|\nabla O\|_{L^2(\mu_\Lambda)}^2\) are absorbed into local counterterms associated to the perimeter/contact structure of \(O\).
> 2. The residual renormalized gradient norm admits an asymptotic expansion
>    \[
>    \|\nabla [O]_{\mathrm{ren}}\|^2_{L^2(\mu_\Lambda)}
>    \sim \sum_{n\ge 0} g_0^{2n}
>      \sum_{\tau\in \mathcal{F}_n}
>        C_\tau (\log \tfrac{1}{a})^{k(\tau)},
>    \]
>    where \(\mathcal{F}_n\) is a finite set of **Zimmermann forests** (nested divergence structures), and \(k(\tau)\) is a combinatorial depth of nested marginal subgraphs.
> 
> In particular, the UV roughness of renormalized composite observables is at most **polylogarithmic** in \(1/a\), not power-like.

This is a perturbative expectation, consistent with BPHZ renormalization, but not yet proven in full lattice YM. The key content is:
From a technical standpoint, Conjecture A is intended to be realized using lattice BPHZ/BGW renormalization and Reisz-type power counting theorems, organized with cluster expansions; see the scalar $\phi^4_4$ prototype in the separate note \emph{Scalar Log--Forest Prototype} for an explicit example where these mechanisms can be carried out in detail.


- **No new power divergences** arise in \(W^{1,2}\) beyond those already handled by perimeter/contact terms.
- The renormalized Dirichlet form is compatible with the existence of **finite** LSI/Poincaré constants at fixed physical scale after RG improvement.

Quantitatively, the goal is a statement of the form:

> For Wilson loops \(W(C_R)\) of fixed physical size \(R\), after RG improving to scale \(\Lambda\sim 1/R\), the gradient norms satisfy
> \[
>  \|\nabla [W(C_R)]_{\mathrm{ren}}\|^2_{L^2(\mu_\Lambda)}
>  \le C(R)\,(\log \Lambda)^p,
> \]
> with finite \(p\) independent of lattice spacing. This is “mild enough” to be compatible with curvature-based functional inequalities in the IR.

---



# Part III – IR Layer: Curvature vs Topology and RG–Hessian Flow

## 3.1. Working Ansatz: Viscous Hamilton–Jacobi Flow

The exact functional RG equations for YM (Polchinski, Wetterich, etc.) are momentum-space flows for a scale-dependent effective action \(S_k\), involving infinitely many couplings and nonlocal operators.

In this white paper we adopt a **working ansatz** for a **local, field-space picture**:

> After truncating to local gauge-invariant functionals and choosing an appropriate field-space metric on \(\mathcal{A}/\mathcal{G}\), the RG flow of the effective action \(S_t\) can be approximated by a **viscous Hamilton–Jacobi** equation:
> \[
>   \partial_t S_t = \Delta S_t - |\nabla S_t|^2 + J_t,
> \]
> where
> - \(\Delta\) is a (horizontal) Laplacian in field space,
> - \(\nabla\) is the corresponding gradient,
> - and \(J_t\) is a source term encoding the trace anomaly and other nonlocal effects.

This is not claimed to be the exact RG, but a model that captures the **curvature dynamics** of coarse-grained effective measures.

**Derivation from Polchinski’s exact RG (schematic).**  
Polchinski’s equation for the Wilsonian effective action \(S_{\mathrm{eff},t}\) at scale \(t\) has the schematic form
\[
  \partial_t S_{\mathrm{eff},t}
  = 
rac{1}{2}\,\mathrm{Tr}ig(\dot{C}_t \,\delta^2 S_{\mathrm{eff},t}ig)
    - 
rac{1}{2}\,\mathrm{Tr}ig(\dot{C}_t \,(\delta S_{\mathrm{eff},t})^2ig),
\]
where \(\dot{C}_t\) is the \(t\)-derivative of the regulated covariance. If we choose a field-space metric \(G_t\) so that \(-\dot{C}_t\) is represented as the inverse of \(G_t\) on the relevant subspace, the traces can be rewritten as
\[
  \partial_t S_{\mathrm{eff},t}
  = \Delta_{G_t} S_{\mathrm{eff},t}
    - ig\|
abla_{G_t} S_{\mathrm{eff},t}ig\|_{G_t}^2
    + J_t,
\]
where \(\Delta_{G_t}\) and \(
abla_{G_t}\) are the Laplacian and gradient associated with \(G_t\), and \(J_t\) collects the remaining trace terms (metric renormalization, truncation remainders, anomalous contributions). In a local, gauge-invariant truncation and after freezing the slow \(t\)-dependence of \(G_t\), one recovers precisely the viscous Hamilton–Jacobi structure
\[
  \partial_t S_t = \Delta S_t - |
abla S_t|^2 + J_t
\]
used as the working ansatz above. Thus the vHJ equation is not an ad hoc choice but a **geometric rephrasing** of the exact RG in an adapted field-space metric.



## 3.2. Derivation of Viscous HJ and Hessian Flow (Finite Dimension)

We summarize the derivation; details are in Part IV.

Let \(\rho_t(\phi)\) be a family of densities on \(\mathbb{R}^n\) evolving under the heat equation
\[
\partial_t \rho_t = \Delta \rho_t.
\]
Assume \(\rho_t = Z_t^{-1}e^{-S_t}\). Then one finds (up to a \(\phi\)-independent normalization term)
\[
\partial_t S_t = \Delta S_t - |\nabla S_t|^2.
\]

Defining:

- \(b = \nabla S_t\) (drift),
- \(h = \nabla^2 S_t\) (Hessian),

one derives the **Hessian flow**:
\[
\partial_t h = \Delta h - 2(\nabla S_t\cdot\nabla h) - 2 h^2,
\]
which has the structure of a **reaction–diffusion equation** for curvature:

- \(\Delta h\): diffusion (smoothing curvature),
- \(-2(\nabla S_t\cdot\nabla h)\): drift along field-space flow,
- \(-2h^2\): local nonlinear “flattening” that drives negative eigenvalues to \(-\infty\) and tends to reduce large positive ones.

Adding a source term \(J_t\) in the viscous HJ equation introduces an extra curvature source
\[
\mathbf{S}_{\mathrm{anom}} = \nabla^2 J_t
\]
in the Hessian flow:
\[
\partial_t h = \Delta h - 2(\nabla S_t\cdot\nabla h) - 2 h^2 + \mathbf{S}_{\mathrm{anom}}.
\]

The **confinement mechanism** we are targeting is:

1. The anomaly provides a **positive curvature source** in the relevant directions.  
2. The reaction–diffusion flow stabilizes a **positive curvature fixed point** for certain eigenvalues of \(h\).  
3. A positive lower bound on curvature implies a Poincaré/LSI inequality via Bakry–Émery, giving a spectral gap.

## 3.3. Conjecture B: Anomaly Source Positivity

We isolate the speculative part:

> **Conjecture B (Horizontal Anomaly Source Positivity).**  
> After projecting to the gauge-invariant horizontal subspace and appropriate renormalization, the anomaly contribution satisfies
> \[
>   \langle v,\,\mathbf{S}_{\mathrm{anom}} v\rangle_{\text{hor}}
>   \;\ge\; \sigma_*\,\|v\|_{\text{hor}}^2
> \]
> for all horizontal test vectors \(v\), with \(\sigma_*>0\) independent of the IR scale near confinement. The dominant contribution is **local** and of the same tensorial type as the Hessian of \(\int \mathrm{tr}(F^2)\).

Interpretation:

- The negative beta function and nonzero gluon condensate inject “upward” curvature into the Hessian flow.
- In the relevant directions, this competes with the flattening term \(-2h^2\) and prevents the curvature from decaying to zero.

In a further truncation where \(h\) is approximated by its smallest eigenvalue \(\lambda(t)\) and diffusion/drift are neglected, we get an ODE
\[
\frac{d}{dt}\lambda \approx -2\lambda^2 + \sigma_*,
\]
which has a positive fixed point \(\lambda_* = \sqrt{\sigma_*/2}\). The full, infinite-dimensional flow is far more complicated, but this toy model illustrates the intended mechanism.

## 3.4. Topology vs Curvature: IR Conjectures

Topological sectors can generate very small eigenvalues associated with slow tunneling of global charges, which may not correspond to light particles. We therefore state:

> **Conjecture IR–1 (Sectorwise Curvature-Driven Gap).**  
> In each fixed topological sector of the YM configuration space, the Langevin generator restricted to local observables has a spectral gap \(\lambda_{\mathrm{loc}}>0\) controlled by an effective curvature lower bound (in the Bakry–Émery sense) of the renormalized measure. This \(\lambda_{\mathrm{loc}}\) corresponds to the physical mass gap.

> **Conjecture IR–2 (Topological Slowness Non-Dominant for Local Observables).**  
> Global topological modes may produce eigenvalues \(\lambda_{\mathrm{top}}\ll\lambda_{\mathrm{loc}}\) for \(-L\) on the full \(L^2(\mu)\), but the associated eigenfunctions have negligible overlap with local cylindrical observables in large volume. Therefore, \(\lambda_{\mathrm{top}}\) does not control the decay rate of local 2-point Schwinger functions.

These conjectures justify the focus on the local-sector spectral gap \(\lambda_{\mathrm{loc}}\) in Conjecture D.

## 3.5. Numerical Diagnostics: T13 and TQ13

To test IR–1/IR–2, we propose:

- **T13 (Pilot):** JAX-based SU(3) Langevin on small lattices (\(8^4\)) with:
  - Autocorrelation times \(\tau(W)\) for small Wilson loops,
  - A “roughness ratio” diagnostic for local fluctuations.

  Result so far: \(\tau(W)\) is \(\mathcal{O}(1)\) across a moderate \(\beta\) range, with no visible critical slowing down at this tiny volume. This mainly validates the code; it says little about true IR behavior.

- **TQ13 (Topological Probe):**  
  On larger lattices (e.g. \(16^4, 24^4\)), implement:
  - Gradient flow to define a lattice topological charge \(Q_t\),
  - Autocorrelation times \(\tau(Q)\) and tunneling rates between sectors,
  - Comparison with \(\tau(W)\) for local loops.

  The aim is to distinguish:
  - **Tunneling-dominated scenario:** \(\tau(Q) \sim e^{cL}\), \(\tau(Q)\gg\tau(W)\), where global gap is dominated by topology;
  - **Curvature-dominated scenario:** \(\tau(Q)\) and \(\tau(W)\) of similar parametric scale, reflecting the same curvature-driven mass.

Design details (choice of flow time, discretization of \(Q_t\), \(\beta\) values around physical scales) are left to a separate numerical note. The conceptual role in this white paper is to provide evidence for or against Conjecture IR–2.

---



# Part IV – Functional Inequalities and Toy Models

## 4.1. Dirichlet Form, Generator, and Poincaré Inequality

In a finite-dimensional model with measure
\[
d\mu(x) = Z^{-1} e^{-V(x)} dx,
\]
and generator
\[
L f = \Delta f - \nabla V\cdot\nabla f,
\]
the Dirichlet form
\[
\mathcal{E}(f,f) = \int |\nabla f|^2 d\mu
\]
is symmetric in \(L^2(\mu)\).

The **Poincaré inequality** with constant \(\lambda>0\) is
\[
\mathrm{Var}_\mu(f)
:= \int f^2 d\mu - \left(\int f d\mu\right)^2
\le \frac{1}{\lambda}\int |\nabla f|^2 d\mu.
\]

This is equivalent to \(-L\) having a **spectral gap** \(\lambda\):

- If \(-L\) has an isolated eigenvalue \(0\) (constants), and \(\lambda_1 \ge \lambda>0\) for all other eigenvalues, then the Poincaré inequality holds with constant \(\lambda\).
- Conversely, a Poincaré inequality implies \(\mathrm{Spec}(-L)\subset\{0\}\cup[\lambda,\infty)\).

The proof uses spectral decomposition and integration by parts; it generalizes to infinite dimensions under standard Dirichlet form theory assumptions.

## 4.2. Bakry–Émery Curvature and Log–Sobolev Inequalities

Define the carré du champ
\[
\Gamma(f) = \tfrac{1}{2}(L(f^2) - 2 f Lf) = |\nabla f|^2,
\]
and
\[
\Gamma_2(f) = \tfrac{1}{2}(L\Gamma(f) - 2\Gamma(f,Lf)).
\]

For \(L = \Delta - \nabla V\cdot\nabla\), a direct computation gives
\[
\Gamma_2(f)
= \|\nabla^2 f\|_{\mathrm{HS}}^2
  + \langle (\nabla^2 V)\nabla f,\nabla f\rangle.
\]

If there exists \(\rho>0\) such that
\[
\nabla^2 V(x) \ge \rho I \quad \forall x,
\]
then
\[
\Gamma_2(f) \ge \rho \Gamma(f).
\]

This is the **Bakry–Émery curvature condition**. It implies:

- A Poincaré inequality with constant \(\lambda\ge \rho\),
- A log–Sobolev inequality (LSI)
  \[
    \mathrm{Ent}_\mu(f^2)
    := \int f^2 \log\frac{f^2}{\int f^2 d\mu} d\mu
    \le \frac{2}{\rho}\int |\nabla f|^2 d\mu.
  \]

The proof uses the entropy decay of the semigroup \(P_t\) and the differential inequality \(\Psi''(t) \ge \rho \Psi'(t)\) for \(\Psi(t)=\mathrm{Ent}_\mu((P_t f)^2)\).

In the YM context, we seek an **effective curvature bound** in the horizontal directions of \(\mathcal{A}/\mathcal{G}\) at large RG scales, consistent with Conjectures A and B.

## 4.3. Double-Well Toy Model and Tunneling

To clarify what curvature-based inequalities can and cannot detect, consider the 1D double-well potential
\[
V(x) = \tfrac{1}{4}(x^2 - 1)^2,
\]
with invariant measure \(\mu(dx) \propto e^{-V(x)}dx\) and generator \(L f = f'' - V'(x)f'\).

- There are two wells around \(x=\pm 1\) separated by a barrier at \(x=0\).
- The lowest nonzero eigenvalue \(\lambda_1\) of \(-L\) corresponds to metastable **tunneling** between the wells. In the small-noise/deep-well regime, \(\lambda_1 \sim C e^{-\Delta V}\) (Eyring–Kramers).

Critically:

- The **Poincaré constant** (spectral gap) is **exponentially small** in the barrier height.
- The **LSI constant** is also exponentially small: for multimodal measures with high barriers, Holley–Stroock and subsequent work show LSI constants degrade exponentially with the barrier height (up to polynomial corrections).

So **both** Poincaré and LSI “see” the tunneling time; neither gives a robust bound that ignores the exponentially slow mode.

For our YM program, this means:

- If topological tunneling produces extremely slow modes that strongly affect the measure, then any global curvature-based inequality (Poincaré/LSI on all of \(L^2(\mu)\)) will have a constant that is at most of the order of the global tunneling rate.
- To get a **mass gap** from curvature, we must either:
  - restrict attention to the **local observable sector** where topological modes are negligible (Conjectures IR–1/2 and D), or
  - use more delicate inequalities that explicitly factor out global topological degrees of freedom.

This is why the distinction between global and local-sector spectral gaps in Part I is essential.

---

## 3.6. Stratified Maximum Principle and Curvature Flow (Conjecture E)

The RG–Hessian layer and the stratified Sobolev/polarity layer are connected by a parabolic positivity mechanism. Informally: once we know that the singular set \(\Sigma\) is polar (so the Langevin diffusion does not hit it), we would like to know that a **parabolic comparison principle** for the lowest curvature eigenvalue persists on the regular stratum \(\mathcal{M}_{\mathrm{reg}}\). This is the role of a stratified maximum principle.

### Conjecture E (Stratified Parabolic Maximum Principle)

Let \(\mathcal{M} = \mathcal{A}/\mathcal{G}\) be the gauge quotient with regular stratum \(\mathcal{M}_{\mathrm{reg}}\) and singular set \(\Sigma\). Let \(L\) be the generator of the Yang–Mills Langevin diffusion on \(\mathcal{M}\), viewed as a second-order (formal) differential operator on \(\mathcal{M}_{\mathrm{reg}}\).

Consider a (matrix-valued or scalar) function \(u(t,x)\) on \([0,\infty)\times\mathcal{M}_{\mathrm{reg}}\) solving a semilinear parabolic inequality of the form
\[
  \partial_t u \;\ge\; L u + F(u,x,t)
\]
in a weak (Dirichlet-form) sense, with \(F\) nondecreasing in \(u\) and satisfying appropriate growth bounds.

Assume:
1. \(u(0,x)\ge 0\) for \(\mu\)-a.e. \(x\in\mathcal{M}_{\mathrm{reg}}\).  
2. The singular set \(\Sigma\) is polar for the diffusion associated with \(L\) (i.e., \(\mathrm{Cap}_\mu(\Sigma)=0\)).

Then for all \(t>0\),
\[
  u(t,x) \ge 0 \quad \text{for \(\mu\)-a.e. }x\in\mathcal{M}_{\mathrm{reg}}.
\]

Informally: under polarity of \(\Sigma\) and mild monotonicity of the nonlinearity \(F\), the positivity-preserving property of the parabolic flow is not destroyed by the singular strata. The “bad set” is too thin to act as a genuine boundary.

### Bridging Proposition: From Polarity and Anomaly to Global Curvature Positivity

We now formulate a conditional statement that shows how polarity, an anomaly-induced curvature source, and the stratified maximum principle would combine to give a uniform positive lower bound on the smallest curvature eigenvalue.


At the tensor level, the RG–Hessian flow can be written schematically (see §3.2) as an evolution equation for the horizontal Hessian \(h_t(x)\) of the effective action:
\[
  \partial_t h_t
  = L_t h_t - 2 h_t^2 + \mathbf{S}_{\mathrm{anom},t},
\]
where \(L_t\) is the (horizontal) diffusion operator on the regular stratum and \(\mathbf{S}_{\mathrm{anom},t}\) encodes the anomaly-induced source. Under the strong form of Conjecture B, there exists \(\sigma_*>0\) with
\[
  \mathbf{S}_{\mathrm{anom},t}(x) \;\ge\; \sigma_*\,I
\]
as quadratic forms, so that
\[
  \partial_t h_t \;\ge\; L_t h_t - 2 h_t^2 + \sigma_* I.
\]
Let \(H(t)\) solve the spatially homogeneous matrix ODE
\[
  
rac{d}{dt} H(t) = -2 H(t)^2 + \sigma_* I,
  \qquad H(t_0)=H_0.
\]

> **Theorem (Tensor Comparison Principle, heuristic form).**  
> Assume a stratified maximum principle holds for symmetric tensor fields (as in Conjecture E, extended from scalars to matrices). If \(h_{t_0}(x)\ge H_0\) for \(\mu\)-almost every \(x\) on the regular stratum, then
> \[
>   h_t(x) \;\ge\; H(t)
> \]
> for all \(t\ge t_0\) and \(\mu\)-a.e. \(x\). In particular, if \(H_0=0\), the ODE solution \(H(t)\) converges monotonically to a positive-definite fixed point \(H_*=\sqrt{\sigma_*/2}\,I\), and therefore the Hessian is uniformly bounded below:
> \[
>   h_t(x) \;\ge\; H_* \quad 	ext{for all large }t.
> \]

Projecting onto the smallest eigenvalue, this tensor comparison reduces to the scalar inequality for
\(
  \lambda(t,x) = \lambda_{\min}(h_t(x)),
\)
with \(\lambda_{\min}(t)\) solving the scalar Riccati ODE. The Bridging Proposition below is exactly this scalar projection.

> **Proposition (Bridging Polarity and Anomaly to Global Curvature Positivity).**  
> Assume:
> 
> 1. **Polarity of singularities (Conjecture C):**  
>    The singular set \(\Sigma\) of reducible connections has capacity zero for the Yang–Mills Dirichlet form and is polar for the Langevin diffusion on \(\mathcal{M}\).
> 
> 2. **Anomaly-induced curvature source (Conjecture B, strong form):**  
>    The RG–Hessian flow for the effective action has a smallest eigenvalue \(\lambda(t,x)\) on the regular stratum satisfying, in a weak sense,
>    \[
>      \partial_t \lambda \;\ge\; L \lambda - 2 \lambda^2 + \sigma_*,
>    \]
>    for some constant \(\sigma_*>0\), where \(L\) is the (horizontal) generator of the Langevin diffusion. In particular, the anomaly provides a strictly positive source term \(\sigma_*\) in the evolution inequality for \(\lambda\).
> 
> 3. **Stratified maximum principle (Conjecture E):**  
>    The positivity-preserving property of the parabolic flow associated with \(L\) extends to \(\mathcal{M}_{\mathrm{reg}}\) despite the singular set \(\Sigma\), as stated in Conjecture E.
> 
> 4. **Initial nonnegativity:**  
>    At some RG scale \(t_0\), the smallest eigenvalue satisfies
>    \[
>      \lambda(t_0,x) \ge 0 \quad \text{for \(\mu\)-a.e. }x\in\mathcal{M}_{\mathrm{reg}}.
>    \]
> 
> Then, for all \(t \ge t_0\) and \(\mu\)-a.e. \(x\in\mathcal{M}_{\mathrm{reg}}\), we have
> \[
>   \lambda(t,x) \;\ge\; \lambda_{\mathrm{min}}(t) \;>\; 0,
> \]
> where \(\lambda_{\mathrm{min}}(t)\) solves the scalar ODE
> \[
>   \partial_t \lambda_{\mathrm{min}} \;=\; -2 \lambda_{\mathrm{min}}^2 + \sigma_*,
>   \qquad \lambda_{\mathrm{min}}(t_0) = 0.
> \]
> 
> In particular, there exists a positive limit
> \[
>   \lambda_* = \lim_{t\to\infty} \lambda_{\mathrm{min}}(t) = \sqrt{\sigma_*/2} > 0,
> \]
> and thus the curvature eigenvalue is uniformly bounded below:
> \[
>   \lambda(t,x) \ge \lambda_* > 0
> \]
> for all sufficiently large \(t\) and \(\mu\)-almost every \(x\).
> 
> *Sketch of reasoning.*  
> Treat \(\lambda(t,x)\) as a supersolution to the parabolic equation
> \[
>   \partial_t u = L u - 2 u^2 + \sigma_*,
> \]
> with \(u(t_0,\cdot)\ge 0\) and the spatially constant ODE solution \(\lambda_{\mathrm{min}}(t)\) (starting from 0) as a subsolution. By the stratified maximum principle (Conjecture E), \(\lambda(t,x)\) cannot drop below \(\lambda_{\mathrm{min}}(t)\) on \(\mathcal{M}_{\mathrm{reg}}\), and hence inherits its positive lower bound in the large-\(t\) limit. Polarity of \(\Sigma\) (Conjecture C) ensures that no boundary at the singular strata can violate this comparison principle. The ODE analysis shows that the positive source \(\sigma_*\) dominates the nonlinear flattening \(-2 u^2\) and drives the system to a strictly positive fixed point \(\lambda_* = \sqrt{\sigma_*/2}\).

## 4.4. The Multiscale Functional Inequality Program (MFIP)

The functional-analytic core of the dynamic route can be phrased as a **Multiscale Functional Inequality Program (MFIP)**. The idea is to track how a log–Sobolev (or Poincaré) constant evolves under **renormalization group (RG)** flow, rather than tracking bare couplings directly.

At each coarse-graining scale \(j\) (lattice spacing \(a_j\), block size \(L^j\)), one has:

- an effective Euclidean measure \(\mu_j\) on coarse gauge degrees of freedom (e.g. block-averaged edge variables or Wilson loops),
- an associated Dirichlet form \(\mathcal{E}_j\) and generator \(L_j\),
- a log–Sobolev constant \(\alpha_j\) and Poincaré constant \(\lambda_j\) on the **horizontal, gauge-invariant sector**.

Formally, MFIP aims to establish:

1. **UV initialization (cluster expansion scale).**  
   For \(j=j_0\) deep in the ultraviolet, constructive methods (cluster/Polymer expansion, finite-range decomposition) give a strictly positive horizontal LSI:
   \[
     \mathrm{LSI}(\alpha_{j_0})\quad\text{with}\quad \alpha_{j_0}>0,
   \]
   uniformly in volume and boundary conditions, for observables built from local Wilson loops and plaquettes.

2. **RG stability and monotonicity.**  
   A single RG step \(j\mapsto j+1\) consists of:
   - integrating out short-distance fluctuations within blocks,
   - rescaling fields and couplings,
   - projecting back to the gauge-invariant (horizontal) sector.

   The MFIP postulate is that there exist universal constants \(c_1,c_2>0\) and a “noise” term \(\varepsilon_j\) controlled by UV regularity (Conjecture A) such that
   \[
     \alpha_{j+1} \;\ge\; c_1\,\alpha_j - \varepsilon_j,
     \qquad
     \lambda_{j+1} \;\ge\; c_2\,\lambda_j - \varepsilon_j.
   \]
   Intuitively: tensorization of LSIs across blocks gives a product lower bound, while the RG perturbation (integrating out constrained noise plus local counterterms) only weakly degrades the constants. Conjecture A (Log–Forest UV control) is designed precisely to keep \(\varepsilon_j\) small and summable.

3. **Horizontal anomaly source and IR saturation.**  
   In Part III, the RG–Hessian picture yields an “anomaly source” term \(\mathsf{S}_{\mathrm{anom}}\) that drives the curvature eigenvalue \(\lambda(t,x)\) toward a positive fixed point. MFIP is the functional-inequality analogue of that picture: the horizontal LSI constants \(\alpha_j\) and \(\lambda_j\) should satisfy a discrete parabolic inequality of the form
   \[
     \alpha_{j+1} - \alpha_j \;\gtrsim\; -C\,\alpha_j^2 + \sigma_{\mathrm{hor}},
   \]
   with \(\sigma_{\mathrm{hor}}>0\) determined by the anomaly on the gauge-invariant sector (Conjecture B). This favours convergence to a strictly positive limit
   \[
     \alpha_* \;=\; \liminf_{j\to\infty}\alpha_j \;>\;0.
   \]

4. **Local gap and physical mass scale.**  
   For each finite block scale \(j\), the horizontal LSI and Poincaré inequalities imply a spectral gap \(\lambda_{\mathrm{loc}}(j)\) for the local-sector generator \(L_j\). If \(\alpha_j\) converges to \(\alpha_*>0\), then
   \[
     \inf_j \lambda_{\mathrm{loc}}(j) \;\ge\; c\,\alpha_* \;>\; 0,
   \]
   giving a uniform **local-sector spectral gap** at all large scales. Conjectures IR–1/2 then assert that this local gap controls the decay of local Schwinger functions in the thermodynamic limit.

5. **From MFIP to the Yang–Mills mass gap.**  
   Finally, Conjecture D (Local-sector spectral gap \(\Rightarrow\) mass gap) identifies the physical mass scale \(\Delta\) with the square root of the local-sector spectral gap:
   \[
     \Delta \;\simeq\; c'\,\sqrt{\lambda_{\mathrm{loc}}} \;\gtrsim\; c''\,\sqrt{\alpha_*} \;>\; 0.
   \]
   Thus, closing the MFIP—establishing UV initialization, RG stability with a positive anomaly source, and IR persistence of a horizontal LSI—would amount to a complete functional-analytic proof of the mass gap, conditional only on the existence of the OS measure and the usual constructive inputs.

### 4.5. Decomposition of Variance and Local-Sector Spectral Gap

Conjectures IR–1 and IR–2 are most cleanly expressed using the **decomposition of variance** for a mixture of topological sectors. Let \\(\{S_k\}_{k\in\mathbb{Z}}\\) denote the topological sectors (e.g. labelled by instanton number), and write the YM measure as a mixture
\[
  \mu = \sum_k \pi_k \mu_k,
\]
where \(\mu_k\) is the restriction of \(\mu\) to \(S_k\) and \(\pi_k = \mu(S_k)\).

For any observable \(f\) we decompose
\[
  \mathrm{Var}_\mu(f)
  = \mathbb{E}_\muig[\mathrm{Var}(f\mid	ext{sector})ig]
    + \mathrm{Var}_\muig(\mathbb{E}[f\mid	ext{sector}]ig),
\]
i.e. a sum of **intra-sector** and **inter-sector** contributions.

Assume:

1. (**IR–1, intra-sector curvature bound**) Each restricted measure \(\mu_k\) satisfies a Poincaré inequality with a uniform constant \(
ho>0\) on the horizontal gauge-invariant sector:
   \[
     \mathrm{Var}_{\mu_k}(f)
     \;\le\; 
rac{1}{
ho}\,\mathcal{E}_k(f,f),
   \]
   where \(\mathcal{E}_k\) is the Dirichlet form restricted to \(S_k\).

2. (**IR–2, sector independence for local observables**) For \(f\) in the local horizontal sector \(\mathcal{H}_{\mathrm{loc}}\), the conditional expectations \(m_k(f):=\mathbb{E}_{\mu_k}[f]\) do not fluctuate much across sectors, in the sense that there exists \(
arepsilon\ge0\) with
   \[
     \mathrm{Var}_\muig(\mathbb{E}[f\mid	ext{sector}]ig)
     = \sum_k \pi_kig(m_k(f) - \mathbb{E}_\mu[f]ig)^2
     \;\le\; 
arepsilon\,\mathcal{E}(f,f).
   \]

Then
\[
  \mathrm{Var}_\mu(f)
  = \sum_k \pi_k \mathrm{Var}_{\mu_k}(f)
    + \mathrm{Var}_\muig(\mathbb{E}[f\mid	ext{sector}]ig)
  \;\le\; \Big(
rac{1}{
ho} + 
arepsilon\Big)\,\mathcal{E}(f,f),
\]
which yields a **local-sector spectral gap**
\[
  \lambda_{\mathrm{loc}} \;\ge\; ig(	frac{1}{
ho}+
arepsilonig)^{-1}.
\]
The global gap \(\lambda_{\mathrm{glob}}\), by contrast, is controlled by the slowest tunnelling between sectors; it may be exponentially smaller. The MFIP is precisely formulated so that the RG flow controls \(
ho\) (via curvature and LSI) and sector independence (via spatial mixing and cluster properties), thereby isolating the physically relevant local spectral gap from topological tunnelling effects.



In short, MFIP recasts the Yang–Mills mass gap as a statement about the **RG flow of horizontal log–Sobolev constants**, rather than about correlation functions directly. Parts II–V are organized so that each conjectural piece (A, B, C, IR–1/2, D) has a precise role in this multiscale inequality chain.



# Part VII – Named Conjectures and Roadmap

For clarity, the program is summarized in terms of the following conjectures and implications:

- **Conjecture A (Log–Forest UV Control).**  
  Renormalized gradient norms of gauge-invariant composite operators (Wilson loops, smeared fields) have at most polylogarithmic UV divergences, controlled by BPHZ forest structures, with no new power divergences beyond perimeter/contact terms.

- **Conjecture B (Horizontal Anomaly Source Positivity).**  
  In the RG–Hessian flow, the anomaly contribution \(\mathbf{S}_{\mathrm{anom}}\) restricted to the horizontal, gauge-invariant subspace is local and provides a positive curvature source.

- **Conjecture C (Polarity of Reducible Strata).**  
  The singular set of reducible connections \(\Sigma\subset\mathcal{A}\) is of capacity zero for the YM Dirichlet form; the Langevin dynamics and all relevant functional inequalities can be formulated on \(\mathcal{M}_{\mathrm{reg}}\) without boundary conditions at \(\Sigma\).

- **Conjecture E (Stratified Parabolic Maximum Principle).**  
  The evolution inequality for the smallest curvature eigenvalue on the regular stratum obeys a maximum principle that is not spoiled by the polar singular set; positivity at one scale propagates along the RG (parabolic) flow.

- **Conjecture IR–1 / IR–2 (Curvature-Driven Local Gap and Non-Dominant Topology).**  
  Within each topological sector, curvature controls a local-observable spectral gap \(\lambda_{\mathrm{loc}}>0\), and global topological modes do not dominate the decay rate of local Schwinger functions in the infinite-volume limit.

- **Conjecture D (Local-Sector Spectral Gap ⇒ Physical Mass Gap).**  
  Under OS/cluster hypotheses, a Poincaré/LSI inequality with constant \(\lambda_{\mathrm{loc}}>0\) on the local-observable sector implies a positive mass gap for the reconstructed Wightman theory.

## Logical Dependency Chain

The intended implication chain is:

1. **UV & Geometry:**  
   Conjecture A (Log–Forest) + Conjecture C (Polarity of singular strata)  
   ⇒ well-defined Dirichlet form and controlled UV behavior on \(\mathcal{M}_{\mathrm{reg}}\).

2. **RG Curvature:**  
   Conjecture B (Anomaly source positivity)  
   ⇒ positive curvature fixed point in the RG–Hessian flow.

3. **IR & Topology:**  
   Conjectures IR–1/2 (local curvature gap, topology non-dominant)  
   ⇒ a positive local-sector spectral gap \(\lambda_{\mathrm{loc}}>0\) for \(-L\) acting on local observables.

4. **Mass Gap:**  
   Conjecture D (functional inequality ⇒ mass gap)  
   ⇒ physical mass gap \(\Delta>0\) in the sense of Clay.

The constructive lattice YM module (F&O) provides **independent support** for:

- The relevance of the Haar measure for mass generation,  
- The robustness and importance of polarity sectors,  
- The existence of positive mass gaps at each finite lattice spacing.

Bridging these constructive results with the dynamic, curvature-based architecture in the continuum is the long-term objective of this program.

---
