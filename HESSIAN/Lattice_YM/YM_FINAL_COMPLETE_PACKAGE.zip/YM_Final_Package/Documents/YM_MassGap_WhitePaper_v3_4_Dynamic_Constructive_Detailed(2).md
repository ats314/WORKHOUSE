# Dynamic and Constructive Structures in the Yang–Mills Mass Gap Problem

**Status:** Internal Working White Paper (v3.4)  
**Date:** 21 November 2025  

---

## Executive Summary

This white paper lays out a **dynamic and constructive program** for the Yang–Mills Existence and Mass Gap problem, combining:

- A **stochastic/dynamic formulation** of Yang–Mills via Langevin (stochastic quantization), focusing on **spectral gaps of the generator** and their relation to the physical mass gap.
- A **UV “Log–Forest” hypothesis** for gradient norms of gauge-invariant observables (Wilson loops), ensuring that the Dirichlet form is not destroyed by uncontrolled UV roughness.
- A **toy RG–Hessian / curvature-flow picture**, where the trace anomaly acts as a positive curvature source in a viscous Hamilton–Jacobi flow for the effective action.
- A **stratified Sobolev framework** on the singular gauge quotient \(\mathcal{A}/\mathcal{G}\), including a rigorous definition of \(W^{1,2}(\mathcal{A}/\mathcal{G})\) and a Gaussian-reference polarity theorem (plus Conjecture C for the full YM measure) showing that reducible strata can be treated as capacity-zero.
- A **constructive lattice YM component** (in the spirit of Faria da Veiga & O’Carroll) where:
  - the Hilbert space is rigorously decomposed into **charge-conjugation (“polarity”) sectors** \(\mathcal{H} = \mathcal{H}^+ \oplus \mathcal{H}^-\) for \(SU(N>2)\),
  - the **Haar measure** is shown to generate an effective local mass term (“mass from geometry”),
  - and **two positive mass gaps** \(\Delta^\pm\) are established at finite lattice spacing.

The program does **not** claim a full Clay-level proof. Instead it:

1. Makes explicit which steps are **formal** and which are **conjectural**.  
2. Identifies a precise **local-sector spectral gap** that should correspond to the physical mass gap, separating it from ultra-slow topological modes.  
3. States a set of named conjectures (A, B, C, IR–1/2, D) whose resolution would turn this architecture into a rigorous solution.

---

# Part I – Dynamic Route to the Mass Gap

## 1. Problem Definition and OS Framework

The Clay Millennium problem asks for a rigorous, Poincaré-invariant quantum Yang–Mills theory on \(\mathbb{R}^4\) with gauge group \(G\) (e.g. \(SU(3)\)), satisfying:

1. **Existence:** A Wightman or OS-compatible Euclidean field theory with reflection positivity, locality, and covariance.
2. **Mass Gap:** The Hamiltonian \(H\) has spectrum
   \[
   \mathrm{Spec}(H) = \{0\} \cup [\Delta,\infty),\quad \Delta>0,
   \]
   i.e. all excitations above the vacuum \(\Omega\) have energy at least \(\Delta\).

In the **Euclidean OS framework**, one typically:

- Constructs a Euclidean measure \(\mu\) on a suitable configuration space (e.g. lattice or continuum fields).
- Uses OS reflection positivity and translation invariance to reconstruct a Hilbert space \(\mathcal{H}\), vacuum \(\Omega\), and Hamiltonian \(H\).
- Reads off the mass spectrum from exponential decay of Schwinger functions.

Our program rephrases the mass gap in **dynamic language**: via **stochastic quantization**.

## 2. Stochastic Quantization and the Langevin Generator

Formally, consider a (gauge-fixed or quotient) configuration space \(\mathcal{X}\) with coordinates \(A\), and define the Langevin dynamics
\[
\partial_\tau A = -\nabla S_{\text{YM}}[A] + \eta(\tau),
\]
where:

- \(S_{\text{YM}}\) is the Euclidean action,
- \(\eta\) is Gaussian noise (white in \(\tau\)) respecting gauge invariance / quotient structure.

This defines a Markov semigroup
\[
P_\tau = e^{\tau L}
\]
on \(L^2(\mu)\), where:

- \(\mu\) is the invariant measure,
- \(L\) is the generator
  \[
  L f = \Delta f - \nabla S_{\text{YM}} \cdot \nabla f
  \]
  in a suitable Sobolev sense.

The associated **Dirichlet form** is
\[
\mathcal{E}(f,f) = \int |\nabla f|^2\,d\mu,
\]
and the Markov process \(A(\tau)\) is reversible with respect to \(\mu\).

The dynamic route aims to:

1. Prove **functional inequalities** (Poincaré, log–Sobolev) with respect to \((\mu,\mathcal{E})\) for relevant classes of observables.
2. Deduce a **spectral gap** for \(-L\).
3. Transfer this spectral gap to exponential decay of Euclidean correlation functions, and hence to a physical **mass gap**.

The subtlety is **which spectral gap** controls the physical mass.

## 3. Local-Sector Spectral Gap vs Topological Modes

Topological sectors (instanton number, Chern–Simons number, etc.) can induce extremely slow modes: tunneling between sectors may produce very small eigenvalues of \(-L\) that are **not** associated with light particle excitations. We therefore distinguish:

- The **global spectral gap**:
  \[
    \lambda_{\mathrm{glob}} := \inf\left\{ \frac{\mathcal{E}(f,f)}{\|f\|^2_{L^2(\mu)}}\; \middle|\; f\perp \mathbf{1} \right\},
  \]
  which may be dominated by topological tunneling.

- The **local-observable sector**:
  \[
    \mathcal{H}_{\mathrm{loc}} := \overline{\mathrm{span}\left\{ F(A)\;\middle|\;F\text{ gauge-invariant, local/cylindrical, compact support in spacetime}\right\}}^{L^2(\mu)}.
  \]
  This is essentially the OS space generated by local fields.

The **target spectral gap** for the mass problem is:

> **Local-sector spectral gap**
> \[
>   \lambda_{\mathrm{loc}}
>   := \inf\left\{ \frac{\mathcal{E}(f,f)}{\|f\|^2_{L^2(\mu)}}\; \middle|\;
>     f \in \mathcal{H}_{\mathrm{loc}},\ \int f\,d\mu = 0
>   \right\}.
> \]

Topological modes may produce \(\lambda_{\mathrm{glob}} \ll \lambda_{\mathrm{loc}}\), but the lowest nonzero eigenvalue **relevant for local Schwinger functions** is controlled by \(\lambda_{\mathrm{loc}}\).

We package this into a central dynamic conjecture:

> **Conjecture D (Local-Sector Spectral Gap ⇒ Mass Gap).**  
> Assume:
> 1. Existence of an OS-compatible Euclidean measure \(\mu\) for YM on \(\mathbb{R}^4\) with reflection positivity, Euclidean covariance, and cluster properties.
> 2. A Poincaré or log–Sobolev inequality with constant \(\lambda_{\mathrm{loc}}>0\) holds on the local-observable subspace \(\mathcal{H}_{\mathrm{loc}}\).
> 
> Then the reconstructed Wightman theory has a mass gap \(\Delta \ge c\,\sqrt{\lambda_{\mathrm{loc}}} > 0\) for some universal \(c>0\).

Making this precise in finite volume and then passing to the thermodynamic and continuum limits is a long-term goal, but it clarifies **what spectral gap we actually need**.

## 4. Architectural Overview (Layers A–E)

The program is organized into five layers:

- **Layer A (UV – Log–Forest Regularity).**  
  Perturbative control of gradient norms of composite operators (e.g. \(\nabla W(C)\)) via **forest-structured renormalization**. Output: at most logarithmic UV divergences in \(W^{1,2}\) norms after renormalization ⇒ UV roughness is “mild”.

- **Layer B (RG–Hessian / Curvature Flow).**  
  A toy RG picture where the Hessian of the effective action obeys a **reaction–diffusion equation**, roughly
  \[
  \partial_t h = \Delta h - 2(\nabla S_t\cdot\nabla h) - 2 h^2 + \mathbf{S}_{\mathrm{anom}},
  \]
  indicating how coarse-graining and anomaly can generate a **positive curvature fixed point**.

- **Layer C (Anomaly Source & Curvature Fixed Point).**  
  The trace anomaly acts as a positive curvature source (\(\mathbf{S}_{\mathrm{anom}}\)) in the Hessian flow, stabilizing a **dimensionless curvature** \(\tilde\lambda_* > 0\) that sets a mass scale \(\sim \tilde\lambda_*^{1/2}\Lambda_{\mathrm{QCD}}\).

- **Layer D (Stratified Sobolev Geometry & Polarity).**  
  Construction of \(W^{1,2}(\mathcal{A}/\mathcal{G})\) via horizontal gradients of gauge-invariant cylindrical functionals; argument that the singular set \(\Sigma\) (reducible connections) has **infinite codimension** and **zero capacity**, so it can be ignored in functional inequalities.

- **Layer E (Functional Inequalities ⇒ Local Spectral Gap ⇒ Mass Gap).**  
  Application of Bakry–Émery theory and related tools to obtain Poincaré/LSI inequalities on the regular stratum, and thus a **local-sector spectral gap** \(\lambda_{\mathrm{loc}}\) leading to a mass gap by Conjecture D.

Later sections add a **constructive lattice YM module** (Faria da Veiga & O’Carroll) that provides:

- Rigorous lattice Hilbert space,
- Charge-conjugation polarity decomposition,
- Haar-measure-induced mass term,
- and explicit two-sector mass gaps at finite lattice spacing.

---

# Part II – UV Layer: Log–Forest Regularity (Conjecture A)

## 2.1. Lattice Gauge Setup and Wilson Loops

We work on a 4D hypercubic lattice \(\Lambda\) with spacing \(a\), gauge group \(G=SU(3)\) (or \(SU(N)\)). Fundamental variables:

- Link fields \(U_\ell \in SU(N)\) on oriented edges \(\ell\).
- Plaquettes \(U_p\) are oriented products around minimal squares.

The Wilson plaquette action is
\[
S_{\Lambda}(U)
= \frac{\beta}{N} \sum_{p\subset\Lambda} \mathrm{Re}\,\mathrm{Tr}(I-U_p),
\quad \beta = \frac{2N}{g_0^2},
\]
with bare coupling \(g_0\).

Gauge-invariant observables include:

- Wilson loops \(W(C) = \frac{1}{N}\mathrm{Re}\,\mathrm{Tr}\prod_{\ell\in C} U_\ell\),
- Smeared field-strength operators, etc.

We introduce Lie-algebra coordinates
\[
U_\ell = \exp(g_0 A_\ell),\quad A_\ell \in \mathfrak{su}(N),
\]
in a suitable gauge (e.g. maximal tree gauge), so that the lattice action admits a perturbative expansion.

## 2.2. Gradients and UV Roughness

Define the Lie-algebra gradient of an observable \(O(U)\) by
\[
(\nabla_\ell^a O)(U)
:= \left.\frac{d}{dt}\right|_{t=0}
  O(\dots, e^{t T^a} U_\ell, \dots),
\]
and the global gradient norm
\[
\|\nabla O\|^2_{L^2(\mu_\Lambda)}
:= \sum_{\ell,a}\int |\nabla_\ell^a O(U)|^2\,d\mu_\Lambda(U),
\]
where \(\mu_\Lambda\) is the normalized lattice YM measure.

Bare derivatives of Wilson loops have:

- **Perimeter divergences** (power-like in \(1/a\)),
- **Contact divergences** when links in the loop fuse.

These appear already in perturbation theory and are absorbed into:

- Perimeter counterterms for the test charge,
- Contact renormalizations (local operator mixings).

The **nontrivial question** is: after renormalizing these power divergences, what is the UV behavior of the **residual** \(W^{1,2}\) norm?

## 2.3. Conjecture A: Log–Forest W^{1,2} Control

The UV layer is organized around:

> **Conjecture A (Log–Forest UV Control).**  
> For each gauge-invariant polynomial observable \(O\) (e.g. Wilson loops with finitely many insertions), there exists a renormalized composite operator \([O]_{\mathrm{ren}}\) such that:
> 
> 1. All power divergences in \(\|\nabla O\|_{L^2(\mu_\Lambda)}^2\) are absorbed into local counterterms associated to the perimeter/contact structure of \(O\).
> 2. The residual renormalized gradient norm admits an asymptotic expansion
>    \[
>    \|\nabla [O]_{\mathrm{ren}}\|^2_{L^2(\mu_\Lambda)}
>    \sim \sum_{n\ge 0} g_0^{2n}
>      \sum_{\tau\in \mathcal{F}_n}
>        C_\tau (\log \tfrac{1}{a})^{k(\tau)},
>    \]
>    where \(\mathcal{F}_n\) is a finite set of **Zimmermann forests** (nested divergence structures), and \(k(\tau)\) is a combinatorial depth of nested marginal subgraphs.
> 
> In particular, the UV roughness of renormalized composite observables is at most **polylogarithmic** in \(1/a\), not power-like.

This is a perturbative expectation, consistent with BPHZ renormalization, but not yet proven in full lattice YM. The key content is:
From a technical standpoint, Conjecture A is intended to be realized using lattice BPHZ/BGW renormalization and Reisz-type power counting theorems, organized with cluster expansions; see the scalar $\phi^4_4$ prototype in the separate note \emph{Scalar Log--Forest Prototype} for an explicit example where these mechanisms can be carried out in detail.


- **No new power divergences** arise in \(W^{1,2}\) beyond those already handled by perimeter/contact terms.
- The renormalized Dirichlet form is compatible with the existence of **finite** LSI/Poincaré constants at fixed physical scale after RG improvement.

Quantitatively, the goal is a statement of the form:

> For Wilson loops \(W(C_R)\) of fixed physical size \(R\), after RG improving to scale \(\Lambda\sim 1/R\), the gradient norms satisfy
> \[
>  \|\nabla [W(C_R)]_{\mathrm{ren}}\|^2_{L^2(\mu_\Lambda)}
>  \le C(R)\,(\log \Lambda)^p,
> \]
> with finite \(p\) independent of lattice spacing. This is “mild enough” to be compatible with curvature-based functional inequalities in the IR.

---

# Part III – IR Layer: Curvature vs Topology and RG–Hessian Flow

## 3.1. Working Ansatz: Viscous Hamilton–Jacobi Flow

The exact functional RG equations for YM (Polchinski, Wetterich, etc.) are momentum-space flows for a scale-dependent effective action \(S_k\), involving infinitely many couplings and nonlocal operators.

In this white paper we adopt a **working ansatz** for a **local, field-space picture**:

> After truncating to local gauge-invariant functionals and choosing an appropriate field-space metric on \(\mathcal{A}/\mathcal{G}\), the RG flow of the effective action \(S_t\) can be approximated by a **viscous Hamilton–Jacobi** equation:
> \[
>   \partial_t S_t = \Delta S_t - |\nabla S_t|^2 + J_t,
> \]
> where
> - \(\Delta\) is a (horizontal) Laplacian in field space,
> - \(\nabla\) is the corresponding gradient,
> - and \(J_t\) is a source term encoding the trace anomaly and other nonlocal effects.

This is not claimed to be the exact RG, but a model that captures the **curvature dynamics** of coarse-grained effective measures.

## 3.2. Derivation of Viscous HJ and Hessian Flow (Finite Dimension)

We summarize the derivation; details are in Part IV.

Let \(\rho_t(\phi)\) be a family of densities on \(\mathbb{R}^n\) evolving under the heat equation
\[
\partial_t \rho_t = \Delta \rho_t.
\]
Assume \(\rho_t = Z_t^{-1}e^{-S_t}\). Then one finds (up to a \(\phi\)-independent normalization term)
\[
\partial_t S_t = \Delta S_t - |\nabla S_t|^2.
\]

Defining:

- \(b = \nabla S_t\) (drift),
- \(h = \nabla^2 S_t\) (Hessian),

one derives the **Hessian flow**:
\[
\partial_t h = \Delta h - 2(\nabla S_t\cdot\nabla h) - 2 h^2,
\]
which has the structure of a **reaction–diffusion equation** for curvature:

- \(\Delta h\): diffusion (smoothing curvature),
- \(-2(\nabla S_t\cdot\nabla h)\): drift along field-space flow,
- \(-2h^2\): local nonlinear “flattening” that drives negative eigenvalues to \(-\infty\) and tends to reduce large positive ones.

Adding a source term \(J_t\) in the viscous HJ equation introduces an extra curvature source
\[
\mathbf{S}_{\mathrm{anom}} = \nabla^2 J_t
\]
in the Hessian flow:
\[
\partial_t h = \Delta h - 2(\nabla S_t\cdot\nabla h) - 2 h^2 + \mathbf{S}_{\mathrm{anom}}.
\]

The **confinement mechanism** we are targeting is:

1. The anomaly provides a **positive curvature source** in the relevant directions.  
2. The reaction–diffusion flow stabilizes a **positive curvature fixed point** for certain eigenvalues of \(h\).  
3. A positive lower bound on curvature implies a Poincaré/LSI inequality via Bakry–Émery, giving a spectral gap.

## 3.3. Conjecture B: Anomaly Source Positivity

We isolate the speculative part:

> **Conjecture B (Horizontal Anomaly Source Positivity).**  
> After projecting to the gauge-invariant horizontal subspace and appropriate renormalization, the anomaly contribution satisfies
> \[
>   \langle v,\,\mathbf{S}_{\mathrm{anom}} v\rangle_{\text{hor}}
>   \;\ge\; \sigma_*\,\|v\|_{\text{hor}}^2
> \]
> for all horizontal test vectors \(v\), with \(\sigma_*>0\) independent of the IR scale near confinement. The dominant contribution is **local** and of the same tensorial type as the Hessian of \(\int \mathrm{tr}(F^2)\).

Interpretation:

- The negative beta function and nonzero gluon condensate inject “upward” curvature into the Hessian flow.
- In the relevant directions, this competes with the flattening term \(-2h^2\) and prevents the curvature from decaying to zero.

In a further truncation where \(h\) is approximated by its smallest eigenvalue \(\lambda(t)\) and diffusion/drift are neglected, we get an ODE
\[
\frac{d}{dt}\lambda \approx -2\lambda^2 + \sigma_*,
\]
which has a positive fixed point \(\lambda_* = \sqrt{\sigma_*/2}\). The full, infinite-dimensional flow is far more complicated, but this toy model illustrates the intended mechanism.

## 3.4. Topology vs Curvature: IR Conjectures

Topological sectors can generate very small eigenvalues associated with slow tunneling of global charges, which may not correspond to light particles. We therefore state:

> **Conjecture IR–1 (Sectorwise Curvature-Driven Gap).**  
> In each fixed topological sector of the YM configuration space, the Langevin generator restricted to local observables has a spectral gap \(\lambda_{\mathrm{loc}}>0\) controlled by an effective curvature lower bound (in the Bakry–Émery sense) of the renormalized measure. This \(\lambda_{\mathrm{loc}}\) corresponds to the physical mass gap.

> **Conjecture IR–2 (Topological Slowness Non-Dominant for Local Observables).**  
> Global topological modes may produce eigenvalues \(\lambda_{\mathrm{top}}\ll\lambda_{\mathrm{loc}}\) for \(-L\) on the full \(L^2(\mu)\), but the associated eigenfunctions have negligible overlap with local cylindrical observables in large volume. Therefore, \(\lambda_{\mathrm{top}}\) does not control the decay rate of local 2-point Schwinger functions.

These conjectures justify the focus on the local-sector spectral gap \(\lambda_{\mathrm{loc}}\) in Conjecture D.

## 3.5. Numerical Diagnostics: T13 and TQ13

To test IR–1/IR–2, we propose:

- **T13 (Pilot):** JAX-based SU(3) Langevin on small lattices (\(8^4\)) with:
  - Autocorrelation times \(\tau(W)\) for small Wilson loops,
  - A “roughness ratio” diagnostic for local fluctuations.

  Result so far: \(\tau(W)\) is \(\mathcal{O}(1)\) across a moderate \(\beta\) range, with no visible critical slowing down at this tiny volume. This mainly validates the code; it says little about true IR behavior.

- **TQ13 (Topological Probe):**  
  On larger lattices (e.g. \(16^4, 24^4\)), implement:
  - Gradient flow to define a lattice topological charge \(Q_t\),
  - Autocorrelation times \(\tau(Q)\) and tunneling rates between sectors,
  - Comparison with \(\tau(W)\) for local loops.

  The aim is to distinguish:
  - **Tunneling-dominated scenario:** \(\tau(Q) \sim e^{cL}\), \(\tau(Q)\gg\tau(W)\), where global gap is dominated by topology;
  - **Curvature-dominated scenario:** \(\tau(Q)\) and \(\tau(W)\) of similar parametric scale, reflecting the same curvature-driven mass.

Design details (choice of flow time, discretization of \(Q_t\), \(\beta\) values around physical scales) are left to a separate numerical note. The conceptual role in this white paper is to provide evidence for or against Conjecture IR–2.

---

# Part IV – Functional Inequalities and Toy Models

## 4.1. Dirichlet Form, Generator, and Poincaré Inequality

In a finite-dimensional model with measure
\[
d\mu(x) = Z^{-1} e^{-V(x)} dx,
\]
and generator
\[
L f = \Delta f - \nabla V\cdot\nabla f,
\]
the Dirichlet form
\[
\mathcal{E}(f,f) = \int |\nabla f|^2 d\mu
\]
is symmetric in \(L^2(\mu)\).

The **Poincaré inequality** with constant \(\lambda>0\) is
\[
\mathrm{Var}_\mu(f)
:= \int f^2 d\mu - \left(\int f d\mu\right)^2
\le \frac{1}{\lambda}\int |\nabla f|^2 d\mu.
\]

This is equivalent to \(-L\) having a **spectral gap** \(\lambda\):

- If \(-L\) has an isolated eigenvalue \(0\) (constants), and \(\lambda_1 \ge \lambda>0\) for all other eigenvalues, then the Poincaré inequality holds with constant \(\lambda\).
- Conversely, a Poincaré inequality implies \(\mathrm{Spec}(-L)\subset\{0\}\cup[\lambda,\infty)\).

The proof uses spectral decomposition and integration by parts; it generalizes to infinite dimensions under standard Dirichlet form theory assumptions.

## 4.2. Bakry–Émery Curvature and Log–Sobolev Inequalities

Define the carré du champ
\[
\Gamma(f) = \tfrac{1}{2}(L(f^2) - 2 f Lf) = |\nabla f|^2,
\]
and
\[
\Gamma_2(f) = \tfrac{1}{2}(L\Gamma(f) - 2\Gamma(f,Lf)).
\]

For \(L = \Delta - \nabla V\cdot\nabla\), a direct computation gives
\[
\Gamma_2(f)
= \|\nabla^2 f\|_{\mathrm{HS}}^2
  + \langle (\nabla^2 V)\nabla f,\nabla f\rangle.
\]

If there exists \(\rho>0\) such that
\[
\nabla^2 V(x) \ge \rho I \quad \forall x,
\]
then
\[
\Gamma_2(f) \ge \rho \Gamma(f).
\]

This is the **Bakry–Émery curvature condition**. It implies:

- A Poincaré inequality with constant \(\lambda\ge \rho\),
- A log–Sobolev inequality (LSI)
  \[
    \mathrm{Ent}_\mu(f^2)
    := \int f^2 \log\frac{f^2}{\int f^2 d\mu} d\mu
    \le \frac{2}{\rho}\int |\nabla f|^2 d\mu.
  \]

The proof uses the entropy decay of the semigroup \(P_t\) and the differential inequality \(\Psi''(t) \ge \rho \Psi'(t)\) for \(\Psi(t)=\mathrm{Ent}_\mu((P_t f)^2)\).

In the YM context, we seek an **effective curvature bound** in the horizontal directions of \(\mathcal{A}/\mathcal{G}\) at large RG scales, consistent with Conjectures A and B.

## 4.3. Double-Well Toy Model and Tunneling

To clarify what curvature-based inequalities can and cannot detect, consider the 1D double-well potential
\[
V(x) = \tfrac{1}{4}(x^2 - 1)^2,
\]
with invariant measure \(\mu(dx) \propto e^{-V(x)}dx\) and generator \(L f = f'' - V'(x)f'\).

- There are two wells around \(x=\pm 1\) separated by a barrier at \(x=0\).
- The lowest nonzero eigenvalue \(\lambda_1\) of \(-L\) corresponds to metastable **tunneling** between the wells. In the small-noise/deep-well regime, \(\lambda_1 \sim C e^{-\Delta V}\) (Eyring–Kramers).

Critically:

- The **Poincaré constant** (spectral gap) is **exponentially small** in the barrier height.
- The **LSI constant** is also exponentially small: for multimodal measures with high barriers, Holley–Stroock and subsequent work show LSI constants degrade exponentially with the barrier height (up to polynomial corrections).

So **both** Poincaré and LSI “see” the tunneling time; neither gives a robust bound that ignores the exponentially slow mode.

For our YM program, this means:

- If topological tunneling produces extremely slow modes that strongly affect the measure, then any global curvature-based inequality (Poincaré/LSI on all of \(L^2(\mu)\)) will have a constant that is at most of the order of the global tunneling rate.
- To get a **mass gap** from curvature, we must either:
  - restrict attention to the **local observable sector** where topological modes are negligible (Conjectures IR–1/2 and D), or
  - use more delicate inequalities that explicitly factor out global topological degrees of freedom.

This is why the distinction between global and local-sector spectral gaps in Part I is essential.

---

## 3.6. Stratified Maximum Principle and Curvature Flow (Conjecture E)

The RG–Hessian layer and the stratified Sobolev/polarity layer are connected by a parabolic positivity mechanism. Informally: once we know that the singular set \(\Sigma\) is polar (so the Langevin diffusion does not hit it), we would like to know that a **parabolic comparison principle** for the lowest curvature eigenvalue persists on the regular stratum \(\mathcal{M}_{\mathrm{reg}}\). This is the role of a stratified maximum principle.

### Conjecture E (Stratified Parabolic Maximum Principle)

Let \(\mathcal{M} = \mathcal{A}/\mathcal{G}\) be the gauge quotient with regular stratum \(\mathcal{M}_{\mathrm{reg}}\) and singular set \(\Sigma\). Let \(L\) be the generator of the Yang–Mills Langevin diffusion on \(\mathcal{M}\), viewed as a second-order (formal) differential operator on \(\mathcal{M}_{\mathrm{reg}}\).

Consider a (matrix-valued or scalar) function \(u(t,x)\) on \([0,\infty)\times\mathcal{M}_{\mathrm{reg}}\) solving a semilinear parabolic inequality of the form
\[
  \partial_t u \;\ge\; L u + F(u,x,t)
\]
in a weak (Dirichlet-form) sense, with \(F\) nondecreasing in \(u\) and satisfying appropriate growth bounds.

Assume:
1. \(u(0,x)\ge 0\) for \(\mu\)-a.e. \(x\in\mathcal{M}_{\mathrm{reg}}\).  
2. The singular set \(\Sigma\) is polar for the diffusion associated with \(L\) (i.e., \(\mathrm{Cap}_\mu(\Sigma)=0\)).

Then for all \(t>0\),
\[
  u(t,x) \ge 0 \quad \text{for \(\mu\)-a.e. }x\in\mathcal{M}_{\mathrm{reg}}.
\]

Informally: under polarity of \(\Sigma\) and mild monotonicity of the nonlinearity \(F\), the positivity-preserving property of the parabolic flow is not destroyed by the singular strata. The “bad set” is too thin to act as a genuine boundary.

### Bridging Proposition: From Polarity and Anomaly to Global Curvature Positivity

We now formulate a conditional statement that shows how polarity, an anomaly-induced curvature source, and the stratified maximum principle would combine to give a uniform positive lower bound on the smallest curvature eigenvalue.

> **Proposition (Bridging Polarity and Anomaly to Global Curvature Positivity).**  
> Assume:
> 
> 1. **Polarity of singularities (Conjecture C):**  
>    The singular set \(\Sigma\) of reducible connections has capacity zero for the Yang–Mills Dirichlet form and is polar for the Langevin diffusion on \(\mathcal{M}\).
> 
> 2. **Anomaly-induced curvature source (Conjecture B, strong form):**  
>    The RG–Hessian flow for the effective action has a smallest eigenvalue \(\lambda(t,x)\) on the regular stratum satisfying, in a weak sense,
>    \[
>      \partial_t \lambda \;\ge\; L \lambda - 2 \lambda^2 + \sigma_*,
>    \]
>    for some constant \(\sigma_*>0\), where \(L\) is the (horizontal) generator of the Langevin diffusion. In particular, the anomaly provides a strictly positive source term \(\sigma_*\) in the evolution inequality for \(\lambda\).
> 
> 3. **Stratified maximum principle (Conjecture E):**  
>    The positivity-preserving property of the parabolic flow associated with \(L\) extends to \(\mathcal{M}_{\mathrm{reg}}\) despite the singular set \(\Sigma\), as stated in Conjecture E.
> 
> 4. **Initial nonnegativity:**  
>    At some RG scale \(t_0\), the smallest eigenvalue satisfies
>    \[
>      \lambda(t_0,x) \ge 0 \quad \text{for \(\mu\)-a.e. }x\in\mathcal{M}_{\mathrm{reg}}.
>    \]
> 
> Then, for all \(t \ge t_0\) and \(\mu\)-a.e. \(x\in\mathcal{M}_{\mathrm{reg}}\), we have
> \[
>   \lambda(t,x) \;\ge\; \lambda_{\mathrm{min}}(t) \;>\; 0,
> \]
> where \(\lambda_{\mathrm{min}}(t)\) solves the scalar ODE
> \[
>   \partial_t \lambda_{\mathrm{min}} \;=\; -2 \lambda_{\mathrm{min}}^2 + \sigma_*,
>   \qquad \lambda_{\mathrm{min}}(t_0) = 0.
> \]
> 
> In particular, there exists a positive limit
> \[
>   \lambda_* = \lim_{t\to\infty} \lambda_{\mathrm{min}}(t) = \sqrt{\sigma_*/2} > 0,
> \]
> and thus the curvature eigenvalue is uniformly bounded below:
> \[
>   \lambda(t,x) \ge \lambda_* > 0
> \]
> for all sufficiently large \(t\) and \(\mu\)-almost every \(x\).
> 
> *Sketch of reasoning.*  
> Treat \(\lambda(t,x)\) as a supersolution to the parabolic equation
> \[
>   \partial_t u = L u - 2 u^2 + \sigma_*,
> \]
> with \(u(t_0,\cdot)\ge 0\) and the spatially constant ODE solution \(\lambda_{\mathrm{min}}(t)\) (starting from 0) as a subsolution. By the stratified maximum principle (Conjecture E), \(\lambda(t,x)\) cannot drop below \(\lambda_{\mathrm{min}}(t)\) on \(\mathcal{M}_{\mathrm{reg}}\), and hence inherits its positive lower bound in the large-\(t\) limit. Polarity of \(\Sigma\) (Conjecture C) ensures that no boundary at the singular strata can violate this comparison principle. The ODE analysis shows that the positive source \(\sigma_*\) dominates the nonlinear flattening \(-2 u^2\) and drives the system to a strictly positive fixed point \(\lambda_* = \sqrt{\sigma_*/2}\).

## 4.4. The Multiscale Functional Inequality Program (MFIP)

The functional-analytic core of the dynamic route can be phrased as a **Multiscale Functional Inequality Program (MFIP)**. The idea is to track how a log–Sobolev (or Poincaré) constant evolves under **renormalization group (RG)** flow, rather than tracking bare couplings directly.

At each coarse-graining scale \(j\) (lattice spacing \(a_j\), block size \(L^j\)), one has:

- an effective Euclidean measure \(\mu_j\) on coarse gauge degrees of freedom (e.g. block-averaged edge variables or Wilson loops),
- an associated Dirichlet form \(\mathcal{E}_j\) and generator \(L_j\),
- a log–Sobolev constant \(\alpha_j\) and Poincaré constant \(\lambda_j\) on the **horizontal, gauge-invariant sector**.

Formally, MFIP aims to establish:

1. **UV initialization (cluster expansion scale).**  
   For \(j=j_0\) deep in the ultraviolet, constructive methods (cluster/Polymer expansion, finite-range decomposition) give a strictly positive horizontal LSI:
   \[
     \mathrm{LSI}(\alpha_{j_0})\quad\text{with}\quad \alpha_{j_0}>0,
   \]
   uniformly in volume and boundary conditions, for observables built from local Wilson loops and plaquettes.

2. **RG stability and monotonicity.**  
   A single RG step \(j\mapsto j+1\) consists of:
   - integrating out short-distance fluctuations within blocks,
   - rescaling fields and couplings,
   - projecting back to the gauge-invariant (horizontal) sector.

   The MFIP postulate is that there exist universal constants \(c_1,c_2>0\) and a “noise” term \(\varepsilon_j\) controlled by UV regularity (Conjecture A) such that
   \[
     \alpha_{j+1} \;\ge\; c_1\,\alpha_j - \varepsilon_j,
     \qquad
     \lambda_{j+1} \;\ge\; c_2\,\lambda_j - \varepsilon_j.
   \]
   Intuitively: tensorization of LSIs across blocks gives a product lower bound, while the RG perturbation (integrating out constrained noise plus local counterterms) only weakly degrades the constants. Conjecture A (Log–Forest UV control) is designed precisely to keep \(\varepsilon_j\) small and summable.

3. **Horizontal anomaly source and IR saturation.**  
   In Part III, the RG–Hessian picture yields an “anomaly source” term \(\mathsf{S}_{\mathrm{anom}}\) that drives the curvature eigenvalue \(\lambda(t,x)\) toward a positive fixed point. MFIP is the functional-inequality analogue of that picture: the horizontal LSI constants \(\alpha_j\) and \(\lambda_j\) should satisfy a discrete parabolic inequality of the form
   \[
     \alpha_{j+1} - \alpha_j \;\gtrsim\; -C\,\alpha_j^2 + \sigma_{\mathrm{hor}},
   \]
   with \(\sigma_{\mathrm{hor}}>0\) determined by the anomaly on the gauge-invariant sector (Conjecture B). This favours convergence to a strictly positive limit
   \[
     \alpha_* \;=\; \liminf_{j\to\infty}\alpha_j \;>\;0.
   \]

4. **Local gap and physical mass scale.**  
   For each finite block scale \(j\), the horizontal LSI and Poincaré inequalities imply a spectral gap \(\lambda_{\mathrm{loc}}(j)\) for the local-sector generator \(L_j\). If \(\alpha_j\) converges to \(\alpha_*>0\), then
   \[
     \inf_j \lambda_{\mathrm{loc}}(j) \;\ge\; c\,\alpha_* \;>\; 0,
   \]
   giving a uniform **local-sector spectral gap** at all large scales. Conjectures IR–1/2 then assert that this local gap controls the decay of local Schwinger functions in the thermodynamic limit.

5. **From MFIP to the Yang–Mills mass gap.**  
   Finally, Conjecture D (Local-sector spectral gap \(\Rightarrow\) mass gap) identifies the physical mass scale \(\Delta\) with the square root of the local-sector spectral gap:
   \[
     \Delta \;\simeq\; c'\,\sqrt{\lambda_{\mathrm{loc}}} \;\gtrsim\; c''\,\sqrt{\alpha_*} \;>\; 0.
   \]
   Thus, closing the MFIP—establishing UV initialization, RG stability with a positive anomaly source, and IR persistence of a horizontal LSI—would amount to a complete functional-analytic proof of the mass gap, conditional only on the existence of the OS measure and the usual constructive inputs.

In short, MFIP recasts the Yang–Mills mass gap as a statement about the **RG flow of horizontal log–Sobolev constants**, rather than about correlation functions directly. Parts II–V are organized so that each conjectural piece (A, B, C, IR–1/2, D) has a precise role in this multiscale inequality chain.


# Part V – Stratified Sobolev Space and Polarity of Reducible Connections (Conjecture C)

## 5.1. Configuration Space and Gauge Quotient

Let \(P\to M\) be a principal \(G\)-bundle over a compact 4D Riemannian manifold \(M\), \(G\) compact (e.g. \(SU(3)\)). The space of smooth connections is
\[
\mathcal{A} \cong A_0 + \Omega^1(M,\mathrm{ad}\,P),
\]
an affine space modeled on a Sobolev space.

The gauge group \(\mathcal{G}\) acts by
\[
A^g = g^{-1}Ag + g^{-1}dg.
\]
The gauge-orbit space is
\[
\mathcal{M} = \mathcal{A}/\mathcal{G}.
\]

\(\mathcal{M}\) is **stratified**:

- The **principal (regular) stratum** \(\mathcal{M}_{\mathrm{reg}}\): irreducible connections whose stabilizer is exactly the center \(Z(G)\). This is an infinite-dimensional smooth manifold.
- The **singular set** \(\Sigma\): reducible connections with larger stabilizers; this is a union of lower-dimensional strata.

We equip \(\mathcal{M}\) with a metric induced from \(\mathcal{A}\) via orbital distance, and a probability measure \(\mu\) arising from the YM action (e.g. a continuum limit of lattice measures).

## 5.2. Horizontal Gradient and Sobolev Space \(W^{1,2}(\mathcal{M})\)

Let \(\mathcal{F}_{\mathrm{cyl}}\) be the algebra of **gauge-invariant cylindrical functionals** \(F\) that depend on finitely many holonomies, Wilson loops, or smeared fields.

Each \(F\in\mathcal{F}_{\mathrm{cyl}}\) lifts to a function on \(\mathcal{A}\) satisfying
\[
F(A^g) = F(A)\quad \forall g\in\mathcal{G}.
\]

The usual gradient \(\nabla_{\mathcal{A}} F(A)\) decomposes into:

- Vertical component tangent to the gauge orbit:
  \[
  V_A = \{D_A \omega\mid \omega\in \mathrm{Lie}(\mathcal{G})\},
  \]
- Horizontal component orthogonal to \(V_A\) in \(L^2(M,\mathrm{ad}\,P)\).

Gauge invariance implies \(\nabla_{\mathcal{A}} F(A)\) is orthogonal to \(V_A\) for all \(A\), i.e. it is **horizontal**. We define the **horizontal gradient**
\[
\nabla_H F(A) := \nabla_{\mathcal{A}} F(A),
\]
viewed as a vector in a chosen horizontal complement to \(V_A\).

We then define the Sobolev norm
\[
\|F\|_{W^{1,2}(\mathcal{M},\mu)}^2
:= \int_{\mathcal{A}} |F(A)|^2\,d\mu(A)
   + \int_{\mathcal{A}} \|\nabla_H F(A)\|^2\,d\mu(A),
\]
and take the closure of \(\mathcal{F}_{\mathrm{cyl}}\) under this norm to obtain \(W^{1,2}(\mathcal{M},\mu)\).

The associated Dirichlet form is
\[
\mathcal{E}(F,F) = \int_{\mathcal{A}} \|\nabla_H F(A)\|^2\,d\mu(A),
\]
which is the infinite-dimensional analogue of \(\int |\nabla f|^2 d\mu\) in Part IV.

## 5.3. Reducible Connections and Infinite Codimension

A connection \(A\) is **reducible** if its stabilizer
\[
\Gamma_A = \{g\in\mathcal{G} \mid A^g = A\}
\]
is larger than \(Z(G)\). Infinitesimally, there exists a nonzero \(\xi\in\Omega^0(M,\mathrm{ad}\,P)\) such that
\[
D_A \xi = 0,
\]
i.e. \(\xi\) is **covariantly constant**.

Applying \(D_A\) again and using \([D_\mu,D_\nu] = \mathrm{ad}_{F_{\mu\nu}}\), we obtain
\[
[F_{\mu\nu}(x),\xi(x)] = 0 \quad \forall x\in M.
\]

Thus, at each point, the curvature \(F_{\mu\nu}(x)\) lies in the **centralizer** of \(\xi(x)\), a proper Lie subalgebra of \(\mathfrak{g}\).

For each fixed nonzero \(\xi\), define
\[
\Sigma_\xi = \{A\in \mathcal{A} \mid D_A\xi=0\},
\quad
\Sigma = \bigcup_{\xi\neq 0}\Sigma_\xi.
\]

Heuristically:

- \(D_A\xi=0\) is a first-order linear PDE in \(A\) with infinitely many independent constraints (at each Fourier mode).
- The solution space \(\Sigma_\xi\) is a **Fréchet submanifold of infinite codimension** in \(\mathcal{A}\).
- Thus \(\Sigma\) is a countable union of infinite-codimension submanifolds.

In loose terms: asking a non-Abelian 4D field to have a covariantly constant adjoint direction everywhere forces it to behave like an Abelian field along \(\xi\) at all points, losing infinitely many degrees of freedom.


> **Lemma 5.3.1 ((H_{\xi\xi}) infinite-rank commutator map).**  
> Let \(k>2\) and let \(\xi\in L^2_k(M,\mathrm{ad}\,P)\) be nonzero and covariantly constant with respect to some background connection \(A_0\). Consider the linear map
> \[
>   T_\xi : L^2_k\big(M, T^*M\otimes\mathrm{ad}\,P\big) \to L^2_{k-1}\big(M, T^*M\otimes\mathrm{ad}\,P\big), \qquad a\mapsto [a,\xi].
> \]
> Then \(T_\xi\) has infinite rank; in particular, its kernel has infinite codimension in \(L^2_k(M,T^*M\otimes\mathrm{ad}\,P)\).
>
> *Sketch of proof.*  
> Work in a local trivialization over a coordinate ball \(B\subset M\) where \(P\) is trivial and \(\xi\) is represented by a smooth \(\mathfrak{su}(N)\)-valued function with \(\xi(x_0)\neq 0\) and noncentral at some point \(x_0\in B\). Because \(k>2\) in four dimensions, Sobolev embedding gives a continuous injection \(L^2_k\hookrightarrow C^0\), so evaluation maps \(a\mapsto a(x_0)\) and restriction to small balls make analytic sense.
>
> Choose an orthonormal frame \(\{e_\mu\}_{\mu=1}^4\) for \(T^*_{x_0}M\) and diagonalize \(\xi(x_0)\) in a Cartan subalgebra of \(\mathfrak{su}(N)\), with corresponding root decomposition \(\mathfrak{su}(N)=\mathfrak{h}\oplus\bigoplus_\alpha\mathfrak{g}_\alpha\). Noncommutativity ensures that there exist root spaces \(\mathfrak{g}_\alpha\) with \([\xi(x_0),X_\alpha]\neq 0\) for \(X_\alpha\in\mathfrak{g}_\alpha\setminus\{0\}\). For each such \(\alpha\) and \(\mu\), pick a bump function \(\varphi_{n}\) supported in a small ball around a point \(x_n\to x_0\), and set
> \[
>   a_{n,\alpha,\mu}(x) := \varphi_n(x)\, e_\mu\otimes X_\alpha.
> \]
> These \(a_{n,\alpha,\mu}\) lie in \(L^2_k(M,T^*M\otimes\mathrm{ad}\,P)\) and are almost orthogonal as \(n\to\infty\).
>
> At the level of pointwise commutators, \([a_{n,\alpha,\mu}(x),\xi(x)]\) is supported where \(\varphi_n\neq 0\) and, at \(x_n\), is proportional to \([e_\mu\otimes X_\alpha,\xi(x_n)]\), which is nonzero by construction. Hence the images \(T_\xi a_{n,\alpha,\mu}\) form an infinite family which is linearly independent modulo \(L^2_{k-1}\)-small errors, giving infinite rank of \(T_\xi\). A standard diagonal argument converts this “almost independence” into strict infinite rank in the Hilbert space sense.
>
> This property is the functional-analytic content of \((H_{\xi\xi})\): the reducibility condition \(D_A\xi=0\) imposes infinitely many independent linear constraints on the connection, so each \(\Sigma_\xi\) sits inside an infinite-codimension affine subspace of \(\mathcal{A}\).

## 5.4. Capacity and Polarity (Conjecture C)

For a Dirichlet form \((\mathcal{E},\mathcal{D}(\mathcal{E}))\) on a measure space \((\mathcal{X},\mu)\), the **capacity** of a set \(E\subset\mathcal{X}\) is
\[
\mathrm{Cap}(E)
= \inf\Big\{
  \mathcal{E}(u,u) + \int u^2 d\mu\;\Big|\;
  u\in\mathcal{D}(\mathcal{E}),\ u\ge 1\ \text{on an open set containing }E
\Big\}.
\]

A set \(E\) is **polar** if \(\mathrm{Cap}(E)=0\). For the associated Markov process \(X_t\), polar sets are almost surely avoided.

In finite dimensions, for Brownian/OU processes:

- Affine subspaces of codimension \(\ge 2\) have zero capacity.
- Codimension-1 hypersurfaces have positive capacity.

In infinite dimensions, infinite-codimension sets are not automatically polar; polarity depends delicately on the specific Dirichlet form and measure.
For Gaussian reference measures, many natural infinite-codimension linear subspaces are polar, but there are important counterexamples in more general settings.

For the YM Dirichlet form on \(\mathcal{A}\) (or \(\mathcal{M}\)), we therefore formulate polarity of \(\Sigma\) as a conjecture rather than a consequence of codimension alone:

> **Conjecture C (Polarity of Reducibles and Singular Strata).**  
> The set of reducible connections \(\Sigma\subset\mathcal{A}\) (and its projection in \(\mathcal{M}\)) has capacity zero with respect to the YM Dirichlet form:
> \[
> \mathrm{Cap}(\Sigma)=0.
> \]
> Hence, the Langevin process almost surely never hits \(\Sigma\), and the singular strata of \(\mathcal{M}\) are dynamically and analytically negligible.

A plausible proof strategy:

1. Prove polarity for \(\Sigma\) relative to a Gaussian reference measure \(\mu_0\) (OU process on \(\mathcal{A}\)).  
2. Show that the YM measure \(\mu\) is absolutely continuous with respect to \(\mu_0\) with a density in a suitable Kato/Novikov class.  
3. Use general results on quasi-regular Dirichlet forms to transfer the capacity-zero property from \(\mu_0\) to \(\mu\).

This is nontrivial and currently heuristic; it is one of the key analytic gaps to be filled.

---

# Part VI – Constructive Lattice Yang–Mills: Polarity and Mass from the Haar Measure

This part distills the constructive lattice YM perspective inspired by Faria da Veiga and O’Carroll (F&O), focusing on:

- OS-compatible lattice construction,
- Charge-conjugation “polarity” sectors,
- Haar-measure induced mass terms,
- Two-sector mass gaps at finite lattice spacing.

## 6.1. Lattice Formalism and Transfer Matrix

On a finite Euclidean lattice \(\Lambda\) with periodic boundary conditions:

- Variables: \(U_b\in SU(N)\) on bonds \(b\).
- Action: Wilson action
  \[
  S_W(U) = \frac{1}{g^2}\sum_{p\subset\Lambda}\mathrm{Re\,Tr}(I-U_p).
  \]
- Measure: product Haar measure
  \[
  Z_\Lambda = \int \prod_{b\in\Lambda} d\mu(U_b)\,e^{-S_W(U)}.
  \]

The transfer matrix \(T\) is defined by slicing the lattice in Euclidean time and integrating over one time step. Osterwalder–Schrader reconstruction yields:

- A Hilbert space \(\mathcal{H}\),
- A vacuum \(\Omega\) corresponding to the largest eigenvalue \(\lambda_{\max}\) of \(T\),
- A Hamiltonian \(H\) via \(T = e^{-aH}\).

The **mass gap** at finite lattice spacing is
\[
\Delta(a) = -\frac{1}{a} \log\left(\frac{\lambda_1}{\lambda_{\max}}\right),
\]
where \(\lambda_1\) is the next eigenvalue above \(\lambda_{\max}\).

## 6.2. Charge Conjugation and Polarity Sectors

Define charge conjugation \(\mathcal{C}\) on bond variables by complex conjugation:
\[
\mathcal{C}: U_b \mapsto U_b^*.
\]

For \(SU(N)\):

- The Wilson action is invariant under \(\mathcal{C}\).
- \(\mathcal{C}\) is an involution: \(\mathcal{C}^2 = I\).

The effect on the lattice Hilbert space depends on \(N\):

- **\(SU(2)\):** The fundamental representation is pseudo-real; characters are real-valued. Charge conjugation acts trivially on gauge-invariant observables (Wilson loops). The Hilbert space \(\mathcal{H}\) has a **single sector** under \(\mathcal{C}\).

- **\(SU(N>2)\):** The fundamental representation is complex; characters are generically complex. \(\mathcal{C}\) is a nontrivial involution with eigenvalues \(\pm 1\).

  Hence
  \[
  \mathcal{H} = \mathcal{H}^+ \oplus \mathcal{H}^-,
  \]
  where \(\mathcal{H}^\pm\) are the \(\pm 1\)-eigenspaces of \(\mathcal{C}\).

Because \(H\) commutes with \(\mathcal{C}\), it preserves these sectors. This yields a **polarity decomposition** of the spectrum:

- States in \(\mathcal{H}^+\): “even under \(\mathcal{C}\)” (positive polarity),
- States in \(\mathcal{H}^-\): “odd under \(\mathcal{C}\)” (negative polarity).

This is the rigorous content of the **Polarity Note** for constructive YM: for \(N>2\), the physical Hilbert space splits into two orthogonal charge-conjugation sectors.

## 6.3. Mass from the Haar Measure

In the classical continuum action, there is no local mass term. F&O highlight that the lattice path integral includes the Haar measure, which induces an **effective local mass** when expressed in Lie-algebra variables.

Parameterize
\[
U_b = e^{iagA_b}, \quad A_b \in \mathfrak{su}(N).
\]

The Haar measure induces a nontrivial Jacobian:
\[
\int d\mu(U)\,f(U)
= \int dA\,\rho(A)\,f(e^{iA}),
\]
with
\[
\rho(A)
= \det\left( \frac{\sin(\mathrm{ad}_A/2)}{\mathrm{ad}_A/2} \right),
\]
where \(\mathrm{ad}_A\) is the adjoint action.

Writing \(\rho(A) = e^{-S_{\mathrm{measure}}(A)}\), one expands \(S_{\mathrm{measure}}\) in powers of \(A\):
\[
S_{\mathrm{measure}}(A)
\approx c_0 \sum_b \mathrm{Tr}(A_b^2) + \ldots,
\]
with \(c_0>0\) proportional to the quadratic Casimir \(C_2(N)\). Thus the **effective action** becomes
\[
S_{\mathrm{eff}}(A) = S_W(A) + S_{\mathrm{measure}}(A),
\]
where \(S_W(A)\) has kinetic and interaction terms but no local mass, and \(S_{\mathrm{measure}}\) adds a gauge-invariant quadratic term.

This provides a **geometric origin** for a mass scale:

- The compactness and curvature of \(SU(N)\) are encoded in \(\rho(A)\).
- This yields a local “mass from geometry”
  \[
  m_{\text{measure}}^2 \sim g^2 C_2(N),
  \]
  which survives in the strong-coupling regime and contributes to the lattice mass gap.

Standard perturbative treatments often linearize the measure and drop \(S_{\mathrm{measure}}\), thereby **losing** this mechanism.

## 6.4. Two-Sector Mass Gaps and Correlation Functions

Define plaquette operators \(F_p(x)\) and their \(\mathcal{C}\)-even/odd parts:
\[
F_p^\pm(x) = F_p(x) \pm \mathcal{C}F_p(x).
\]

- \(F_p^+(x)\) creates states in \(\mathcal{H}^+\),
- \(F_p^-(x)\) in \(\mathcal{H}^-\).

One then shows (at finite lattice spacing \(a\)) that:

- The 2-point functions
  \[
  \langle F_p^\pm(x) F_p^\pm(y)\rangle
  \sim e^{-m^\pm |x-y|}
  \]
  define **two positive masses** \(m^\pm(a) > 0\), corresponding to the lowest excitations in each polarity sector.

In the strong-coupling regime, F&O obtain asymptotic formulas:
\[
m^\pm(\beta)
\approx \frac{-4\ln\beta}{a} + r^\pm(\beta),
\]
where \(\beta\sim 1/g^2\) and \(r^\pm(\beta)\) are analytic corrections. To leading order, \(m^+\approx m^-\), but higher orders split the two sectors.

This gives a **two-mass-gap structure** at finite lattice spacing for \(SU(N>2)\):

- The lightest glueball in \(\mathcal{H}^+\) (scalar-like \(0^{++}\) state),
- A heavier partner in \(\mathcal{H}^-\) (odd polarity).

## 6.5. Elitzur’s Theorem and Sector Decoupling

Elitzur’s Theorem states that a local gauge symmetry cannot be spontaneously broken: the expectation value of any gauge non-invariant local operator is zero.

F&O combine this with \(\mathcal{C}\)-invariance of the vacuum to show:

- Cross correlators between \(\mathcal{H}^+\) and \(\mathcal{H}^-\) vanish:
  \[
  \langle F_p^+(x) F_p^-(y) \rangle = 0.
  \]
- Hence the two sectors are **exactly decoupled** in the spectrum; there are no mixed-polarity glueballs.

This rigorous decoupling justifies treating the mass gap problem as a **two-channel spectral problem**, one per polarity sector.

## 6.6. Stability Bounds and Continuum Limit Status

F&O further establish:

- **Thermodynamic stability:** free energy density and correlation functions have well-defined infinite-volume limits (\(L\to\infty\)).
- **UV stability:** generating functionals remain bounded as \(a\to 0\) with appropriately scaled couplings, reflecting asymptotic freedom and the stabilizing role of the Haar measure.

However, the final Clay-level step remains open:

- For each fixed \(a>0\), there are positive mass gaps \(m^\pm(a)\).
- One must show that along an appropriate RG trajectory \(g(a)\), the continuum limit
  \[
  \lim_{a\to 0} m^\pm(a) = m^\pm_{\mathrm{phys}} > 0
  \]
  exists and yields a nonzero physical mass gap.

The constructive lattice program provides a **strong base**: it shows that YM with compact gauge group and Haar measure is a well-defined, massive theory at each finite \(a\), with rich polarity structure. Connecting this to a continuum, OS/Wightman-compatible mass gap is the remaining challenge.

---

# Part VII – Named Conjectures and Roadmap

For clarity, the program is summarized in terms of the following conjectures and implications:

- **Conjecture A (Log–Forest UV Control).**  
  Renormalized gradient norms of gauge-invariant composite operators (Wilson loops, smeared fields) have at most polylogarithmic UV divergences, controlled by BPHZ forest structures, with no new power divergences beyond perimeter/contact terms.

- **Conjecture B (Horizontal Anomaly Source Positivity).**  
  In the RG–Hessian flow, the anomaly contribution \(\mathbf{S}_{\mathrm{anom}}\) restricted to the horizontal, gauge-invariant subspace is local and provides a positive curvature source.

- **Conjecture C (Polarity of Reducible Strata).**  
  The singular set of reducible connections \(\Sigma\subset\mathcal{A}\) is of capacity zero for the YM Dirichlet form; the Langevin dynamics and all relevant functional inequalities can be formulated on \(\mathcal{M}_{\mathrm{reg}}\) without boundary conditions at \(\Sigma\).

- **Conjecture IR–1 / IR–2 (Curvature-Driven Local Gap and Non-Dominant Topology).**  
  Within each topological sector, curvature controls a local-observable spectral gap \(\lambda_{\mathrm{loc}}>0\), and global topological modes do not dominate the decay rate of local Schwinger functions in the infinite-volume limit.

- **Conjecture D (Local-Sector Spectral Gap ⇒ Physical Mass Gap).**  
  Under OS/cluster hypotheses, a Poincaré/LSI inequality with constant \(\lambda_{\mathrm{loc}}>0\) on the local-observable sector implies a positive mass gap for the reconstructed Wightman theory.

## Logical Dependency Chain

The intended implication chain is:

1. **UV & Geometry:**  
   Conjecture A (Log–Forest) + Conjecture C (Polarity of singular strata)  
   ⇒ well-defined Dirichlet form and controlled UV behavior on \(\mathcal{M}_{\mathrm{reg}}\).

2. **RG Curvature:**  
   Conjecture B (Anomaly source positivity)  
   ⇒ positive curvature fixed point in the RG–Hessian flow.

3. **IR & Topology:**  
   Conjectures IR–1/2 (local curvature gap, topology non-dominant)  
   ⇒ a positive local-sector spectral gap \(\lambda_{\mathrm{loc}}>0\) for \(-L\) acting on local observables.

4. **Mass Gap:**  
   Conjecture D (functional inequality ⇒ mass gap)  
   ⇒ physical mass gap \(\Delta>0\) in the sense of Clay.

The constructive lattice YM module (F&O) provides **independent support** for:

- The relevance of the Haar measure for mass generation,  
- The robustness and importance of polarity sectors,  
- The existence of positive mass gaps at each finite lattice spacing.

Bridging these constructive results with the dynamic, curvature-based architecture in the continuum is the long-term objective of this program.

---

# Appendix H – Polarity of Reducible Connections: Gaussian and Capacity Lemmas

**Objective.**  
Show that the set of reducible connections \(\Sigma\) is polar (capacity zero) for a suitable reference Dirichlet form, and isolate precise hypotheses under which this polarity transfers to the Yang–Mills Dirichlet form. This justifies ignoring \(\Sigma\) in the Dirichlet domain and working on the regular stratum \(\mathcal{M}_{\mathrm{reg}}\) without boundary conditions.

We proceed in three steps:

1. Correct finite-dimensional intuition (codimension vs polarity).  
2. Infinite-dimensional Gaussian result: infinite-codimension linear subspaces are polar.  
3. Capacity comparison under change of measure.

## H.1 Finite-Dimensional Warm-up: Subspaces vs Polarity

Let \((B_t)_{t\ge 0}\) be standard Brownian motion in \(\mathbb{R}^n\). Let \(S\subset \mathbb{R}^n\) be a linear subspace of codimension \(m\):
\[
\dim S = n-m,\qquad \dim S^\perp = m.
\]

Decompose \(B_t = (Y_t,Z_t)\) with \(Y_t\in S\), \(Z_t\in S^\perp\simeq \mathbb{R}^m\). Then
\[
\{B_t\in S\} \iff \{Z_t = 0\}.
\]

For Brownian motion in \(\mathbb{R}^m\), the hitting probability of a point obeys:

- \(m = 1,2\): a fixed point is hit with probability 1.  
- \(m \ge 3\): a fixed point is hit with probability 0.

Thus:

> **Lemma H.1.**  
> Let \(S\subset\mathbb{R}^n\) be a linear subspace of codimension \(m\). Then
> - If \(m \le 2\), Brownian motion hits \(S\) with positive probability.  
> - If \(m \ge 3\), Brownian motion almost surely never hits \(S\); \(S\) has capacity zero for the Brownian Dirichlet form.

The correct finite-dimensional rule is therefore:

> Linear subspaces of codimension \(\ge 3\) are polar; codimension 1 or 2 is not enough.

This will serve as the template for the infinite-dimensional case, where “infinite codimension” plays the role of “\(\ge 3\)”.

## H.2 Infinite-Dimensional Gaussian OU Polarity

Let \(H\) be a separable real Hilbert space with inner product \(\langle\cdot,\cdot\rangle_H\). Let \(\gamma\) be a centered, nondegenerate Gaussian measure on \(H\), and let \((X_t)_{t\ge 0}\) be the Ornstein–Uhlenbeck process
\[
dX_t = -X_t\,dt + \sqrt{2}\,dW_t,
\]
with invariant law \(\gamma\). The associated Dirichlet form is
\[
\mathcal{E}_0(f,f)
= \int_H \|\nabla f(x)\|_H^2\,d\gamma(x),
\quad
f\in W^{1,2}(H,\gamma).
\]

We say a set \(E\subset H\) is *polar* (for \(\gamma\) and \(\mathcal{E}_0\)) if, for \(\gamma\)-a.e. starting point \(x\),
\[
\mathbb{P}_x\big(\exists t>0 : X_t\in E\big) = 0.
\]

> **Proposition H.2 (Gaussian OU polarity for linear subspaces).**  
> Let \(S\subset H\) be a closed linear subspace.
> 1. If \(\operatorname{codim}(S) = m < \infty\), then:
>    - for \(m \le 2\), \(S\) is nonpolar (hit with positive probability);  
>    - for \(m \ge 3\), \(S\) is polar (almost surely never hit).
> 2. If \(\operatorname{codim}(S) = \infty\), then \(S\) is polar.

*Sketch of proof.*

**Finite codimension.**  
Assume \(\operatorname{codim}(S) = m < \infty\). Then \(H = S \oplus N\) with \(N\simeq \mathbb{R}^m\). Under \(\gamma\), the components in \(S\) and \(N\) are independent Gaussians; the OU process decomposes
\[
X_t = Y_t + Z_t,
\quad
Y_t\in S,\quad Z_t\in N.
\]
As in the warm-up,
\[
\{X_t\in S\} \iff \{Z_t=0\}.
\]
The process \(Z_t\) is an \(m\)-dimensional OU process; its hitting behavior of \(0\) is identical to Brownian’s up to drift, giving positive hitting probability for \(m\le 2\) and zero for \(m\ge 3\).

**Infinite codimension.**  
Assume \(\operatorname{codim}(S)=\infty\). Choose an orthonormal basis \((e_j)_{j\ge 1}\) of \(S^\perp\), and define
\[
N_N := \mathrm{span}\{e_1,\dots,e_N\},
\quad
S_N := (N_N)^\perp.
\]
Then:
- \(\operatorname{codim}(S_N) = N\),
- \(S \subset S_{N+1} \subset S_N\) for all \(N\),
- \(\bigcap_{N\ge 1} S_N = S\).

By the finite-codimension case, each \(S_N\) with \(N\ge 3\) is polar for OU:
\[
\mathbb{P}_x\big(\exists t>0: X_t\in S_N\big) = 0.
\]
If a path hits \(S\), it also lies in every \(S_N\):
\[
\{\exists t>0: X_t\in S\}
\subseteq
\{\exists t>0: X_t\in S_N\}.
\]
Thus for all \(N\ge 3\),
\[
\mathbb{P}_x\big(\exists t>0: X_t\in S\big)
\le
\mathbb{P}_x\big(\exists t>0: X_t\in S_N\big)
= 0,
\]
so \(\mathbb{P}_x(\exists t>0: X_t\in S)=0\) for \(\gamma\)-a.e. \(x\). ∎

**Interpretation.**  
Any closed linear subspace that “misses infinitely many directions” (infinite codimension) is invisible to the Gaussian OU process: trajectories almost surely never lie exactly in it. This is the rigorous version of the heuristic “infinite codimension ⇒ capacity zero” for the Gaussian reference model.

## H.3 Capacity under Change of Measure

We now show how polarity for a Gaussian reference measure transfers to a more complicated measure \(\mu\), provided the density is controlled.

Let \((X,\mathcal{B})\) be a measurable space, and \(\mu_0,\mu\) two probability measures with
\[
\frac{d\mu}{d\mu_0} = \rho.
\]
Suppose:

- \(0 < c_1 \le \rho(x) \le c_2 < \infty\) for \(\mu_0\)-almost all \(x\);  
- The Dirichlet forms share the same carré du champ \(\Gamma\), but different reference measures:
  \[
  \mathcal{E}_0(f,f) = \int_X \Gamma(f)\,d\mu_0,
  \qquad
  \mathcal{E}(f,f) = \int_X \Gamma(f)\,d\mu.
  \]

Define capacities (standard Dirichlet-form definition) by
\[
\mathrm{Cap}_{\mu_0}(E)
:= \inf_{u} \Big\{\mathcal{E}_0(u,u) + \int u^2\,d\mu_0
:\ u\in\mathcal{D}(\mathcal{E}_0),\ u\ge 1\ \text{on some open }G\supset E\Big\},
\]
and similarly \(\mathrm{Cap}_\mu(E)\) with \(\mathcal{E}\) and \(\mu\).

> **Lemma H.3 (Capacity comparison under bounded density).**  
> Under the assumptions above, for every Borel set \(E\subset X\),
> \[
> c_1\,\mathrm{Cap}_{\mu_0}(E)
> \;\le\;
> \mathrm{Cap}_\mu(E)
> \;\le\;
> c_2\,\mathrm{Cap}_{\mu_0}(E).
> \]
> In particular, \(\mathrm{Cap}_{\mu_0}(E)=0\) if and only if \(\mathrm{Cap}_\mu(E)=0\).

*Proof.*  
Let \(u\) be admissible in the definition of \(\mathrm{Cap}_{\mu_0}(E)\). Then, by absolute continuity and the bounds on \(\rho\),
\[
\mathcal{E}(u,u)
= \int \Gamma(u)\,d\mu
= \int \Gamma(u)\rho\,d\mu_0
\le c_2\int \Gamma(u)\,d\mu_0
= c_2\,\mathcal{E}_0(u,u),
\]
and
\[
\mathcal{E}(u,u)
\ge c_1\,\mathcal{E}_0(u,u).
\]
Similarly,
\[
\int u^2\,d\mu
= \int u^2 \rho\,d\mu_0
\le c_2\int u^2\,d\mu_0,
\quad
\int u^2\,d\mu
\ge c_1\int u^2\,d\mu_0.
\]
Thus
\[
\mathcal{E}(u,u)+\int u^2\,d\mu
\le
c_2\big(\mathcal{E}_0(u,u)+\int u^2\,d\mu_0\big),
\]
and
\[
\mathcal{E}(u,u)+\int u^2\,d\mu
\ge
c_1\big(\mathcal{E}_0(u,u)+\int u^2\,d\mu_0\big).
\]
Taking infima over admissible \(u\) gives the inequality between capacities. The zero-capacity equivalence follows immediately. ∎

**Interpretation.**  
Polarity is stable under “nice” changes of measure: if \(\mu\) and \(\mu_0\) are equivalent and the density is bounded above and below, then a set is polar for \((\mathcal{E}_0,\mu_0)\) if and only if it is polar for \((\mathcal{E},\mu)\).

## H.4 Application to Reducible Connections

Let \(\mathcal{A}\) be a Sobolev completion of the space of gauge potentials, and model it as a Hilbert space \(H\). Let \(\gamma\) be a Gaussian reference measure on \(H\) (e.g. free-field Gaussian), with OU process and Dirichlet form \((\mathcal{E}_0,\gamma)\) as in Section H.2. Let \(\mu\) be the Euclidean YM measure (once constructed), with Dirichlet form \((\mathcal{E},\mu)\) corresponding to the YM Langevin generator.

Denote by \(\Sigma\subset H\) the set of reducible connections, i.e. those admitting a nontrivial covariantly constant adjoint field:
\[
\Sigma
:= \{A\in H : \exists\,\xi\neq 0\ \text{with } D_A\xi = 0\}.
\]

We now state a geometric embedding assumption and its analytic consequences.

> **Assumption H.4 (Infinite-codimension embedding of reducibles).**  
> For each reducibility type (e.g. each nontrivial stabilizer \(H\subset G\)), there exists a closed linear subspace \(S_H\subset H\) such that:
> 1. The subset of connections with stabilizer \(H\) is contained in an affine translate:
>    \[
>    \Sigma_H \subset A_0 + S_H,
>    \]
>    for some fixed \(A_0\).  
> 2. \(\operatorname{codim}(S_H) = \infty\).
> 
> Then
> \[
> \Sigma = \bigcup_H \Sigma_H \subset \bigcup_H (A_0 + S_H).
> \]
> 
> In words: each reducible stratum lies inside an affine subspace that misses infinitely many directions.

This is a geometric claim about the solution set of \(D_A\xi = 0\) in a given Sobolev gauge model; verifying it is the nontrivial PDE step in the Polarity program.

> **Corollary H.5 (Polarity of \(\Sigma\) for the Gaussian reference).**  
> Under Assumption H.4, the reducible set \(\Sigma\) has capacity zero with respect to the Gaussian OU Dirichlet form \((\mathcal{E}_0,\gamma)\):
> \[
> \mathrm{Cap}_\gamma(\Sigma) = 0.
> \]

*Proof.*  
Each affine translate \(A_0+S_H\) has the same codimension as \(S_H\). By Assumption H.4, \(\operatorname{codim}(S_H) = \infty\), so Proposition H.2 implies that each \(A_0+S_H\) is polar for OU. A countable union of polar sets is polar, so \(\mathrm{Cap}_\gamma(\Sigma)=0\). ∎

> **Corollary H.6 (Polarity for the Yang–Mills Dirichlet form).**  
> Assume in addition that the YM measure \(\mu\) is absolutely continuous with respect to \(\gamma\) with a density \(\rho\) satisfying \(0<c_1 \le \rho \le c_2 <\infty\) on the relevant Sobolev configuration space, and that the carré du champ is the same for \(\mathcal{E}_0\) and \(\mathcal{E}\). Then
> \[
> \mathrm{Cap}_\mu(\Sigma) = 0.
> \]

*Proof.*  
By Corollary H.5, \(\mathrm{Cap}_\gamma(\Sigma) = 0\). By Lemma H.3 (capacity comparison), \(\mathrm{Cap}_\mu(\Sigma)=0\) if and only if \(\mathrm{Cap}_\gamma(\Sigma)=0\). ∎

**Conclusion.**  
Under Assumption H.4 and a controlled change-of-measure condition between a Gaussian reference and the YM measure, the reducible set \(\Sigma\) is polar for the YM Dirichlet form. In particular:

- The YM Langevin process almost surely never reaches \(\Sigma\).  
- \(\Sigma\) can be removed from the state space without affecting the Dirichlet form or its self-adjointness.  
- All functional inequalities and spectral properties may be formulated on the regular stratum \(\mathcal{M}_{\mathrm{reg}}\) without boundary conditions at \(\Sigma\).

This is the precise form of the Polarity Condition in the Dirichlet-form framework: reducible connections are too thin (in infinite codimension, relative to a Gaussian reference) to matter for the stochastic analysis.