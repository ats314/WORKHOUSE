#!/usr/bin/env python3
"""Analyze file redundancy and create consolidation recommendations."""

import os
import re
from collections import defaultdict
from pathlib import Path

def analyze_files(directory):
    """Analyze files for redundancy patterns."""
    
    files = list(Path(directory).glob("*.md"))
    
    # Group files by base name
    groups = defaultdict(list)
    
    for f in files:
        name = f.name
        
        # Extract base name without version numbers
        base = re.sub(r'_v\d+', '', name)
        base = re.sub(r'\(\d+\)', '', base)
        base = re.sub(r'_Extended', '', base)
        
        groups[base].append((name, f.stat().st_size))
    
    # Identify redundant groups
    redundant = {}
    for base, versions in groups.items():
        if len(versions) > 1:
            redundant[base] = sorted(versions, key=lambda x: x[1], reverse=True)
    
    return redundant, groups

def main():
    directory = "/home/ubuntu/upload"
    redundant, all_groups = analyze_files(directory)
    
    print("=" * 80)
    print("FILE REDUNDANCY ANALYSIS")
    print("=" * 80)
    print()
    
    print(f"Total files: {sum(len(v) for v in all_groups.values())}")
    print(f"Unique base documents: {len(all_groups)}")
    print(f"Documents with multiple versions: {len(redundant)}")
    print()
    
    print("=" * 80)
    print("REDUNDANT FILE GROUPS (sorted by size)")
    print("=" * 80)
    print()
    
    for base in sorted(redundant.keys()):
        versions = redundant[base]
        print(f"\n📁 {base}")
        print(f"   Versions: {len(versions)}")
        total_size = sum(v[1] for v in versions)
        print(f"   Total size: {total_size / 1024:.1f} KB")
        print(f"   Potential savings: {(total_size - versions[0][1]) / 1024:.1f} KB")
        print(f"   Files:")
        for name, size in versions:
            marker = "✓ KEEP" if size == versions[0][1] else "✗ DELETE"
            print(f"      {marker:12} {name:60} ({size/1024:6.1f} KB)")
    
    print()
    print("=" * 80)
    print("CONSOLIDATION RECOMMENDATIONS")
    print("=" * 80)
    print()
    
    # Calculate potential savings
    total_current = sum(sum(v[1] for v in versions) for versions in redundant.values())
    total_after = sum(versions[0][1] for versions in redundant.values())
    savings = total_current - total_after
    
    print(f"Current size (redundant files): {total_current / 1024:.1f} KB")
    print(f"After consolidation: {total_after / 1024:.1f} KB")
    print(f"Total savings: {savings / 1024:.1f} KB ({100 * savings / total_current:.1f}%)")
    print()
    
    # Group by document type
    doc_types = {
        'White Papers': [],
        'Doc A (Scalar Prototype)': [],
        'Doc B (Dynamic Mechanism)': [],
        'Doc C (Polarity)': [],
        'Doc D (Lattice)': [],
        'Doc E (Roadmap)': [],
        'Standalone Proofs': []
    }
    
    for base, versions in redundant.items():
        if 'WhitePaper' in base:
            doc_types['White Papers'].append((base, versions))
        elif 'DocA' in base:
            doc_types['Doc A (Scalar Prototype)'].append((base, versions))
        elif 'DocB' in base:
            doc_types['Doc B (Dynamic Mechanism)'].append((base, versions))
        elif 'DocC' in base:
            doc_types['Doc C (Polarity)'].append((base, versions))
        elif 'DocD' in base:
            doc_types['Doc D (Lattice)'].append((base, versions))
        elif 'DocE' in base:
            doc_types['Doc E (Roadmap)'].append((base, versions))
        else:
            doc_types['Standalone Proofs'].append((base, versions))
    
    print("=" * 80)
    print("GROUPED BY DOCUMENT TYPE")
    print("=" * 80)
    print()
    
    for doc_type, items in doc_types.items():
        if items:
            print(f"\n📚 {doc_type}")
            for base, versions in items:
                print(f"   • {base}: {len(versions)} versions, keep latest")

if __name__ == "__main__":
    main()
