#!/usr/bin/env python3
"""Split the YM paper into manageable chunks for detailed analysis."""

import os

input_file = "/home/ubuntu/upload/YM_MassGap_WhitePaper_v3_2_Dynamic_Constructive_Detailed.md"
output_dir = "/home/ubuntu/paper_chunks"

# Create output directory
os.makedirs(output_dir, exist_ok=True)

# Read the entire file
with open(input_file, 'r', encoding='utf-8') as f:
    lines = f.readlines()

total_lines = len(lines)
chunk_size = 200  # lines per chunk
num_chunks = (total_lines + chunk_size - 1) // chunk_size

print(f"Total lines: {total_lines}")
print(f"Chunk size: {chunk_size}")
print(f"Number of chunks: {num_chunks}")

# Split into chunks
for i in range(num_chunks):
    start_line = i * chunk_size
    end_line = min((i + 1) * chunk_size, total_lines)
    
    chunk_lines = lines[start_line:end_line]
    
    output_file = os.path.join(output_dir, f"chunk_{i+1:02d}_lines_{start_line+1}-{end_line}.md")
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.writelines(chunk_lines)
    
    print(f"Created {output_file}")

print(f"\nAll chunks saved to {output_dir}")
