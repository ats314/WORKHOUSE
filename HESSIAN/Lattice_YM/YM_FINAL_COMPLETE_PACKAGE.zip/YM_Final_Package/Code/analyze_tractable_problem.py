#!/usr/bin/env python3
"""
Analyze the YM paper to identify the most tractable and impactful problem to solve.
"""

from openai import OpenAI

client = OpenAI()

# Read the comprehensive review
with open('/home/ubuntu/YM_MassGap_Comprehensive_Technical_Review.md', 'r') as f:
    review_content = f.read()

# Read the original paper chunks to understand context
paper_chunks = []
for i in range(1, 7):
    chunk_file = f'/home/ubuntu/paper_chunks/chunk_{i:02d}_lines_{(i-1)*200+1}-{min(i*200, 1082)}.md'
    with open(chunk_file, 'r') as f:
        paper_chunks.append(f.read())

paper_content = "\n\n".join(paper_chunks[:3])  # Focus on first half for context

analysis_prompt = f"""You are an expert mathematical physicist. Based on the comprehensive technical review of a Yang-Mills mass gap paper, identify ONE concrete, tractable problem that:

1. **Is mathematically rigorous and solvable**: Can be addressed with existing mathematical tools
2. **Has high impact**: Directly strengthens a critical conjecture or fills a major gap
3. **Is self-contained**: Doesn't require solving the entire mass gap problem
4. **Can be completed in a focused effort**: Not a multi-year research program

Consider these candidate problems:

A. **Rigorous proof of infinite codimension for reducible connections**: Show that the set Σ_ξ = {{A | D_A ξ = 0}} is an infinite-codimension Fréchet submanifold of the gauge connection space.

B. **Explicit construction of horizontal gradient on A/G**: Provide a rigorous definition of the horizontal distribution and gradient operator using gauge-fixing or connection theory.

C. **Finite-dimensional toy model with full proof**: Prove Conjecture D (spectral gap ⇒ mass gap) rigorously in a finite-dimensional gauge theory toy model (e.g., 2D Yang-Mills or lattice gauge theory in finite volume).

D. **Haar measure mass term explicit calculation**: Rigorously derive the effective mass term from the Haar measure Jacobian for SU(N) and compute the leading coefficient.

E. **Log-Forest bound for simple Wilson loop**: Prove the UV log-forest bound (Conjecture A) for a specific simple case, e.g., a single rectangular Wilson loop in perturbation theory.

F. **Polarity of reducibles for Gaussian measure**: Rigorously prove that reducible connections have zero capacity with respect to a Gaussian reference measure on the space of connections.

Review excerpt:
{review_content[:8000]}

Paper context:
{paper_content[:8000]}

Analyze each option and recommend THE SINGLE MOST TRACTABLE AND IMPACTFUL problem to solve now. Provide:
1. The chosen problem
2. Why it's tractable
3. Why it's impactful
4. Concrete approach/strategy to solve it
5. Expected mathematical tools needed"""

print("Analyzing tractable problems...")

response = client.chat.completions.create(
    model="gpt-4.1-mini",
    messages=[
        {"role": "system", "content": "You are an expert in rigorous mathematical physics and gauge theory."},
        {"role": "user", "content": analysis_prompt}
    ],
    temperature=0.3,
    max_tokens=3000
)

analysis = response.choices[0].message.content

# Save analysis
with open('/home/ubuntu/tractable_problem_analysis.md', 'w') as f:
    f.write("# Analysis of Most Tractable Problem to Solve\n\n")
    f.write(analysis)

print("\n" + "="*60)
print("Analysis complete!")
print("="*60)
print(analysis)
