#!/usr/bin/env python3
"""
Comprehensive technical review of Yang-Mills mass gap paper.
Uses LLM API to analyze each chunk for mathematical rigor and physical consistency.
"""

import os
import json
from openai import OpenAI

# Initialize OpenAI client (API key and base URL pre-configured in environment)
client = OpenAI()

chunk_dir = "/home/ubuntu/paper_chunks"
output_dir = "/home/ubuntu/review_results"
os.makedirs(output_dir, exist_ok=True)

# Review prompt template
REVIEW_PROMPT = """You are an expert mathematical physicist specializing in quantum field theory, gauge theory, functional analysis, and the Yang-Mills mass gap problem.

Conduct a deep technical review of this section from a Yang-Mills mass gap paper. Focus on:

1. **Mathematical Rigor**: Check all derivations, equations, inequalities, and proofs for correctness and completeness.
2. **Physical Consistency**: Verify that physical assumptions, gauge theory principles, and QFT foundations are sound.
3. **Logical Flow**: Assess whether arguments follow logically and whether conjectures are clearly distinguished from proven results.
4. **Technical Issues**: Identify any errors, gaps, unjustified steps, dimensional inconsistencies, or problematic assumptions.
5. **Notation and Definitions**: Check that all symbols are properly defined and used consistently.

For each significant issue found, provide:
- The specific equation or claim
- The nature of the problem
- Severity (critical/major/minor)
- Suggestions for correction or clarification

Also note any particularly strong or innovative aspects of the work.

Paper section:
---
{content}
---

Provide a detailed technical analysis."""

def review_chunk(chunk_file):
    """Review a single chunk of the paper."""
    with open(chunk_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    chunk_name = os.path.basename(chunk_file)
    print(f"\nReviewing {chunk_name}...")
    
    try:
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[
                {"role": "system", "content": "You are an expert mathematical physicist conducting a rigorous technical review."},
                {"role": "user", "content": REVIEW_PROMPT.format(content=content)}
            ],
            temperature=0.3,
            max_tokens=4000
        )
        
        review_text = response.choices[0].message.content
        
        # Save individual review
        output_file = os.path.join(output_dir, chunk_name.replace('.md', '_review.md'))
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"# Technical Review: {chunk_name}\n\n")
            f.write(review_text)
        
        print(f"  ✓ Review saved to {output_file}")
        return {
            "chunk": chunk_name,
            "review": review_text,
            "status": "success"
        }
        
    except Exception as e:
        print(f"  ✗ Error reviewing {chunk_name}: {e}")
        return {
            "chunk": chunk_name,
            "error": str(e),
            "status": "error"
        }

def main():
    # Get all chunk files
    chunk_files = sorted([
        os.path.join(chunk_dir, f) 
        for f in os.listdir(chunk_dir) 
        if f.endswith('.md')
    ])
    
    print(f"Found {len(chunk_files)} chunks to review")
    
    # Review each chunk
    results = []
    for chunk_file in chunk_files:
        result = review_chunk(chunk_file)
        results.append(result)
    
    # Save summary
    summary_file = os.path.join(output_dir, "review_summary.json")
    with open(summary_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"Review complete!")
    print(f"Individual reviews saved to: {output_dir}")
    print(f"Summary saved to: {summary_file}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
