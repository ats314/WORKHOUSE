#!/usr/bin/env python3
"""
Synthesize all chunk reviews into a comprehensive technical review document.
"""

import os
import json
from openai import OpenAI

client = OpenAI()

review_dir = "/home/ubuntu/review_results"
output_file = "/home/ubuntu/YM_MassGap_Comprehensive_Technical_Review.md"

def read_all_reviews():
    """Read all individual chunk reviews."""
    reviews = []
    for i in range(1, 7):
        filename = f"chunk_{i:02d}_lines_{(i-1)*200+1}-{min(i*200, 1082)}_review.md"
        filepath = os.path.join(review_dir, filename)
        
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                reviews.append({
                    'chunk': i,
                    'filename': filename,
                    'content': content
                })
    
    return reviews

def synthesize_comprehensive_review(reviews):
    """Use LLM to synthesize all reviews into a comprehensive document."""
    
    # Prepare the synthesis prompt
    all_reviews_text = "\n\n---\n\n".join([
        f"# Review of Chunk {r['chunk']}\n\n{r['content']}" 
        for r in reviews
    ])
    
    synthesis_prompt = f"""You are an expert mathematical physicist conducting a comprehensive technical review of a Yang-Mills mass gap paper.

You have been provided with detailed technical reviews of 6 sections of the paper. Your task is to synthesize these into a single, comprehensive technical review document.

The comprehensive review should:

1. **Executive Summary**: Provide an overall assessment of the paper's strengths, weaknesses, and viability as an approach to the mass gap problem.

2. **Major Technical Issues**: Consolidate and prioritize all critical and major issues across all sections, organized by theme:
   - Functional analytic foundations
   - Infinite-dimensional analysis
   - Gauge theory and geometric issues
   - Physical assumptions and consistency
   - Renormalization and UV control
   - Spectral theory and mass gap connection

3. **Detailed Section-by-Section Analysis**: For each major part of the paper:
   - Mathematical rigor assessment
   - Key equations and derivations review
   - Physical consistency check
   - Specific technical problems

4. **Minor Issues and Notation**: Consolidate all minor issues and notation problems.

5. **Strengths and Innovations**: Highlight the novel and promising aspects of the work.

6. **Recommendations**: Provide concrete, prioritized suggestions for improvement.

7. **Overall Assessment**: Give a final verdict on the technical quality and promise of this approach.

Be thorough, precise, and constructive. Use proper mathematical notation and maintain professional academic tone.

Individual chunk reviews:
---
{all_reviews_text}
---

Provide the comprehensive synthesis."""

    print("Synthesizing comprehensive review...")
    
    try:
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[
                {"role": "system", "content": "You are an expert mathematical physicist conducting rigorous technical reviews."},
                {"role": "user", "content": synthesis_prompt}
            ],
            temperature=0.3,
            max_tokens=8000
        )
        
        synthesis = response.choices[0].message.content
        return synthesis
        
    except Exception as e:
        print(f"Error during synthesis: {e}")
        return None

def create_final_document(synthesis, reviews):
    """Create the final comprehensive review document."""
    
    # Header
    document = """# Comprehensive Technical Review
# Yang-Mills Mass Gap White Paper v3.2
# Dynamic and Constructive Structures Approach

**Review Date:** November 21, 2025  
**Reviewer:** Expert Mathematical Physics Analysis  
**Paper Version:** v3.2 (Dynamic and Constructive Detailed)

---

"""
    
    # Add synthesis
    document += synthesis
    
    # Add appendix with individual reviews
    document += "\n\n---\n\n# Appendix: Individual Section Reviews\n\n"
    document += "The following are the detailed reviews of each section of the paper.\n\n"
    
    for review in reviews:
        document += f"\n\n## {review['filename']}\n\n"
        document += review['content']
        document += "\n\n---\n"
    
    return document

def main():
    print("Reading all chunk reviews...")
    reviews = read_all_reviews()
    print(f"Found {len(reviews)} reviews")
    
    print("\nSynthesizing comprehensive review...")
    synthesis = synthesize_comprehensive_review(reviews)
    
    if synthesis:
        print("\nCreating final document...")
        final_doc = create_final_document(synthesis, reviews)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(final_doc)
        
        print(f"\n{'='*60}")
        print(f"Comprehensive review saved to:")
        print(f"{output_file}")
        print(f"{'='*60}")
    else:
        print("Failed to synthesize review")

if __name__ == "__main__":
    main()
