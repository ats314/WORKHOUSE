#!/usr/bin/env python3
"""
Lattice Yang-Mills Monte Carlo Simulation
Tests whether the mass gap vanishes in the continuum limit
"""

import numpy as np
import matplotlib.pyplot as plt

# SU(2) group operations
def random_su2():
    """Generate random SU(2) matrix using Haar measure"""
    # Parameterization: exp(i θ·σ) where σ are Pauli matrices
    theta = np.random.randn(3)
    theta = theta / np.linalg.norm(theta) * np.random.uniform(0, 0.5)  # Small for Metropolis
    
    a0 = np.cos(np.linalg.norm(theta))
    a = np.sin(np.linalg.norm(theta)) * theta / (np.linalg.norm(theta) + 1e-10)
    
    return np.array([
        [a0 + 1j*a[2], 1j*a[0] + a[1]],
        [1j*a[0] - a[1], a0 - 1j*a[2]]
    ], dtype=complex)

def plaquette(U, x, y, mu, nu, L):
    """Compute plaquette at site (x,y) in mu-nu plane"""
    # U_mu(x) * U_nu(x+mu) * U_mu^†(x+nu) * U_nu^†(x)
    xp_mu = ((x + (mu==0)) % L, (y + (mu==1)) % L)
    xp_nu = ((x + (nu==0)) % L, (y + (nu==1)) % L)
    
    P = U[mu][x, y] @ U[nu][xp_mu] @ U[mu][xp_nu].conj().T @ U[nu][x, y].conj().T
    return P

def wilson_action(U, L, beta):
    """Compute Wilson action S = beta * sum(1 - Re Tr P / 2)"""
    S = 0.0
    for x in range(L):
        for y in range(L):
            P = plaquette(U, x, y, 0, 1, L)
            S += beta * (1 - np.real(np.trace(P)) / 2)
    return S

def wilson_loop(U, R, T, L):
    """Compute Wilson loop of size R x T"""
    W_sum = 0.0
    count = 0
    
    for x0 in range(L):
        for y0 in range(L):
            # Construct loop: go R steps in x, T steps in y, -R in x, -T in y
            W = np.eye(2, dtype=complex)
            
            # Forward in x (R steps)
            x, y = x0, y0
            for _ in range(R):
                W = W @ U[0][x, y]
                x = (x + 1) % L
            
            # Forward in y (T steps)
            for _ in range(T):
                W = W @ U[1][x, y]
                y = (y + 1) % L
            
            # Backward in x (R steps)
            for _ in range(R):
                x = (x - 1) % L
                W = W @ U[0][x, y].conj().T
            
            # Backward in y (T steps)
            for _ in range(T):
                y = (y - 1) % L
                W = W @ U[1][x, y].conj().T
            
            W_sum += np.real(np.trace(W)) / 2
            count += 1
    
    return W_sum / count

def metropolis_update(U, L, beta):
    """Single Metropolis sweep"""
    for mu in range(2):
        for x in range(L):
            for y in range(L):
                U_old = U[mu][x, y].copy()
                S_old = wilson_action(U, L, beta)
                
                # Propose new link
                U[mu][x, y] = random_su2() @ U_old
                S_new = wilson_action(U, L, beta)
                
                # Accept/reject
                if np.random.rand() > np.exp(-(S_new - S_old)):
                    U[mu][x, y] = U_old  # Reject

def run_simulation(L, beta, n_therm, n_meas, R, T):
    """Run Monte Carlo simulation"""
    print(f"Running simulation: L={L}, beta={beta:.2f}")
    
    # Initialize configuration
    U = [np.array([[np.eye(2, dtype=complex) for _ in range(L)] for _ in range(L)]) for _ in range(2)]
    
    # Thermalization
    for i in range(n_therm):
        metropolis_update(U, L, beta)
        if (i+1) % 1000 == 0:
            print(f"  Thermalization: {i+1}/{n_therm}")
    
    # Measurement
    W_values = []
    for i in range(n_meas):
        metropolis_update(U, L, beta)
        if (i+1) % 100 == 0:
            W = wilson_loop(U, R, T, L)
            W_values.append(W)
            if (i+1) % 1000 == 0:
                print(f"  Measurement: {i+1}/{n_meas}, <W> = {np.mean(W_values):.4f}")
    
    return np.mean(W_values), np.std(W_values) / np.sqrt(len(W_values))

# Main calculation
if __name__ == "__main__":
    print("=" * 60)
    print("YANG-MILLS MASS GAP CALCULATION")
    print("=" * 60)
    
    # Parameters
    lattice_sizes = [8, 12, 16]
    beta_values = [2.0, 3.0, 4.0]  # Corresponds to different lattice spacings
    R, T = 2, 4  # Wilson loop size
    
    results = []
    
    for L in lattice_sizes:
        for beta in beta_values:
            W_mean, W_err = run_simulation(L, beta, n_therm=2000, n_meas=5000, R=R, T=T)
            
            # Extract string tension: <W> ~ exp(-sigma * R * T)
            if W_mean > 0:
                sigma = -np.log(W_mean) / (R * T)
                sigma_err = W_err / (W_mean * R * T)
            else:
                sigma, sigma_err = np.nan, np.nan
            
            results.append((L, beta, W_mean, W_err, sigma, sigma_err))
            print(f"\nResult: L={L}, beta={beta:.1f}")
            print(f"  <W({R},{T})> = {W_mean:.4f} ± {W_err:.4f}")
            print(f"  sigma = {sigma:.4f} ± {sigma_err:.4f}")
            print(f"  mass gap ~ {np.sqrt(sigma):.4f}\n")
    
    # Save results
    np.savetxt('/home/ubuntu/ym_results.txt', results, 
               header='L beta W_mean W_err sigma sigma_err',
               fmt='%d %.2f %.6f %.6f %.6f %.6f')
    
    print("\n" + "=" * 60)
    print("CALCULATION COMPLETE")
    print("Results saved to: /home/ubuntu/ym_results.txt")
    print("=" * 60)
