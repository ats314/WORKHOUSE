# Extracted technical notes (Markdown + LaTeX)

This folder contains a curated extraction of the most *structurally powerful* derivations/proofs in the project files, rewritten as stand‑alone, lemma–proof documents.

The common spine is the “matrix hinge” program:

\[
\text{(Haar/Bakry–Émery coercivity on a canonical set)} 
\;\Rightarrow\;
\text{(matrix covariance bound via Helffer–Sjöstrand)}
\;\Rightarrow\;
\text{(massive Maxwell Green's function decay)}
\;\Rightarrow\;
\text{(uniform exponential clustering)}
\;\Rightarrow\;
\text{(OS mass gap, via decay or a one‑step comparison).}
\]

## Files

1. **01_wilson_hessian_hodge.md**  
   Wilson plaquette action: second variation at the vacuum, identity
   \(\nabla^2 S_W(U^{(0)}) = (\beta/N)\, d_1^\ast d_1\), discrete Hodge decomposition, and “physical” positivity on the coexact sector.

2. **02_matrix_hinge_haar_mass.md**  
   The localized *matrix* hinge inequality on a canonical small‑field region \(K_\Lambda\):  
   \(\mathrm{Ric}_{g_\Lambda} + \nabla^2 S_\Lambda \succeq m^2 I + t\, d_1^\ast d_1\) on horizontal directions, with explicit remainder control.

3. **03_helffer_sjostrand_covariance.md**  
   Helffer–Sjöstrand (Witten Laplacian) covariance identity and the matrix Brascamp–Lieb bound that reduces covariances to \(M^{-1}\) on gradients.

4. **04_green_function_decay_horizontal.md**  
   Exponential off‑diagonal decay of the inverse \((m^2 I + t\,d_1^\ast d_1)^{-1}\) restricted to the horizontal sector \(\ker d_0^\ast\), with an explicit exponent \(\nu(m^2,t)\).

5. **05_localization_removing_K.md**  
   Localization: removing the restriction \(U\in K_\Lambda\) without destroying the exponent coming from \(M^{-1}\). Covariance decomposition + sharp “do not spoil the rate” bookkeeping.

6. **06_OS_mass_gap_reductions.md**  
   Two clean OS reductions:  
   (A) exponential Euclidean time decay \(\Rightarrow\) spectral gap of the OS Hamiltonian;  
   (B) “one‑step” formulation via the compressed transfer operator (boundary Markov kernel) and the single comparison inequality target.

7. **A1_u1_numerical_sanity_check.md**  
   A small numerical verification (with code + output) showing, for \(U(1)\) lattice gauge theory, that the Wilson Hessian at the vacuum matches \(\beta\,d_1^\top d_1\) to numerical precision, and that the kernel dimensions match the exact+harmonic decomposition.

---
