# Helffer–Sjöstrand covariance identity and the matrix Brascamp–Lieb bound

This note is the “matrix-not-scalar” pivot: once you have a *pointwise matrix lower bound*
\[
\mathrm{Ric}_{g_\Lambda} + \nabla^2 S_\Lambda \ \succeq\ M,
\]
the Helffer–Sjöstrand/Witten-Laplacian identity turns covariances into **\(M^{-1}\) acting on gradients**, without taking absolute values of cross-terms.

---

## 1. Reversible diffusion and Dirichlet form

Let \((M,g)\) be a compact Riemannian manifold and let \(S\in C^2(M)\). Define the probability measure
\[
d\mu = Z^{-1} e^{-S}\,d\mathrm{vol}_g.
\]

Define the reversible generator
\[
L f := \Delta_g f - \langle \nabla S,\nabla f\rangle_g,
\]
which is self-adjoint on \(L^2(\mu)\) and satisfies \(L\mathbf 1=0\).

The Dirichlet form is
\[
\mathcal E(f,g) := \int_M \langle \nabla f,\nabla g\rangle_g\,d\mu = -\int_M f\,Lg\,d\mu.
\]

---

## 2. The covariance identity: reduce to a Poisson problem

Let \(F,G\in C^\infty(M)\) with \(\mu(F)=\mu(G)=0\). Define the covariance
\[
\mathrm{Cov}_\mu(F,G) := \int FG\,d\mu.
\]

Since \(-L\) is a nonnegative self-adjoint operator with kernel spanned by constants, on the mean-zero subspace \(L^2_0(\mu)\) it is invertible. Let \(u\in L^2_0(\mu)\) solve
\[
-Lu = G.
\tag{2.1}
\]

### Lemma 2.1 (Covariance as a gradient pairing)
\[
\mathrm{Cov}_\mu(F,G) = \int \langle \nabla F,\nabla u\rangle_g\,d\mu.
\]

**Proof.**
By (2.1), \(\int FG\,d\mu = \int F(-Lu)\,d\mu\).  
Integrate by parts using the Dirichlet form identity:
\[
\int F(-Lu)\,d\mu = \int \langle \nabla F,\nabla u\rangle\,d\mu.
\]
\(\square\)

So everything now hinges on expressing \(\nabla u\) in terms of \(\nabla G\).

---

## 3. The Witten Laplacian on 1-forms (Helffer–Sjöstrand operator)

Let \(\nabla^2 u\) denote the Hessian (covariant second derivative), and let \(\mathrm{Ric}_g\) denote the Ricci tensor. Define the Bakry–Émery tensor
\[
\mathrm{Ric}_\mu := \mathrm{Ric}_g + \nabla^2 S.
\]

### Proposition 3.1 (Gradient commutation formula)
For any smooth \(u\),
\[
\nabla(-Lu)
=
\Big( (-L)\otimes I + \mathrm{Ric}_\mu \Big)(\nabla u),
\tag{3.1}
\]
where the operator \((-L)\otimes I\) acts componentwise on vector fields.

**Proof.**
This is a standard consequence of the Bochner–Weitzenböck identity for the drift Laplacian. One convenient derivation is:

1. Start from the (drift) Bochner identity
   \[
   \frac12 L|\nabla u|^2 - \langle \nabla u,\nabla Lu\rangle
   = \|\nabla^2 u\|^2 + \langle \mathrm{Ric}_\mu(\nabla u),\nabla u\rangle.
   \tag{3.2}
   \]
2. Interpret the left side as \(\langle \nabla u,\, \nabla(-Lu) - ((-L)\otimes I)(\nabla u)\rangle\) and compare pointwise for arbitrary \(u\). (In local coordinates, this becomes a direct computation; in Euclidean space it reduces to \(\partial_i(-Lu)=(-L)\partial_i u + (\nabla^2 S\,\nabla u)_i\).)
3. The “defect term” is exactly \(\mathrm{Ric}_\mu(\nabla u)\).

Thus (3.1) holds. \(\square\)

Define the **Helffer–Sjöstrand / Witten Laplacian on 1-forms**
\[
\mathcal L^{(1)} := (-L)\otimes I + \mathrm{Ric}_\mu.
\tag{3.3}
\]

---

## 4. Helffer–Sjöstrand covariance representation

Let \(u\) solve (2.1). Apply \(\nabla\) and use (3.1):
\[
\nabla G = \nabla(-Lu) = \mathcal L^{(1)}(\nabla u).
\tag{4.1}
\]
Formally (and rigorously on the orthogonal complement of the kernel),
\[
\nabla u = (\mathcal L^{(1)})^{-1}\nabla G.
\tag{4.2}
\]

Plug into Lemma 2.1:

### Theorem 4.1 (Helffer–Sjöstrand covariance identity)
For mean-zero \(F,G\in C^\infty(M)\),
\[
\boxed{
\mathrm{Cov}_\mu(F,G)
=
\int_M \left\langle \nabla F,\ (\mathcal L^{(1)})^{-1}\nabla G\right\rangle_g\,d\mu.
}
\tag{4.3}
\]

**Proof.**
Combine Lemma 2.1 with (4.2). \(\square\)

---

## 5. Matrix Brascamp–Lieb bound from a pointwise hinge

The identity (4.3) becomes a *bound* once you compare \((\mathcal L^{(1)})^{-1}\) to a simpler inverse.

### Lemma 5.1 (Monotonicity of the inverse)
If \(A,B\) are self-adjoint positive definite operators with \(A\succeq B\succ 0\), then \(A^{-1}\preceq B^{-1}\).

### Proposition 5.2 (Matrix Brascamp–Lieb inequality)
Assume a pointwise operator lower bound
\[
\mathrm{Ric}_\mu(x)\ \succeq\ M(x)\ \succ 0
\qquad\forall x\in M.
\tag{5.1}
\]
Then, for mean-zero \(F,G\),
\[
\mathrm{Cov}_\mu(F,G)
\le
\int \langle \nabla F,\ M^{-1}\nabla G\rangle\,d\mu.
\tag{5.2}
\]

**Proof.**
Since \((-L)\otimes I\succeq 0\),
\[
\mathcal L^{(1)} = (-L)\otimes I + \mathrm{Ric}_\mu \ \succeq\ \mathrm{Ric}_\mu \ \succeq\ M.
\]
Invert and apply Lemma 5.1:
\((\mathcal L^{(1)})^{-1}\preceq M^{-1}\). Insert into (4.3). \(\square\)

---

## 6. Gauge theory specialization: why the “horizontal” projection is natural

In the lattice gauge setting, \(M=M_\Lambda=G^{E(\Lambda)}\) and \(\mu=\mu_\Lambda\). For gauge-invariant observables \(F\), the gradient is orthogonal to gauge orbits (vertical directions), hence lies in the horizontal sector.  

So in (4.3)–(5.2) one may replace \(\nabla\) by the horizontal projection \(\Pi_H\nabla\) without changing the value for gauge-invariant observables.

---

## 7. The payoff once the hinge is \(m^2I+t\,d_1^\ast d_1\)

If the localized hinge of `02_matrix_hinge_haar_mass.md` holds on a canonical set \(K_\Lambda\),
\[
\mathrm{Ric}_{\mu_\Lambda}(U)\ \succeq\ m^2 I + t\,d_1^\ast d_1
\quad\text{on horizontal directions, for }U\in K_\Lambda,
\tag{7.1}
\]
then (5.2) reduces covariances to the inverse of a **massive Maxwell operator** on the horizontal sector:
\[
M := m^2 I + t\,d_1^\ast d_1 \quad\Rightarrow\quad
\mathrm{Cov}(F,G)\lesssim \langle \Pi_H\nabla F,\ M^{-1}\Pi_H\nabla G\rangle.
\tag{7.2}
\]

Everything then reduces to estimating the kernel of \(M^{-1}\), i.e. Green's function decay (see `04_green_function_decay_horizontal.md`).

---
