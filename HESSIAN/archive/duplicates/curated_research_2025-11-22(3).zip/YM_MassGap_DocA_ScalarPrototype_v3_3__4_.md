# Convex Scalar Prototype and Bakry–Émery Mass Gap

_Derived from the master white paper on Yang–Mills mass gap (v3.6)._  


## Context

## Executive Summary

This white paper lays out a **dynamic and constructive program** for the Yang–Mills Existence and Mass Gap problem, combining:

- A **convex scalar prototype** (lattice \(\phi^4_4\)) where the Bakry–\u00c9mery curvature condition yields a uniform log–Sobolev inequality and spectral gap, providing a fully rigorous test case for the dynamic route.
- A **stochastic/dynamic formulation** of Yang–Mills via Langevin (stochastic quantization), focusing on **spectral gaps of the generator** and their relation to the physical mass gap.
- A **UV “Log–Forest” hypothesis** for gradient norms of gauge-invariant observables (Wilson loops), ensuring that the Dirichlet form is not destroyed by uncontrolled UV roughness.
- A **toy RG–Hessian / curvature-flow picture**, where the trace anomaly acts as a positive curvature source in a viscous Hamilton–Jacobi flow for the effective action.
- A **stratified Sobolev framework** on the singular gauge quotient \(\mathcal{A}/\mathcal{G}\), including a rigorous definition of \(W^{1,2}(\mathcal{A}/\mathcal{G})\) and a Gaussian-reference polarity theorem (plus Conjecture C for the full YM measure) showing that reducible strata can be treated as capacity-zero.
- A **constructive lattice YM component** (in the spirit of Faria da Veiga & O’Carroll) where:
  - the Hilbert space is rigorously decomposed into **charge-conjugation (“polarity”) sectors** \(\mathcal{H} = \mathcal{H}^+ \oplus \mathcal{H}^-\) for \(SU(N>2)\),
  - the **Haar measure** is shown to generate an effective local mass term (“mass from geometry”),
  - and **two positive mass gaps** \(\Delta^\pm\) are established at finite lattice spacing.

The program does **not** claim a full Clay-level proof. Instead it:

1. Makes explicit which steps are **formal** and which are **conjectural**.  
2. Identifies a precise **local-sector spectral gap** that should correspond to the physical mass gap, separating it from ultra-slow topological modes.  
3. States a set of named conjectures (A, B, C, IR–1/2, D) whose resolution would turn this architecture into a rigorous solution.

---





## Scope and relation to Doc B

This document focuses on the **convex scalar prototype** and its role as a calibration point for the dynamic route to the mass gap.

General material on:

- abstract functional inequalities (Bakry–Émery curvature, Log–Sobolev and Poincaré inequalities),
- the stratified parabolic maximum principle,
- the Multiscale Functional Inequality Program (MFIP),
- and the decomposition of variance into local and topological components

is developed **once and for all** in Doc B (*Dynamic Yang–Mills and the Multiscale Functional Inequality Program*).

Here we:

- state only the functional inequalities actually used in the scalar model,
- prove them directly from uniform convexity of the scalar action,
- and refer to Doc B for the full MFIP architecture and its application to Yang–Mills.

# Part 0 – Convex Scalar Prototype: Log–Sobolev Inequalities and Mass Gap

## 0.1. Lattice scalar field with strictly convex action

We begin with a finite Euclidean lattice \(\Lambda_L \subset \mathbb{Z}^4\) with periodic boundary conditions and a real-valued scalar field \(\phi = (\phi_x)_{x\in\Lambda_L}\in\mathbb{R}^{|\Lambda_L|}\). Consider the action
\[
S_\Lambda(\phi)
= \sum_{x\in\Lambda_L} \bigg[
  \frac{m_0^2}{2}\,\phi_x^2 + \frac{\lambda}{4}\,\phi_x^4
\bigg]
+ \frac{\kappa}{2} \sum_{\langle x,y\rangle} (\phi_x - \phi_y)^2,
\]
where the second sum runs over nearest-neighbour pairs \(\langle x,y\rangle\).

We assume parameters satisfy
\[
\lambda>0,\qquad \kappa\ge 0,\qquad m_0^2 - 2d\kappa \ge \rho_*>0,\quad d=4.
\]
This ensures that the Hessian of \(S_\Lambda\) obeys the **uniform convexity bound**
\[
\nabla^2 S_\Lambda(\phi) \ge \rho_* I
\]
as a quadratic form on \(\mathbb{R}^{|\Lambda_L|}\), uniformly in \(\phi\) and in the volume \(|\Lambda_L|\).

Define the Gibbs measure
\[
d\mu_\Lambda(\phi) = Z_\Lambda^{-1} e^{-S_\Lambda(\phi)} \prod_{x\in\Lambda_L} d\phi_x
\]
and the associated Langevin generator
\[
L_\Lambda f(\phi) = \Delta f(\phi) - \nabla S_\Lambda(\phi)\cdot\nabla f(\phi),
\]
with Dirichlet form
\[
\mathcal{E}_\Lambda(f,f)
= \int_{\mathbb{R}^{|\Lambda_L|}} \|\nabla f(\phi)\|^2\,d\mu_\Lambda(\phi).
\]

This is the canonical finite-dimensional Bakry–\u00c9mery setup.

## 0.2. Bakry–Émery log–Sobolev and spectral gap

The uniform convexity bound implies a curvature condition in the Bakry–\u00c9mery sense:
\[
\nabla^2 S_\Lambda(\phi) \ge \rho_* I
\quad\Longrightarrow\quad
\Gamma_2(f) \ge \rho_*\,\Gamma(f)
\]
for all smooth \(f\), where \(\Gamma, \Gamma_2\) are defined as in Part IV.

From the standard Bakry–\u00c9mery theory one obtains (see \u00a74.2):

> **Theorem 0.1 (Bakry–\u00c9mery LSI and spectral gap for convex lattice \(\phi^4\)).**  
> Under the assumptions above, for each finite \(\Lambda_L\) the measure \(\mu_\Lambda\) satisfies:
> 1. A log–Sobolev inequality
>    \[
>      \mathrm{Ent}_{\mu_\Lambda}(f^2)
>      \le \frac{2}{\rho_*} \int \|\nabla f\|^2\,d\mu_\Lambda
>      \quad\text{for all smooth }f.
>    \]
> 2. A Poincar\u00e9 inequality
>    \[
>      \mathrm{Var}_{\mu_\Lambda}(f)
>      \le \frac{1}{\rho_*} \int \|\nabla f\|^2\,d\mu_\Lambda.
>    \]
> 3. A spectral gap for the Langevin generator:
>    \[
>      \mathrm{Spec}(-L_\Lambda)
>      \subset \{0\}\cup[\rho_*,\infty).
>    \]
> 
> The constant \(\rho_*\) is independent of the volume \(|\Lambda_L|\).

The volume-independence is immediate from the uniform Hessian bound, which does not depend on \(L\).

## 0.3. Thermodynamic limit and dynamic mass gap

Because the constants in Theorem 0.1 do not depend on \(|\Lambda_L|\), the family \(\{\mu_\Lambda\}\) is **log–Sobolev stable** under taking increasing volumes and weak limits. In particular, along any sequence of cubes \(\Lambda_L\nearrow\mathbb{Z}^4\) one obtains an infinite-volume measure \(\mu_\infty\) and a Markov generator \(L_\infty\) such that:

- The finite-volume LSIs and Poincar\u00e9 inequalities pass to the limit with the same constant \(\rho_*\).
- The spectrum of \(-L_\infty\) on \(L^2(\mu_\infty)\) has a spectral gap \(\ge \rho_*\).

For local observables \(F\) (depending on finitely many sites) the semigroup \(P_t = e^{tL_\infty}\) satisfies
\[
\|P_t F - \mathbb{E}_{\mu_\infty}[F]\|_{L^2(\mu_\infty)}
\le e^{-\rho_* t}\,\|F - \mathbb{E}_{\mu_\infty}[F]\|_{L^2(\mu_\infty)}.
\]

In the OS reconstruction of the scalar field theory, this spectral gap for the Langevin generator can be identified with a strictly positive **mass scale** \(m_{\mathrm{dyn}}\) controlling the exponential decay of 2-point functions in Euclidean time. Thus the convex lattice \(\phi^4\) model provides a fully rigorous example where:

- A Bakry–\u00c9mery curvature bound directly yields a log–Sobolev inequality;
- The log–Sobolev inequality yields a spectral gap for the stochastic dynamics;
- The spectral gap corresponds to a genuine physical mass gap.

This is the prototype of Conjecture D in a setting where all pieces are under complete mathematical control.

## 0.4. Role as a calibration point for Yang–Mills

The convex scalar prototype serves as a **calibration point** for the Yang–Mills program:

- It shows that the dynamic route “curvature \(\Rightarrow\) functional inequality \(\Rightarrow\) spectral gap \(\Rightarrow\) mass gap” is not merely formal; it works rigorously when the action is strictly convex.
- It isolates precisely what fails in Yang–Mills:
  - the bare action is not uniformly convex (due to gauge redundancy and flat directions),
  - the configuration space has a singular gauge quotient,
  - UV renormalization complicates curvature bounds.
- It motivates the introduction of:
  - the Log–Forest UV hypothesis (Conjecture A),
  - the anomaly-driven curvature source (Conjecture B),
  - the stratified Sobolev and polarity framework (Conjecture C),
  - the stratified maximum principle (Conjecture E),
  - and the local-sector gap/mass-gap conjecture (Conjecture D).

In short, Part 0 is a non-circular **proof-of-concept**: in a simpler but genuinely interacting 4D model (\(\phi^4_4\) with a convex parameter regime), the entire dynamic chain can be completed. The remainder of the white paper explains what additional geometric, analytic, and constructive inputs are needed to replicate this chain for 4D Yang–Mills.



# Part IV – Functional Inequalities and Toy Models

## 4.1. Dirichlet Form, Generator, and Poincaré Inequality

In a finite-dimensional model with measure
\[
d\mu(x) = Z^{-1} e^{-V(x)} dx,
\]
and generator
\[
L f = \Delta f - \nabla V\cdot\nabla f,
\]
the Dirichlet form
\[
\mathcal{E}(f,f) = \int |\nabla f|^2 d\mu
\]
is symmetric in \(L^2(\mu)\).

The **Poincaré inequality** with constant \(\lambda>0\) is
\[
\mathrm{Var}_\mu(f)
:= \int f^2 d\mu - \left(\int f d\mu\right)^2
\le \frac{1}{\lambda}\int |\nabla f|^2 d\mu.
\]

This is equivalent to \(-L\) having a **spectral gap** \(\lambda\):

- If \(-L\) has an isolated eigenvalue \(0\) (constants), and \(\lambda_1 \ge \lambda>0\) for all other eigenvalues, then the Poincaré inequality holds with constant \(\lambda\).
- Conversely, a Poincaré inequality implies \(\mathrm{Spec}(-L)\subset\{0\}\cup[\lambda,\infty)\).

The proof uses spectral decomposition and integration by parts; it generalizes to infinite dimensions under standard Dirichlet form theory assumptions.

## 4.2. Bakry–Émery Curvature and Log–Sobolev Inequalities

Define the carré du champ
\[
\Gamma(f) = \tfrac{1}{2}(L(f^2) - 2 f Lf) = |\nabla f|^2,
\]
and
\[
\Gamma_2(f) = \tfrac{1}{2}(L\Gamma(f) - 2\Gamma(f,Lf)).
\]

For \(L = \Delta - \nabla V\cdot\nabla\), a direct computation gives
\[
\Gamma_2(f)
= \|\nabla^2 f\|_{\mathrm{HS}}^2
  + \langle (\nabla^2 V)\nabla f,\nabla f\rangle.
\]

If there exists \(\rho>0\) such that
\[
\nabla^2 V(x) \ge \rho I \quad \forall x,
\]
then
\[
\Gamma_2(f) \ge \rho \Gamma(f).
\]

This is the **Bakry–Émery curvature condition**. It implies:

- A Poincaré inequality with constant \(\lambda\ge \rho\),
- A log–Sobolev inequality (LSI)
  \[
    \mathrm{Ent}_\mu(f^2)
    := \int f^2 \log\frac{f^2}{\int f^2 d\mu} d\mu
    \le \frac{2}{\rho}\int |\nabla f|^2 d\mu.
  \]

The proof uses the entropy decay of the semigroup \(P_t\) and the differential inequality \(\Psi''(t) \ge \rho \Psi'(t)\) for \(\Psi(t)=\mathrm{Ent}_\mu((P_t f)^2)\).

In the YM context, we seek an **effective curvature bound** in the horizontal directions of \(\mathcal{A}/\mathcal{G}\) at large RG scales, consistent with Conjectures A and B.

## 4.3. Double-Well Toy Model and Tunneling

To clarify what curvature-based inequalities can and cannot detect, consider the 1D double-well potential
\[
V(x) = \tfrac{1}{4}(x^2 - 1)^2,
\]
with invariant measure \(\mu(dx) \propto e^{-V(x)}dx\) and generator \(L f = f'' - V'(x)f'\).

- There are two wells around \(x=\pm 1\) separated by a barrier at \(x=0\).
- The lowest nonzero eigenvalue \(\lambda_1\) of \(-L\) corresponds to metastable **tunneling** between the wells. In the small-noise/deep-well regime, \(\lambda_1 \sim C e^{-\Delta V}\) (Eyring–Kramers).

Critically:

- The **Poincaré constant** (spectral gap) is **exponentially small** in the barrier height.
- The **LSI constant** is also exponentially small: for multimodal measures with high barriers, Holley–Stroock and subsequent work show LSI constants degrade exponentially with the barrier height (up to polynomial corrections).

So **both** Poincaré and LSI “see” the tunneling time; neither gives a robust bound that ignores the exponentially slow mode.

For our YM program, this means:

- If topological tunneling produces extremely slow modes that strongly affect the measure, then any global curvature-based inequality (Poincaré/LSI on all of \(L^2(\mu)\)) will have a constant that is at most of the order of the global tunneling rate.
- To get a **mass gap** from curvature, we must either:
  - restrict attention to the **local observable sector** where topological modes are negligible (Conjectures IR–1/2 and D), or
  - use more delicate inequalities that explicitly factor out global topological degrees of freedom.

This is why the distinction between global and local-sector spectral gaps in Part I is essential.

---

## 3.6. Stratified Maximum Principle and Curvature Flow (Conjecture E)

The RG–Hessian layer and the stratified Sobolev/polarity layer are connected by a parabolic positivity mechanism. Informally: once we know that the singular set \(\Sigma\) is polar (so the Langevin diffusion does not hit it), we would like to know that a **parabolic comparison principle** for the lowest curvature eigenvalue persists on the regular stratum \(\mathcal{M}_{\mathrm{reg}}\). This is the role of a stratified maximum principle.

### Conjecture E (Stratified Parabolic Maximum Principle)

Let \(\mathcal{M} = \mathcal{A}/\mathcal{G}\) be the gauge quotient with regular stratum \(\mathcal{M}_{\mathrm{reg}}\) and singular set \(\Sigma\). Let \(L\) be the generator of the Yang–Mills Langevin diffusion on \(\mathcal{M}\), viewed as a second-order (formal) differential operator on \(\mathcal{M}_{\mathrm{reg}}\).

Consider a (matrix-valued or scalar) function \(u(t,x)\) on \([0,\infty)\times\mathcal{M}_{\mathrm{reg}}\) solving a semilinear parabolic inequality of the form
\[
  \partial_t u \;\ge\; L u + F(u,x,t)
\]
in a weak (Dirichlet-form) sense, with \(F\) nondecreasing in \(u\) and satisfying appropriate growth bounds.

Assume:
1. \(u(0,x)\ge 0\) for \(\mu\)-a.e. \(x\in\mathcal{M}_{\mathrm{reg}}\).  
2. The singular set \(\Sigma\) is polar for the diffusion associated with \(L\) (i.e., \(\mathrm{Cap}_\mu(\Sigma)=0\)).

Then for all \(t>0\),
\[
  u(t,x) \ge 0 \quad \text{for \(\mu\)-a.e. }x\in\mathcal{M}_{\mathrm{reg}}.
\]

Informally: under polarity of \(\Sigma\) and mild monotonicity of the nonlinearity \(F\), the positivity-preserving property of the parabolic flow is not destroyed by the singular strata. The “bad set” is too thin to act as a genuine boundary.

### Bridging Proposition: From Polarity and Anomaly to Global Curvature Positivity

We now formulate a conditional statement that shows how polarity, an anomaly-induced curvature source, and the stratified maximum principle would combine to give a uniform positive lower bound on the smallest curvature eigenvalue.


At the tensor level, the RG–Hessian flow can be written schematically (see §3.2) as an evolution equation for the horizontal Hessian \(h_t(x)\) of the effective action:
\[
  \partial_t h_t
  = L_t h_t - 2 h_t^2 + \mathbf{S}_{\mathrm{anom},t},
\]
where \(L_t\) is the (horizontal) diffusion operator on the regular stratum and \(\mathbf{S}_{\mathrm{anom},t}\) encodes the anomaly-induced source. Under the strong form of Conjecture B, there exists \(\sigma_*>0\) with
\[
  \mathbf{S}_{\mathrm{anom},t}(x) \;\ge\; \sigma_*\,I
\]
as quadratic forms, so that
\[
  \partial_t h_t \;\ge\; L_t h_t - 2 h_t^2 + \sigma_* I.
\]
Let \(H(t)\) solve the spatially homogeneous matrix ODE
\[
  
rac{d}{dt} H(t) = -2 H(t)^2 + \sigma_* I,
  \qquad H(t_0)=H_0.
\]

> **Theorem (Tensor Comparison Principle, heuristic form).**  
> Assume a stratified maximum principle holds for symmetric tensor fields (as in Conjecture E, extended from scalars to matrices). If \(h_{t_0}(x)\ge H_0\) for \(\mu\)-almost every \(x\) on the regular stratum, then
> \[
>   h_t(x) \;\ge\; H(t)
> \]
> for all \(t\ge t_0\) and \(\mu\)-a.e. \(x\). In particular, if \(H_0=0\), the ODE solution \(H(t)\) converges monotonically to a positive-definite fixed point \(H_*=\sqrt{\sigma_*/2}\,I\), and therefore the Hessian is uniformly bounded below:
> \[
>   h_t(x) \;\ge\; H_* \quad 	ext{for all large }t.
> \]

Projecting onto the smallest eigenvalue, this tensor comparison reduces to the scalar inequality for
\(
  \lambda(t,x) = \lambda_{\min}(h_t(x)),
\)
with \(\lambda_{\min}(t)\) solving the scalar Riccati ODE. The Bridging Proposition below is exactly this scalar projection.

> **Proposition (Bridging Polarity and Anomaly to Global Curvature Positivity).**  
> Assume:
> 
> 1. **Polarity of singularities (Conjecture C):**  
>    The singular set \(\Sigma\) of reducible connections has capacity zero for the Yang–Mills Dirichlet form and is polar for the Langevin diffusion on \(\mathcal{M}\).
> 
> 2. **Anomaly-induced curvature source (Conjecture B, strong form):**  
>    The RG–Hessian flow for the effective action has a smallest eigenvalue \(\lambda(t,x)\) on the regular stratum satisfying, in a weak sense,
>    \[
>      \partial_t \lambda \;\ge\; L \lambda - 2 \lambda^2 + \sigma_*,
>    \]
>    for some constant \(\sigma_*>0\), where \(L\) is the (horizontal) generator of the Langevin diffusion. In particular, the anomaly provides a strictly positive source term \(\sigma_*\) in the evolution inequality for \(\lambda\).
> 
> 3. **Stratified maximum principle (Conjecture E):**  
>    The positivity-preserving property of the parabolic flow associated with \(L\) extends to \(\mathcal{M}_{\mathrm{reg}}\) despite the singular set \(\Sigma\), as stated in Conjecture E.
> 
> 4. **Initial nonnegativity:**  
>    At some RG scale \(t_0\), the smallest eigenvalue satisfies
>    \[
>      \lambda(t_0,x) \ge 0 \quad \text{for \(\mu\)-a.e. }x\in\mathcal{M}_{\mathrm{reg}}.
>    \]
> 
> Then, for all \(t \ge t_0\) and \(\mu\)-a.e. \(x\in\mathcal{M}_{\mathrm{reg}}\), we have
> \[
>   \lambda(t,x) \;\ge\; \lambda_{\mathrm{min}}(t) \;>\; 0,
> \]
> where \(\lambda_{\mathrm{min}}(t)\) solves the scalar ODE
> \[
>   \partial_t \lambda_{\mathrm{min}} \;=\; -2 \lambda_{\mathrm{min}}^2 + \sigma_*,
>   \qquad \lambda_{\mathrm{min}}(t_0) = 0.
> \]
> 
> In particular, there exists a positive limit
> \[
>   \lambda_* = \lim_{t\to\infty} \lambda_{\mathrm{min}}(t) = \sqrt{\sigma_*/2} > 0,
> \]
> and thus the curvature eigenvalue is uniformly bounded below:
> \[
>   \lambda(t,x) \ge \lambda_* > 0
> \]
> for all sufficiently large \(t\) and \(\mu\)-almost every \(x\).
> 
> *Sketch of reasoning.*  
> Treat \(\lambda(t,x)\) as a supersolution to the parabolic equation
> \[
>   \partial_t u = L u - 2 u^2 + \sigma_*,
> \]
> with \(u(t_0,\cdot)\ge 0\) and the spatially constant ODE solution \(\lambda_{\mathrm{min}}(t)\) (starting from 0) as a subsolution. By the stratified maximum principle (Conjecture E), \(\lambda(t,x)\) cannot drop below \(\lambda_{\mathrm{min}}(t)\) on \(\mathcal{M}_{\mathrm{reg}}\), and hence inherits its positive lower bound in the large-\(t\) limit. Polarity of \(\Sigma\) (Conjecture C) ensures that no boundary at the singular strata can violate this comparison principle. The ODE analysis shows that the positive source \(\sigma_*\) dominates the nonlinear flattening \(-2 u^2\) and drives the system to a strictly positive fixed point \(\lambda_* = \sqrt{\sigma_*/2}\).

## 4.4. The Multiscale Functional Inequality Program (MFIP)

The functional-analytic core of the dynamic route can be phrased as a **Multiscale Functional Inequality Program (MFIP)**. The idea is to track how a log–Sobolev (or Poincaré) constant evolves under **renormalization group (RG)** flow, rather than tracking bare couplings directly.

At each coarse-graining scale \(j\) (lattice spacing \(a_j\), block size \(L^j\)), one has:

- an effective Euclidean measure \(\mu_j\) on coarse gauge degrees of freedom (e.g. block-averaged edge variables or Wilson loops),
- an associated Dirichlet form \(\mathcal{E}_j\) and generator \(L_j\),
- a log–Sobolev constant \(\alpha_j\) and Poincaré constant \(\lambda_j\) on the **horizontal, gauge-invariant sector**.

Formally, MFIP aims to establish:

1. **UV initialization (cluster expansion scale).**  
   For \(j=j_0\) deep in the ultraviolet, constructive methods (cluster/Polymer expansion, finite-range decomposition) give a strictly positive horizontal LSI:
   \[
     \mathrm{LSI}(\alpha_{j_0})\quad\text{with}\quad \alpha_{j_0}>0,
   \]
   uniformly in volume and boundary conditions, for observables built from local Wilson loops and plaquettes.

2. **RG stability and monotonicity.**  
   A single RG step \(j\mapsto j+1\) consists of:
   - integrating out short-distance fluctuations within blocks,
   - rescaling fields and couplings,
   - projecting back to the gauge-invariant (horizontal) sector.

   The MFIP postulate is that there exist universal constants \(c_1,c_2>0\) and a “noise” term \(\varepsilon_j\) controlled by UV regularity (Conjecture A) such that
   \[
     \alpha_{j+1} \;\ge\; c_1\,\alpha_j - \varepsilon_j,
     \qquad
     \lambda_{j+1} \;\ge\; c_2\,\lambda_j - \varepsilon_j.
   \]
   Intuitively: tensorization of LSIs across blocks gives a product lower bound, while the RG perturbation (integrating out constrained noise plus local counterterms) only weakly degrades the constants. Conjecture A (Log–Forest UV control) is designed precisely to keep \(\varepsilon_j\) small and summable.

3. **Horizontal anomaly source and IR saturation.**  
   In Part III, the RG–Hessian picture yields an “anomaly source” term \(\mathsf{S}_{\mathrm{anom}}\) that drives the curvature eigenvalue \(\lambda(t,x)\) toward a positive fixed point. MFIP is the functional-inequality analogue of that picture: the horizontal LSI constants \(\alpha_j\) and \(\lambda_j\) should satisfy a discrete parabolic inequality of the form
   \[
     \alpha_{j+1} - \alpha_j \;\gtrsim\; -C\,\alpha_j^2 + \sigma_{\mathrm{hor}},
   \]
   with \(\sigma_{\mathrm{hor}}>0\) determined by the anomaly on the gauge-invariant sector (Conjecture B). This favours convergence to a strictly positive limit
   \[
     \alpha_* \;=\; \liminf_{j\to\infty}\alpha_j \;>\;0.
   \]

4. **Local gap and physical mass scale.**  
   For each finite block scale \(j\), the horizontal LSI and Poincaré inequalities imply a spectral gap \(\lambda_{\mathrm{loc}}(j)\) for the local-sector generator \(L_j\). If \(\alpha_j\) converges to \(\alpha_*>0\), then
   \[
     \inf_j \lambda_{\mathrm{loc}}(j) \;\ge\; c\,\alpha_* \;>\; 0,
   \]
   giving a uniform **local-sector spectral gap** at all large scales. Conjectures IR–1/2 then assert that this local gap controls the decay of local Schwinger functions in the thermodynamic limit.

5. **From MFIP to the Yang–Mills mass gap.**  
   Finally, Conjecture D (Local-sector spectral gap \(\Rightarrow\) mass gap) identifies the physical mass scale \(\Delta\) with the square root of the local-sector spectral gap:
   \[
     \Delta \;\simeq\; c'\,\sqrt{\lambda_{\mathrm{loc}}} \;\gtrsim\; c''\,\sqrt{\alpha_*} \;>\; 0.
   \]
   Thus, closing the MFIP—establishing UV initialization, RG stability with a positive anomaly source, and IR persistence of a horizontal LSI—would amount to a complete functional-analytic proof of the mass gap, conditional only on the existence of the OS measure and the usual constructive inputs.

### 4.5. Decomposition of Variance and Local-Sector Spectral Gap

Conjectures IR–1 and IR–2 are most cleanly expressed using the **decomposition of variance** for a mixture of topological sectors. Let \\(\{S_k\}_{k\in\mathbb{Z}}\\) denote the topological sectors (e.g. labelled by instanton number), and write the YM measure as a mixture
\[
  \mu = \sum_k \pi_k \mu_k,
\]
where \(\mu_k\) is the restriction of \(\mu\) to \(S_k\) and \(\pi_k = \mu(S_k)\).

For any observable \(f\) we decompose
\[
  \mathrm{Var}_\mu(f)
  = \mathbb{E}_\muig[\mathrm{Var}(f\mid	ext{sector})ig]
    + \mathrm{Var}_\muig(\mathbb{E}[f\mid	ext{sector}]ig),
\]
i.e. a sum of **intra-sector** and **inter-sector** contributions.

Assume:

1. (**IR–1, intra-sector curvature bound**) Each restricted measure \(\mu_k\) satisfies a Poincaré inequality with a uniform constant \(
ho>0\) on the horizontal gauge-invariant sector:
   \[
     \mathrm{Var}_{\mu_k}(f)
     \;\le\; 
rac{1}{
ho}\,\mathcal{E}_k(f,f),
   \]
   where \(\mathcal{E}_k\) is the Dirichlet form restricted to \(S_k\).

2. (**IR–2, sector independence for local observables**) For \(f\) in the local horizontal sector \(\mathcal{H}_{\mathrm{loc}}\), the conditional expectations \(m_k(f):=\mathbb{E}_{\mu_k}[f]\) do not fluctuate much across sectors, in the sense that there exists \(
arepsilon\ge0\) with
   \[
     \mathrm{Var}_\muig(\mathbb{E}[f\mid	ext{sector}]ig)
     = \sum_k \pi_kig(m_k(f) - \mathbb{E}_\mu[f]ig)^2
     \;\le\; 
arepsilon\,\mathcal{E}(f,f).
   \]

Then
\[
  \mathrm{Var}_\mu(f)
  = \sum_k \pi_k \mathrm{Var}_{\mu_k}(f)
    + \mathrm{Var}_\muig(\mathbb{E}[f\mid	ext{sector}]ig)
  \;\le\; \Big(
rac{1}{
ho} + 
arepsilon\Big)\,\mathcal{E}(f,f),
\]
which yields a **local-sector spectral gap**
\[
  \lambda_{\mathrm{loc}} \;\ge\; ig(	frac{1}{
ho}+
arepsilonig)^{-1}.
\]
The global gap \(\lambda_{\mathrm{glob}}\), by contrast, is controlled by the slowest tunnelling between sectors; it may be exponentially smaller. The MFIP is precisely formulated so that the RG flow controls \(
ho\) (via curvature and LSI) and sector independence (via spatial mixing and cluster properties), thereby isolating the physically relevant local spectral gap from topological tunnelling effects.



In short, MFIP recasts the Yang–Mills mass gap as a statement about the **RG flow of horizontal log–Sobolev constants**, rather than about correlation functions directly. Parts II–V are organized so that each conjectural piece (A, B, C, IR–1/2, D) has a precise role in this multiscale inequality chain.
