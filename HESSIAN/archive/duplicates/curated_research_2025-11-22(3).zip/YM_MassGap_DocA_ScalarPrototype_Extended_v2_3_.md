# Extended Derivations for the Convex Scalar Prototype

**Document:** YM\_MassGap\_DocA\_ScalarPrototype – Extended Proofs  
**Role:** Technical backbone for the scalar calibration layer in the Yang–Mills mass gap program.

This document expands the derivations and proofs in Doc A. It is designed to be LLM‑friendly: each lemma is stated cleanly, with local notation, and most steps are written in line so they can be reasoned about in isolation.

---

## 0. Model and Basic Setup

We consider a real scalar field \(\phi:\Lambda\to\mathbb{R}\) on a finite 4D lattice \(\Lambda\subset\mathbb{Z}^4\) with periodic boundary conditions.

The action is
\[
S_\Lambda(\phi)
= \sum_{x\in\Lambda}\left(\frac{m_0^2}{2}\phi_x^2 + \frac{\lambda}{4}\phi_x^4\right)
  + \frac{\kappa}{2}\sum_{\langle x,y\rangle}(\phi_x-\phi_y)^2,
\]
with parameters \(m_0^2>0\), \(\lambda\ge 0\), and nearest‑neighbour coupling \(\kappa\ge 0\). The sum \(\sum_{\langle x,y\rangle}\) runs over unordered nearest‑neighbour pairs.

We view \(\phi\) as a vector in \(\mathbb{R}^{|\Lambda|}\). The Gibbs measure is
\[
\mu_\Lambda(d\phi) = Z_\Lambda^{-1}e^{-S_\Lambda(\phi)}\,d\phi,
\quad
Z_\Lambda = \int_{\mathbb{R}^{|\Lambda|}}e^{-S_\Lambda(\phi)}\,d\phi.
\]

The Langevin generator is
\[
(L_\Lambda f)(\phi) = \Delta f(\phi) - \nabla S_\Lambda(\phi)\cdot\nabla f(\phi),
\]
acting initially on smooth, rapidly decaying cylinder functions.

The associated carré du champ and Dirichlet form are
\[
\Gamma(f) = |\nabla f|^2, \quad
\mathcal{E}_\Lambda(f,f) = \int|\nabla f|^2\,d\mu_\Lambda.
\]

We want to prove, with maximal explicitness:

1. A uniform Hessian lower bound for \(S_\Lambda\).
2. Bakry–Émery curvature condition and volume‑uniform Log–Sobolev and Poincaré inequalities.
3. Existence of an infinite‑volume Dirichlet form with a spectral gap.
4. Identification of the scalar mass gap with this spectral gap via OS reconstruction (at least at the level of a precise sketch).

---

## 1. Hessian and Uniform Convexity

We first compute the Hessian \(\nabla^2 S_\Lambda(\phi)\) and extract a volume‑uniform convexity constant.

### 1.1. On‑site Hessian

For each site \(x\), define
\[
S_{\text{site}}(\phi_x) := \frac{m_0^2}{2}\phi_x^2 + \frac{\lambda}{4}\phi_x^4.
\]
Then
\[
\partial_{\phi_x}S_{\text{site}} = m_0^2\phi_x + \lambda\phi_x^3,
\quad
\partial_{\phi_x}^2 S_{\text{site}} = m_0^2 + 3\lambda\phi_x^2.
\]
The mixed second derivatives \(\partial_{\phi_x}\partial_{\phi_y}S_{\text{site}}=0\) for \(x\ne y\).

Thus the on‑site contribution to the Hessian bilinear form is
\[
\sum_{x\in\Lambda}(m_0^2 + 3\lambda\phi_x^2)\psi_x^2,
\]
for any test vector \(\psi\in\mathbb{R}^{|\Lambda|}\).

### 1.2. Nearest‑neighbour Hessian

The nearest‑neighbour term is
\[
S_{\text{nn}}(\phi) = \frac{\kappa}{2}\sum_{\langle x,y\rangle}(\phi_x-\phi_y)^2.
\]

For a single pair \(\langle x,y\rangle\),
\[
\frac{\kappa}{2}(\phi_x-\phi_y)^2
= \frac{\kappa}{2}(\phi_x^2+\phi_y^2-2\phi_x\phi_y).
\]
Differentiating w.r.t. \(\phi_x\),
\[
\partial_{\phi_x}\left(\frac{\kappa}{2}(\phi_x-\phi_y)^2\right)
= \kappa(\phi_x-\phi_y),
\]
and then
\[
\partial_{\phi_x}^2\left(\frac{\kappa}{2}(\phi_x-\phi_y)^2\right)
= \kappa.
\]
Similarly,
\[
\partial_{\phi_y}^2\left(\frac{\kappa}{2}(\phi_x-\phi_y)^2\right) = \kappa,
\quad
\partial_{\phi_x}\partial_{\phi_y}\left(\frac{\kappa}{2}(\phi_x-\phi_y)^2\right) = -\kappa.
\]
Summing over all pairs \(\langle x,y\rangle\) yields the quadratic form
\[
\langle \psi,\nabla^2 S_{\text{nn}}(\phi)\psi\rangle
= \kappa\sum_{\langle x,y\rangle}(\psi_x-\psi_y)^2,
\]
independent of \(\phi\).

### 1.3. Combined Hessian and lower bound

Putting together on‑site and nearest‑neighbour parts,
\[
\langle\psi,\nabla^2 S_\Lambda(\phi)\psi\rangle
= \sum_x(m_0^2+3\lambda\phi_x^2)\psi_x^2
  + \kappa\sum_{\langle x,y\rangle}(\psi_x-\psi_y)^2.
\]

We now bound this from below by a multiple of \(\sum_x\psi_x^2\) that is independent of \(\phi\) and \(\Lambda\).

On the on‑site part we simply drop the nonnegative \(3\lambda\phi_x^2\) term:
\[
\sum_x(m_0^2+3\lambda\phi_x^2)\psi_x^2
\ge m_0^2\sum_x\psi_x^2.
\]

For the nearest‑neighbour term we use the standard discrete Laplacian bound. Define the graph Laplacian \((\Delta_{\text{disc}}\psi)_x := \sum_{y\sim x} (\psi_x-\psi_y)\), where the sum is over nearest neighbours. Then
\[
\sum_{\langle x,y\rangle}(\psi_x-\psi_y)^2
= \frac{1}{2}\sum_{x} \psi_x(\Delta_{\text{disc}}\psi)_x.
\]
On a \(d\)-dimensional torus, the spectrum of \(-\Delta_{\text{disc}}\) is contained in \([0,4d]\), so for the quadratic form
\[
\sum_{\langle x,y\rangle}(\psi_x-\psi_y)^2
\ge -2d\sum_{x}\psi_x^2
\]
in the sense of quadratic forms (because the minimal eigenvalue of \(\Delta_{\text{disc}}\) is \(-4d\), but we have a symmetric counting of edges; the factor 2 reflects this).

Therefore
\[
\kappa\sum_{\langle x,y\rangle}(\psi_x-\psi_y)^2
\ge -2d\kappa\sum_x\psi_x^2.
\]

Combining,
\[
\langle\psi,\nabla^2 S_\Lambda(\phi)\psi\rangle
\ge (m_0^2-2d\kappa)\sum_x\psi_x^2.
\]

> **Conclusion.**  
> If we choose parameters such that
> \[
> m_0^2 - 2d\kappa \ge \rho_*>0,
> \]
> then
> \[
> \nabla^2 S_\Lambda(\phi)\ge \rho_* I
> \]
> as a quadratic form, uniformly in \(\phi\) and \(\Lambda\).

---

## 2. Bakry–Émery Curvature and Functional Inequalities

We now apply Bakry–Émery theory to the generator
\[
L_\Lambda f = \Delta f - \nabla S_\Lambda\cdot\nabla f.
\]

### 2.1. Carré du champ and \(\Gamma_2\)

Define
\[
\Gamma(f) := \frac{1}{2}(L_\Lambda(f^2) - 2fL_\Lambda f) = |\nabla f|^2.
\]
Then
\[
\Gamma_2(f) := \frac{1}{2}\big(L_\Lambda\Gamma(f) - 2\Gamma(f,L_\Lambda f)\big).
\]

A standard computation in \(\mathbb{R}^n\) yields
\[
\Gamma_2(f)
= \|\nabla^2 f\|_{\text{HS}}^2 + \langle\nabla^2 S_\Lambda\nabla f,\nabla f\rangle,
\]
where \(\|\cdot\|_{\text{HS}}\) is the Hilbert–Schmidt norm. For completeness we sketch the derivation.

**Derivation sketch.** Working in coordinates, write \(x\in\mathbb{R}^{|\Lambda|}\), \(f=f(x)\), \(S=S_\Lambda(x)\).

- \(L f = \Delta f - \nabla S\cdot\nabla f.\)
- \(\Gamma(f) = \sum_i (\partial_i f)^2.\)

Then
\[
L\Gamma(f) = \Delta\Gamma(f) - \nabla S\cdot\nabla\Gamma(f),
\]
and
\[
\Gamma(f,L f) = \sum_i (\partial_i f)(\partial_i L f).
\]

Compute
\[
\partial_i\Gamma(f) = 2\sum_j (\partial_j f)(\partial_{ij}^2 f),
\]
\[
\Delta\Gamma(f) = 2\sum_{i,j}(\partial_{ij}^2 f)^2 + 2\sum_j(\partial_j f)(\Delta\partial_j f).
\]

Similarly,
\[
\partial_i L f
= \partial_i\Delta f - \sum_j(\partial_{ij}^2 S)\partial_j f - \sum_j(\partial_j S)(\partial_{ij}^2 f).
\]

Plugging into the definition of \(\Gamma_2(f)\) and simplifying using symmetry of second derivatives yields
\[
\Gamma_2(f) = \sum_{i,j}(\partial_{ij}^2 f)^2 + \sum_{i,j}(\partial_{ij}^2 S)(\partial_i f)(\partial_j f).
\]
The first term is \(\|\nabla^2 f\|_{\text{HS}}^2\), the second is \(\langle\nabla^2 S\nabla f,\nabla f\rangle\).

This is a standard identity in the Bakry–Émery framework.

### 2.2. Curvature lower bound and LSI

By the Hessian bound,
\[
\langle\nabla^2 S_\Lambda\nabla f,\nabla f\rangle
\ge \rho_*|\nabla f|^2 = \rho_*\Gamma(f).
\]
Thus
\[
\Gamma_2(f) \ge \rho_*\Gamma(f).
\]

This is exactly the curvature‑dimension condition \(\mathrm{CD}(\rho_*,\infty)\) of Bakry–Émery. It implies both a Poincaré inequality and a Log–Sobolev inequality with constants depending only on \(\rho_*\).

> **Theorem 2.1 (Finite‑volume BE LSI and Poincaré).**  
> Let \(\mu_\Lambda\) be the Gibbs measure defined above and assume \(m_0^2-2d\kappa\ge\rho_*>0\). Then:
> 
> 1. (Poincaré) For all smooth \(f\),
>    \[
>    \operatorname{Var}_{\mu_\Lambda}(f)
>    \le \frac{1}{\rho_*}\int|\nabla f|^2\,d\mu_\Lambda.
>    \]
> 2. (Log–Sobolev) For all smooth \(f\),
>    \[
>    \operatorname{Ent}_{\mu_\Lambda}(f^2)
>    \le \frac{2}{\rho_*}\int|\nabla f|^2\,d\mu_\Lambda.
>    \]
> 
> Both constants are independent of \(\Lambda\).

*Sketch of proof.*  

Bakry–Émery’s theory (see, e.g., Bakry–Gentil–Ledoux, _Analysis and Geometry of Markov Diffusion Operators_) shows:

- From \(\Gamma_2(f)\ge \rho_*\Gamma(f)\), one obtains an \(L^2\) exponential contraction of the semigroup:
  \[
  \|P_tf - \mu_\Lambda(f)\|_{L^2}\le e^{-\rho_* t}\|f-\mu_\Lambda(f)\|_{L^2}.
  \]
  Spectral theory then yields the Poincaré inequality with constant \(\rho_*\).

- Similarly, one gets exponential decay of entropy:
  \[
  \operatorname{Ent}_{\mu_\Lambda}((P_tf)^2)
  \le e^{-2\rho_*t}\operatorname{Ent}_{\mu_\Lambda}(f^2),
  \]
  which implies the Log–Sobolev inequality with constant \(2/\rho_*\).

Crucially, the curvature bound is uniform in \(\Lambda\), so the constants are volume‑independent.

---

## 2.3. Poincaré Inequality and Spectral Gap: Detailed Spectral Proof

We now give a full spectral proof of the equivalence between the Poincaré inequality and a spectral gap for the scalar Langevin generator in finite volume. This fills in the details behind the standard statement "Poincaré ⇔ spectral gap ⇔ \(L^2\) semigroup decay" and will be used implicitly in the dynamic framework of Doc B.

We work in the finite-volume setting of Part 0:

- Configuration space \(\mathbb{R}^{|\Lambda|}\) with Gibbs measure
  \[
  d\mu_\Lambda(\phi)
  = Z_\Lambda^{-1} e^{-S_\Lambda(\phi)} \prod_{x\in\Lambda} d\phi_x,
  \]
  where \(S_\Lambda\) is uniformly strictly convex as in §1.

- Langevin generator
  \[
  L_\Lambda f(\phi) = \Delta f(\phi) - \nabla S_\Lambda(\phi)\cdot\nabla f(\phi)
  \]
  with Dirichlet form
  \[
  \mathcal{E}_\Lambda(f,f)
  = \int |\nabla f(\phi)|^2\,d\mu_\Lambda(\phi)
  = -\int f(\phi)\,L_\Lambda f(\phi)\,d\mu_\Lambda(\phi).
  \]

Throughout this subsection, write \(L = L_\Lambda\), \(\mu = \mu_\Lambda\), \(\mathcal{E} = \mathcal{E}_\Lambda\), and work in the Hilbert space \(H = L^2(\mu)\).

### 2.3.1. Poincaré inequality and spectral gap: statement

Recall:

- The **Poincaré inequality** with constant \(\lambda>0\) is
  \[
  \mathrm{Var}_\mu(f)
  := \int f^2\,d\mu -\Big(\int f\,d\mu\Big)^2
  \;\le\; \frac{1}{\lambda}\,\mathcal{E}(f,f)
  \quad\text{for all smooth } f.
  \tag{P}
  \]

- The (nonnegative) selfadjoint operator \(A := -L\) has compact resolvent in finite volume, so its spectrum consists of discrete eigenvalues
  \[
  0 = \lambda_0 < \lambda_1 \le \lambda_2 \le \dots \uparrow \infty
  \]
  with an orthonormal eigenbasis \((\varphi_k)_{k\ge 0}\) of \(H\), where \(\varphi_0 \equiv 1\) (normalized). The **spectral gap** is
  \[
  \lambda_{\mathrm{spec}} := \lambda_1.
  \]

We now prove:

> **Theorem 2.3.1 (Poincaré inequality \(\Longleftrightarrow\) spectral gap; best constant).**
> In the finite-volume scalar model described above:
>
> 1. The following are equivalent for a given \(\lambda>0\):
>    - (P) holds (Poincaré inequality with constant \(\lambda\)).
>    - All nonzero eigenvalues of \(A = -L\) satisfy \(\lambda_k \ge \lambda\) for \(k\ge 1\), i.e.
>      \(\operatorname{Spec}(A)\subset\{0\}\cup[\lambda,\infty)\).
> 2. The **optimal** Poincaré constant is exactly the spectral gap:
>    \[
>    \lambda_{\mathrm{Poinc}} := \sup\{\lambda>0 : (P) \text{ holds}\}
>    = \lambda_{\mathrm{spec}} = \lambda_1.
>    \]
> 3. Equivalently, for all \(t\ge 0\) and all \(f\in L^2(\mu)\),
>    \[
>    \|e^{tL}f - \textstyle\int f\,d\mu\|_{L^2(\mu)}
>    \;\le\; e^{-\lambda_1 t}\,\|f - \textstyle\int f\,d\mu\|_{L^2(\mu)}.
>    \]
>    That is, \(-L\) has a spectral gap \(\lambda_1\) iff the Langevin semigroup contracts fluctuations around equilibrium at rate \(\lambda_1\) in \(L^2(\mu)\).

### 2.3.2. Spectral decomposition

Because \(A = -L\) is selfadjoint and nonnegative on the finite-dimensional space \(\mathbb{R}^{|\Lambda|}\) with smooth, strictly confining potential, the standard elliptic theory implies that:

- The resolvent \((A+I)^{-1}\) is compact.
- The spectrum is purely discrete:
  \[
  0=\lambda_0 < \lambda_1\le\lambda_2\le\ldots,\ \lambda_k\to\infty.
  \]
- There exists an orthonormal basis \((\varphi_k)_{k\ge 0}\) of \(H=L^2(\mu)\) with
  \[
  A\varphi_k = \lambda_k\,\varphi_k.
  \]

The constant function \(\mathbf{1}\) is an eigenfunction for \(\lambda_0=0\): indeed, \(\nabla \mathbf{1}=0\) implies \(L\mathbf{1}=0\), hence \(A\mathbf{1}=0\). After normalization we set \(\varphi_0 \equiv 1\).

Any \(f\in H\) admits a unique expansion
\[
f = \sum_{k=0}^\infty c_k \varphi_k,
\qquad c_k = \langle f,\varphi_k\rangle_{L^2(\mu)}.
\]

Then:

- The mean is \(\displaystyle \int f\,d\mu = \langle f, \varphi_0\rangle = c_0\).
- The variance is
  \[
  \mathrm{Var}_\mu(f)
  = \|f - c_0\varphi_0\|_{L^2(\mu)}^2
  = \sum_{k\ge 1} |c_k|^2.
  \]
- The Dirichlet form satisfies
  \[
  \mathcal{E}(f,f)
  = \langle f,Af\rangle
  = \Big\langle \sum_k c_k\varphi_k,\ \sum_j c_j\lambda_j\varphi_j\Big\rangle
  = \sum_{k\ge 0}\lambda_k |c_k|^2
  = \sum_{k\ge 1}\lambda_k |c_k|^2,
  \]
  since \(\lambda_0=0\).

Thus, in eigenbasis coordinates the key quantities are
\[
\mathrm{Var}_\mu(f) = \sum_{k\ge 1}|c_k|^2,
\qquad
\mathcal{E}(f,f) = \sum_{k\ge 1}\lambda_k |c_k|^2.
\tag{2.3.2}
\]

### 2.3.3. (Spectral gap) ⇒ (Poincaré inequality)

Assume \(A=-L\) has a spectral gap \(\lambda_1>0\), i.e.
\[
0 = \lambda_0 < \lambda_1 \le \lambda_2 \le \dots
\]
and define \(\lambda := \lambda_1\).

For any \(f\in H\) with expansion \(f=\sum_k c_k\varphi_k\), we have, by (2.3.2),
\[
\mathcal{E}(f,f)
= \sum_{k\ge 1}\lambda_k |c_k|^2
\;\ge\; \lambda_1 \sum_{k\ge 1}|c_k|^2
= \lambda_1\,\mathrm{Var}_\mu(f).
\]

Rewriting,
\[
\mathrm{Var}_\mu(f)
\le \frac{1}{\lambda_1}\,\mathcal{E}(f,f),
\]
so the Poincaré inequality holds with constant \(\lambda = \lambda_1\).

### 2.3.4. (Poincaré inequality) ⇒ (spectral gap and optimal constant)

Conversely, suppose the Poincaré inequality holds with some \(\lambda>0\), i.e.
\[
\sum_{k\ge 1}|c_k|^2
= \mathrm{Var}_\mu(f)
\;\le\; \frac{1}{\lambda}\,\mathcal{E}(f,f)
= \frac{1}{\lambda}\sum_{k\ge 1}\lambda_k|c_k|^2
\]
for all (say smooth) \(f\). Using (2.3.2), this is equivalent to
\[
\sum_{k\ge 1}|c_k|^2
\;\le\; \frac{1}{\lambda}\sum_{k\ge 1}\lambda_k|c_k|^2
\quad\text{for all sequences }(c_k)_{k\ge 1}\in \ell^2.
\tag{2.3.3}
\]

Now test (2.3.3) on functions with only one nonzero coefficient: fix \(m\ge 1\), set \(c_m\neq 0\), and \(c_k=0\) for \(k\ne m\). Then (2.3.3) reads
\[
|c_m|^2 \;\le\; \frac{1}{\lambda}\,\lambda_m |c_m|^2
\quad\Longrightarrow\quad
1 \;\le\; \frac{\lambda_m}{\lambda}
\quad\Longrightarrow\quad
\lambda \;\le\; \lambda_m.
\]

Since this must hold for every \(m\ge 1\), we get
\[
\lambda \;\le\; \lambda_1 = \inf_{k\ge 1} \lambda_k.
\]

Thus:

- Any Poincaré constant \(\lambda\) is bounded above by \(\lambda_1\).
- On the other hand, taking \(\lambda = \lambda_1\) we already showed in §2.3.3 that (P) holds.

Therefore the **best** Poincaré constant is exactly \(\lambda_1\):
\[
\lambda_{\mathrm{Poinc}} = \sup\{\lambda>0 : (P)\ \text{holds}\}
= \lambda_1.
\]

Equivalently, the smallest nonzero eigenvalue of \(A=-L\) is the optimal constant in the Poincaré inequality.

### 2.3.5. Semigroup decay and the same constant

Let \((P_t)_{t\ge 0}\) be the Langevin semigroup \(P_t = e^{tL} = e^{-tA}\). In the eigenbasis:
\[
P_t f
= e^{tL}f
= \sum_{k\ge 0} c_k e^{-\lambda_k t}\varphi_k.
\]

The mean of \(f\) is \(c_0\); the centered part is
\[
f - \textstyle\int f\,d\mu
= \sum_{k\ge 1} c_k \varphi_k.
\]
After time \(t\),
\[
P_t f - \textstyle\int f\,d\mu
= \sum_{k\ge 1} c_k e^{-\lambda_k t}\varphi_k.
\]

Hence
\[
\|P_t f - \textstyle\int f\,d\mu\|_{L^2(\mu)}^2
= \sum_{k\ge 1} |c_k|^2 e^{-2\lambda_k t}
\le e^{-2\lambda_1 t}\sum_{k\ge 1} |c_k|^2
= e^{-2\lambda_1 t}\,\mathrm{Var}_\mu(f).
\]

Taking square roots:
\[
\|P_t f - \textstyle\int f\,d\mu\|_{L^2(\mu)}
\le e^{-\lambda_1 t}\,\|f - \textstyle\int f\,d\mu\|_{L^2(\mu)}.
\]

Thus, the same constant \(\lambda_1\) that appears:

- as the optimal Poincaré constant, and
- as the smallest nonzero eigenvalue of \(-L\),

also controls the **exponential \(L^2\) relaxation rate** of the Langevin dynamics to equilibrium.

### 2.3.6. Infinite-dimensional / abstract Dirichlet form remark

In the abstract Dirichlet-form setting of Doc B (quasi-regular symmetric forms on \(L^2(\mu)\)), one replaces the discrete eigenbasis expansion above by the spectral theorem for a nonnegative selfadjoint operator \(A=-L\) on \(L^2(\mu)\). The same equivalence holds:

- Poincaré with constant \(\lambda\)
  \(\Longleftrightarrow\)
  \(\operatorname{Spec}(A)\subset\{0\}\cup[\lambda,\infty)\),

and the best constant is the bottom of the nonzero spectrum \(\lambda_1:=\inf(\operatorname{Spec}(A)\setminus\{0\})\). The finite-volume scalar case treated here is the concrete, fully explicit instance.


## 3. Infinite‑Volume Limit and Dynamic Mass Gap

We now outline how to pass from finite \(\Lambda\) to an infinite lattice and how to relate the spectral gap to a physical mass gap.

### 3.1. Tightness and DLR limit

Consider an increasing sequence of tori \(\Lambda_L\subset\mathbb{Z}^4\) with side length \(L\to\infty\). For each \(L\), we have a measure \(\mu_L\) with density \(e^{-S_{\Lambda_L}}\) relative to Lebesgue measure.

Because the potential is uniformly strictly convex and grows at least quadratically in \(\phi\), standard arguments from Gibbs measures show:

- The family \(\{\mu_L\}\) is tight in the product topology on \(\mathbb{R}^{\mathbb{Z}^4}\).
- Any weak limit \(\mu_\infty\) is a translation‑invariant Gibbs measure (DLR measure) associated to the formal action
  \[
  S_\infty(\phi)
  = \sum_{x\in\mathbb{Z}^4}\left(\frac{m_0^2}{2}\phi_x^2 + \frac{\lambda}{4}\phi_x^4\right)
    + \frac{\kappa}{2}\sum_{\langle x,y\rangle}(\phi_x-\phi_y)^2.
  \]

The convexity prevents phase coexistence; in fact, uniqueness of the infinite‑volume Gibbs measure is expected and can be proved using Dobrushin’s or Holley’s criteria, but we do not need the full uniqueness here.

### 3.2. Dirichlet forms and Mosco convergence

For each \(\Lambda_L\), define the Dirichlet form
\[
\mathcal{E}_L(f,f)
:= \int_{\mathbb{R}^{\Lambda_L}}|\nabla f|^2\,d\mu_L,
\]
initially on cylinder functions depending on finitely many sites.

Key properties:

- \(\mathcal{E}_L\) is closable on \(L^2(\mu_L)\).
- It satisfies an LSI and Poincaré inequality with constants \(\rho_*,2/\rho_*\) independent of \(L\).
- The associated semigroup \(P_t^{(L)}\) is hypercontractive and has a uniform spectral gap \(\ge\rho_*\).

We lift these forms to the infinite configuration space by extending cylinder functions constantly outside \(\Lambda_L\). Then we can consider a sequence of forms \(\tilde{\mathcal{E}}_L\) on a common Hilbert space \(L^2(\mu_\infty)\) (using the identification via restriction/projection maps).

Under standard conditions (uniform LSI and coercivity), one can show that \(\tilde{\mathcal{E}}_L\) converges in the sense of Mosco to a limiting form \(\mathcal{E}_\infty\) on \(L^2(\mu_\infty)\), with:

- The same carré du champ \(\Gamma(f) = |\nabla f|^2\) (now interpreted as gradient w.r.t. a Gaussian reference product measure).
- Preservation of the spectral gap lower bound:
  \[
  \lambda_{\text{spec}}(\mathcal{E}_\infty)\ge \rho_*.
  \]

This is a standard consequence of the stability of spectral gaps under Mosco convergence.

> **Theorem 3.1 (Infinite‑volume spectral gap).**  
> There exists a Dirichlet form \(\mathcal{E}_\infty\) on \(L^2(\mu_\infty)\) associated with the infinite‑volume Langevin dynamics such that:
> \[
> \mathcal{E}_\infty(f,f) = \int |\nabla f|^2\,d\mu_\infty
> \]
> for cylinder \(f\), and
> \[
> \mathrm{spec}(-L_\infty) = \{0\}\cup[\lambda_\infty,\infty)
> \]
> with \(\lambda_\infty\ge \rho_*\). Here \(L_\infty\) is the generator associated with \(\mathcal{E}_\infty\).

### 3.3. Dynamic mass gap and correlation decay

For any local observable \(F\) (depending on finitely many sites), define its time‑correlation under the Langevin dynamics as
\[
C_F(t) := \langle F(\phi_t)F(\phi_0)\rangle_{\mu_\infty} - \langle F\rangle_{\mu_\infty}^2.
\]
Spectral theory shows
\[
|C_F(t)| \le e^{-\lambda_\infty t}\operatorname{Var}_{\mu_\infty}(F),
\]
so correlations decay exponentially in time.

To relate this to spatial decay of \(\langle F(x)F(y)\rangle\), one uses:

- OS reflection and reconstruction to identify the scalar Euclidean field with a relativistic QFT.
- The standard fact that exponential decay of time correlations in the Markov picture corresponds to a mass gap in the physical spectrum.

Although OS reconstruction is not fully re‑proved here, the logic is standard: the convex scalar model provides a clean example where:

- The dynamic spectral gap is explicitly controlled through curvature.
- The mass gap in the scalar QFT coincides with this spectral gap.

This completes the “calibration” of the dynamic route for the scalar prototype.

---

## 4. LLM‑Friendly Task Decomposition

To make this document maximally useful for LLM‑based work, here are explicit micro‑tasks (lemmas) that can be tackled in isolation:

1. **Task A1:** For the discrete Laplacian on \(\mathbb{Z}^4/L\mathbb{Z}^4\), compute the exact spectrum and give the optimal constant in the inequality
   \[
   \sum_{\langle x,y\rangle}(\psi_x-\psi_y)^2
   \ge -C_d\sum_x\psi_x^2.
   \]

2. **Task A2:** Fill in the full derivation of the \(\Gamma_2\) identity for a general potential \(S\) in \(\mathbb{R}^n\), starting from the coordinate expressions for \(L\), \(\Gamma\), and \(\Gamma_2\).

3. **Task A3:** Prove Mosco convergence of the finite‑volume Dirichlet forms \(\mathcal{E}_L\) to \(\mathcal{E}_\infty\) explicitly, under the uniform LSI assumption.

4. **Task A4:** Starting from the Langevin SDE
   \[
   d\phi_t = -\nabla S_\Lambda(\phi_t)\,dt + \sqrt{2}\,dB_t,
   \]
   derive the generator \(L_\Lambda\) and verify that \(\mu_\Lambda\) is invariant.

5. **Task A5:** For a given local observable \(F\), prove rigorously that its time‑correlation \(C_F(t)\) decays at a rate controlled by the spectral gap, and connect this to the Laplace transform representation of the spectral measure associated with \(F\).

Each of these tasks can be given to an LLM separately, with this document as context, to check steps, fill gaps, or explore variants (e.g. adding a quartic nearest‑neighbour term).