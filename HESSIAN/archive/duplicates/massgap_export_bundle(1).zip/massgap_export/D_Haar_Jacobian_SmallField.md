# D. Haar Jacobian in Exponential Coordinates: Small-Field Expansion and a Hessian Lower Bound

This document isolates one analytic “must-have” lemma for the convexity/BE program:

> **In a sufficiently small exponential chart, the Haar Jacobian produces a strictly positive quadratic potential**, and its Hessian remains bounded below by a positive constant up to \(O(\|A\|^2)\) corrections.

The only subtlety is normalization.

---

## D1. Setup

Let \(G\) be a compact Lie group (here \(G=SU(3)\)) with Lie algebra \(\mathfrak{g}\), and fix an inner product \(\langle\cdot,\cdot\rangle\) on \(\mathfrak{g}\) (equivalently, a bi-invariant Riemannian metric on \(G\)).

For \(A\in\mathfrak{g}\), define the adjoint map \(\mathrm{ad}_A:\mathfrak{g}\to\mathfrak{g}\) by \(\mathrm{ad}_A(X)=[A,X]\).

In a sufficiently small ball \(B_{r_0}(0)\subset\mathfrak{g}\), the exponential map \(\exp:\mathfrak{g}\to G\) is a diffeomorphism onto its image.  
In that chart, Haar measure takes the form:
\[
dU = J(A)\,dA,\qquad U=\exp(A),
\]
where \(dA\) is Lebesgue measure induced by the chosen inner product.

Define the **Haar potential**
\[
S_{\rm Haar}(A) := -\log J(A).
\]

---

## D2. Exact Jacobian formula

A standard identity for the differential of the exponential map implies:
\[
J(A) \;=\; \det\!\left(\frac{1-e^{-\mathrm{ad}_A}}{\mathrm{ad}_A}\right).
\]

Because \(G\) is compact, \(\mathrm{ad}_A\) is skew-adjoint and has purely imaginary spectrum; so \(J(A)\) can equivalently be written in terms of \(\sin\) factors in a root decomposition.  
The determinant is analytic for \(\|\mathrm{ad}_A\|\) below the first singularity (at \(2\pi\)).

---

## D3. Small-field expansion: the universal quadratic term

Use the symmetric factorization:
\[
\frac{1-e^{-\mathrm{ad}_A}}{\mathrm{ad}_A}
= e^{-\mathrm{ad}_A/2}\,\frac{2\sinh(\mathrm{ad}_A/2)}{\mathrm{ad}_A}.
\]
Taking determinants and logs, the \(e^{-\mathrm{ad}_A/2}\) term drops out because \(\mathrm{Tr}(\mathrm{ad}_A)=0\), so
\[
\log J(A)
= \mathrm{Tr}\,\log\!\left(\frac{2\sinh(\mathrm{ad}_A/2)}{\mathrm{ad}_A}\right).
\]

Now use the Taylor series (an even analytic function):
\[
\log\!\left(\frac{2\sinh(z/2)}{z}\right)
= \frac{z^2}{24} - \frac{z^4}{2880} + O(z^6).
\]

Therefore,
\[
\log J(A) = \frac{1}{24}\mathrm{Tr}(\mathrm{ad}_A^2) + O(\|\mathrm{ad}_A\|^4),
\]
so
\[
\boxed{
S_{\rm Haar}(A) = -\frac{1}{24}\mathrm{Tr}(\mathrm{ad}_A^2)\;+\;O(\|\mathrm{ad}_A\|^4).
}
\]

Because \(\mathrm{ad}_A\) is skew-adjoint, \(\mathrm{Tr}(\mathrm{ad}_A^2)\le 0\), hence the leading term is **positive**.

---

## D4. Normalization bookkeeping

The quantity \(-\mathrm{Tr}(\mathrm{ad}_A^2)\) is (up to normalization) the adjoint quadratic form.  
There is a constant \(\kappa_G>0\) (depending on the inner product convention) such that
\[
-\mathrm{Tr}(\mathrm{ad}_A^2) = \kappa_G\,\|A\|^2.
\]

Under the **Killing-form normalization**, \(\kappa_G = 2g^\vee\), where \(g^\vee\) is the dual Coxeter number.  
For \(SU(N)\), \(g^\vee=N\).

So in that normalization:
\[
S_{\rm Haar}(A)
= \frac{g^\vee}{12}\,\|A\|^2 + O(\|A\|^4).
\]

In many lattice codes, the basis is normalized differently (e.g. \(T^a = i\lambda^a/2\) for SU(3)), which shifts the numeric coefficient by an overall constant factor.

The correct “physics-safe” statement is:
- the quadratic coefficient exists and is strictly positive,
- its numeric value depends on the chosen algebra norm.

---

## D5. Haar Hessian Lemma (small-field, rigorous form)

**Lemma (Haar Hessian lower bound in a chart).**  
Fix a compact Lie group \(G\) and an inner product on \(\mathfrak{g}\).  
There exist constants \(r_0>0\), \(c_0>0\), \(C_H>0\) (depending only on \(G\) and the inner product) such that for all \(A\in\mathfrak{g}\) with \(\|A\|\le r\le r_0\),
\[
\nabla^2 S_{\rm Haar}(A)\ \succeq\ \bigl(c_0 - C_H r^2\bigr)\,I.
\]

Moreover, \(c_0\) is exactly the minimal eigenvalue of \(\nabla^2 S_{\rm Haar}(0)\), and in Killing normalization one has \(c_0 = g^\vee/12\).

**Proof sketch (rigorous mechanism).**

1. The map \(A\mapsto S_{\rm Haar}(A)\) is real-analytic on the ball \(\|{\rm ad}_A\|<2\pi\).  
2. The series above shows \(\nabla^2 S_{\rm Haar}(0)\) is a positive multiple of the identity in any orthonormal basis.
3. Since \(S_{\rm Haar}\) is analytic and even, the Hessian is \(C^2\) and satisfies
   \[
   \|\nabla^2 S_{\rm Haar}(A)-\nabla^2 S_{\rm Haar}(0)\|_{\rm op}
   \le C\,\|A\|^2
   \]
   for \(\|A\|\le r_0\), by Taylor remainder bounds (or Cauchy estimates on derivatives of the scalar analytic function \(z\mapsto \log(2\sinh(z/2)/z)\) composed with \(\mathrm{ad}_A\)).
4. Rearranging gives the claimed lower bound.

This proves the lemma with explicit dependence on a chart radius \(r_0\) below the first singularity.

---

## D6. Why this matters for SU(3) Wilson+Haar convexity

In the combined action,
\[
S_{\rm eff}(A) = \sum_\ell S_{\rm Haar}(A_\ell) + \beta S_W(A),
\]
the Haar term contributes a **uniform positive Hessian** at \(A=0\), while the Wilson term can contribute negative curvature away from the identity.

So the Haar lemma is the “positive anchor” in the inequality
\[
\nabla^2 S_{\rm eff}(A)
\succeq
c_0 I\;-\;\beta\,(\text{Wilson Hessian increment})\;-\;O(r^2).
\]

The numerics in the project strongly suggest a convexity radius scaling \(R_{\rm conv}(\beta)\sim \beta^{-1/2}\) in the chosen normalization, consistent with the Wilson increment being \(O(\beta r^2)\).

---
