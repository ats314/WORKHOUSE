# C2 acceptance gate — integration with G3 / the settlement harness

## What this is
A **necessary-condition structural acceptance test** for the exact fourth-order
off-axis coefficient `C_shp` that G3 (GLUEBALL §18.1, marked-cluster engine,
target-blind) will emit.  It checks that the emitted value lies in the cubic
rank-3 order-4 denominator localization:

    support(den) ⊆ S4 = {2,3,5,7,11,13,17,19,23,29,31,37,47}
    den | QBOUND      (2^36·3^20·5^7·7·11·13·17^3·19·23·29·31·37·47)

Validated: it accepts all 8 known exact cubic order-4 coefficients (including the
exact historical `C_shp`), and rejects the C20 artifact, a float, and hypothetical
violations (7², alien 43, 17⁴).

## Where it plugs in
`settlement/mce_adjudication_harness.py::stage_adjudicate` currently decides the
shape verdict **numerically** — `dC_old = |C - C_old|`, `dC_new = |C - C_new|`,
labelling HISTORICAL / RUN15-FOLDED / THIRD VALUE by float proximity (lines
~316-321).  It extracts `C` and can already form exact rationals (`_to_fraction`).

Add the gate as **item 12 — structural localization**, run on the engine's EXACT
`C` before the numerical verdict:

    from c2_acceptance_gate import gate
    g = gate(C_exact)                       # C_exact = _to_fraction(engine C)
    verdict["shape"]["localization"] = {
        "passed": g.passed, "support": list(g.support),
        "denominator": g.denominator, "violation": g.violation,
    }
    # if not g.passed: the engine emitted an exact coefficient OUTSIDE the cubic
    # o4 localization -> reject the RUN (engine bug or float contamination),
    # independent of which anchor it is near.

## What it adds that the numerical verdict cannot
A run can land near an anchor yet emit an exact coefficient with an alien prime
or a squared large prime — a signature of float contamination or an engine fault.
Float proximity is blind to that; the gate catches it.  It independently
reproduces C20: the RUN15-printed linked vacuum leaves the localization, the
intended exact value stays inside it.

## What it CANNOT do (non-negotiable #2)
It does not adjudicate C2.  The historical `C_shp` is exact and passes; the
v10a.26 value is a float with no exact denominator to gate.  S4-smooth rationals
are dense near any float (QBOUND permits 2^36·3^20·5^7), so the gate cannot
distinguish the two sides from the recorded numbers.  Its decisive use is
**prospective**: the structural acceptance test on G3's target-blind EXACT output.
It never prefers a side.
