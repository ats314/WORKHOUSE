"""C2 acceptance gate: the cubic rank-3 order-4 denominator-localization check
that any exact fourth-order off-axis coefficient C_shp emitted by G3
(GLUEBALL §18.1, target-blind) must pass.

This is a NECESSARY condition, not a resolution of C2.  It cannot pick between
the historical and v10a.26 values; it can only reject a candidate whose reduced
denominator leaves the cubic order-4 localization, and validate that a legitimate
exact output lies inside it.  Per non-negotiable #2 it never prefers a side.

The localization is the hash-frozen, Lean-verified bound of the cubic rank-3
order-4 scope:
    S4     = {2,3,5,7,11,13,17,19,23,29,31,37,47}
    QBOUND = 2^36·3^20·5^7·7·11·13·17^3·19·23·29·31·37·47
             (freeze sha256 5020661c...; qTight in Rank3Order4QBoundCertificate.lean)
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from sympy import Rational, factorint

S4 = frozenset({2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 47})
QBOUND = 62895057857493885215590055852113920000000
QBOUND_EXP = {2: 36, 3: 20, 5: 7, 7: 1, 11: 1, 13: 1, 17: 3, 19: 1,
              23: 1, 29: 1, 31: 1, 37: 1, 47: 1}


@dataclass(frozen=True)
class GateResult:
    passed: bool
    support_ok: bool
    divides_qbound: bool
    denominator: int
    support: tuple
    violation: str  # "" if passed


def gate(value) -> GateResult:
    """Necessary-condition acceptance gate for an EXACT cubic order-4 coefficient.

    `value` must be an exact rational (sympy.Rational / Fraction / int).  A float
    is rejected outright: the gate certifies exact coefficients, and a float has
    no exact denominator to localize (that is the C2 firewall, not an answer)."""
    if isinstance(value, float):
        return GateResult(False, False, False, 0, (),
                          "value is a float; the gate certifies exact rationals only")
    q = int(Rational(value).q)
    fac = factorint(q) if q > 1 else {}
    support = tuple(sorted(fac))
    support_ok = set(fac) <= S4
    divides = (QBOUND % q == 0)
    viol = ""
    if not support_ok:
        alien = sorted(set(fac) - S4)
        viol = f"alien prime(s) {alien} outside cubic o4 localization S4"
    elif not divides:
        over = {p: e for p, e in fac.items() if e > QBOUND_EXP.get(p, 0)}
        allowed = {p: QBOUND_EXP.get(p, 0) for p in over}
        viol = f"exponent(s) exceed QBOUND: {over} (allowed {allowed})"
    return GateResult(support_ok and divides, support_ok, divides, q, support, viol)


# ----------------------------------------------------------------------
# Validation: the gate must ACCEPT every known exact cubic order-4 coefficient
# and REJECT the recorded artifact and any out-of-scope value.
# ----------------------------------------------------------------------
if __name__ == "__main__":
    import workhouse.constants as C

    print("=== ACCEPTANCE (known exact cubic order-4 coefficients must pass) ===")
    accept = {
        "A_SHP_3": C.A_SHP_3, "ALPHA_PEN_3": C.ALPHA_PEN_3,
        "CUBE_COMPLETION_4": C.CUBE_COMPLETION_4,
        "Q_BAND_4": C.Q_BAND_4, "BETA_PEN_3": C.BETA_PEN_3,
        "Q4_CROSS": C.Q4_CROSS,
        "C_SHP_HISTORICAL": C.C_SHP_HISTORICAL,   # the exact C2 side
        "LINKED_VACUUM_4": C.LINKED_VACUUM_4,
    }
    allpass = True
    for name, v in accept.items():
        r = gate(v)
        allpass &= r.passed
        print(f"  {'PASS' if r.passed else 'FAIL':4} {name:18s} support={list(r.support)}")
    print(f"  -> all known exact coefficients accepted: {allpass}")

    print("\n=== REJECTION (must be rejected) ===")
    reject = {
        "LINKED_VACUUM_4_ARTIFACT": C.LINKED_VACUUM_4_ARTIFACT,  # the C20 artifact
        "C_SHP_NEW_NUM (v10a.26 float)": C.C_SHP_NEW_NUM,        # float -> firewalled
        "hypothetical 7^2 denom": Rational(1, 49),               # squared exp-1 prime
        "hypothetical alien 43": Rational(1, 43),                # 43 ∉ S4
        "hypothetical 17^4": Rational(1, 17**4),                 # exceeds 17^3
    }
    allrej = True
    for name, v in reject.items():
        r = gate(v)
        allrej &= (not r.passed)
        print(f"  {'REJECT' if not r.passed else 'ACCEPT!':7} {name:32s} :: {r.violation}")
    print(f"  -> all rejected as required: {allrej}")

    print("\n=== C2 STATUS UNDER THE GATE (no adjudication) ===")
    print("  historical C_shp (exact) : PASS  -> consistent with cubic o4 localization")
    print("  v10a.26  C_shp (float)   : firewalled -> gate inapplicable to a float")
    print("  => the gate is the structural acceptance test for G3's target-blind EXACT output:")
    print("     any C_shp it emits must land in S4 with den | QBOUND, or G3 is rejected.")

    assert allpass and allrej, "gate validation failed"
    print("\ngate validated.")
