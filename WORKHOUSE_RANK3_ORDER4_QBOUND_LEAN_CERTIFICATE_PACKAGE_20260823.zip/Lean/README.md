# WORKHOUSE denominator checker prototype

Status: `Workhouse/DenominatorChecker.lean` was compiled on 2026-08-23 with
Lean `v4.34.0-rc1` and the already-cached Mathlib revision
`1f29011071772620f612bf5a06433775f06067b8`.  It contains no `sorry`.

## What the compiled kernel proves

- `PrimeSupported S n`: every prime dividing `n` is in the caller-supplied
  finite set `S`.
- Rational denominators supported on `S` stay supported under negation,
  addition, subtraction, multiplication, finite list sums, and finite list
  products.
- Division is deliberately different: support for the divisor's numerator is
  required, since inversion moves numerator primes into the denominator.
- `DenominatorDivides Q x` composes with LCM at additive nodes and product at
  multiplicative nodes.
- `CertifiedAtom` and `ExactExpr` form a small certificate language.  The main
  theorem, `ExactExpr.denominator_dvd_qBound`, proves that the evaluated reduced
  denominator divides the mechanically computed expression bound.
- `ExactExpr.eval_primeSupported` transfers a supplied support proof for the
  computed bound to the actual reduced denominator.
- `crt_unique_centered` proves the final uniqueness step: integers congruent
  modulo `M` are equal if their difference has absolute value strictly below
  `|M|`.

## Compiled rank-three, order-four certificate

`Workhouse/Rank3Order4QBoundCertificate.lean` is a small generated-style
certificate for the frozen cubic rank-three, order-four arithmetic envelope.
The Lean kernel checks the displayed component factorizations, the equality of
the pair envelope with
`62895057857493885215590055852113920000000`, divisibility of the analytic
denominator `896`, and divisibility of that tighter bound into the earlier
conservative source-only bound with the exact quotient
`68410380572018343936`.  It also supplies conditional bridge theorems for a
finite sum once the external producer provides denominator certificates for
each `W2`, `R2`, and Haar factor.

The analytic coefficient `-13/896` is no longer an unexplained target literal:
the external exact-history generator derives it by a four-by-four exact
recurrence from inputs pinned to the `DATA_O4` source hash.  Lean verifies the
emitted reduced rational and that `896` divides the declared QBOUND.  Lean does
not currently re-run the recurrence, verify SHA-256, or establish that those
recurrence inputs faithfully and completely represent the source artifact.

The zero-gap boundary is now externally certified rather than assumed.  Before
excluding `gap = 0` histories, the hashed generator projects every W1/W2
resonant physical block against the scaled plaquette band using exact SU(3)
Haar Gram arithmetic and fails unless every residual norm is exactly zero.
The external certificate reports one W1 and 25 W2 resonant blocks.  This Lean
file does not re-run that construction or authenticate its hash; it verifies
the arithmetic consequences supplied at its deliberately small interface.
Ledger-generation completeness and the endpoint-Haar numerator/topology sum
remain external obligations.

These are generic certificate consequences.  They do **not** prove that a
manifest's allowed set or QBOUND is physically complete, and they do not prove
any rank/order `Pmax` conjecture.

## Typed external manifest

Keep the large history ledger outside Lean and hash every immutable artifact.
A generated manifest should contain:

```text
schema_version
scope:
  rank, perturbative_order, sector, basis, normalization, convention
coefficient:
  stable_id
  role: primitive_weight | haar_factor | resolvent | normalization |
        assembled_coefficient | published_target | diagnostic_ratio
  exact_numerator, exact_denominator
  source_artifact_sha256, source_location
certificate:
  declared_allowed_primes
  atom_qbound
  qbound_factor_witnesses[]
  expression_ast_sha256
crt:
  cleared_integer_convention
  moduli[], residues[], combined_modulus, candidate, uniqueness_bound
  residue_ledger_sha256
```

The generator should emit a tiny `.lean` certificate containing only exact
atoms, their denominator-divisibility proofs, the expression AST, the declared
support proof, and the final combined CRT congruence/window.  Semantic source
classification, enumeration completeness, JSON parsing, and SHA-256 checking
remain external and independently reproducible.

## Still proposed, not compiled here

- A theorem connecting `denominator | Q` directly to the selected
  denominator-clearing convention (`Q*x` is an integer).
- Pairwise-coprime CRT combination from an arbitrary residue list.  The current
  kernel begins at the combined-congruence interface and verifies uniqueness.
- A fully generated per-history certificate tying every emitted physical
  coefficient to the frozen ledger.  The included rank-three/order-four file
  checks the aggregate arithmetic envelope and conditional composition only.
- A completeness theorem deriving the supplied `S`/`QBOUND` from a physical
  state enumeration.  This is the substantive research obligation, not a
  consequence of the generic checker.
