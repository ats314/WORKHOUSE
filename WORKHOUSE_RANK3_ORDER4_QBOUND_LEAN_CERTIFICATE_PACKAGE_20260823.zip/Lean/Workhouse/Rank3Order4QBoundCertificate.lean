import Workhouse.DenominatorChecker
import Mathlib.Tactic.NormNum

/-!
# Rank-three, order-four QBOUND arithmetic certificate

This file verifies only the small arithmetic interface exported by the frozen
external history ledger:

* the displayed component factorizations;
* `QPAIR ∣ QTIGHT` and `896 ∣ QTIGHT`;
* the exact factorization of `QTIGHT`;
* `QTIGHT ∣ QPATH`, with the exact quotient;
* conditional denominator composition for a `W2 * R2 * Haar` term and a
  finite sum of such terms.

It deliberately does **not** assert that the external history ledger is
complete or that every physical coefficient satisfies the supplied component
bounds.  The hashed external generator separately certifies exact supportwise
`E0/P0` cancellation before excluding resonant blocks.  The analytic
coefficient `-13/896` is likewise derived externally by an exact four-by-four
recurrence whose inputs are pinned to the `DATA_O4` source hash.  Lean checks
the emitted rational atom and `896 ∣ QTIGHT`; it does not re-run either
external derivation or connect it to a hash.  Those are provenance/physics
premises, not consequences of this arithmetic checker.
-/

namespace Workhouse.Rank3Order4QBoundCertificate

open Workhouse.DenominatorChecker

def qW2 : ℕ := 881280
def qR2 : ℕ := 409824214482575692800
def qHaar : ℕ := 87071293440000
def qBilinear : ℕ := 2
def qAnalytic : ℕ := 896

/-- `1/2` encoded as an already-reduced rational atom, so its denominator is
kernel-visible rather than dependent on simplification of field division. -/
def halfRat : ℚ := ⟨1, 2, by decide, by decide⟩

/-- `-13/896`, emitted by the external exact recurrence, encoded as an
already-reduced rational atom.  This definition does not re-run the recurrence. -/
def analyticRat : ℚ := ⟨-13, 896, by decide, by decide⟩

theorem halfRat_eq : halfRat = (1 : ℚ) / 2 := by
  rw [halfRat, Rat.mk_eq_divInt, Rat.divInt_eq_div]
  norm_num

theorem analyticRat_eq : analyticRat = (-13 : ℚ) / 896 := by
  rw [analyticRat, Rat.mk_eq_divInt, Rat.divInt_eq_div]
  norm_num

def qPair : ℕ := qBilinear * qW2 * qR2 * qHaar

def qTight : ℕ :=
  62895057857493885215590055852113920000000

def qPath : ℕ :=
  4302674844130269372677454153332635148085549843213189120000000

def pathQuotient : ℕ := 68410380572018343936

theorem qW2_factorization :
    qW2 = 2^7 * 3^4 * 5 * 17 := by
  norm_num [qW2]

theorem qR2_factorization :
    qR2 =
      2^10 * 3^4 * 5^2 * 7 * 11 * 13 * 17^2 * 19 * 23 * 29 * 31 * 37 * 47 := by
  norm_num [qR2]

theorem qHaar_factorization :
    qHaar = 2^18 * 3^12 * 5^4 := by
  norm_num [qHaar]

theorem qTight_factorization :
    qTight =
      2^36 * 3^20 * 5^7 * 7 * 11 * 13 * 17^3 * 19 * 23 * 29 * 31 * 37 * 47 := by
  norm_num [qTight]

theorem qPair_eq_qTight : qPair = qTight := by
  norm_num [qPair, qBilinear, qW2, qR2, qHaar, qTight]

theorem qPair_dvd_qTight : qPair ∣ qTight := by
  rw [qPair_eq_qTight]

theorem qAnalytic_dvd_qTight : qAnalytic ∣ qTight := by
  norm_num [qAnalytic, qTight]

theorem qTight_eq_lcm : Nat.lcm qAnalytic qPair = qTight := by
  rw [qPair_eq_qTight]
  exact Nat.lcm_eq_right qAnalytic_dvd_qTight

theorem pathQuotient_factorization :
    pathQuotient = 2^20 * 3^25 * 7 * 11 := by
  norm_num [pathQuotient]

theorem qPath_eq_qTight_mul_quotient :
    qPath = qTight * pathQuotient := by
  norm_num [qPath, qTight, pathQuotient]

theorem qTight_dvd_qPath : qTight ∣ qPath := by
  exact ⟨pathQuotient, qPath_eq_qTight_mul_quotient.symm⟩

theorem denominatorDivides_mono {Q R : ℕ} {x : ℚ}
    (hx : DenominatorDivides Q x) (hQR : Q ∣ R) :
    DenominatorDivides R x := by
  exact hx.trans hQR

theorem half_denominator :
    DenominatorDivides qBilinear halfRat := by
  simp [DenominatorDivides, halfRat, qBilinear]

theorem analytic_term_denominator :
    DenominatorDivides qTight analyticRat := by
  rw [DenominatorDivides]
  change 896 ∣ qTight
  simpa [qAnalytic] using qAnalytic_dvd_qTight

/-- Conditional arithmetic bridge for one external ledger term.  The three
component hypotheses are exactly what a generated external certificate must
supply; this theorem does not manufacture them from a ledger hash. -/
theorem pair_term_denominator_dvd_qTight
    (w2 r2 haar : ℚ)
    (hw2 : DenominatorDivides qW2 w2)
    (hr2 : DenominatorDivides qR2 r2)
    (hhaar : DenominatorDivides qHaar haar) :
    DenominatorDivides qTight (((halfRat * w2) * r2) * haar) := by
  have hpair : DenominatorDivides qPair (((halfRat * w2) * r2) * haar) :=
    ((half_denominator.mul hw2).mul hr2).mul hhaar
  exact denominatorDivides_mono hpair qPair_dvd_qTight

theorem denominatorDivides_list_sum_same (Q : ℕ) (xs : List ℚ)
    (h : ∀ x ∈ xs, DenominatorDivides Q x) :
    DenominatorDivides Q xs.sum := by
  induction xs with
  | nil => simp [DenominatorDivides]
  | cons x xs ih =>
      rw [List.sum_cons]
      have hx : DenominatorDivides Q x := h x (by simp)
      have hxs : DenominatorDivides Q xs.sum := ih (by
        intro y hy
        exact h y (by simp [hy]))
      simpa using hx.add hxs

/-- Conditional final assembly.  This proves denominator divisibility once the
external producer supplies the per-term certificates. -/
theorem assembled_denominator_dvd_qTight (terms : List ℚ)
    (hterms : ∀ term ∈ terms, DenominatorDivides qTight term) :
    DenominatorDivides qTight (analyticRat + terms.sum) := by
  have hsum := denominatorDivides_list_sum_same qTight terms hterms
  simpa using analytic_term_denominator.add hsum

end Workhouse.Rank3Order4QBoundCertificate

#print axioms Workhouse.Rank3Order4QBoundCertificate.qTight_factorization
#print axioms Workhouse.Rank3Order4QBoundCertificate.qTight_dvd_qPath
#print axioms Workhouse.Rank3Order4QBoundCertificate.pair_term_denominator_dvd_qTight
#print axioms Workhouse.Rank3Order4QBoundCertificate.assembled_denominator_dvd_qTight
