import Mathlib.Data.Int.ModEq
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Lemmas

/-!
# Denominator-localization certificate core

This file is deliberately generic in a declared prime set `S` and in supplied
natural-number denominator bounds.  It proves consequences of those inputs; it
does **not** prove that a physics manifest enumerated every primitive factor, or
that any proposed rank/order ceiling is complete.

The intended trust boundary is small:

* an external derivation emits exact rational atoms and positive bounds;
* each atom carries the check `atom.value.den ∣ atom.bound`;
* the expression checker composes those certificates through `+`, `-`, `*`,
  negation, and integer constants;
* a single theorem proves `eval e |>.den ∣ qBound e`;
* an external denominator-clearing/CRT ledger can then provide a combined
  congruence and a uniqueness window to the small CRT theorem below.

No corpus history, hashes, JSON parsing, perturbative reachability, or `Pmax`
conjecture is internalized here.
-/

namespace Workhouse.DenominatorChecker

/-! ## Prime-support localization -/

/-- Every prime divisor of `n` belongs to the declared finite set `S`. -/
def PrimeSupported (S : Finset ℕ) (n : ℕ) : Prop :=
  ∀ p : ℕ, p.Prime → p ∣ n → p ∈ S

/-- The reduced denominator of `x` uses only declared primes. -/
def AllowedDenominator (S : Finset ℕ) (x : ℚ) : Prop :=
  PrimeSupported S x.den

/-- The absolute reduced numerator of `x` uses only declared primes.

This is intentionally separate: inversion moves numerator primes into the
denominator, which is why division is not closed from denominator data alone.
-/
def AllowedNumerator (S : Finset ℕ) (x : ℚ) : Prop :=
  PrimeSupported S x.num.natAbs

theorem primeSupported_one (S : Finset ℕ) : PrimeSupported S 1 := by
  intro p hp hpd
  have hp1 : p = 1 := Nat.dvd_one.mp hpd
  exact (hp.ne_one hp1).elim

theorem primeSupported_of_dvd {S : Finset ℕ} {a b : ℕ}
    (hab : a ∣ b) (hb : PrimeSupported S b) : PrimeSupported S a := by
  intro p hp hpa
  exact hb p hp (hpa.trans hab)

theorem primeSupported_mul {S : Finset ℕ} {a b : ℕ}
    (ha : PrimeSupported S a) (hb : PrimeSupported S b) :
    PrimeSupported S (a * b) := by
  intro p hp hpab
  rcases hp.dvd_mul.mp hpab with hpa | hpb
  · exact ha p hp hpa
  · exact hb p hp hpb

theorem allowedDenominator_zero (S : Finset ℕ) : AllowedDenominator S 0 := by
  simpa [AllowedDenominator] using primeSupported_one S

theorem allowedDenominator_one (S : Finset ℕ) : AllowedDenominator S 1 := by
  simpa [AllowedDenominator] using primeSupported_one S

theorem allowedDenominator_int (S : Finset ℕ) (z : ℤ) :
    AllowedDenominator S (z : ℚ) := by
  simpa [AllowedDenominator] using primeSupported_one S

theorem AllowedDenominator.neg {S : Finset ℕ} {x : ℚ}
    (hx : AllowedDenominator S x) : AllowedDenominator S (-x) := by
  simpa [AllowedDenominator] using hx

theorem AllowedDenominator.add {S : Finset ℕ} {x y : ℚ}
    (hx : AllowedDenominator S x) (hy : AllowedDenominator S y) :
    AllowedDenominator S (x + y) := by
  apply primeSupported_of_dvd (Rat.add_den_dvd x y)
  exact primeSupported_mul hx hy

theorem AllowedDenominator.sub {S : Finset ℕ} {x y : ℚ}
    (hx : AllowedDenominator S x) (hy : AllowedDenominator S y) :
    AllowedDenominator S (x - y) := by
  apply primeSupported_of_dvd (Rat.sub_den_dvd x y)
  exact primeSupported_mul hx hy

theorem AllowedDenominator.mul {S : Finset ℕ} {x y : ℚ}
    (hx : AllowedDenominator S x) (hy : AllowedDenominator S y) :
    AllowedDenominator S (x * y) := by
  apply primeSupported_of_dvd (Rat.mul_den_dvd x y)
  exact primeSupported_mul hx hy

/-- Safe inversion requires support for the divisor's **numerator**. -/
theorem AllowedNumerator.inv_denominator {S : Finset ℕ} {x : ℚ}
    (hx : AllowedNumerator S x) : AllowedDenominator S x⁻¹ := by
  by_cases hzero : x.num = 0
  · simpa [AllowedDenominator, Rat.den_inv, hzero] using primeSupported_one S
  · simpa [AllowedDenominator, AllowedNumerator, Rat.den_inv, hzero] using hx

/-- Division exposes the numerator primes of the divisor. -/
theorem AllowedDenominator.div {S : Finset ℕ} {x y : ℚ}
    (hx : AllowedDenominator S x) (hy : AllowedNumerator S y) :
    AllowedDenominator S (x / y) := by
  rw [div_eq_mul_inv]
  exact hx.mul hy.inv_denominator

theorem allowedDenominator_list_sum (S : Finset ℕ) (xs : List ℚ)
    (h : ∀ x ∈ xs, AllowedDenominator S x) :
    AllowedDenominator S xs.sum := by
  induction xs with
  | nil => simpa using allowedDenominator_zero S
  | cons x xs ih =>
      rw [List.sum_cons]
      exact (h x (by simp)).add (ih (by
        intro y hy
        exact h y (by simp [hy])))

theorem allowedDenominator_list_prod (S : Finset ℕ) (xs : List ℚ)
    (h : ∀ x ∈ xs, AllowedDenominator S x) :
    AllowedDenominator S xs.prod := by
  induction xs with
  | nil => simpa using allowedDenominator_one S
  | cons x xs ih =>
      rw [List.prod_cons]
      exact (h x (by simp)).mul (ih (by
        intro y hy
        exact h y (by simp [hy])))

/-! ## Explicit `QBOUND` divisibility -/

/-- The reduced denominator of `x` divides the supplied bound `Q`. -/
def DenominatorDivides (Q : ℕ) (x : ℚ) : Prop := x.den ∣ Q

theorem denominatorDivides_int (z : ℤ) : DenominatorDivides 1 (z : ℚ) := by
  simp [DenominatorDivides]

theorem DenominatorDivides.neg {Q : ℕ} {x : ℚ}
    (hx : DenominatorDivides Q x) : DenominatorDivides Q (-x) := by
  simpa [DenominatorDivides] using hx

/-- Addition needs only the LCM of the two supplied bounds. -/
theorem DenominatorDivides.add {Qx Qy : ℕ} {x y : ℚ}
    (hx : DenominatorDivides Qx x) (hy : DenominatorDivides Qy y) :
    DenominatorDivides (Nat.lcm Qx Qy) (x + y) := by
  have hx' : x.den ∣ Nat.lcm Qx Qy := hx.trans (Nat.dvd_lcm_left Qx Qy)
  have hy' : y.den ∣ Nat.lcm Qx Qy := hy.trans (Nat.dvd_lcm_right Qx Qy)
  exact (Rat.add_den_dvd_lcm x y).trans (Nat.lcm_dvd hx' hy')

/-- Subtraction needs only the LCM of the two supplied bounds. -/
theorem DenominatorDivides.sub {Qx Qy : ℕ} {x y : ℚ}
    (hx : DenominatorDivides Qx x) (hy : DenominatorDivides Qy y) :
    DenominatorDivides (Nat.lcm Qx Qy) (x - y) := by
  have hx' : x.den ∣ Nat.lcm Qx Qy := hx.trans (Nat.dvd_lcm_left Qx Qy)
  have hy' : y.den ∣ Nat.lcm Qx Qy := hy.trans (Nat.dvd_lcm_right Qx Qy)
  exact (Rat.sub_den_dvd_lcm x y).trans (Nat.lcm_dvd hx' hy')

/-- Multiplication uses the product of the two supplied bounds. -/
theorem DenominatorDivides.mul {Qx Qy : ℕ} {x y : ℚ}
    (hx : DenominatorDivides Qx x) (hy : DenominatorDivides Qy y) :
    DenominatorDivides (Qx * Qy) (x * y) := by
  exact (Rat.mul_den_dvd x y).trans (Nat.mul_dvd_mul hx hy)

/-- A typed exact atom.  `bound_pos` rules out the vacuous bound `0`. -/
structure CertifiedAtom where
  value : ℚ
  bound : ℕ
  bound_pos : 0 < bound
  denominator_dvd : DenominatorDivides bound value

/-- A small exact-expression language for generated certificates. -/
inductive ExactExpr where
  | atom (a : CertifiedAtom)
  | integer (z : ℤ)
  | neg (e : ExactExpr)
  | add (left right : ExactExpr)
  | sub (left right : ExactExpr)
  | mul (left right : ExactExpr)

namespace ExactExpr

def eval : ExactExpr → ℚ
  | .atom a => a.value
  | .integer z => z
  | .neg e => -eval e
  | .add left right => eval left + eval right
  | .sub left right => eval left - eval right
  | .mul left right => eval left * eval right

/-- The compositional denominator bound: LCM for additive nodes, product for
multiplicative nodes. -/
def qBound : ExactExpr → ℕ
  | .atom a => a.bound
  | .integer _ => 1
  | .neg e => qBound e
  | .add left right => Nat.lcm (qBound left) (qBound right)
  | .sub left right => Nat.lcm (qBound left) (qBound right)
  | .mul left right => qBound left * qBound right

theorem qBound_pos (e : ExactExpr) : 0 < e.qBound := by
  induction e with
  | atom a => exact a.bound_pos
  | integer z => simp [qBound]
  | neg e ih => simpa [qBound] using ih
  | add left right ihLeft ihRight =>
      simpa [qBound] using Nat.lcm_pos ihLeft ihRight
  | sub left right ihLeft ihRight =>
      simpa [qBound] using Nat.lcm_pos ihLeft ihRight
  | mul left right ihLeft ihRight =>
      simpa [qBound] using Nat.mul_pos ihLeft ihRight

/-- The main checker theorem.  Every expression assembled from certified atoms
has a reduced denominator dividing its computed `QBOUND`. -/
theorem denominator_dvd_qBound (e : ExactExpr) :
    DenominatorDivides e.qBound e.eval := by
  induction e with
  | atom a => exact a.denominator_dvd
  | integer z => exact denominatorDivides_int z
  | neg e ih => exact ih.neg
  | add left right ihLeft ihRight => exact ihLeft.add ihRight
  | sub left right ihLeft ihRight => exact ihLeft.sub ihRight
  | mul left right ihLeft ihRight => exact ihLeft.mul ihRight

/-- Any prime-support claim proved for the supplied `QBOUND` transfers to the
actual reduced denominator.  This still does not prove the supplied bound is a
complete physical one. -/
theorem eval_primeSupported {S : Finset ℕ} (e : ExactExpr)
    (hQ : PrimeSupported S e.qBound) : AllowedDenominator S e.eval := by
  exact primeSupported_of_dvd e.denominator_dvd_qBound hQ

end ExactExpr

/-! ## CRT uniqueness checker

The external process may use any number of pairwise-coprime moduli and keep a
large, hashed residue ledger.  Lean's small interface starts only after that
process supplies a combined modulus congruence. -/

/-- Two integers congruent modulo `M` are equal when their difference lies in a
strict centered uniqueness window smaller than `|M|`. -/
theorem crt_unique_centered {M a b : ℤ}
    (hmod : a ≡ b [ZMOD M])
    (hsmall : (b - a).natAbs < M.natAbs) : a = b := by
  have hzero : b - a = 0 :=
    Int.eq_zero_of_dvd_of_natAbs_lt_natAbs hmod.dvd hsmall
  exact (sub_eq_zero.mp hzero).symm

end Workhouse.DenominatorChecker

#print axioms Workhouse.DenominatorChecker.ExactExpr.denominator_dvd_qBound
#print axioms Workhouse.DenominatorChecker.crt_unique_centered
