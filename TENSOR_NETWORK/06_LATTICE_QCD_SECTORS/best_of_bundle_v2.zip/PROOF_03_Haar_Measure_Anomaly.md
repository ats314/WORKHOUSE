<!--
GPT-5.1 CLEANED & UNIFIED
Source: MASTER_9602047v1.md
Date: 2025-12-07T15:44:40.551649
Model: gpt-5.1 (High Reasoning)
-->

# Emergence of the Haar measure in the standard functional integral representation of the Yang-Mills partition function

**H. Reinhardt\***  
Institut für Theoretische Physik, Universität Tübingen  
Auf der Morgenstelle 14, D-72076 Tübingen, Germany\†  

and  

Center for Theoretical Physics  
Laboratory for Nuclear Science  
and Department of Physics  
Massachusetts Institute of Technology  
Cambridge, Massachusetts 02139, USA  

\* Supported by DFG Re 856/1-3  
\† permanent address  

---

## Abstract

The conventional path integral expression for the Yang-Mills transition amplitude with flat measure and gauge-fixing built in via the Faddeev-Popov method has been claimed to fall short of guaranteeing gauge invariance in the non-perturbative regime. We show, however, that it yields the gauge invariant partition function where the projection onto gauge invariant wave functions is explicitly performed by integrating over the compact gauge group. In a variant of maximal Abelian gauge the Haar measure arises in the conventional Yang-Mills path integral from the Faddeev-Popov determinant.

---

## 1. Introduction

The importance of gauge invariance for confinement is generally accepted. Several approaches have been proposed which explicitly resolve Gauss’ law to obtain a gauge invariant description either directly in terms of gauge invariant variables [1] or at least in unconstrained variables [2]. It has been argued that the conventional path-integral expression for quantizing $SU(N)$ Yang-Mills theory [3] falls short of guaranteeing gauge invariance in the non-perturbative regime [4]. One has therefore constructed alternative path integral representations of the Yang-Mills transition amplitude where gauge invariance is guaranteed by explicitly projecting the external states on gauge invariant states [5, 6]. Projection onto gauge invariant states basically means integration over the compact gauge group with the corresponding Haar measure. It is the apparent absence of the Haar measure in the conventional functional integral representation which has been the main subject of criticism [4, 5].

In this note we show for the partition function that the conventional functional integral representation with the gauge fixed by the Faddeev-Popov method fully respects the gauge invariance and is therefore also applicable in the non-perturbative regime. In particular we show that the invariant (Haar) measure of the gauge group is, in fact, contained in the conventional path integral representation and explicitly arises in certain gauges in the form of the Faddeev-Popov determinant.

To make the paper self-contained and to fix our notation we have first to summarize some well known facts and put them in the appropriate context.

---

## 2. The Yang-Mills transition amplitude

We consider Euclidean Yang-Mills theory with gauge group $G = SU(N)$. In the Weyl gauge $A_0^a(x) = 0$ the dynamical degrees of freedom (coordinates) are the vector potentials $A_i^a(x)$, and the Hamilton operator is defined by
$$
H = \int d^3x \left[ \frac{g^2}{2} E_i^a(x) E_i^a(x)
+ \frac{1}{2g^2} B_i^a(x) B_i^a(x) \right].
\tag{1}
$$
Here the electric field
$$
E_i^a(x) = -\,i \frac{\delta}{\delta A_i^a(x)}
$$
represents the canonical momentum conjugate to $A_i^a(x)$ and
$$
B_i^a(x) = \frac{1}{2}\,\epsilon_{ijk}
\left( \partial_j A_k^a(x) - \partial_k A_j^a(x)
+ f^{abc} A_j^b(x) A_k^c(x) \right)
$$
is the magnetic field. Furthermore $f^{abc}$ is the structure constant of the gauge group and $g$ denotes the bare coupling constant. We also define the matrix-valued fields
$$
A_\mu(x) = A_\mu^a(x) T^a
$$
with $T^a$ being the anti-hermitian generators of the gauge group satisfying
$$
[T^a, T^b] = f^{abc} T^c.
$$

Let $|C\rangle$ denote an eigenstate of $\hat A_i(x)$, i.e.
$$
\hat A_i(x)\,|C\rangle = C_i(x)\,|C\rangle,
\tag{2}
$$
with some classical field function $C_i(x)$, so that each wave functional $\Psi_k(C)$ can be expressed as
$$
\Psi_k(C) = \langle C | k \rangle.
$$
The quantity of interest is the quantum transition amplitude $\langle C' | e^{-HT} | C \rangle$.

Due to the gauge invariance of $H$ the transition amplitude is invariant under simultaneous gauge transformations $\Omega(\vec x)$ of initial and final field configurations:
$$
\langle C'^{\Omega} | e^{-HT} | C^{\Omega} \rangle
= \langle C' | e^{-HT} | C \rangle,
\tag{3}
$$
where
$$
C_i^\Omega = \Omega C_i \Omega^\dagger + \Omega \partial_i \Omega^\dagger,
\qquad \Omega \in G
\tag{4}
$$
denotes the gauge transform of $C_i(x)$. But the transition amplitude is not invariant under a separate (independent) gauge transformation of one of the external fields.

The gauge invariant transition amplitude of Yang-Mills theory is obtained by projecting the external states onto gauge invariant states [5, 6]:
$$
Z[C', C] = \langle C' | e^{-HT} P | C \rangle,
\tag{5}
$$
where the projector is defined by
$$
P | C \rangle
= \sum_n e^{-in\Theta} \int_G D\mu(\Omega_n)\,|C^{\Omega_n}\rangle.
\tag{6}
$$
Here $\Theta$ is the vacuum angle [7, 8], and the functional integration with respect to the invariant (Haar) measure of the gauge group, $D\mu(\Omega)$, extends over all time-independent gauge transformations $\Omega_n(\vec x)$ with winding number $n$.

For a gauge transformation $\Omega(x)$ the winding number is defined by
$$
n[\Omega] = \frac{1}{24\pi^2} \int d^3x\,\epsilon_{ijk}\,
\operatorname{tr}(L_i L_j L_k),
\qquad
L_k = \Omega \partial_k \Omega^\dagger.
\tag{7}
$$
As usual we assume here that the gauge function $\Omega(\vec x)$ approaches a unique value $\Omega_\infty$ for $|\vec x| \to \infty$ so that $\mathbb{R}^3$ can be compactified to $S^3$ and $n[\Omega]$ is a topological invariant. For simplicity we will choose $\Omega_\infty = 1$.

At each $\vec x$ the gauge functions $\Omega_n(\vec x)\in G$ can be diagonalized, which yields the Cartan decomposition
$$
\Omega_n(\vec x) = V_n^\dagger(\vec x)\,\omega_n(\vec x)\,V_n(\vec x),
\tag{8}
$$
where $\omega_n(\vec x)$ is a diagonal unitary matrix living in the Cartan subgroup (invariant torus) $H = U(1)^{N-1}$ and $V_n(\vec x)$ lives in the corresponding coset $G/H$. Note that this representation is unique only up to space-dependent Abelian gauge transformations $v(\vec x)$,
$$
V_n(\vec x) \to v(\vec x)\,V_n(\vec x).
$$
More precisely, $v(x)$ is an element of the so-called normalizer $N$ of $H$ in $G$, and $N/H = W$ is the Weyl group, which for $G = SU(N)$ is given by the group of permutations of $N$ elements, $S_N$ [10].

The integration over the gauge group can then be expressed by the Weyl formula [10]:
$$
\int_G d\mu(\Omega_n)\,f(\Omega_n)
= \frac{1}{|W|} \int_H d\bar\mu(\omega_n)
\int_{G/H} dV\, f\!\big(V_n^\dagger \omega_n V_n\big),
\tag{9}
$$
where $|W|$ is the order of the Weyl group ($|W| = N!$ for $G=SU(N)$) and the reduced Haar measure $\bar\mu(\omega)$ is defined by [9]
$$
d\bar\mu(\omega)
= \prod_k d\lambda_k\;
\delta\!\left(\sum_i \lambda_i - 2\pi p\right)
\prod_{i<j} \sin^2\left(\frac{\lambda_i - \lambda_j}{2}\right).
\tag{10}
$$
Here $e^{i\lambda_k}$ denotes the eigenvalue of $\omega$, i.e. $i\lambda_k$ denotes the eigenvalue of $\ln\omega$ (the $\lambda_k$ are real), and $p$ is an integer.

Let us also mention that the diagonalization (8), which is possible pointwise, cannot be done smoothly and globally due to topological obstructions, i.e. in general for an arbitrary $\Omega_n$ there is no globally defined smooth $V_n(x)$. As a consequence, when the Weyl formula (9) is applied to functional integrals the summation over the different topological sectors has to be included. We will return to this point later.

Of particular interest is the partition function
$$
Z = \int \mathcal{D}C_i\; \langle C | e^{-HT} P | C \rangle,
\tag{11}
$$
which upon using the completeness of eigenstates $|k\rangle$ of $H$, $H|k\rangle = E_k |k\rangle$ and $P^2 = P$ can be written as
$$
Z = \sum_k \int \mathcal{D}C_i\;
\tilde\Psi_k(C)\,e^{-E_k T}\,\tilde\Psi_k^*(C).
\tag{12}
$$
Here
$$
\tilde\Psi_k(C) = \langle C | P | k \rangle
\tag{13}
$$
are the gauge “invariant” energy eigenfunctionals (i.e. the gauge invariant eigenstates of $H$ in the “coordinate” representation), which have been assumed to be properly normalized:
$$
\int \mathcal{D}C_i\;\tilde\Psi_k^*(C)\,\tilde\Psi_l(C)
= \delta_{kl}.
\tag{14}
$$
It is then seen that eq. (12) reduces, in fact, to the standard form of the partition function
$$
Z = \sum_k e^{-E_k T}.
\tag{15}
$$

Let us also mention that the wave functionals (13) are invariant only under “small” gauge transformations (with zero winding number). For a “large” gauge transformation $\Omega_n$ with winding number $n$ they transform as
$$
\tilde\Psi_k(C^{\Omega_n}) = e^{-in\Theta}\,\tilde\Psi_k(C)
\tag{16}
$$
as can be inferred from (13) using the explicit form of $P$ (6).

Using the Cartan decomposition (9) for the group integration in $P$ (6) the partition function (11) becomes
$$
Z = \sum_n e^{-in\Theta} \int_H D\bar\mu(\omega_n)
\int_{G/H} DV_n \int \mathcal{D}C_i\;
\langle C | e^{-HT} | C^{V_n^\dagger \omega_n V_n} \rangle.
\tag{17}
$$
Using further the invariance of $H$ under gauge transformations (see eq. (3))
$$
\langle C | e^{-HT} | C^{V_n^\dagger \omega_n V_n} \rangle
= \langle C^{V_n} | e^{-HT} | C^{V_n \omega_n} \rangle
\tag{18}
$$
and changing the integration variable $C_i \to C_i^{V_n}$, for which $\mathcal{D}C_i = \mathcal{D}C_i^{V_n}$, the integration over the coset $DV_n$ becomes trivial, yielding an irrelevant constant, and we obtain
$$
Z = \text{const}\;\sum_n e^{-in\Theta}
\int_H D\bar\mu(\omega_n)\int \mathcal{D}C_i\;
\langle C | e^{-HT} | C^{\omega_n} \rangle.
\tag{19}
$$

---

## 3. Path integral representation of the Yang-Mills amplitude

Following the standard procedure [11] one derives the following functional integral representation of the transition amplitude:
$$
\langle C' | e^{-HT} | C \rangle
= \int_{A_i(0,\vec x)=C_i(\vec x)}^{A_i(T,\vec x)=C_i'(\vec x)}
\mathcal{D}A_i(x)\;e^{-S_{\text{YM}}[A_0=0,A_i]},
\tag{20}
$$
where the functional integration is performed over all classical field configurations $A_i(x)$ satisfying the boundary conditions
$$
A_i(x_0 = 0,\vec x) = C_i(\vec x),
\qquad
A_i(x_0 = T,\vec x) = C_i'(\vec x)
\tag{21}
$$
and
$$
S_{\text{YM}}[A_0,A_i]
= \frac{1}{4g^2} \int d^4x\;F_{\mu\nu}^a(x)F_{\mu\nu}^a(x)
\tag{22}
$$
is the standard Yang-Mills action with
$$
F_{\mu\nu}^a
= \partial_\mu A_\nu^a - \partial_\nu A_\mu^a
+ f^{abc}A_\mu^b A_\nu^c
\tag{23}
$$
being the field strength.

Inserting (20) into (5) we obtain
$$
Z[C',C] = \sum_n e^{-in\Theta}\int_G D\mu(\Omega_n)
\int_{A_i(0)=C_i^{\Omega_n}}^{A_i(T)=C_i'}\mathcal{D}A_i(x)\;
e^{-S_{\text{YM}}[A_0=0,A_i]}.
\tag{24}
$$

For the following it is convenient to introduce the Pontryagin index (topological charge)
$$
\nu[A] = -\frac{1}{16\pi^2} \int d^4x\;\operatorname{tr}\big(F_{\mu\nu}\tilde F_{\mu\nu}\big),
\tag{25}
$$
where
$$
\tilde F_{\mu\nu} = \frac{1}{2}\epsilon_{\mu\nu\kappa\lambda}F_{\kappa\lambda}
$$
is the dual field strength. In the $A_0 = 0$ gauge this quantity is related to the Chern-Simons action
$$
S_{\text{CS}}[A]
= -\frac{1}{8\pi^2}\int d^3x\;\epsilon_{ijk}\;
\operatorname{tr}\left(
A_i \partial_j A_k + \frac{2}{3} A_i A_j A_k
\right)
\tag{26}
$$
of the temporal boundary values of the spatial gauge fields $A_i(x_0 = 0) = C_i^{\Omega_n} \equiv C_i''$, $A_i(x_0 = T) = C_i'$ by [6]
$$
\nu[A_0 = 0, A_i] = S_{\text{CS}}[C_i'] - S_{\text{CS}}[C_i''].
\tag{27}
$$
Furthermore, under gauge transformation $\Omega$ the Chern-Simons action transforms as [8]
$$
S_{\text{CS}}[A_i^\Omega] = S_{\text{CS}}[A_i] + n[\Omega].
\tag{28}
$$
Therefore the winding number $n = n[\Omega_n]$ (7) in (24) can be expressed as
$$
n = n[\Omega_n]
= S_{\text{CS}}[C_i'] - S_{\text{CS}}[C_i]
- \nu[A_0 = 0, A_i].
\tag{29}
$$
This representation of $n[\Omega]$ is convenient since the first two terms on the right-hand side depend only on the externally given boundary fields while the last term is gauge invariant.

Let us now remove the gauge function $\Omega_n$ from the boundary field
$$
A_i(x_0=0,\vec x) = C_i^{\Omega_n}(\vec x)
$$
in eq. (24) by performing the following time-dependent gauge transformation
$$
U(x) = \Omega_n^{\,x_0/T}.
\tag{30}
$$
Using the gauge invariance of $S_{\text{YM}}[A]$ and $\nu[A]$ we find after a change of integration variables $A_\mu \to A_\mu^U$
$$
\begin{aligned}
Z[C',C]
&= \exp\left[-i\Theta\big(S_{\text{CS}}[C_i'] - S_{\text{CS}}[C_i]\big)\right] \\
&\quad\times \sum_n \int D\mu(\Omega_n)
\int_{A_i(0)=C_i}^{A_i(T)=C_i'}
\mathcal{D}A_i\;
\exp\big(-S_{\text{YM}}[A_0,A_i] + i\Theta\nu[A_0,A_i]\big),
\end{aligned}
\tag{31}
$$
where a time-independent temporal gauge potential
$$
A_0 = -\frac{1}{T}\ln\Omega_n
\tag{32}
$$
has been induced by the gauge transformation (30) and the functional integration is now performed with the boundary conditions $A_i(x_0=0,\vec x) = C_i(\vec x)$, $A_i(x_0=T,\vec x) = C_i'(\vec x)$.

Note that the winding number of the original gauge function $\Omega_n(\vec x)$ is now encoded in the temporal gauge potential (32). By integrating over all possible (time-independent) field configurations $A_0(\vec x)$ compatible with the boundary condition $\Omega_n(|\vec x|\to\infty)=1$, i.e.[^1]
$$
A_0(|\vec x|\to\infty) = 2\pi p\, i, \qquad p \in \mathbb{Z},
$$
we will automatically include the summation over all winding numbers $n$. We will henceforth omit this sum and understand that it is included in the (functional) integral over $A_0(\vec x)$.[^2]

For the partition function (19) we obtain from (31) the representation
$$
Z_\Theta = \int D\bar\mu(\omega)
\int_{\text{periodic b.c.}} \mathcal{D}A_i(x)\;
\exp\big(-S_{\text{YM}}[A_0,A_i] + i\Theta\nu[A_0,A_i]\big),
\tag{33}
$$
where the induced temporal gauge potential
$$
A_0 = -\frac{1}{T}\ln\omega \in H
\tag{34}
$$
is now diagonal, i.e. lives in the Cartan subalgebra, and the functional integration runs over periodic spatial fields
$$
A_i(x_0=T,\vec x) = A_i(x_0=0,\vec x).
$$

Eq. (33) should be compared with the standard representation of the Yang-Mills partition function, which is used for finite temperature QCD considerations [12]:
$$
Z_\Theta = \int_{\text{periodic b.c.}} \mathcal{D}A_\mu\;
\delta_{\text{gf.}}(A)\;
\exp\big(-S_{\text{YM}}[A] + i\Theta\nu[A]\big).
\tag{35}
$$
Here the integration is over all temporally periodic field configurations
$$
A_\mu(x_0=T,\vec x) = A_\mu(x_0=0,\vec x)
\tag{36}
$$
and $\delta_{\text{gf.}}(A) = \delta(\chi(A))\det M$ denotes the gauge-fixing according to the Faddeev-Popov method with $\chi(A) = 0$ being the gauge condition and $\det M$ the corresponding Faddeev-Popov determinant.

Eq. (33) is “almost” the standard representation (35) except for the presence of the invariant Haar measure for $A_0$ in (33). Furthermore $A_0$ is diagonal and time-independent in (33) but time-dependent in (35)[^3] and there is no explicit gauge fixing included in (33).

In refs. [4, 5] the importance of the Haar measure was emphasized, which ensures gauge invariance and (in the presence of quarks) center symmetry. (The latter leads naturally to quark confinement [5].) It is usually argued that the use of the flat integration measure is justified only for perturbation theory since the Haar measure reduces to the flat measure near $A_0 = 0$. We will now show, however, that for the partition function both representations (33) and (35) are completely equivalent, even in the non-perturbative regime.

---

## 4. Equivalence proof

To reduce (35) to (33) (which uses a time-independent $A_0$) we choose the gauge
$$
\partial_0 A_0 = 0,
\tag{37}
$$
which is compatible with the periodic boundary condition (36). This constraint still allows for time-independent gauge transformations $V(\vec x)$, under which $A_0$ in (35) transforms homogeneously:
$$
A_0(\vec x) \;\longrightarrow\; A_0^V(\vec x)
= V(\vec x) A_0(\vec x) V^\dagger(\vec x).
\tag{38}
$$
Therefore this residual gauge freedom can be exploited to diagonalize $A_0(\vec x)$, which implies the gauge condition
$$
A_0^{\text{ch}}(\vec x) = 0,
\tag{39}
$$
where $A_0^{\text{ch}}$ is the off-diagonal (charged) part of $A_0$. Again, the diagonalization can be done pointwise but in general not globally and smoothly due to topological obstructions. We face here the same problem for the Lie algebra as we observed in the Cartan decomposition of the gauge group (see the discussion following eq. (8)).

At certain points $\vec x = \vec x_S$ in space the field $A_0(\vec x)$ is degenerate (i.e. two eigenvalues coincide) such that the unitary matrix $V(x)\in G$ in (38) necessary to make $A_0^V(\vec x)$ diagonal is not well defined, i.e. at these points the constraint (39) does not fix the gauge uniquely. (For $G = SU(2)$ the degeneracy points are those where the gauge function $A_0(x)$ vanishes.)

The physical meaning of these degeneracy points is easily understood by observing that eqs. (37), (39) are a variant of maximal Abelian gauge [13]. Therefore, by following ’t Hooft’s arguments [13] one easily shows that the degeneracy points $\vec x = \vec x_S$ are the positions of magnetic monopoles in the spatial gauge potential $A_i(x)$. In fact, under a space-dependent gauge transformation
$$
A_i^V = V A_i V^\dagger + V \partial_i V^\dagger.
\tag{40}
$$
In the vicinity of a degeneracy point $\vec x = \vec x_S$ of $A_0(\vec x)$, the structure of $V(x)$ is such that the Abelian part of the inhomogeneous term $V\partial_i V^\dagger$ develops a magnetic monopole at $\vec x = \vec x_S$.

The gauge conditions (37) and (39) still remain invariant under time-independent Abelian gauge transformations. To prove the equivalence between (33) and (35) we need not fix this residual gauge since the same residual gauge freedom is also present in eq. (33).[^4]

Note also that for the charged part $A_0^{\text{ch}}$ the condition (37) is already included in (39), so we have to implement (37) only for the neutral (diagonal) part $A_0^n$ of $A_0$, which lives in the Cartan subgroup $(U(1))^{N-1}$. Therefore our gauge conditions read
$$
\chi_0^{a_0}(x) = \partial_0 A_0^{a_0}(x) = 0,
\tag{42}
$$
$$
\chi_0^{\bar a}(x) = A_0^{\bar a}(x) = 0.
\tag{43}
$$
Here and in the following we use the indices $a = a_0$ and $a = \bar a$ for diagonal and off-diagonal generators, respectively.

The gauge fixing constraints (42) and (43) give rise to a Faddeev-Popov kernel
$$
\begin{aligned}
M^{a_0 b_0}(x,y)
&= \hat D_0^{a_0 b_0}(x)\,\partial_{0,y}\,\delta^{(4)}(x-y),\\[0.3em]
M^{\bar a \bar b}(x,y)
&= \hat D_0^{\bar a \bar b}(x)\,\delta^{(4)}(x-y),
\end{aligned}
\tag{44}
$$
where
$$
\hat D_\mu = \partial_\mu + \hat A_\mu,
\qquad
\hat A_\mu = A_\mu^a \hat T^a
\tag{45}
$$
is the covariant derivative with $\hat T^a$ being the generators in the adjoint representation,
$$
(\hat T^a)_{bc} = -f^{abc}.
$$
Using $f^{a b_0 c_0}=0$, for gauge configurations satisfying the gauge constraints (42), (43) the Faddeev-Popov kernel reduces to
$$
M^{ab} \equiv
\begin{pmatrix}
M^{a_0 b_0} & M^{a_0 \bar b}\\[0.3em]
M^{\bar a b_0} & M^{\bar a \bar b}
\end{pmatrix}
=
\begin{pmatrix}
-\delta^{a_0 b_0}\,\partial_{0,x}^2\,\delta^{(4)}(x-y) & 0\\[0.3em]
0 & \hat D_0^{\bar a \bar b}(x)\,\delta^{(4)}(x-y)
\end{pmatrix}.
\tag{46}
$$
Since this matrix is block-diagonal we find for the Faddeev-Popov determinant
$$
\det M
= \text{const}\;\det\Big[\hat D_0^{\bar a \bar b}(x)\,\delta^{(4)}(x-y)\Big],
\tag{47}
$$
where the irrelevant constant arises from the Cartan subgroup (upper left block in (46)).

Due to the adopted gauge, eqs. (37) and (39), the eigenvalue equation
$$
i\hat D_0^{\bar a \bar b} \phi_n^{\bar b}
\equiv \big(i\partial_0\,\delta^{\bar a \bar b}
+ \hat A_0^{\bar a \bar b}(\vec x)\big)\,\phi_n^{\bar b}
= \mu_n(\vec x)\,\phi_n^{\bar a}
\tag{48}
$$
is easily solved. In the fundamental representation
$$
\phi = \phi^{\bar a} T^{\bar a},\qquad
T^a = -\,\frac{i}{2}\lambda^a,
$$
this equation reads
$$
i\partial_0 \phi + [iA_0(\vec x),\phi] = \mu \phi,
\qquad
A_0 = A_0^{c_0} T^{c_0}.
\tag{49}
$$
Adopting the Weyl basis, in which the index $\bar c$ for the off-diagonal generator $T^{\bar c}$ is expressed by the two respective indices $(k,l)$ of the fundamental representation for which $T^{\bar c} = T^{kl}$ with $(T^{kl})_{mn} \neq 0$ only for $(m,n)=(k,l)$ or $(l,k)$, i.e. $\bar c=(k,l)$, the eigenvalues are given for the temporally periodic boundary condition (36) by
$$
\mu_{n,\bar c}(\vec x)
= \omega_n + i\big[(A_0(\vec x))_{kk} - (A_0(\vec x))_{ll}\big],
\qquad
\omega_n = \frac{2\pi n}{T},
\tag{50}
$$
with $n\in\mathbb{Z}$.

Using
$$
\sin x = x \prod_{n=1}^{\infty}
\left(1 - \frac{x^2}{\pi^2 n^2}\right)
\tag{51}
$$
straightforward evaluation yields
$$
\det M
= \text{const}\;\prod_{n=-\infty}^{\infty}\prod_{k\neq l}\mu_{n,(k,l)}
= \text{const}\;\prod_{k>l}
\sin^2\!\left[
\frac{T}{2}\big((iA_0)_{kk} - (iA_0)_{ll}\big)
\right].
\tag{52}
$$

Taking into account that by definition of $A_0$ (34) the integration over $A_0$ extends from $-\infty$ to $\infty$ and furthermore $\operatorname{tr} A_0 = \sum_k (A_0)_{kk} = i2\pi n$, $n = 0, \pm1, \dots$, the Faddeev-Popov determinant (52) gives precisely the (reduced) Haar measure (10). Therefore in the gauges (37), (39) we have
$$
\int \mathcal{D}A_0\;\delta(\chi)\,\det M\;\cdots
= \int d\bar\mu(\omega)\;\cdots,
\qquad
\omega = e^{-T A_0}\in H,
\tag{53}
$$
which shows that in this gauge the functional integral representation (35) coincides with the representation (33). Furthermore, the usual functional integral representation (35) is invariant under a change of the gauge condition. Therefore, if eq. (35) reproduces the invariant partition function (33) in one gauge it does so in any gauge.

One may argue here that the Haar measure escapes in the gauge $A_0 = 0$. However, the gauge condition $A_0 = 0$ conflicts with the periodic boundary condition (36). This can be easily seen by considering the Polyakov line operator
$$
L_0(x) = \mathcal{P}\exp\left(\int_{x_0}^{x_0+T} dx_0'\,A_0(x_0',\vec x)\right),
\tag{54}
$$
where $\mathcal{P}$ denotes path ordering and the integration runs from a point $x = (x_0,\vec x)$ along the $0$-axis to the point $x=(x_0+T,\vec x)$. Due to the periodic boundary condition on $A_0$ the integration in (54) runs over a closed loop but nevertheless, due to the path-ordering, $L_0(x)$ depends on the starting point $x$. Under gauge transformation this quantity transforms as
$$
L_0(x) \;\longrightarrow\; L_0^\Omega(x)
= \Omega(x) L_0(x) \Omega^\dagger(x)
\tag{55}
$$
and one can obviously choose a gauge in which $L_0(x)$ is diagonal:
$$
L_0^\Omega(x) = e^{a_0(x)T},\qquad
a_0(x) = a_0^{c_0}(x) T^{c_0}.
\tag{56}
$$
But it is impossible to gauge transform $L_0(x)$ to $L_0(x)\equiv 1$.[^5]

To summarize we have shown that the usual functional integral representation with flat integration measure and the gauge fixed by the Faddeev-Popov method yields the proper gauge invariant partition function and is hence not restricted to the perturbative regime contrary to what is commonly believed. In certain gauges the compact integration measure of the gauge group arises directly from the Faddeev-Popov determinant.

Finally let me comment on the degeneracy points of the field $A_0(\vec x)$, where the maximal Abelian gauge (39) is not well defined and monopoles arise in $A_i(x)$. At these points two of the eigenvalues $(A_0(\vec x))_{kk}$ coincide and, consequently, the Faddeev-Popov determinant (52) vanishes, as usual when the gauge is not unique. The field configurations of vanishing Faddeev-Popov determinant define the Gribov horizon. We may thus conclude that in this context the Gribov horizon is built up from monopole configurations.

---

## Acknowledgements

This work was largely performed during a visit at MIT. The author thanks the colleagues of the Center for Theoretical Physics, in particular K. Johnson, for many interesting discussions and also for the hospitality extended to him. He also acknowledges discussions with M. Quandt.

---

## References

1. K. Johnson, “The Yang-Mills Ground State”, in *QCD - 20 Years Later*, Aachen, June 1992.  
   D.Z. Freedman, P.E. Haagensen, K. Johnson and J.I. Latorre, Nucl. Phys.  
   P.E. Haagensen and K. Johnson, Nucl. Phys. B439 (1995) 597.  
   M. Bauer, D.Z. Freedman and P.E. Haagensen, Nucl. Phys. B428 (1994) 147.

2. J. Goldstone and R. Jackiw, Phys. Lett. B74 (1978) 81.  
   V. Baluni and B. Grossman, Phys. Lett. B78 (1978) 226.  
   A.G. Izergin et al., Theor. Math. Phys. 38 (1979) 3.  
   Yu. A. Simonov, Sov. J. Nucl. Phys. 41 (1985) 835, 1014.  
   F. Lenz, H.W.L. Naus and M. Thies, Ann. Phys. 233 (1994) 314.  
   N.H. Christ and T.D. Lee, Phys. Rev. D22 (1980) 939.  
   J. Gervais and B. Sakita, Phys. Rev. D18 (1978) 453.  
   M. Creutz, I.J. Muzinich and T.N. Tudron, Phys. Rev. D19 (1979) 531.

3. C. Itzykson and J.-B. Zuber, *Quantum Field Theory*, McGraw-Hill, 1980.

4. G.C. Rossi and M. Testa, Nucl. Phys. B163 (1980) 109, B179 (1980) 477.  
   J. Polonyi, Phys. Lett. B213 (1988) 340.

5. K. Johnson, L. Lellouch and J. Polonyi, Nucl. Phys. B367 (1991) 675.

6. M. Lüscher, R. Narayanan, P. Weisz and U. Wolff, Nucl. Phys. B384 (1992) 168.

7. R. Jackiw and C. Rebbi, Phys. Rev. Lett. 37 (1976) 172.  
   C.G. Callan, R.F. Dashen and D.J. Gross, Phys. Lett. B63 (1976) 334.

8. R. Jackiw, Rev. Mod. Phys. 52 (1978) 661.

9. H. Weyl, *The Classical Groups*, Princeton University Press, Princeton, NJ, 1973.

10. T. Bröcker and T. tom Dieck, *Representations of Compact Lie Groups*, Springer
    Graduate Texts in Mathematics, New York, 1985.

11. R. Feynman and A. Hibbs, *Quantum Mechanics and Path Integrals*, McGraw-Hill,
    New York, 1965.

12. D.J. Gross, R.D. Pisarski and L.G. Yaffe, Rev. Mod. Phys. 53 (1981) 43.

13. G. ’t Hooft, Nucl. Phys. B190 (1981) 455.

---

[^1]: Without loss of generality we can restrict ourselves to a single Riemann sheet of the logarithm, e.g. $p=0$.

[^2]: Let us also mention that eq. (31) is equivalent to the functional integral representation of the gauge invariant transition amplitude derived in ref. [5] in a somewhat different way. We would have obtained that representation had we parametrized $\Omega_n = \Omega U_n$ with $n[\Omega] = 0$ and chosen $\Omega$ instead of $\Omega_n$ in eq. (30).

[^3]: An alternative functional integral representation for the gauge invariant transition amplitude with a time-dependent $A_0$ was also derived in ref. [5]. This representation is, however, equivalent to eq. (31). Let us also mention that representation (31) follows also from the lattice formulation by using the gauge $\partial_0 U_0(\vec x,x_0)=0$ (where $U_0(x)$ denotes the temporal link) and taking the continuum limit in the spatial directions.

[^4]: This residual gauge freedom could be fixed e.g. by the Coulomb type of gauge condition
$$
\int_0^T dx_0\,\vec\nabla\cdot\vec A^{\,n} = 0,
$$
where $\vec A^{\,n}$ is the diagonal (neutral) part of $\vec A$. Inclusion of this gauge condition would, however, not change the Faddeev-Popov determinant (see eq. (47) above).

[^5]: This can be also easily seen in the lattice formulation. Starting at $x_0 = 0$ one can bring the links $U_0(x) = \exp(-aA_0(x))$ to the gauge $U_0(x) = 1$ except for the last link terminating at $x_0 = T$, which cannot be gauged away due to the periodic boundary condition.