# PROOF 10: Stability of Curvature under Mosco Convergence (Theorem M)
**Status:** ESTABLISHED THEOREM
**Subject:** The Analytic Engine of the Mass Gap Proof

---

## 1. The Mosco Stability Theorem (Theorem M)
We prove that the sequence of lattice Dirichlet Non-Linear Forms $(\mathcal{E}_a, \mu_a)$ converges to a limit $(\mathcal{E}, \mu)$ in the **Mosco sense**, and that this convergence preserves the Bakry-Émery curvature-dimension condition $CD(\rho_0, \infty)$.

**Theorem M:**
The curvature bound $\rho_0$ derived on the lattice (Pillar I) persists in the continuum:
$$ \Gamma_2(f) \ge \rho_0 \Gamma(f) \quad \forall f \in D(\mathcal{E}) $$

---

## 2. Proof of Lemma D1 (Mosco Lower Bound)
**Statement:** For any $f_a \to f$ strongly in $L^2(\mu)$, $\mathcal{E}(f,f) \le \liminf_{a \to 0} \mathcal{E}_a(f_a, f_a)$.

**Proof:**
1.  **Weak Convergence of Gradients:** Since $\sup_a \mathcal{E}_a(f_a) < \infty$, the gradients $\nabla_a f_a$ are uniformly bounded in $L^2$.
2.  **extraction:** There exists a subsequence converging weakly to some vector field $V$.
3.  **Identification:** Since $\nabla$ is a closed operator (Lemma M3), $V = \nabla f$.
4.  **Lower Semicontinuity:** The $L^2$ norm is weakly lower semicontinuous. Thus $||V||^2 \le \liminf ||\nabla_a f_a||^2$.

---

## 3. Proof of Lemma D2 (Recovery Sequences)
**Statement:** For any $f \in D(\mathcal{E})$, $\exists f_a \to f$ such that $\mathcal{E}_a(f_a) \to \mathcal{E}(f)$.

**Proof:**
1.  **Cylindrical Density:** Cylindrical functions (depending on finite effective loops) are dense in $D(\mathcal{E})$ (by M3).
2.  **Projection:** For a cylindrical $f$, define $f_a$ by evaluating $f$ on the coarsened lattice field (block averaging).
3.  **Energy Convergence:** For smooth cylindrical functions, the lattice derivative $\nabla_a$ converges strongly to the functional derivative $\delta / \delta A$. The error is $O(a^2)$. Thus $\mathcal{E}_a(f_a) \to \mathcal{E}(f)$ pointwise.
4.  **Diagonal Argument:** For general $f$, approximate by cylindrical $f^{(k)}$ and verify the diagonal sequence recovery.

---

## 4. Proof of Lemma D5 (Infinite-Dimensional Bakry-Émery)
**Statement:** Stability of $\Gamma_2 \ge \rho_0 \Gamma$.

**Proof:**
1.  **Heat Flow Characterization:** The condition $\Gamma_2 \ge \rho_0 \Gamma$ is equivalent to the **exponential contraction** of the gradient under the heat flow $P_t$:
    $$ ||\nabla P_t f||^2 \le e^{-2\rho_0 t} ||\nabla f||^2 $$
2.  **Semigroup Convergence:** By the Trotter-Kato theorem (extended to Mosco convergence), if forms converge in Mosco sense, their semigroups $P_t^a$ converge strongly to $P_t$.
3.  **Preservation of Estimates:**
    $||\nabla_a P_t^a f_a||^2 \le e^{-2\rho_0 t} ||\nabla_a f_a||^2$.
    Taking the limit $a \to 0$:
    LHS: Using D1 (Lower Bound), $||\nabla P_t f||^2 \le \liminf ||\nabla_a P_t^a f_a||^2$.
    RHS: Using D2 (Recovery), we choose $f_a$ such that limit is exact.
4.  **Result:** $||\nabla P_t f||^2 \le e^{-2\rho_0 t} ||\nabla f||^2$.
5.  **Differentiation:** Differentiating at $t=0$ yields $\Gamma_2(f) \ge \rho_0 \Gamma(f)$.

---

## 5. Conclusion
The curvature condition is stable under the weak limit.
This closes the gap between Lattice Geometry and Continuum Spectral Analysis.

**Q.E.D.**
