<!--
GPT-5.1 CLEANED & UNIFIED
Source: MASTER_1-s2.0-002212369190123M-main.md
Date: 2025-12-07T03:06:40.650469
Model: gpt-5.1 (High Reasoning)
-->

---
title: Logarithmic Sobolev Inequalities on Loop Groups  
authors: Leonard Gross  
arxiv_id: N/A  
year: 1991  
relevance_to_yang_mills:  

Loop groups of compact Lie groups are closely related to configuration spaces of gauge fields on a circle and, via time-slicing/Euclidean methods, to Yang–Mills fields in 1+1 dimensions and to certain reduced models in higher dimensions. Logarithmic Sobolev inequalities (LSIs) and hypercontractivity on such infinite-dimensional configuration spaces are a key analytic tool in constructive field theory, in particular for establishing good control on measures induced by gauge-invariant actions, for proving uniqueness/ergodicity of dynamics, and for deriving spectral gaps of associated operators. The presence of a quadratic potential in the LSI here mirrors the role of mass terms (or infrared regulators) in Yang–Mills and related quantum field theories, and the structural method of “inheritance” of LSIs from ambient Gaussian/Wiener measures is conceptually close to techniques used in attempts to control Yang–Mills path measures.  

mathematical_domain: Probability on Lie groups, Infinite-dimensional analysis, Logarithmic Sobolev inequalities, Stochastic analysis on manifolds, Dirichlet forms, Hypercontractivity.  

---

# Logarithmic Sobolev Inequalities on Loop Groups

## Abstract

Let $G$ be a compact Lie group. Denote by $m$ the Brownian bridge measure on the loop group
\[
\mathcal{Y} = \{ g \in C([0,1]; G) : g(0) = g(1) = e\}.
\]
The finite energy subgroup of $\mathcal{Y}$ determines in a natural way a gradient operation for functions on $\mathcal{Y}$. The following logarithmic Sobolev inequality is proven:
\[
\int f^2 \log |f|\,dm 
\;\le\; 
\int \big( |\operatorname{grad} f(y)|^2 + V(y) f(y)^2\big)\,dm
\;+\;
\|f\|_2^2 \log \|f\|_2,
\]
where $\|f\|_2$ denotes the $L^2(m)$ norm and $V$ is a potential which is quadratic in the associated Lie algebra–valued Brownian motion. The inequality is derived by a method of inheritance from the known inequality for the $G$–valued Brownian motion. $\copyright$ 1991 Academic Press, Inc.

---

## 1. Introduction

The classical Sobolev inequalities are a fundamental tool in analysis over finite-dimensional manifolds. For infinite-dimensional manifolds logarithmic Sobolev inequalities, because of their dimension-independent character, seem to be the proper analogs of these classical inequalities.

Logarithmic Sobolev inequalities have been investigated extensively over infinite-dimensional linear spaces and finite-dimensional manifolds as well as over some infinite products of finite-dimensional manifolds. (See [DGS, G4] for surveys and [HS].) In this paper we establish logarithmic Sobolev inequalities on an important class of infinite-dimensional manifolds.

Let $G$ be a compact connected Lie group. Denote by $W_e$ the space of continuous functions $g$ from $[0,1]$ into $G$ such that $g(0) = e$, the identity element of $G$. Given a choice of an $\operatorname{Ad}G$–invariant inner product on the Lie algebra $\mathfrak{g}$ of $G$ there is a natural probability measure $P$ on $W_e$ induced by the $G$–valued Brownian motion over $[0,1]$ which starts at $e$.

For each point $x \in G$ the set $W_x$, consisting of functions $g \in W_e$ for which $g(1) = x$, supports a probability measure $p_x$, which is the conditional measure
\[
P(\cdot \mid g(1) = x),
\]
the Brownian bridge measure on the bridge space $W_x$.

$W_e$ is a group under pointwise multiplication. $W_e$ is a subgroup, the so-called group of based loops. Loop spaces have been extensively studied in both the mathematics and physics literature. See, for example, [AH, AV2, Fr, Ge, M, MM, P]. There is a natural gradient operation for functions on $W_e$ corresponding to a Hilbert space of right-invariant vector fields on $W_e$.

Let $h$ be an absolutely continuous function from $[0,1]$ into the Lie algebra $\mathfrak{g}$ of $G$ which vanishes at zero and has square integrable derivative. Denote by $H$ the Hilbert space of such functions and by $H_0$ the closed subspace of those functions which also vanish at one. For $h \in H$ and $g \in W_e$ define the product $\exp(th)\,g$ to be that element of $W_e$ whose value at $s$ is $\exp(th(s))\,g(s)$.

The gradient of a function $f$ on $W_e$ may be defined (informally) by
\[
(\operatorname{grad} f(g), h)_H
\;=\;
\frac{d}{dt}\Big|_{t=0} f\big( e^{t h}\,g\big),
\qquad h \in H.
\tag{1.1}
\]
$\operatorname{grad} f(g)$ lies in $H$. Similarly if $f$ is a function on $W_x$ its tangential gradient $\operatorname{grad}_x f(g)$ lies in $H_0$ and is defined the same way but with $h$ running over $H_0$.

The logarithmic Sobolev inequality
\[
\int_{W_e} f(g)^2 \log |f(g)|\,P(dg)
\;\le\;
C \int_{W_e} |\operatorname{grad} f(g)|^2 \,P(dg)
\;+\;
A \|f\|_{L^2(P)}^2
\;+\;
\|f\|_{L^2(P)}^2 \log \|f\|_{L^2(P)}
\tag{1.2}
\]
is a consequence of the corresponding well-known inequality on Wiener space, because the measure $P$ is in a certain sense Gaussian.

It is our aim to investigate the existence of a similar inequality over the loop group $W_e$ with respect to the Brownian bridge measure $p_x$. E. Getzler [Ge] has shown, however, that the powerful method of Bakry and Émery [B] fails to yield the precise $W_e$ analog of the inequality (1.2). The method of this paper also fails to yield such an inequality. In the author’s opinion the precise analog of (1.2) is false. But the present method suggests an alternative inequality and gives a little insight into why the precise analog of (1.2) could fail.

We shall obtain a logarithmic Sobolev inequality over $(W_x, p_x)$ by adding a quadratic potential onto the Dirichlet form operator appearing on the right side. Let $b$ denote the $\mathfrak{g}$–valued Wiener process associated to the given inner product on $\mathfrak{g}$. Let $g(\cdot)$ denote the solution to the stochastic differential equation
\[
dg = db \circ g,\qquad g(0) = e.
\tag{1.3}
\]
(Here $\circ$ denotes the Stratonovich differential.)

We shall prove
\[
\int_{W_x} f(y)^2 \log |f(y)|\,p_x(dy)
\;\le\;
C_1 \int_{W_x}\big( |\operatorname{grad}_x f(y)|^2 + V(y) f(y)^2\big)\,p_x(dy)
\;+\;
A_1 \|f\|_{L^2(p_x)}^2
\;+\;
\|f\|_{L^2(p_x)}^2 \log \|f\|_{L^2(p_x)}.
\tag{1.4}
\]
Here $V$ is a potential which is quadratic in the terminal value $b(1)$ of the associated $\mathfrak{g}$–valued Brownian motion, of the form
\[
V(y) = \lambda_*\,|b(1)|^2 + \text{constant},
\qquad \lambda_* > 0,
\]
for a suitable constant $\lambda_*$ depending on the geometry and the chosen tubular neighborhood (see Sections 4–5).

This inequality is the main result of this paper. Let $L$ be the form closure in $L^2(p_x)$ of the operator
\[
(\operatorname{grad}_x)^* \operatorname{grad}_x + V.
\]
Then (1.4) implies that $e^{-tL}$ is hypercontractive and that $L$ has an eigenvalue of finite multiplicity at the bottom of its spectrum. It seems likely that over each connected component of $W_x$, $L$ has a unique ground state. But this has not yet been investigated.

Our method is conceptually very simple and most easily explained in finite dimensions. Let $\Omega$ be a finite-dimensional Riemannian manifold and $Y$ an embedded submanifold. Assume that there is a neighborhood $U$ of $Y$ which is diffeomorphic to a product: $U = X \times Y$. Suppose that $P$ is a measure on $\Omega$ for which a logarithmic Sobolev inequality is known to hold. Apply the known inequality to a function $F$ on $U$ of the form
\[
F(x,y) = u(x)\,f(y)\,\beta(x,y)
\]
wherein $u$ is a fixed function in $C_c^\infty(X)$ and $\beta(x,y)$ is determined by the disintegration of $P|_U$ under the product decomposition $U = X \times Y$. With some simple estimates the desired logarithmic Sobolev inequality over $Y$ will hold for $f$ if the embedding satisfies a number of important technical conditions.

In Section 2 we carry out this procedure and give an example showing that one cannot expect to get best constants this way even if the $X$ and $Y$ level sets are mutually orthogonal. In Section 3 we show how a smooth map $\varphi$ from $\Omega = \mathbb{R}^d$ to $\mathbb{R}^n$ can generate such a decomposition and disintegration if $P$ transforms suitably under the inverse gradient flow of $\varphi$. In Section 4 we carry out these finite-dimensional techniques in the infinite-dimensional case of interest to us, with $\Omega$ replaced by $W_e$ and $Y$ replaced by the “submanifold’’ $W_x$ (and more generally by $W_\bullet$). In Section 5 we prove hypercontractivity of the associated semigroup and existence of ground states.

---

## 2. Hereditability of Logarithmic Sobolev Inequalities by Submanifolds

Let $\Omega$ be a finite-dimensional $C^\infty$ Riemannian manifold and $P$ a probability measure on the Borel sets of $\Omega$. We assume throughout this section that
\[
\int_\Omega G(z)^2 \log |G(z)|\,P(dz)
\;\le\;
C \int_\Omega |\nabla G(z)|^2\,P(dz)
\;+\;
A \|G\|_2^2
\;+\;
\|G\|_2^2 \log \|G\|_2
\tag{2.1}
\]
for some constants $C>0$ and $A\in\mathbb{R}$ and all real-valued functions $G$ on $\Omega$ whose weak gradient $\nabla G$ is in $L^2(\Omega,P)$. Here $\|G\|_2$ denotes the $L^2(P)$ norm. We consider only real-valued functions.

Denote by $Y$ an embedded submanifold of $\Omega$. We assume that $Y$ has an open tubular neighborhood $U$ in $\Omega$ with the following uniformity and regularity properties. Let $X$ be a bounded open neighborhood of the origin in $\mathbb{R}^n$. We assume $U$ is diffeomorphic to $X\times Y$ and we identify $U$ with $X\times Y$ by this diffeomorphism. $Y$ itself is identified to $\{(0,y): y\in Y\}$.

We do not assume that the $\Omega$–metric on $X\times Y$ is a direct sum of metrics on the tangent spaces of $X$ and $Y$ and consequently the derivative $R'$ of the projection operator
\[
R(x,y) = (0,y)
\tag{2.2}
\]
from $U$ to $Y$ need not have norm one. But we assume that there is a constant $\alpha$ such that
\[
\|R'(z)\| \;\le\; \alpha \quad\text{for all } z\in U.
\tag{2.3}
\]

Furthermore we assume that the restriction of $P$ to $U$ may be decomposed as
\[
P(dx,dy) = \omega(x,y)\,dx\,\mu(dy),
\tag{2.4}
\]
where $\mu$ is a probability measure on $Y$, $dx$ is Lebesgue measure on $X$, and $\omega$ is a strictly positive $C^1$ function on $U$ satisfying $\omega(0,y) = \text{constant}$ (independent of $y$).

If
\[
\rho(x) = \int_Y \omega(x,y)\,\mu(dy)
\]
then the probability measure $\mu_x$ given by
\[
\mu_x(dy)
\;=\;
\rho(x)^{-1} \,\omega(x,y)\,\mu(dy)
\tag{2.5}
\]
on $Y$ is the conditional probability
\[
\mu_x(E)
\;=\;
P\big((x,y)\in E \,\big|\, (x,y)\in U\big)
=
P\big( (x,y)\in E \,\big|\, x \big),
\tag{2.6}
\]
for any Borel set $E\subset U$. Moreover $\rho(x)\,dx$ is the measure on $X$ induced by projecting $P|_U$ down to $X$. We assume $\rho\in C^1(X)$.

Although we are describing our strategy in the context of a finite-dimensional manifold $\Omega$ our real interest lies in the case wherein $\Omega$ is the infinite-dimensional space $W_e$ described in the Introduction and $Y$ is the cofinite-dimensional submanifold $W_x$. It will be essential therefore to obtain estimates in this section which are independent of the dimension of $Y$ and which depend on $P$–integrals in a manner which is computable for loop groups. We shall carry out the extension to this infinite-dimensional case in the next two sections.

For a smooth function $f: Y\to\mathbb{R}$ we write $f'(y)$ for its derivative instead of $df(y)$. We similarly denote by $u'(x)$ the derivative of a function $u: X\to\mathbb{R}$.

### Theorem 2.1

Let $u$ be a nonnegative function in $C_c^\infty(X)$ with $\int_X u(x)^2\,dx = 1$. Write $R_y(z) = x$ if $z = (x,y)\in U$. Choose $\varepsilon>0$ and $\varepsilon_1>0$ such that $2(\varepsilon + \varepsilon_1) < 1$. Let
\[
\beta(z) = \omega(z)^{1/2}, \qquad z\in U.
\]
Let $V: Y\to\mathbb{R}$ be locally $\mu$–integrable and put
\[
K(z)
=
3C\big( |\nabla \log \beta(z)|^2 - \varepsilon^2 V(y)\big)
-
\log \beta(z),
\qquad z=(x,y)\in U,
\tag{2.7}
\]
and
\[
K_1(z)
=
3C |X|\,|u'(x)|^2 \|R'(z)\|^2,
\qquad z = (x,y)\in U,
\tag{2.8}
\]
where $|X|$ is the Lebesgue measure of $X$, $\alpha$ is as in (2.3), and $\omega$ is as in (2.4).

Assume that
\[
D
:=
\varepsilon \int_U
\exp\!\left(
\frac{K(z)}{\varepsilon\,u(x)^2}
\right) u(x)^2 P(dz)
<\infty
\tag{2.9}
\]
and
\[
D_1
:=
\varepsilon_1 |X|^{-1}
\int_U
\exp\!\left(
\frac{K_1(z)}{\varepsilon_1}
\right)
\beta(z)^2
P(dz)
<\infty.
\tag{2.10}
\]

Then for any bounded function $f\in L^2(\mu)$
\[
\int_Y f(y)^2 \log |f(y)| \,\mu(dy)
\;\le\;
C_1 \int_Y\big( |f'(y)|^2 + V(y) f(y)^2\big)\,\mu(dy)
+
A_1 \|f\|_2^2
+
\|f\|_2^2 \log \|f\|_2,
\tag{2.11}
\]
where
\[
C_1 = (1 - 2\varepsilon - 2\varepsilon_1)^{-1} 3C\alpha^2,
\tag{2.12}
\]
and
\[
A_1
=
(1 - 2\varepsilon - 2\varepsilon_1)^{-1}
\Big(
A
+
\int_X u(x)^2 \log u(x)\,dx
+
(\varepsilon + \varepsilon_1)^{-1}(D + D_1)
+
(\varepsilon + \varepsilon_1)\log \frac{1}{\varepsilon + \varepsilon_1}
\Big).
\tag{2.13}
\]

#### Proof

It suffices to prove (2.11) for $f\in C_c^\infty(Y)$. Let
\[
G(z) = f(y) u(x) \beta(x,y),\qquad z=(x,y)\in U,
\]
and put $G(z)=0$ if $z\notin U$. Then
\[
\begin{aligned}
\int_\Omega G(z)^2\,P(dz)
&=
\int_X \int_Y f(y)^2 u(x)^2 \beta(x,y)^2 \omega(x,y)\,\mu(dy)\,dx\\
&=
\int_X u(x)^2\,dx \int_Y f(y)^2 \mu(dy)
=
\|f\|_{L^2(\mu)}^2,
\end{aligned}
\tag{2.14}
\]
since $\beta^2 = \omega$ and $\int_X u^2 = 1$.

Similarly,
\[
\begin{aligned}
\int_\Omega G(z)^2 \log |G(z)|\,P(dz)
&=
\int_X \int_Y
f(y)^2 u(x)^2 \Big(\log|f(y)| + \log u(x) + \log \beta(x,y)\Big)\,\mu(dy)\,dx\\
&=
\int_Y f(y)^2 \log|f(y)|\,\mu(dy)
+
\int_X u(x)^2 \log u(x)\,dx\\
&\qquad
+
\int_U f(y)^2 u(x)^2 \log \beta(z)\,P(dz).
\end{aligned}
\tag{2.15}
\]

We shall apply (2.1) to $G$ after analyzing the gradient term. We use $\nabla$ to denote the Riemannian gradient on $U$ (in the metric induced from $\Omega$). On $U$ we have
\[
\big|\nabla G(z)\big|^2
=
\big| (\nabla f) u\beta + f (\nabla u)\beta + f u (\nabla\beta) \big|^2
\;\le\;
3\big(
u^2 \beta^2 |\nabla f|^2
+
f^2 \beta^2 |\nabla u|^2
+
f^2 u^2 |\nabla\beta|^2
\big),
\tag{2.16}
\]
where we used the inequality $|a+b+c|^2\le 3(|a|^2+|b|^2+|c|^2)$.

Now $|\nabla f| = |f'(R(z)) R'(z)| \le \alpha\,|f'(R(z))|$ by (2.3). Furthermore $|\nabla u| = |u'(R_x(z))|\cdot \|R_x'(z)\|$, where $R_x(z)=x$ is the projection onto $X$; we bound $\|R_x'(z)\|\le \alpha$ similarly (after possibly enlarging the constant). Hence
\[
\begin{aligned}
|\nabla G(z)|^2
&\le
3\alpha^2 u(x)^2 \beta(z)^2 |f'(R(z))|^2
+
3 f(y)^2 \beta(z)^2 |u'(x)|^2 \|R_x'(z)\|^2
+
3 f(y)^2 u(x)^2 \beta(z)^2 |\nabla\log\beta(z)|^2.
\end{aligned}
\]

Thus
\[
\begin{aligned}
\int_\Omega |\nabla G(z)|^2\,P(dz)
&\le
3\alpha^2 \int_Y |f'(y)|^2\,\mu(dy)\\
&\quad+
\int_U f(y)^2
\left\{
3 |u'(x)|^2 \|R_x'(z)\|^2
+
3 u(x)^2 |\nabla\log\beta(z)|^2
\right\}
P(dz).
\end{aligned}
\tag{2.17}
\]

Combining (2.1), (2.14), (2.15), and (2.17) gives
\[
\begin{aligned}
\int_Y f(y)^2 \log|f(y)|\,\mu(dy)
&\le
3C\alpha^2 \int_Y |f'(y)|^2\,\mu(dy)\\
&\quad+
\int_U f(y)^2\Big\{
3C |u'(x)|^2 \|R_x'(z)\|^2
+
3C u(x)^2 |\nabla\log\beta(z)|^2
-
3\varepsilon^2 V(y)
-
\log\beta(z)
\Big\}
u(x)^2 P(dz)\\
&\quad+
A \|f\|_2^2
+
\|f\|_2^2 \log \|f\|_2
-
\|f\|_2^2 \int_X u(x)^2 \log u(x)\,dx.
\end{aligned}
\tag{2.18}
\]

Insert the definition of $K(z)$ and $K_1(z)$ to get
\[
\begin{aligned}
\int_Y f(y)^2 \log|f(y)|\,\mu(dy)
&\le
3C\alpha^2 \int_Y\big( |f'(y)|^2 + V(y) f(y)^2\big)\,\mu(dy)\\
&\quad+
\int_U f(y)^2 e^{-K_1(z)} u(x)^2 P(dz) 
+
\int_U f(y)^2 e^{-K(z)} u(x)^2 P(dz)\\
&\quad+
A\|f\|_2^2
+
\|f\|_2^2 \log \|f\|_2
+
\|f\|_2^2 \int_X u(x)^2 \log u(x)\,dx.
\end{aligned}
\tag{2.19}
\]

Now we apply Young’s inequality
\[
st \le \varepsilon s \log s + \varepsilon e^{t/\varepsilon}
\]
which is valid for $s\ge 0$ and $t\in\mathbb{R}$, with appropriate choices of $\varepsilon$ for each term. Put $s=f(y)^2$ and $t = -K_1(z)$ (respectively, $t=-K(z)$) in the second and third integrals on the right of (2.19) to get
\[
\begin{aligned}
\int_Y f(y)^2 \log|f(y)|\,\mu(dy)
&\le
3C\alpha^2 \int_Y\big( |f'(y)|^2 + V(y) f(y)^2\big)\,\mu(dy)\\
&\quad+
\varepsilon_1 |X|^{-1}
\int_U \big( f(y)^2 \log f(y)^2 - f(y)^2 + e^{K_1(z)/\varepsilon_1}\big) u(x)^2 P(dz)\\
&\quad+
\varepsilon
\int_U \big( f(y)^2 \log f(y)^2 - f(y)^2 + e^{K(z)/\varepsilon}\big) u(x)^2 P(dz)\\
&\quad+
A \|f\|_2^2
+
\|f\|_2^2 \int_X u(x)^2 \log u(x)\,dx
+
\|f\|_2^2 \log\|f\|_2.
\end{aligned}
\]

But for any bounded function $g:Y\to\mathbb{R}$ we have
\[
\int_U g(y) u(x)^2 \omega(x,y)\,\mu(dy)\,dx
=
\int_Y g(y)\,\mu(dy).
\]
Hence
\[
\begin{aligned}
(1 - 2\varepsilon - 2\varepsilon_1)
\int_Y f(y)^2 \log|f(y)|\,\mu(dy)
&\le
3C\alpha^2 \int_Y\big( |f'(y)|^2 + V(y)f(y)^2\big)\,\mu(dy)\\
&\quad+
D_1 - \varepsilon_1 \|f\|_2^2
+
D - \varepsilon \|f\|_2^2
+
A \|f\|_2^2
+
\|f\|_2^2 \int_X u(x)^2 \log u(x)\,dx
+
\|f\|_2^2 \log\|f\|_2.
\end{aligned}
\tag{2.20}
\]

Thus
\[
\begin{aligned}
\int_Y f(y)^2 \log|f(y)|\,\mu(dy)
&\le
\frac{3C\alpha^2}{1 - 2\varepsilon - 2\varepsilon_1} \int_Y\big( |f'(y)|^2 + V(y) f(y)^2\big)\,\mu(dy)\\[4pt]
&\quad+
\frac{1}{1-2\varepsilon - 2\varepsilon_1}
\Big(
A - (\varepsilon + \varepsilon_1) \|f\|_2^2 + D + D_1
+ \|f\|_2^2 \int_X u(x)^2 \log u(x)\,dx
\Big)\\[4pt]
&\quad+
\frac{1}{1 - 2\varepsilon - 2\varepsilon_1}\,\|f\|_2^2 \log\|f\|_2.
\end{aligned}
\tag{2.21}
\]

The theorem now follows from the following lemma, which normalizes the local-norm and logarithmic terms.

### Lemma 2.2

Let $\mu$ be a probability measure and $Q$ a densely defined quadratic form on $L^2(\mu)$. Suppose that there exist real numbers $a,b,c$ with $b>0$ and $c>1$ such that for $f$ in the domain of $Q$
\[
\int f^2 \log |f|\,d\mu
\;\le\;
Q(f,f) + a\|f\|_2^2 + b + c\|f\|_2^2 \log \|f\|_2.
\tag{2.22}
\]

Then for $f$ in the domain of $Q$
\[
\int f^2 \log |f|\,d\mu
\;\le\;
Q(f,f)
+
A_1 \|f\|_2^2
+
\|f\|_2^2 \log \|f\|_2
\tag{2.23}
\]
with
\[
A_1
=
a + \tfrac12 (c-1)\Big(1 + \log\frac{2b}{c-1}\Big).
\tag{2.24}
\]

#### Proof

Since the inequality (2.23) is homogeneous it suffices to prove it in case $\|f\|_2 = 1$. With $\|f\|_2 = 1$ and $t^2 = 2b/(c-1)$ and $t>0$, apply (2.22) to the function $tf$ and then divide by $t^2$ to get
\[
\int f^2(\log |f| + \log t)\,d\mu
\;\le\;
Q(f,f)
+
a + \tfrac12(c-1) + (c-1)\log t.
\]
Hence
\[
\int f^2 \log|f|\,d\mu
\;\le\;
Q(f,f) + a + \tfrac12(c-1) + (c-1)\log t
= Q(f,f) + A_1.
\]

### Corollary 2.3

Assume that $\|R_x'(z)\|$ is bounded on $U$. Denote by $c_1$ a constant such that
\[
K_1(z) \le c_1
\quad\text{on }U.
\tag{2.25}
\]
Suppose that $0<\varepsilon<\frac12$ and that (2.9) holds. Then (2.11) holds with
\[
C_1 = (1 - 2\varepsilon)^{-1} 3C\alpha^2
\]
and
\[
A_1
=
(1-2\varepsilon)^{-1}
A
+
(1-2\varepsilon)^{-1}
\int_X u(x)^2 \log u(x)\,dx
+
\varepsilon^{-1}\log\frac{D}{\varepsilon}.
\tag{2.26}
\]

#### Proof

In the inequality (2.19) the entire $K_1(z)$ term is dominated by $c_1\|f\|_2^2$. Thus we may delete this term if we replace $A$ by $A + c_1$ in that and the remaining inequalities. The remainder of the proof is the same as before with no $K_1(z)$ term and $\varepsilon_1=0$.

### Remark 2.4

The estimate of $\int |\nabla G(z)|^2 P(dz)$ that begins in Eq. (2.16) can be made in several ways. If for example the inner product in $\Omega$ is the sum of the inner products on $X$ and $Y$ then $\nabla(f\circ R)$ is orthogonal to $\nabla(u\circ R_x)$ and consequently the coefficient $3C$ can be reduced to $2C$.

More generally, the cross term
\[
2\int \beta^2 (\nabla(fu)\cdot \nabla\beta)\,P(dz)
\]
in an expansion of $\int |\nabla G|^2 P(dz)$ can also be handled by an integration by parts, yielding a modified $K(z)$ of the form
\[
k(z)
=
C\Big(|\nabla\log \beta(z)|^2 + \tfrac12 \beta(z)^2 \Delta(\beta^{-2})(z) - 2\varepsilon^2 V(y)\Big) - \log \beta(z)
\]
and
\[
K_1(z)
=
2C |X|\,|u'(x)|^2 \|R_x'(z)\|^2
\]
with $C_1 = (1 - 2\varepsilon - 2\varepsilon_1)^{-1}2 C\alpha^2$ and $A_1$ expressed in terms of the new $k$ and $K_1$ as before. However, in the loop group case this yields only a very slight improvement of coefficients at the cost of a more complicated computation. (See Remark 3.4 and Remark 4.19 for the result of the computation.)

### Example 2.5

Even without the crude estimates made in the preceding proof the logarithmic Sobolev inequalities obtained by inheriting from the ambient space do not seem to produce best constants. Take $\Omega = \mathbb{R}^{n+1}$ and $Y = S^n = \{ y\in \mathbb{R}^{n+1} : |y| = 1\}$. Take
\[
P(dz) = (2\pi t)^{-(n+1)/2} \exp\left(-\frac{|z|^2}{2t}\right)\,dz.
\]
Decompose $U := \mathbb{R}^{n+1}\setminus\{0\}$ by polar coordinates as $U = X\times Y$ with $X = (0,\infty)$ (the radial coordinate $r$) and $Y=S^n$. Then $\mu$ is the normalized Lebesgue measure on $Y$ and the function $\omega(r,y)$ defined in (2.4) is independent of the angular coordinate $y$.

Writing $r$ for the radial coordinate instead of $x$ we have
\[
\omega(r,y) = \omega(r) \sim (2\pi t)^{-(n+1)/2} r^n e^{-r^2/(2t)}.
\]
It is known [G1] that (2.1) holds with $C=t$ and $A=0$ if one uses the Euclidean metric on $\mathbb{R}^{n+1}$. Moreover these are the best constants.

If $f: S^n\to\mathbb{R}$ and $u: X\to\mathbb{R}$ are smooth put $U(r) = u(r)\omega(r)^{-1/2}$ and $G(r,y) = f(y) u(r)$. The method of this section consists in applying (2.1) to $G$. It is easy to see what inequality for $f$ we can get this way. Because of the orthogonality of $X$ and $Y$ we have
\[
|\nabla G(r,y)|^2 = u(r)^2 |\nabla_Y f(y)|^2 + f(y)^2 |u'(r)|^2.
\]
Inserting this into (2.1) and putting $\|u\|_2^2 = \int_0^\infty u(r)^2\omega(r)\,dr = 1$ we get exactly
\[
\begin{aligned}
\int_Y f(y)^2 \log |f(y)|\,\mu(dy)
&\le
\frac{t\|u\|_2^2}{\|u\|_2^2} \int_Y |\nabla_Y f|^2\,\mu(dy)
+
\|f\|_2^2\log\|f\|_2\\
&\quad+
\|f\|_2^2
\left[
\frac{\|u'\|_2^2}{\|u\|_2^2}
-
\int_0^\infty u(r)^2 \log (u(r)^2 \omega(r))\,dr
\right]
\end{aligned}
\tag{2.27}
\]
upon dividing by $\|u\|_2^2$ and simplifying.

If we put $f \equiv 1$ in (2.27) we see that the expression in braces is nonnegative. This just expresses (2.1) for a radial function. But (2.1) is never an equality except for constant functions. Thus in order to derive (2.11) with $A_1=0$ we must put $u$ constant in (2.27) which makes the expression in braces equal to zero. However, if $n=1$ and $u$ is constant then the weak gradient of $G$ is not in $L^2(\mathbb{R}^2, P)$ if $f$ is not constant. This is reflected in the fact that $\|1/r\|_2 = \infty$ if $n+1=2$. We consider only $n>2$ henceforth.

Without loss of information we may put $t=1$. An integration by parts in the $r$-integral for $\|u'\|_2^2$ shows that $\|u\|_2^2 = (n-1)\|1/r\|_2^2$ for $n\ge2$. Hence (2.27) reduces to
\[
\int_Y f(y)^2 \log |f(y)|\,\mu(dy)
\;\le\;
\frac{1}{n-1}\int_Y |\nabla_Y f(y)|^2\,\mu(dy)
+
\|f\|_2^2 \log\|f\|_2,
\qquad n\ge2.
\tag{2.28}
\]
Since we have used only equalities at every stage of the derivation of (2.28) from (2.1) the coefficient $(n-1)^{-1}$ of the gradient term $\|\nabla_Y f\|_2^2$ is the smallest coefficient we can get by applying (2.1) to a product $f(y)u(r)$ if we insist on obtaining the inequality (2.11) with $A_1=0$.

But in fact Müller and Weissler [MW, Theorem 3] have shown that (2.28) holds with the coefficient $(n-1)^{-1}$ replaced by the smaller coefficient $1/n$ (which is the smallest possible constant, cf. [MW]). Thus we cannot obtain the smallest possible coefficient of $\|\nabla_Y f\|_2^2$ by this method.

---

## 3. Disintegration and the Inverse Gradient Flow

We consider in this section an embedded submanifold $Y$ of $\mathbb{R}^d$ which arises as the level set of a map $\varphi:\mathbb{R}^d \to \mathbb{R}^n$. We describe a tubular neighborhood of $Y$ and a corresponding disintegration (2.4) of a given probability measure $P(dz)$ on $\mathbb{R}^d$. We then apply the conditions of Theorem 2.1 under which a logarithmic Sobolev inequality for $P$ induces one on $Y$. We conclude with an example of a hyperboloid for $Y$. This section is intended as a finite-dimensional prototype of the method to be used in the next section for loop groups.

Let $\varphi:\mathbb{R}^d\to\mathbb{R}^n$ be a $C^\infty$ map. We will be interested only in the case $d>n$. Write $\varphi'(z)$ for the derivative. Let $X$ be an open convex set in $\mathbb{n}^n$ and put $U = \varphi^{-1}(X)$. We assume that $\varphi'(z)$ has rank $n$ for all $z\in U$. Put
\[
Y_x = \varphi^{-1}(x),\qquad x\in X.
\]

We use the Euclidean metric on $\mathbb{R}^d$ and $\mathbb{R}^n$. Denote by $K_z$ the kernel of $\varphi'(z)$ and by $K_z^\perp$ its orthogonal complement in $\mathbb{R}^d$. Then $\varphi'(z)|_{K_z^\perp}$ is one-to-one and onto $\mathbb{R}^n$. For each point $\xi\in\mathbb{R}^n$ and $z\in U$ let
\[
u_\xi(z)
=
\big(\varphi'(z)|_{K_z^\perp}\big)^{-1}\xi.
\tag{3.1}
\]
Then $u_\xi$ is a $C^\infty$ vector field on $U$ which depends linearly on $\xi$.

Let $z(t)$ be the solution to the initial value problem
\[
\frac{dz}{dt} = u_\xi(z(t)),\qquad z(0) = z_0.
\tag{3.2}
\]
Clearly $z(t)$ exists for $t$ in an interval around zero. We have
\[
\frac{d}{dt}\varphi(z(t))
=
\varphi'(z(t))\frac{dz}{dt}
=
\varphi'(z(t))u_\xi(z(t))
=
\xi.
\]
Hence $\varphi(z(t)) = \varphi(z_0) + t\xi$. We refer to the map $(z_0,t)\mapsto z(t)$ as the inverse gradient flow for $\varphi$.

We assume henceforth that if $\varphi(z_0)$ and $\varphi(z_0) + \xi$ are in $X$ then the function $z(t)$ exists for $0\le t\le1$. Define $S_\xi(z_0) = z(1)$. Then
\[
\varphi(S_\xi(z)) = \varphi(z) + \xi
\]
if $z\in U$ and $\varphi(z)+\xi\in X$. Hence $S_\xi:Y_x\to Y_{x+\xi}$ if $x$ and $x+\xi$ are in $X$. $S_\xi$ is injective by uniqueness of solutions of (3.2). Moreover since
\[
\frac{dz(1-t)}{dt} = -u_\xi(z(1-t)) = u_{-\xi}(z(1-t))
\]
it is clear that $S_\xi$ maps $Y_x$ onto $Y_{x+\xi}$ and $(S_\xi)^{-1} = S_{-\xi}$.

Since the solution of (3.2) depends smoothly on $\xi$ and $z_0$ each $S_\xi$ is a diffeomorphism from $Y_x$ to $Y_{x+\xi}$ and moreover the map
\[
X\times Y_{x_0}\ni (x,y) \longmapsto S_{x - x_0}(y)\in U
\]
is a diffeomorphism from $X\times Y_{x_0}$ onto $U$. If $z = S_{x-x_0}(y)$ for $y\in Y_{x_0}$ then $x = \varphi(z)$ and $y = S_{x_0-x}(z)$.

Hence the map
\[
R(z) = S_{x_0 - \varphi(z)}(z)
\]
projects $U$ to $Y_{x_0}$ in this product decomposition.

Note that the adjoint operator $\varphi'(z)^* : \mathbb{R}^n\to\mathbb{R}^d$ has range $K_z^\perp$. Hence $\varphi'(z)\varphi'(z)^*$ is a strictly positive operator on $\mathbb{R}^n$ for each $z\in U$. Moreover
\[
(\varphi'(z)|_{K_z^\perp})^{-1} = \varphi'(z)^*\big(\varphi'(z)\varphi'(z)^*\big)^{-1}.
\]

We summarize part of this discussion in the following lemma.

### Lemma 3.1

Let $\varphi:\mathbb{R}^d\to\mathbb{R}^n$ be a $C^\infty$ map with $d>n$. Let $X$ be an open convex set in $\mathbb{R}^n$ and put $U = \varphi^{-1}(X)$. Assume that the derivative $\varphi'$ satisfies  

(a) $\varphi'(z)$ has rank $n$ at each point $z$ of $U$.

(b) For each point $z_0$ in $U$ and $\xi\in\mathbb{R}^n$ the initial value problem
\[
\frac{dz(t)}{dt} = \varphi'(z(t))^*\big(\varphi'(z(t))\varphi'(z(t))^*\big)^{-1}\xi,\qquad z(0) = z_0
\]
has a solution in $U$ for $0\le t\le1$ if $\varphi(z_0)+\xi\in X$. Write $S_\xi(z_0) = z(1)$.

Let $x_0$ be a point of $X$. Then for each point $x\in X$, $S_{x-x_0}$ is a diffeomorphism from $Y:=\varphi^{-1}(x_0)$ onto $\varphi^{-1}(x)$ and $S_{x_0} = \operatorname{id}$, $S_{x_0 + \xi} = S_\xi\circ S_{x_0}$, etc. The map $(x,y)\mapsto S_{x-x_0}(y)$ is a diffeomorphism of $X\times Y$ onto $U$.

Next we describe the disintegration of a probability measure over $U$. Let
\[
\delta(z) = \big(\det(\varphi'(z)\varphi'(z)^*)\big)^{1/2}.
\]
Denote by $\sigma_x$ the Lebesgue surface measure on $Y_x$. We shall use the coarea formula [F, Theorem 3.2.12]
\[
\int_U f(z)\,dz
=
\int_X
\left(
\int_{Y_x} f(z)\,\delta(z)^{-1}\,\sigma_x(dz)
\right) dx,
\tag{3.3}
\]
which is valid for example if $f\in C_c(U)$. Moreover in this case the integral in braces is a continuous function of $x$.

If $f\in C_c(U)$ and $\operatorname{supp} S_\xi^{-1}(f)\subset U$ then
\[
\int_U f(S_\xi z) \det S_\xi'(z)\,dz = \int_U f(z)\,dz.
\]
Now use (3.3) on both sides of this equation to get
\[
\begin{aligned}
\int_X \int_{Y_x} f(S_\xi z)\,\delta(z)^{-1}\,\sigma_x(dz)\,dx
&=
\int_X \int_{Y_x} f(z)\,\delta(z)^{-1}\,\sigma_x(dz)\,dx\\
&=
\int_X \int_{Y_x} f(S_\xi y)\,\delta(S_\xi y)^{-1}\,\sigma_x(d(S_\xi y))\,dx.
\end{aligned}
\]
Replacing $f(z)$ by $u(\varphi(z)) f(z)$ yields
\[
\int_X u(x)
\left(
\int_{Y_x} f(S_\xi z)\,\delta(z)^{-1}\,\sigma_x(dz)
\right) dx
=
\int_X u(x)
\left(
\int_{Y_x} f(S_\xi y)\,\delta(S_\xi y)^{-1}\det S_\xi'(y)\,\sigma_x(dy)
\right) dx,
\]
for any function $u\in C(X)$. Since the two integrals over $Y_x$ are continuous in $x$ and $u$ is arbitrary it follows that
\[
\int_{Y_x} f(S_\xi z)\,\delta(z)^{-1}\,\sigma_x(dz)
=
\int_{Y_{x+\xi}} f(y)\,\delta(y)^{-1}\,\sigma_{x+\xi}(dy).
\tag{3.4}
\]

We shall use (3.3) and (3.4) to disintegrate a probability measure on $\mathbb{R}^d$. Let $p(z)$ be a strictly positive continuous function on $\mathbb{R}^d$ with $\int_{\mathbb{R}^d} p(z)\,dz = 1$. Put $P(dz) = p(z)\,dz$. We assume that the induced measure $\varphi_*P$ on $\mathbb{R}^n$ has a strictly positive continuous density $\rho(x)$ on $X$.

Let
\[
\mu_x(dy)
=
\rho(x)^{-1}
\delta(y)^{-1}
p(y)\,\sigma_x(dy)
\tag{3.5}
\]
which is a measure on $Y_x$.

### Lemma 3.2

Let
\[
J_\xi(z) = \frac{p(S_\xi z)}{p(z)} \det S_\xi'(z).
\tag{3.6}
\]

Then

(a) For any Borel $A\subset U$,
\[
P(A) = \int_X \mu_x(A\cap Y_x) \,\rho(x)\,dx,
\]
i.e.,
\[
P(A \mid \varphi = x) = \mu_x(A\cap \varphi^{-1}(x)).
\]

(b) For each Borel set $E\subset Y_x$,
\[
\int_E J_\xi(z)\,\mu_x(dz) = \mu_{x+\xi}(S_\xi(E)).
\]
Upon identifying $X\times Y$ with $U$ as in Lemma 3.1 we have, over $U$,

(c) 
\[
P(dz)
=
P(dx,dy)
=
\rho(x_0)\,J_{x-x_0}(y)\,dx\,\mu_{x_0}(dy),
\qquad z = S_{x-x_0}(y).
\]

#### Proof

Replace $f(z)$ by $f(z)p(z)$ in (3.3) to get
\[
\int_X
\left(
\int_{Y_x} f(z)\,\mu_x(dz)
\right)
\rho(x)\,dx
=
\int_U f(z)\,P(dz),
\tag{3.7}
\]
for $f\in C_c(U)$. This is equivalent to (a).

Replace $f$ by $f(z)p(z)$ in (3.4) to get
\[
\rho(x)
\int_{Y_x} f(S_\xi z) J_\xi(z)\,\mu_x(dz)
=
\rho(x+\xi)\int_{Y_{x+\xi}} f(y)\,\mu_{x+\xi}(dy).
\tag{3.8}
\]

Replace $f$ by $f\circ S_{-\xi}$ in this equation to get (b).

Put $x=x_0$ in (3.8) and $\xi = x-x_0$ to get
\[
\rho(x_0)\int_{Y_{x_0}} f(S_{x-x_0} z) J_{x-x_0}(z)\,\mu_{x_0}(dz)
=
\rho(x)\int_{Y_x} f(y)\,\mu_x(dy).
\tag{3.9}
\]

Integrate both sides of this over $X$ with respect to $x$ and use (3.7). This is (c). We note that although we have used a rather detailed description of the surface measure $\sigma_x$, $J_\xi$ is simply the Radon–Nikodym derivative $d(P\circ S_\xi)/dP$.

For simplicity of statement we take $x_0 = 0$ in the next theorem.

### Theorem 3.3

With the hypotheses on $\varphi$ and $p$ stated in this section assume further that $p\in C^1(\mathbb{R}^d)$ and that
\[
\int_{\mathbb{R}^d} G(z)^2 \log |G(z)|\,P(dz)
\;\le\;
C \int_{\mathbb{R}^d} |\nabla G(z)|^2\,P(dz)
+
A\|G\|_2^2
+
\|G\|_2^2 \log\|G\|_2
\tag{3.10}
\]
for all real-valued functions $G$ on $\mathbb{R}^d$ whose weak gradient $\nabla G$ is in $L^2(P)$. Here $\|G\|_2$ is the $L^2(P)$ norm of $G$.

Let $u$ be a nonnegative function in $C_c^\infty(X)$ with $\int_X u(x)^2\,dx = 1$. Define $S_\xi$ by the inverse gradient flow for $\varphi$ as above. Let $R(z) = S_{-\varphi(z)}(z)$ for $z\in U$ and assume that there exists a constant $\alpha$ such that
\[
\|R'(z)\| \le \alpha \quad\text{for all }z\in U.
\tag{3.11}
\]
Here $\|R'(z)\|$ denotes the operator norm of $R'(z)$ from $\mathbb{R}^d$ to $\mathbb{R}^d$.

Let $Y = \varphi^{-1}(0)$ and write
\[
\omega(S_x(y)) = \rho(0) J_x(y),\qquad y\in Y.
\]
That is,
\[
\omega(z) = \rho(0)\,J_{\varphi(z)}(S_{-\varphi(z)}z).
\]
Write $\beta(z) = \omega(z)^{1/2}$ for $z\in U$ and choose $\varepsilon>0$ and $\varepsilon_1>0$ such that $2(\varepsilon+\varepsilon_1)<1$. Let $V: Y\to\mathbb{R}$ be locally $\mu_0$–integrable and define $K(z)$ by (2.7) and $K_1(z)$ by (2.8) with $R(z)$ as above. Assume (2.9) and (2.10) hold. Then (2.11) holds with $\mu = \mu_0$ (cf. (3.5)) and the values of $C_1$ and $A_1$ given by (2.12) and (2.13).

Moreover if $|\nabla\log\beta(z)|\le c_0$ on $U$ then $C_1$ and $A_1$ may be replaced by the values given in Corollary 2.3.

#### Proof

In view of Lemmas 3.1 and 3.2(c) this is just a special case of Theorem 2.1 and Corollary 2.3.

### Remark 3.4

A more delicate estimate of $A_1$ depending on the second derivatives of $\beta$ was sketched in Remark 2.4. The expression for $k(z)$ given there reduces, when $P(dz) = p(z)\,dz$, to
\[
k(z)
=
-C\big(
|\nabla\log\beta(z)|^2
+
\operatorname{div}(\nabla\log\beta(z))
+
\nabla\log\beta(z)\cdot\nabla\log p(z)
\big)
-
\log\beta(z)
-
2\varepsilon^2 V(y).
\]
Here the divergence is the Euclidean divergence. In the case of loop groups the third term in braces proves to be very large and negative, making this more refined approach of no apparent advantage. See Remark 4.19.

### Example 3.5

We give an example of a hyperboloid in $\mathbb{R}^d$ with its natural Lorentz-invariant measure and an additional Gaussian density. No potential is needed to get a logarithmic Sobolev inequality (i.e., we can take $V=0$ in (2.11)), but we need to use the generality of Theorem 2.1 rather than merely the special case which is Corollary 2.3.

Let $z = (s,\xi)$ denote a point in $\mathbb{R}^d$ with $s\in\mathbb{R}$ and $\xi\in\mathbb{R}^{d-1}$. Define
\[
\varphi(z) = s^2 - |\xi|^2.
\]
We have $\varphi : \mathbb{R}^d\to\mathbb{R}$. Let $B = \operatorname{diag}(1,-1,\dots,-1)$. Then $\varphi(z) = (Bz,z)$ and $\varphi'(z)q = 2(Bz,q)$. Thus $\varphi'(z)$ has rank one as long as $z\ne0$.

Let $0<\varepsilon<m$. Let
\[
U = \{z\in\mathbb{R}^d : \varepsilon<\varphi(z)<m\}.
\]
Then $\varphi$ has rank one on $U$. Clearly, if $K_z = \ker\varphi'(z)$ then $K_z^\perp = \operatorname{span}\{Bz\}$. Thus if $\tau\in\mathbb{R}$ then $(\varphi'(z)|_{K_z^\perp})^{-1}\tau$ is a multiple of $Bz$ and is easily computable. It is
\[
\frac{\tau}{2|Bz|^2}Bz.
\]
The differential equation (3.2) can be solved: If $z_0 = (s_0,\xi_0)$ put
\[
f(t)
=
\frac{(t\tau + \varphi(z_0))^{1/2}}{\big(\varphi(z_0)\big)^{1/2}}
\]
and consider $z(t) = (f(t)s_0, f(t)^{-1}\xi_0)$; this solves (3.2). Put $\ell(\tau,z_0) = f(1)$. Then $S_\tau$ is given by
\[
S_\tau(z) = \big(\ell(\tau,z)s, \ell(\tau,z)^{-1}\xi\big),\qquad z=(s,\xi).
\]

One can compute that
\[
\det S_\tau'(z) = |z|^2\,|S_\tau z|^{-2} \ell(\tau,z)^{d-2}
\]
by computing the matrix of $S_\tau'(z)$ on an orthonormal basis of the form
\[
\{(1,0,\dots,0),\ (0,\tfrac{\xi}{|\xi|}),\ e_3,\dots,e_d\}
\]
where $z=(s,\xi)$.

We take $p(z) = (2\pi)^{-d/2}\exp(-|z|^2/2)$ and $P(dz) = p(z)\,dz$. Then the inequality (2.1) holds for $P$ with $A=0$ and $C=1$ [G1]. We let $Y = \varphi^{-1}(1)$. Then $Y$ is a two-sheeted hyperboloid located in the interior of $U$.

Since $\delta(y) = |\varphi'(y)| = 2|By|$ one computes easily that the conditional measure $\mu_1$ on $Y$ is
\[
\mu_1(dy)
=
\mathrm{const.}\,|y|^{-1} e^{-|y|^2/2}\,d\sigma(y)
\]
where $d\sigma$ is Lebesgue surface measure on $Y$. Alternatively one may parametrize the upper sheet, say, by
\[
y = \big((1+|\eta|^2)^{1/2}, \eta\big),\qquad \eta\in\mathbb{R}^{d-1},
\]
which then gives
\[
\mu_1(d\eta) = \mathrm{const.}\,(1+|\eta|^2)^{-1/2} e^{-(1+|\eta|^2)/2}\,d\eta.
\]

With $J_\tau(z)$ defined by (3.6) and with $\omega(z)$ and $\beta(z)$ defined as in the statement of Theorem 3.3 one can show easily that $\log\beta(z)$ and $|\nabla\log\beta(z)|$ are bounded on $U$. Moreover the projection $R(z) = S_{-\varphi(z)}(z)$ from $U$ onto $Y$ has a bounded derivative on $U$. Thus the key hypothesis (2.9) holds for any choice of $u\in C_c^\infty((\varepsilon,m))$.

The vertical projection $R_x = \varphi: U\to X=(\varepsilon,m)$ does not have a bounded derivative, however, so Corollary 2.3 does not apply. In fact $|\varphi'(z)| = 2|z|$ so that (cf. (2.8))
\[
K_1(z)
=
3(m-\varepsilon) |u'(x)|^2 \frac{|\xi|^2}{|z|^2}
\]
where $x=\varphi(z)$. Because of the quadratic $|z|^2$ dependence the quantity $D_1$ (cf. (2.10)) will be infinite unless $2(m-\varepsilon)|u'(x)|^2$ is small. This can be arranged by choosing $m$ large and taking $u\in C_c^\infty((\varepsilon,m))$ to have approximately a linear increase on the first half of this interval to a height $h$ and a linear decrease on the second half. In this case the normalization $1=\int_\varepsilon^m u(x)^2 dx$ forces approximately $h^2 \sim \mathrm{const.}\,m^{-1}$ so that
\[
m\,|u'(x)|^2 \lesssim m\cdot\mathrm{const.}\,(h/m)^2
=
\mathrm{const.}\,m^{-1}.
\]
Thus for any $\alpha>0$ and for large $m$ the coefficient of $|z|^2$ in $\varepsilon_1^{-1}K_1(z)$ can be made less than $1/2$ and this will make $D_1$ finite. We note in conclusion that in this example, although one doesn’t need to include a potential $V$ in the right side of (2.11), our method yields a non-zero local norm $A_1$.

---

## 4. Logarithmic Sobolev Inequalities on Loop Groups

Let $G$ be a compact connected finite-dimensional Lie group with Lie algebra $\mathfrak{g}=T_e(G)$. We fix an $\operatorname{Ad}G$–invariant inner product on $\mathfrak{g}$ and denote by $|\cdot|$ the associated norm for an element $\xi\in\mathfrak{g}$.

Let
\[
W_e = \{ y\in C([0,1],G) : y(0) = e\}.
\]
For $x\in G$ write
\[
W_x = \{y\in W_e : y(1) = x\}.
\]
$W_e$ is a topological group under the pointwise product
\[
(y_1 y_2)(s) = y_1(s) y_2(s),\qquad 0\le s\le 1,
\]
and the topology of uniform convergence. $W_e$ is a closed subgroup, the loop group.

In this section we describe a natural gradient operation for functions on $W_e$ and prove a logarithmic Sobolev inequality for Brownian bridge measure on the “bridge space’’ $W_x$.

Let $H$ be the set of absolutely continuous functions from $[0,1]$ into $\mathfrak{g}$ such that
\[
\int_0^1 |h'(s)|^2\,ds < \infty
\quad\text{and}\quad
h(0) = 0.
\]
If $h\in H$, $y\in W_e$ and $t\in\mathbb{R}$ write
\[
(e^{th}y)(s) = \exp(th(s))\,y(s),\quad 0\le s\le1.
\]

For a real-valued function $f$ on $W_e$ and $h\in H$ put
\[
(\mathbf{a}_h f)(y)
=
\frac{d}{dt}\Big|_{t=0}f(e^{th}y)
\tag{4.1}
\]
if the derivative exists. We say $f$ has a gradient at $y$ if $h\mapsto (\mathbf{a}_h f)(y)$ is a continuous linear functional on $H$ and we define $\nabla f(y)$ as the element of $H$ determined by
\[
\big(\nabla f(y),h\big)_H = (\mathbf{a}_h f)(y).
\tag{4.2}
\]

Let
\[
H_0 = \{h\in H : h(1) = 0\}.
\]
Then $H_0$ is a closed subspace of $H$. If $y\in W_x$ and $h\in H_0$ then $(e^{th}y)(1) = y(1)=x$. So $e^{th}y$ is also in $W_x$. Hence if $f:W_x\to\mathbb{R}$ then the tangential gradient of $f$ can be defined as the element $(\nabla_x f)(y)$ of $H_0$ such that
\[
\big((\nabla_x f)(y),h\big)_H = (\mathbf{a}_h f)(y),
\qquad h\in H_0,\ y\in W_x.
\tag{4.3}
\]
$(\nabla_x f)(y)$ exists whenever the right side of (4.3) is a continuous linear functional on $H_0$.

Now let $b(t)$, $0\le t\le1$, be a $\mathfrak{g}$–valued Wiener process with $b(0)=0$ such that for $\xi,\eta\in\mathfrak{g}$ and $0\le s,t\le1$
\[
\mathbb{E}\big[ (\xi,b(s))(\eta,b(t))\big] = (\xi,\eta)\, \min(s,t).
\tag{4.4}
\]
Denote by $g(t)$ the solution to the stochastic differential equation
\[
dg(t) = db(t)\circ g(t),\qquad g(0)=e.
\tag{4.5}
\]
The stochastic differential is that of Fisk–Stratonovich [IW, Chap. 5]. As is well known [IW, Chap. 5], Eq. (4.5) has a solution which lies in $W_e$ a.s. Denote by $P$ the probability measure induced on $W_e$ by the map $b\mapsto g$. If $\{\xi_j\}$ is an orthonormal basis of $\mathfrak{g}$ and $X_j$, $j=1,\dots,d$, are the corresponding right-invariant vector fields on $G$, put
\[
\Delta = \sum_{j=1}^d X_j^2.
\]
Then $P$ is the diffusion process measure with generator $(1/2)\Delta$ and initial value $g(0) = e$.

For each point $x\in G$ there is a probability measure $p_x$ on $W_e$ with $p_x(W_x)=1$ and which is a concrete version of the conditional probability
\[
p_x(A) = P(A\mid g(1) = x),\qquad A\subset W_e.
\]

$p_x$ will be discussed in some detail in Lemmas 4.4 and 4.6.

### Theorem 4.1

There are nonnegative constants $C_1$ and $A_1$ such that for any point $x\in G$,
\[
\int_{W_x} f(y)^2 \log|f(y)|\,p_x(dy)
\;\le\;
C_1 \int_{W_x}
\Big(
|\nabla_x f(y)|_H^2
+
|b(1)|^2 f(y)^2
\Big)\,p_x(dy)
+
A_1 \|f\|_2^2
+
\|f\|_2^2 \log\|f\|_2,
\tag{4.6}
\]
where $\|f\|_2^2 = \int_{W_x} f(y)^2 p_x(dy)$. The inequality (4.6) holds at least in case $f$ has the form
\[
f(y) = v\big(y(t_1),\dots,y(t_n)\big)
\]
where $0<t_1<\dots<t_n<1$ and $v\in C^\infty(G^n)$.

The proof follows the pattern of the proof of Theorem 2.1. One constructs a tubular neighborhood $U$ of the bridge space $W_x$, identifies $U$ with a product $B_a\times W_x$ where $B_a$ is a ball in the Lie algebra corresponding to the terminal Brownian increment, and disintegrates the Wiener measure $P$ over $U$ with respect to Brownian bridge measures $p_x$ and a density $\omega(\xi,y)$. One then applies the logarithmic Sobolev inequality on Wiener space for the right Brownian motion, together with detailed estimates on the Jacobian factor $\beta=\omega^{1/2}$ and a suitable potential $V(y)\sim |b(1)|^2$, to obtain (4.6) via Theorem 2.1 and Corollary 2.3.

### Remark 4.19

The need for the potential of the form $V(y)\propto |b(1)|^2$ in (4.6) arises because the leading term $(1/4)|b(1)|^2$ in $|\nabla\log\beta(g)|^2$ (cf. (4.51)) is too large and is not controlled by taking $|\xi|$ small. The potential $V$ cancels these terms (cf. (4.53)). If one uses the more careful estimate involving an integration by parts as in Remark 2.4 or Remark 3.4 one still finds (with $C=1$)
\[
k(g)
=
\frac14 |b(1)|^2
+
\text{(small quadratic terms in $b$)}
+
\text{(linear terms in $b$)}
+
\text{(bounded terms)}
-
2\varepsilon^2 V.
\]
Hence one still needs the potential $V$ to cancel (at least part of) the term $(1/4)|b(1)|^2$ because $\varepsilon^2(1/4) > 1/2$ and $\mathbb{E}(e^{\gamma|b(1)|^2}) = \infty$ for sufficiently large $\gamma$.

### Remark 4.20

One may gain some understanding for the need of a potential $V(y)\propto |b(1)|^2$ on the right side of (4.6) by comparing the cases $G=S^1$ and $G=SU(2)$. In case $G=S^1$ the solution to the stochastic differential equation (4.5) is $g(s)=e^{ib(s)}$ where $b(s)$ lies in $i\mathbb{R}$, the Lie algebra of $S^1$. Then the loop space $W_e$ may be identified with the set of Brownian paths $b$ such that $b(1) = 2\pi n i$ for some $n\in\mathbb{Z}$. Thus $W_e$ is a countable union of connected open sets
\[
\Omega_n := \{b : b(1) = 2\pi n i\}
\]
in $W$. Clearly $h\mapsto \Omega_n$ is invariant if $h\in H_0$. Hence if $f$ is a function on $W_e$ which is constant on each $\Omega_n$ then $\mathbf{a}_h f = 0$ on $W_e$ if $h\in H_0$. Thus the tangential gradient $\nabla_x f$ is zero on $W_x$.

Let $a_n = p_x(\Omega_n)$. Then $a_n>0$ for all $n\in\mathbb{Z}$ and $\sum_n a_n = 1$. There exists a sequence $a_n\ge1$, $n\in\mathbb{Z}$, such that $\sum_n a_n^2 a_n<\infty$ and $\sum_n a_n^2(\log a_n) a_n = \infty$. If $f = a_n$ on $\Omega_n$ then
\[
\int f^2 \log|f|\,dp_x = \infty
\]
while $\|f\|_2^2 = \sum_n a_n^2 a_n<\infty$. Hence the inequality (4.6) cannot hold with $V\equiv0$.

The trouble results from the fact that functions of $b(1)$, such as the above function $f$, are invariant under translations by $H_0$. Of course one could dispense with the potential $V(y)\propto |b(1)|^2$ if one restricted attention to functions on $\Omega_0$, the connected component of the identity in the loop group $W_e$. In this case not only is $|b(1)|^2 = 0$ on $\Omega_0$ but $p_x$ is (after normalization) Gaussian on $\Omega_0$, and (4.6) is known to hold with $C_1=1$ and $A_1=0$.

By contrast, if $G=SU(2)$, then $W_e$ is connected, since $SU(2)$ is simply connected. The conditioning $g(1) = e$ imposes no constraint on the values of $b(1)$ in this case. We only know that $b(1)$ has a reasonable distribution with respect to $p_x$ (cf. Corollary 4.10). On the other hand $b(1)$ is not invariant under $H_0$: If one puts $k(s) = \exp(th(s))$ in (4.9) and differentiates with respect to $t$ at $t=0$ one gets
\[
\mathbf{a}_h b(s) = \int_0^s [h(\sigma),db(\sigma)] + h(s).
\tag{4.55}
\]
Hence even if $h(1)=0$ (i.e., $h\in H_0$), $\mathbf{a}_h b(1)$ may not be zero because $G$ is not commutative. Thus $\nabla_x f(b(1))$ is not in general zero. Nevertheless it is believed that $\|\nabla_x f(b(1))\|_{L^2(p_x)}$ is not strong enough to control $\int f^2 \log|f|\,dp_x$.

---

## 5. Hypercontractivity and Ground State

Denote by $C_c^\infty(W_x)$ functions $f:W_x\to\mathbb{R}$ of the form
\[
f(y) = v\big(y(t_1),\dots,y(t_n)\big)
\]
where $0<t_1<\dots<t_n<1$ and $v\in C^\infty(G^n)$. We consider in this section the Friedrichs extension $L$ of the operator
\[
(\nabla_x)^* \nabla_x + |b(1)|^2
\]
on $L^2(W_x,p_x)$, where $p_x$ is the Brownian bridge measure on the bridge space $W_x$, $x\in G$, and $\nabla_x : C_c^\infty(W_x)\to L^2(W_x,p_x;H_0)$ is the tangential gradient defined by (4.3). We show that $e^{-tL}$ is a positivity preserving hypercontractive semigroup and that $L$ has at least one ground state. All function spaces are real.

### Theorem 5.1

Fix $x\in G$. Write
\[
Q(f,g)
=
\int_{W_x}
\Big(
(\nabla_x f(y),\nabla_x g(y))_H
+
|b(1)|^2 f(y) g(y)
\Big)\,p_x(dy)
\tag{5.1}
\]
for $f,g\in C_c^\infty(W_x)$.

Then $Q$ has a closed extension. Let $Q$ be the minimal closed extension of $Q$ and denote by $L$ the nonnegative self-adjoint operator on $L^2(W_x,p_x)$ associated to $Q$ via the equality
\[
Q(f,g)
=
\big(L^{1/2}f,L^{1/2}g\big)_{L^2(p_x)}.
\]

Then:

(i) $e^{-tL}$ extends (or restricts) to a positivity preserving contraction on $L^p(W_x,p_x)$ for all $t\ge0$ and $1<p<\infty$.

(ii)
\[
\|e^{-tL} f\|_{L^p(p_x)}
\;\le\;
e^{M(t,q)}\|f\|_{L^q(p_x)},
\qquad 2\le q<p<\infty,
\tag{5.2}
\]
for $f\in L^q(p_x)$, where
\[
p = p(t,q) = 1 + (q-1)e^{2t/C_1},
\tag{5.3}
\]
and
\[
M(t,q) = 2A_1\big((q-1)^{-1} - (p-1)^{-1}\big),
\tag{5.4}
\]
and $A_1$ and $C_1$ are the constants that appear in (4.6).

Moreover $\inf\operatorname{spec}(L)$ is an eigenvalue with finite multiplicity and belongs to at least one nonnegative eigenfunction (a ground state).

### Lemma 5.2

$\nabla_x : C_c^\infty(W_x)\to L^2(W_x,p_x;H_0)$ has a closed extension in $L^2(W_x,p_x)$.

#### Proof

It suffices to show that $(\nabla_x)^*$ is densely defined. Let $v\in C_c^\infty(W_x)$ and $h\in C_c^\infty((0,1);\mathfrak{g})$. Since these two spaces are dense in $L^2(p_x)$ and $H_0$, respectively, linear combinations of functions of the form $F(y)=v(y)h$ are dense in $L^2(W_x,p_x;H_0)$. It suffices therefore to show that $F$ is in the domain of $(\nabla_x)^*$.

Let $f\in C_c^\infty(W_x)$. Then
\[
\begin{aligned}
\big(\nabla_x f,F\big)_{L^2(p_x;H_0)}
&=
\int_{W_x} \big(\nabla_x f(y),h\big)_H\,v(y)\,p_x(dy)\\
&=
\int_{W_x} (\mathbf{a}_h f)(y) v(y)\,p_x(dy).
\end{aligned}
\]

Choose $0<\alpha<1$ such that $f(y)$ and $v(y)$ depend only on $y|_{[0,\alpha]}$ and such that $h(s)=0$ for $s>\alpha$. Write $k(s) = e^{th(s)}$.

By Lemma 4.4 and (4.8) we have
\[
\begin{aligned}
\int_{W_x} f(e^{th}y) v(y)\,p_x(dy)
&=
\int_{W_e} f(e^{th}y) v(y)\,\frac{p_{1-\alpha}(y(\alpha)x^{-1})}{p_1(x)}\,P(dy)\\
&=
\int_{W_e} f(y) v(y)\,\frac{p_{1-\alpha}(y(\alpha)x^{-1})}{p_1(x)}\,J_t(y)\,P(dy),
\end{aligned}
\tag{5.5}
\]
where $J_t(y)$ is given by the right side of (4.8) with $k=e^{th}$ and $y=Z(b)$.

Now
\[
\frac{d}{dt}(k(s)^{-1} k(s))
\Big|_{t=0}
=
\frac{d}{dt}\Big|_{t=0} \frac{d}{ds}e^{-th(s)} e^{th(s)}
=
-h(s),
\tag{5.6}
\]
and the $t$–derivative exists uniformly in $s$. Thus
\[
\frac{d}{dt}\Big|_{t=0} J_t(y)
=
-\int_0^\alpha (h(s),db(s)).
\tag{5.7}
\]

Since the first three factors in the integrand in (5.5) are bounded we may interchange the $t$–derivative with the integral in (5.5). We get
\[
\big(\nabla_x f,F\big)_{L^2(p_x)}
=
\int_{W_x} f(y)\Big(
-(\mathbf{a}_h v)(y) + j_h(y)
\Big)\,p_x(dy),
\tag{5.8}
\]
where
\[
j_h(y) = -\int_0^\alpha (h(s),db(s)).
\]

Since $h(s)=0$ for $s>\alpha$ the integrand is $\mathcal{F}_\alpha^g$–measurable, hence
\[
\big(\nabla_x f,F\big)_{L^2(p_x)}
=
\int_{W_x} f(y)\Big(
-(\mathbf{a}_h v)(y) + j_h(y)v(y)
\Big)\,p_x(dy).
\tag{5.9}
\]
$j_h$ is in $L^2(p_x)$ by Corollary 4.10. Hence $f\mapsto(\nabla_x f,F)$ is continuous in $f$ in $L^2(p_x)$ norm and $F$ is therefore in the domain of $(\nabla_x)^*$.

### Remark 5.3

The equation (5.9) is actually valid for any $h\in H_0$, so that the corresponding function $v(y)h$ is in the domain of $(\nabla_x)^*$. The necessary estimates on $j_h$ in this case have been made in [MM, Theorem B]. Moreover a general class of Dirichlet forms on quasi-sure subvarieties of Wiener space of finite codimension has been investigated for closability and generation of processes by Airault and Van Biesen [AV], using the test function space $\mathbb{D}^{\infty}$ of the Malliavin calculus.

### Lemma 5.4

The quadratic form $Q$ defined by (5.1) has a closed extension. If $Q$ is the minimal closed extension and $L$ is the associated nonnegative self-adjoint operator associated to $Q$ (via $Q(f,g) = (L^{1/2}f,L^{1/2}g)$ for $f,g$ in $\mathcal{D}(L^{1/2})$) then $L$ satisfies conclusion (i) of Theorem 5.1.

#### Proof

If $Q_1(f,g) = \int_{W_x} (\nabla_x f,\nabla_x g)_H\,p_x(dy)$ and $Q_2(f,g) = \int_{W_x} |b(1)|^2 f(y)g(y)\,p_x(dy)$ with both domains equal to $C_c^\infty(W_x)$ then both quadratic forms are well-defined because $|b(1)|^2\in L^1(p_x)$ by Corollary 4.10.

$Q_1$ has a closed extension $Q_1$ by Lemma 5.2. The domain of $Q_1$ is in fact exactly the domain $\mathcal{D}_1$ of the closure of $\nabla_x$. $Q_2$ clearly has a closure $Q_2$ with domain
\[
\mathcal{D}_2 = \{ f\in L^2(p_x) : \int |b(1)|^2 f(y)^2\,p_x(dy)<\infty\}.
\]
$Q_1+Q_2$ is a closed extension of $Q = Q_1+Q_2$. (Of course $Q_1 + Q_2\subset Q_1 + Q_2$. It is not hard to show that equality holds, although we don’t need this.)

Now if $\varphi\in C^\infty(\mathbb{R})$ with $\varphi(0)=0$ and $0\le\varphi'(t)\le1$ and if $f\in\mathcal{D}_1$ then $\varphi\circ f\in\mathcal{D}_1$ and
\[
Q(\varphi\circ f,\varphi\circ f)
=
\int\big(\varphi'(f)^2 |\nabla_x f|^2 + |b(1)|^2\varphi(f)^2\big)\,dp_x
\le
Q(f,f).
\]
Hence $Q$ is Markovian. By [Fu, Theorem 2.1.1], $Q$ is also Markovian. Hence by the Beurling–Deny criterion (cf. [Fu, Theorem 1.4.1]), $L$ satisfies conclusion (i) of Theorem 5.1.

### Lemma 5.5 (Stroock)

Let $(\Omega,\mu)$ be a finite measure space. Let $L$ be a nonnegative self-adjoint operator on $L^2(\mu)$ such that $e^{-tL}$ is positivity preserving and is a contraction on $L^1(\mu)$. Let $\mathcal{D} = \mathcal{D}(L^{1/2})$. For $f,g\in\mathcal{D}$ put
\[
Q(f,g) = (L^{1/2}f,L^{1/2}g)_{L^2(\mu)}.
\]

If $0\le f\in L^\infty\cap\mathcal{D}$ and $2<p<\infty$ then $f^{p/2}$ and $f^{p-1}$ are in $\mathcal{D}$ and
\[
Q(f^{p/2},f^{p/2})
\;\le\;
\Big(\frac{p}{2}\Big)^2 (p-1)^{-1} Q(f,f^{p-1}),\qquad 2\le p<\infty.
\tag{5.10}
\]

#### Proof

Write $P_t = e^{-tL}$ and let $a_t(y) = (P_t1)(y)$. Then $1-a_t(y)\ge0$ a.e. because $P_t$ is a contraction on $L^1$. If $u$ and $v$ are bounded measurable functions on $\Omega$ we write
\[
(u-v)(x) = u(x) - v(x).
\]

A straightforward expansion of the right side using the symmetry of $P_t$ establishes the well-known equality
\[
\begin{aligned}
\int_\Omega (u(x)-u(y))(v(x)-v(y))\,P_t(x,dy)\,\mu(dx)
&=
\int_\Omega u(x)v(x)(1-a_t(x))\,\mu(dx)\\
&\quad+
\int_\Omega u(y)v(y)(1-a_t(y))\,\mu(dy).
\end{aligned}
\tag{5.11}
\]

Since $t^{-1}(1-e^{-t\lambda})$ increases to $\lambda$ for $\lambda\ge0$ as $t\downarrow0$, the spectral theorem shows that for any functions $u$ and $v$ in $L^2(\mu)$
\[
Q(u,v)
=
\lim_{t\downarrow0}
\frac{1}{t}
\big((I-P_t)u,v\big)_{L^2(\mu)}
\tag{5.12}
\]
if $u$ and $v$ are in $\mathcal{D}$. Moreover $u\in\mathcal{D}$ if and only if $\lim_{t\downarrow0} t^{-1}( (I-P_t)u,u)$ is finite.

Suppose $0<f(y)\le1$ for all $y\in\Omega$ and that $\alpha\ge1$. By the mean value theorem $(f(y)^\alpha - f(x)^\alpha)^2 \le \alpha^2(f(y)-f(x))^2$ while $f(y)^{2\alpha}\le f(y)^2\le \alpha f(y)^2$. Thus if we put $u=v=f^\alpha$ in (5.11) we get
\[
\int|f(y)^\alpha - f(x)^\alpha|^2 P_t(x,dy)\,\mu(dx)
\le
\alpha^2 \int|f(y)-f(x)|^2 P_t(x,dy)\,\mu(dx),
\]
which implies that $f^\alpha\in\mathcal{D}$ when $f\in\mathcal{D}$ and $0\le f\le1$.

Since $p/2\ge1$ and $p-1\ge1$ the first assertion of the lemma follows for a bounded nonnegative function $f$ by considering $Cf$ where $C=\sup f(y)$.

To prove (5.10) we assume $0\le f\le C$ is bounded. Now if $0\le g\le q$ then
\[
(g^{p/2} - h^{p/2})^2
=
\Big(\frac{p}{2}\Big)^2 (p-1)^{-1}(g-h)(g^{p-1} - h^{p-1}),
\]
hence
\[
(g^{p/2} - h^{p/2})^2
\le
\Big(\frac{p}{2}\Big)^2 (p-1)^{-1}(g-h)(g^{p-1} - h^{p-1}).
\]

Moreover $(p/2)^2(p-1)^{-1}$ is increasing on $[2,\infty)$ and is therefore $\ge1$ on $[2,\infty)$. By (5.11) we therefore have
\[
\begin{aligned}
\int |f(x)^{p/2} - f(y)^{p/2}|^2 P_t(x,dy)\,\mu(dx)
&\le
\Big(\frac{p}{2}\Big)^2 (p-1)^{-1} \int (f(x)-f(y))(f(x)^{p-1} - f(y)^{p-1})\,P_t(x,dy)\,\mu(dx)\\
&=
\Big(\frac{p}{2}\Big)^2(p-1)^{-1}\big((I-P_t)f,f^{p-1}\big)_{L^2(\mu)}.
\end{aligned}
\]

Inequality (5.10) now follows from (5.12).

### Proof of Theorem 5.1

By Theorem 4.1 we have
\[
\int_{W_x} f(y)^2 \log|f(y)|\,p_x(dy)
\le
C_1 \int_{W_x}
\big(
|\nabla_x f(y)|^2 + |b(1)|^2 f(y)^2
\big)\,p_x(dy)
+
A_1\|f\|_2^2
+
\|f\|_2^2 \log\|f\|_2
\tag{5.13}
\]
for $f\in C_c^\infty(W_x)$; here $\|f\|_2$ is the $L^2(p_x)$ norm. Moreover this inequality holds for all functions $f$ in the domain of $Q$. For there is a sequence $f_n\in C_c^\infty(W_x)$ which converges to $f$ in $L^2(p_x)$ while $Q(f_n)\to Q(f)$. Choosing a subsequence we may assume that $f_n\to f$ a.e. [p_x]. By Fatou’s lemma (5.13) holds for $f$ also because the integrand on the left is bounded below and $p_x$ is a finite measure.

Let $p\ge2$ and suppose $0\le f$ is bounded and is in the domain of $Q$. By Lemma 5.4, $e^{-tL}$ is a positivity preserving contraction semigroup on $L^q(p_x)$ for $1\le q\le\infty$, so we may apply Lemma 5.5. Thus $f^{p/2}$ and $f^{p-1}$ are in $\mathcal{D}(L^{1/2})$ and (5.13) applied to $f^{p/2}$ yields
\[
\frac{p}{2} \int f^{p/2} \log f\,dp_x
\le
\Big(\frac{p}{2}\Big)^2 (p-1)^{-1} C_1 Q(f,f^{p-1})
+
A_1\|f\|_p^p
+
\|f\|_p^p \log\|f\|_p.
\tag{5.14}
\]

Now proceed as in [G1, Corollary 2.11] on the interval $[2,\infty)$: define
\[
c(p) = \frac{p}{p-1}\frac{C_1}{2}
\]
and
\[
\gamma(p) = \frac{A_1}{c(p)}\frac{1}{p}.
\]
Solving the differential inequality arising from the semigroup and (5.14) leads to (5.2) with
\[
p(t,q) = 1 + (q-1)e^{2t/C_1}
\]
and
\[
M(t,q) = 2A_1\big((q-1)^{-1} - (p-1)^{-1}\big).
\]

To prove the existence of a ground state for $L$ take $t=1$ in (5.2) and $q=2$. Let $K = e^{M(1,2)}$ and $p = 1 + e^{2/C_1}$. Then $p>2$ and $\|e^{-L}\|_{L^2\to L^p}\le K$. Moreover $e^{-L}$ is symmetric and positivity preserving and $p_x$ is a finite measure. Hence $1/\|e^{-L}\|_{L^2\to L^2}$ is an eigenvalue of $e^{-L}$ of finite multiplicity by [G2, Theorem 1]. The eigenfunctions constructed in the proof are nonnegative. These eigenfunctions clearly belong to $\inf\operatorname{spec}(L)$.

### Remark 5.6

It is conjectured