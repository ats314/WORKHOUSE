# Canonical SU(3), order-four cubic denominator ledger

This is a fresh-process, read-only certificate generator. It reconstructs the scaled charge-odd two-step half-history directly from exact SU(3) electric/Fierz algebra and exact representation projectors. It never imports repository code or reads a target coefficient while constructing the history ledger or `QBOUND`.

## What is now derived

For the canonical scope—Hamiltonian SU(3), periodic cubic `L=5`, `T1+-`, polarization `(0,1)`, two magnetic insertions per half-history—the generator produces:

- exact `W2` and `R2` coefficients as `fractions.Fraction` values;
- a canonical external ledger containing all 164,662 exact `W2/R2` state coefficients;
- exact fusion-projector and reduced-resolvent factor ledgers, with roles and provenance;
- an independent compatibility census over every H0-matched state pair;
- a conservative Haar divisor derived from the seven supported local projector denominators and the verified 24-occurrence cap;
- a target-independent, exponent-sensitive `QBOUND` frozen and hashed before `constants.py` is audited;
- an independent exact scalar-P recurrence that derives the analytic one-face term `-13/896` from a four-state H0/interaction model rather than accepting that coefficient as input.

The exact compatibility pass reproduces the historical source's intended structural census:

- 5,400 matched H0 blocks;
- 9,814,138 raw-pair upper bound;
- 54 analytic one-face matches;
- 2,468,250 center-compatible state pairs;
- precisely seven observed Haar patterns and no unsupported pattern;
- maximum bra/ket occurrence count 24.

The resulting exact-history / universal-Haar bound is

```text
QBOUND = 62895057857493885215590055852113920000000
       = 2^36 3^20 5^7 7 11 13 17^3 19 23 29 31 37 47.
```

This is deliberately conservative. It is derived before targets as

```text
lcm(896, 2 * LCM(den W2) * LCM(den R2) * universal_Haar_divisor).
```

The pair-weight denominator divides `LCM(den W2) * LCM(den R2)` because each pair weight is an integer sum of products of one exact `W2` and one exact `R2` coefficient. The universal Haar divisor is computed prime-by-prime over every combination of declared local patterns consuming at most 24 occurrences. Therefore each compatible term denominator divides the displayed `QBOUND` without examining a target coefficient.

The exact history itself derives the rank/order support

```text
{2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 47}.
```

In particular, 23 and 47 enter through exact nonresonant `R2` energy gaps. They are not fitted from a published or historical target denominator.

For comparison, the independent path-level envelope is

```text
QPATH = 4302674844130269372677454153332635148085549843213189120000000
      = 2^56 3^45 5^7 7^2 11^2 13 17^3 19 23 29 31 37 47.
```

The generated-history bound divides that conservative envelope exactly.  The quotient is

```text
QPATH / QBOUND = 68410380572018343936 = 2^20 3^25 7 11.
```

The large reduction is not a target-driven tightening. `QPATH` applies local-H denominator-6 worst cases to 9,392 W2 and 9,201 R2 paths before trace-network terms are added and reduced. `QBOUND` first derives every one of the 82,384 W2 and 82,278 nonresonant R2 trace-network coefficients symbolically, then takes their actual denominator LCMs. Both bounds retain the same universal endpoint-Haar exponent envelope `2^18 3^12 5^4`; neither uses a fitted target denominator.

## Freeze protocol

`generate` performs this order of operations:

1. reject every JSON float, unknown field, missing completeness assertion, unclassified factor, or mismatched source hash;
2. generate `W1 -> R1 -> W2 -> R2` using exact arithmetic only;
3. subtract the exact scaled plaquette `P0` band supportwise in every W1/W2 `E0` physical block, require every residual Gram norm to be exactly zero, then record exact `gap == 0` exclusions;
4. run the independent H0/center-flux/Haar-pattern completeness census;
5. derive the denominator envelopes and `QBOUND` by two arithmetic routes;
6. canonicalize and hash the full history ledger;
7. write temporary files, re-read and verify both hashes, then atomically publish the frozen files.

Existing frozen files are never overwritten. `audit` then re-verifies the freeze and history hashes before reading `constants.py`. Target data therefore cannot alter the ledger or bound.

## Run

From this directory, with Python 3.11 or newer:

```text
python ledger_generator.py --repo ../WORKHOUSE-readonly generate \
  --primitives primitive_rank3_order4_cubic.json --out canonical-run

python ledger_generator.py --repo ../WORKHOUSE-readonly audit \
  --targets targets_rank3_order4_cubic.json --out canonical-run

python -m unittest -v test_ledger_generator.py
```

Generation takes roughly one minute on the current CPU and writes a roughly 46 MB uncompressed exact history ledger. The tool has no third-party dependencies.

## Fail-closed behavior

- Decimal or inferred floats are forbidden throughout primitive input, frozen output, and target manifests.
- Every completeness switch must be literally `true`.
- Every primitive and every final prime-power contribution requires a role and provenance.
- All pinned source-document hashes must match the read-only snapshot.
- A missing/nonexact enforced target, unsupported Haar pattern, exceeded occurrence cap, census drift, QBOUND factor mismatch, or hash mutation is fatal.
- `LINKED_VACUUM_4_ARTIFACT` is quarantined. Its generic prime denominator is supporting forensic evidence, not an automatic mathematical verdict.

## Boundary

This is an **exact Q-reduced denominator certificate**, not the missing exact fourth-order scalar evaluation. It does not contract and sum the 117,161 canonical Haar topologies, produce `D_EXACT`, or certify the injected fold term. The reduced resolvent's `E0-H0 == 0` test and exclusion are exact. Before exclusion, the generator constructs the scaled plaquette band, computes its SU(3) Haar Gram projection support by support, and proves exact zero residual norm in 1 W1 and 25 W2 resonant physical blocks. The certificate therefore has no unresolved `P0`-cancellation premise. A full fourth-order coefficient certificate must still compute exact endpoint-Haar numerators and perform the topology sum over this frozen input lineage.
