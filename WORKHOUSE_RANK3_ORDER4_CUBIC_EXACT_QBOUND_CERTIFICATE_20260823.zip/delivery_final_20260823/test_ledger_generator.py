from __future__ import annotations

import copy
import json
import shutil
import tempfile
import unittest
from pathlib import Path

import ledger_generator as generator


HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "WORKHOUSE-readonly"
PRIMITIVES = HERE / "primitive_rank3_order4_cubic.json"
TARGETS = HERE / "targets_rank3_order4_cubic.json"


class FastFailClosedTests(unittest.TestCase):
    def setUp(self):
        self.spec = json.loads(PRIMITIVES.read_text(encoding="utf-8"))

    def test_float_is_rejected(self):
        spec = copy.deepcopy(self.spec)
        spec["scope"]["extent"] = 5.0
        with self.assertRaisesRegex(generator.ClosedGate, "float is forbidden"):
            generator.validate_primitives(spec, REPO)

    def test_missing_completeness_is_rejected(self):
        spec = copy.deepcopy(self.spec)
        spec["completeness"]["all_fusion_outputs"] = False
        with self.assertRaisesRegex(generator.ClosedGate, "completeness assertions"):
            generator.validate_primitives(spec, REPO)

    def test_missing_factor_provenance_is_rejected(self):
        spec = copy.deepcopy(self.spec)
        spec["electric_algebra"]["factor_metadata"][0]["provenance"] = ""
        with self.assertRaisesRegex(generator.ClosedGate, "lacks role/provenance"):
            generator.validate_primitives(spec, REPO)

    def test_source_hash_mismatch_is_rejected(self):
        spec = copy.deepcopy(self.spec)
        spec["source_documents"][0]["sha256"] = "0" * 64
        with self.assertRaisesRegex(generator.ClosedGate, "source hash mismatch"):
            generator.validate_primitives(spec, REPO)

    def test_haar_divisor_is_independently_recomputed(self):
        divisor, exponents = generator.universal_haar_divisor(
            self.spec["haar_projectors"], self.spec["assembly"]["haar_occurrence_cap"]
        )
        self.assertEqual(exponents, {2: 18, 3: 12, 5: 4})
        self.assertEqual(divisor, 2**18 * 3**12 * 5**4)

    def test_one_face_term_is_derived_not_supplied(self):
        self.assertNotIn("-13/896", PRIMITIVES.read_text(encoding="utf-8"))
        coefficients = generator.exact_one_face_recurrence(
            self.spec["assembly"]["analytic_one_face_model"]
        )
        self.assertEqual(coefficients[4], generator.Fraction(-13, 896))


class FullExactIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.out = Path(cls.temp.name) / "frozen"
        cls.freeze = generator.generate(REPO, PRIMITIVES, cls.out)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def test_exact_history_regression_and_hash(self):
        stages = self.freeze["history_summary"]["stages"]
        self.assertEqual(stages["w2"], {"supports": 171, "signature_blocks": 6805, "coefficients": 82384})
        self.assertEqual(stages["r2"], {"supports": 171, "signature_blocks": 6755, "coefficients": 82278})
        self.assertEqual(self.freeze["history_ledger"]["records"], 164662)
        self.assertEqual(
            self.freeze["history_ledger"]["sha256"],
            "543869b10f5137ea74fbd5f27d25027dea66f936ce9844b77a029453b8bf8c97",
        )

    def test_independent_compatibility_census_closes_haar_patterns(self):
        census = self.freeze["history_summary"]["compatibility_census"]
        self.assertEqual(census["matched_h0_blocks"], 5400)
        self.assertEqual(census["raw_pair_upper_bound"], 9814138)
        self.assertEqual(census["skipped_one_face_matches"], 54)
        self.assertEqual(census["max_bra_ket_occurrences"], 24)
        self.assertEqual(census["unsupported_haar_patterns"], [])
        self.assertEqual(
            census["observed_haar_patterns"],
            [[0, 3], [0, 6], [1, 1], [2, 2], [3, 0], [3, 3], [6, 0]],
        )

    def test_qbound_is_derived_and_factor_complete(self):
        qbound = int(self.freeze["qbound"]["value"])
        self.assertEqual(qbound, 62895057857493885215590055852113920000000)
        self.assertEqual(
            [row["prime"] for row in self.freeze["qbound"]["factorization"]],
            [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 47],
        )
        reconstructed = 1
        for row in self.freeze["qbound"]["factorization"]:
            reconstructed *= row["prime"] ** row["exponent"]
            self.assertTrue(row["contributions"])
            for contribution in row["contributions"]:
                self.assertTrue(contribution["role"])
                self.assertTrue(contribution["provenance"])
        self.assertEqual(reconstructed, qbound)
        self.assertTrue(all(self.freeze["self_checks"].values()))

    def test_e0_p0_cancellation_is_exactly_certified(self):
        self.assertEqual(self.freeze["certificate_status"], "exact-q-reduced-denominator-certificate")
        self.assertEqual(self.freeze["unresolved_premises"], {})
        requirement = self.freeze["verified_e0_requirement"]["e0_p0_residual_cancellation"]
        self.assertEqual(requirement["status"], "verification-required")
        scope = self.freeze["history_summary"]["e0_scope"]
        self.assertTrue(scope["p0_residual_cancellation_inside_resonant_block_verified"])
        self.assertGreater(scope["resonant_signature_blocks_excluded_across_r1_r2"], 0)
        self.assertEqual([row["groups"] for row in scope["certificates"]], [1, 25])
        self.assertTrue(all(row["all_residual_norms_exactly_zero"] for row in scope["certificates"]))

    def test_tighter_bound_divides_independent_path_envelope(self):
        relation = self.freeze["bound_comparison"]["relation"]
        self.assertTrue(relation["symbolic_history_bound_divides_path_envelope"])
        self.assertEqual(relation["quotient"], "68410380572018343936")
        self.assertEqual(relation["quotient_factorization"], {"2": 20, "3": 25, "7": 1, "11": 1})

    def test_frozen_hashes_verify_after_re_read(self):
        verified = generator.verify_freeze(self.out)
        self.assertEqual(verified["freeze_sha256"], self.freeze["freeze_sha256"])

    def test_target_audit_occurs_after_freeze_and_cannot_change_qbound(self):
        freeze_path = self.out / "rank3_order4_cubic_freeze.json"
        before = freeze_path.read_bytes()
        before_qbound = self.freeze["qbound"]["value"]
        report = generator.audit_targets(REPO, TARGETS, self.out)
        after = freeze_path.read_bytes()
        self.assertTrue(report["ok"], report["errors"])
        self.assertEqual(report["summary"], {"targets": 11, "enforced": 10, "quarantined": 1, "errors": 0})
        self.assertEqual(before, after)
        self.assertEqual(report["frozen_qbound"]["value"], before_qbound)

    def test_quarantined_generic_prime_is_not_auto_adjudicated(self):
        report = generator.audit_targets(REPO, TARGETS, self.out)
        artifact = next(row for row in report["targets"] if row["symbol"] == "LINKED_VACUUM_4_ARTIFACT")
        self.assertEqual(artifact["policy"], "quarantine")
        self.assertEqual(artifact["denominator_divides_frozen_qbound"], "not-enforced")

    def test_tampered_freeze_fails_closed(self):
        tampered = Path(self.temp.name) / "tampered"
        tampered.mkdir()
        shutil.copy2(self.out / "rank3_order4_cubic_history_ledger.json", tampered)
        freeze = json.loads((self.out / "rank3_order4_cubic_freeze.json").read_text(encoding="utf-8"))
        freeze["qbound"]["value"] = "1"
        generator.write_canonical_json(tampered / "rank3_order4_cubic_freeze.json", freeze)
        with self.assertRaisesRegex(generator.ClosedGate, "freeze self-hash mismatch"):
            generator.verify_freeze(tampered)

    def test_existing_freeze_is_never_overwritten(self):
        with self.assertRaisesRegex(generator.ClosedGate, "refusing to overwrite"):
            generator.generate(REPO, PRIMITIVES, self.out)


if __name__ == "__main__":
    unittest.main(verbosity=2)
