#!/usr/bin/env python3
"""Exact SU(3) Haar certificate for the E0/P0 resonant-block gate.

This is an independent proof harness around ``ledger_generator.py``.  It
rebuilds source -> W1 -> R1 -> W2 with ``fractions.Fraction``, extracts every
signature at E0=8/3, and evaluates its squared distance from the exact
one-plaquette C-odd P0 span.  No floating point or target coefficient enters.

Only the local Haar cases that actually occur in this gate are implemented:

* (1 U, 1 Ubar), via delta-delta / 3;
* (2 U, 2 Ubar), via the S2 unitary Weingarten values 1/8 and -1/24;
* (3 U, 0 Ubar) and its conjugate, via epsilon-epsilon / 6.

Any other center-neutral local occurrence pattern fails closed.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import itertools
import json
import sys
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
GENERATOR_PATH = ROOT / "work" / "rank3_order4_cubic_ledger" / "ledger_generator.py"
E0 = Fraction(8, 3)
RANK = 3
SCHEMA = "workhouse.rank3-order4-cubic-e0-p0-haar-certificate/v1"


def ftext(value: Fraction) -> str:
    return f"{value.numerator}/{value.denominator}"


def canonical_bytes(value) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_generator():
    module_spec = importlib.util.spec_from_file_location("rank3_order4_generator", GENERATOR_PATH)
    if module_spec is None or module_spec.loader is None:
        raise RuntimeError("cannot load ledger generator")
    module = importlib.util.module_from_spec(module_spec)
    sys.modules[module_spec.name] = module
    module_spec.loader.exec_module(module)
    return module


class UnionFind:
    def __init__(self, size: int):
        self.parent = list(range(size))

    def clone(self):
        result = UnionFind(0)
        result.parent = self.parent.copy()
        return result

    def find(self, value: int) -> int:
        while self.parent[value] != value:
            self.parent[value] = self.parent[self.parent[value]]
            value = self.parent[value]
        return value

    def union(self, left: int, right: int) -> None:
        left, right = self.find(left), self.find(right)
        if left != right:
            self.parent[right] = left

    def classes(self) -> int:
        return len({self.find(index) for index in range(len(self.parent))})


def permutation_sign(permutation: tuple[int, ...]) -> int:
    inversions = sum(
        permutation[left] > permutation[right]
        for left in range(len(permutation))
        for right in range(left + 1, len(permutation))
    )
    return -1 if inversions % 2 else 1


def local_haar_terms(unbarred, barred, pattern_log: Counter):
    """Return exact (coefficient, delta-unions) terms for one SU(3) link."""
    p, q = len(unbarred), len(barred)
    pattern_log[(p, q)] += 1
    if (p - q) % RANK:
        return ()
    if (p, q) == (1, 1):
        u, b = unbarred[0], barred[0]
        return ((Fraction(1, 3), ((u[0], b[0]), (u[1], b[1]))),)
    if (p, q) == (2, 2):
        permutations = ((0, 1), (1, 0))
        terms = []
        for sigma in permutations:
            for tau in permutations:
                coefficient = Fraction(1, 8) if sigma == tau else Fraction(-1, 24)
                unions = []
                for index in range(2):
                    unions.append((unbarred[index][0], barred[sigma[index]][0]))
                    unions.append((unbarred[index][1], barred[tau[index]][1]))
                terms.append((coefficient, tuple(unions)))
        return tuple(terms)
    if (p, q) in ((3, 0), (0, 3)):
        occurrences = unbarred if p == 3 else barred
        terms = []
        for permutation in itertools.permutations(range(3)):
            unions = tuple(
                (occurrences[index][0], occurrences[permutation[index]][1])
                for index in range(3)
            )
            terms.append((Fraction(permutation_sign(permutation), 6), unions))
        return tuple(terms)
    raise RuntimeError(f"unsupported center-neutral SU(3) local Haar pattern {(p, q)}")


HAAR_PATTERN_LOG = Counter()


@lru_cache(maxsize=None)
def state_inner(left, right) -> Fraction:
    """Exact Haar inner product, conjugating ``left``."""
    left_slots = 2 * len(left.occ)
    total_slots = left_slots + 2 * len(right.occ)
    base = UnionFind(total_slots)

    first_by_label = {}
    for slot, label in enumerate(left.part):
        if label in first_by_label:
            base.union(slot, first_by_label[label])
        else:
            first_by_label[label] = slot
    first_by_label = {}
    for local_slot, label in enumerate(right.part):
        slot = left_slots + local_slot
        if label in first_by_label:
            base.union(slot, first_by_label[label])
        else:
            first_by_label[label] = slot

    by_link = defaultdict(lambda: [[], []])
    for index, (link, orientation) in enumerate(left.occ):
        # The bra is complex-conjugated: U <-> Ubar, indices unchanged.
        is_unbarred = not orientation
        by_link[link][0 if is_unbarred else 1].append((2 * index, 2 * index + 1))
    for index, (link, orientation) in enumerate(right.occ):
        slots = (left_slots + 2 * index, left_slots + 2 * index + 1)
        by_link[link][0 if orientation else 1].append(slots)

    link_terms = []
    for link in sorted(by_link):
        terms = local_haar_terms(tuple(by_link[link][0]), tuple(by_link[link][1]), HAAR_PATTERN_LOG)
        if not terms:
            return Fraction()
        link_terms.append(terms)

    total = Fraction()

    def visit(index: int, coefficient: Fraction, unions: UnionFind) -> None:
        nonlocal total
        if index == len(link_terms):
            total += coefficient * (RANK ** unions.classes())
            return
        for factor, pairs in link_terms[index]:
            next_unions = unions.clone()
            for left_slot, right_slot in pairs:
                next_unions.union(left_slot, right_slot)
            visit(index + 1, coefficient * factor, next_unions)

    visit(0, Fraction(1), base)
    return total


def vector_inner(left, right) -> Fraction:
    total = Fraction()
    for left_state, left_coefficient in left.items():
        for right_state, right_coefficient in right.items():
            total += left_coefficient * right_coefficient * state_inner(left_state, right_state)
    return total


def merge_vectors(vectors):
    result = defaultdict(Fraction)
    for vector in vectors:
        for state, coefficient in vector.items():
            result[state] += coefficient
    return {state: coefficient for state, coefficient in result.items() if coefficient}


def flatten_state_map(state_map):
    return merge_vectors(state_map.values())


def resonant_vector(state_map, generator):
    return merge_vectors(
        vector
        for signature, vector in state_map.items()
        if generator.signature_energy(signature) == E0
    )


def all_p0_sources(complex_, generator):
    result = []
    for face in range(len(complex_.faces)):
        labeled = generator.initial_source(complex_, face)
        result.append(flatten_state_map(next(iter(labeled.values()))))
    return result


def source_gram_certificate(p0):
    diagonal = []
    nonzero_off_diagonal = []
    for left in range(len(p0)):
        diagonal.append(vector_inner(p0[left], p0[left]))
        for right in range(left):
            value = vector_inner(p0[left], p0[right])
            if value:
                nonzero_off_diagonal.append((left, right, value))
    if set(diagonal) != {Fraction(2)} or nonzero_off_diagonal:
        raise RuntimeError(
            f"P0 Gram is not 2I: diagonal={set(diagonal)}, offdiag={nonzero_off_diagonal[:3]}"
        )
    return {
        "dimension": len(p0),
        "diagonal": "2/1",
        "nonzero_off_diagonal_entries": 0,
        "status": "exactly-2I",
    }


def certify_stage(name, stage, p0, generator):
    rows = []
    for support, state_map in sorted(stage.items(), key=lambda item: tuple(sorted(item[0]))):
        vector = resonant_vector(state_map, generator)
        if not vector:
            continue
        norm = vector_inner(vector, vector)
        overlaps = []
        projection_norm = Fraction()
        for face, basis in enumerate(p0):
            overlap = vector_inner(basis, vector)
            if overlap:
                coefficient = overlap / 2
                overlaps.append({
                    "face": face,
                    "overlap": ftext(overlap),
                    "p0_coefficient": ftext(coefficient),
                })
                projection_norm += overlap * overlap / 2
        residual_norm = norm - projection_norm
        if residual_norm != 0:
            raise RuntimeError(
                f"{name} support {sorted(support)} has nonzero exact P0 residual norm {ftext(residual_norm)}"
            )
        rows.append({
            "support": sorted(support),
            "resonant_signature_blocks": sum(
                generator.signature_energy(signature) == E0 for signature in state_map
            ),
            "resonant_monomials_after_merge": len(vector),
            "norm_squared": ftext(norm),
            "projection_norm_squared": ftext(projection_norm),
            "residual_norm_squared": ftext(residual_norm),
            "p0_expansion": overlaps,
        })
    return {
        "stage": name,
        "resonant_supports": len(rows),
        "all_residual_norms_zero": all(row["residual_norm_squared"] == "0/1" for row in rows),
        "blocks": rows,
    }


def resonant_vectors_by_support(stage, generator):
    return [
        resonant_vector(state_map, generator)
        for _, state_map in sorted(stage.items(), key=lambda item: tuple(sorted(item[0])))
        if resonant_vector(state_map, generator)
    ]


def crosscheck_native_inner(generator, complex_, p0, w1, w2):
    """Compare every independently used state-pair value to the integrated routine."""
    pairs = set()
    for left_index, left_vector in enumerate(p0):
        for right_vector in p0[: left_index + 1]:
            pairs.update(itertools.product(left_vector, right_vector))
    for vector in resonant_vectors_by_support(w1, generator) + resonant_vectors_by_support(w2, generator):
        pairs.update(itertools.product(vector, vector))
        for basis in p0:
            pairs.update(itertools.product(basis, vector))
    for left, right in pairs:
        independent = state_inner(left, right)
        integrated = generator.haar_inner_e0_exact(left, right, RANK)
        if independent != integrated:
            raise RuntimeError(
                "integrated Haar mismatch: "
                f"independent={ftext(independent)}, integrated={ftext(integrated)}"
            )
    native_w1 = generator.prove_e0_p0_cancellation(complex_, w1, E0, RANK, "W1")
    native_w2 = generator.prove_e0_p0_cancellation(complex_, w2, E0, RANK, "W2")
    if [native_w1["groups"], native_w2["groups"]] != [1, 25]:
        raise RuntimeError("integrated certificate group-count drift")
    if not all(
        row["all_residual_norms_exactly_zero"] for row in (native_w1, native_w2)
    ):
        raise RuntimeError("integrated certificate reports a nonzero residual")
    return {
        "distinct_state_pairs_compared": len(pairs),
        "all_exact_inner_products_agree": True,
        "integrated_physical_block_groups": {
            "W1": native_w1["groups"],
            "W2": native_w2["groups"],
        },
        "integrated_all_residual_norms_zero": True,
    }


def build_certificate():
    generator = load_generator()
    complex_ = generator.CubicComplex(4)
    anchor = complex_.anchor_face((0, 1))
    events = generator.EventLog.empty()
    source = generator.initial_source(complex_, anchor)
    w1 = generator.apply_w_labeled(complex_, source, RANK, events)
    policy = getattr(
        generator,
        "E0_VERIFIED_POLICY",
        getattr(generator, "E0_UNRESOLVED_POLICY", None),
    )
    if policy is None:
        raise RuntimeError("generator exposes no explicit E0 resolvent policy")
    r1 = generator.resolvent_labeled(
        w1, E0, events, resonant_policy=policy
    )
    w2 = generator.apply_w_labeled(complex_, r1, RANK, events)

    p0 = all_p0_sources(complex_, generator)
    gram = source_gram_certificate(p0)
    w1_certificate = certify_stage("W1", w1, p0, generator)
    w2_certificate = certify_stage("W2", w2, p0, generator)
    native_crosscheck = crosscheck_native_inner(generator, complex_, p0, w1, w2)
    certificate = {
        "schema_version": SCHEMA,
        "scope": {
            "group": "SU(3)",
            "rank": 3,
            "order": 4,
            "geometry": "periodic-cubic",
            "extent": 4,
            "sector": "C-odd one-plaquette band",
            "e0": "8/3",
            "anchor_face": anchor,
        },
        "lineage": {
            "generator_path": str(GENERATOR_PATH.relative_to(ROOT)).replace("\\", "/"),
            "generator_sha256": sha256_file(GENERATOR_PATH),
            "proof_harness_sha256": sha256_file(Path(__file__).resolve()),
        },
        "arithmetic": {
            "scalar_type": "fractions.Fraction",
            "floating_point_used": False,
            "haar_formulas": {
                "1,1": "delta(row)*delta(column)/3",
                "2,2": "S2 Weingarten: Wg(identity)=1/8, Wg(transposition)=-1/24",
                "3,0_and_0,3": "epsilon(row)*epsilon(column)/6 = determinant(delta)/6",
            },
            "encountered_local_patterns": {
                f"{p},{q}": count for (p, q), count in sorted(HAAR_PATTERN_LOG.items())
            },
        },
        "p0_gram": gram,
        "integrated_implementation_crosscheck": native_crosscheck,
        "stage_certificates": [w1_certificate, w2_certificate],
        "gate": {
            "p0_residual_cancellation_inside_resonant_block_verified": (
                w1_certificate["all_residual_norms_zero"]
                and w2_certificate["all_residual_norms_zero"]
            ),
            "meaning": (
                "For every separately labeled history support, the exact E0 component has zero "
                "Haar norm after projection onto the full translated/oriented C-odd one-plaquette "
                "span. Therefore dropping E0 signatures in the reduced resolvent equals applying Q=1-P0."
            ),
        },
    }
    return certificate


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    certificate = build_certificate()
    payload = canonical_bytes(certificate)
    if arguments.output:
        arguments.output.parent.mkdir(parents=True, exist_ok=True)
        arguments.output.write_bytes(payload)
    print(json.dumps({
        "certificate_sha256": hashlib.sha256(payload).hexdigest(),
        "gate": certificate["gate"],
        "p0_gram": certificate["p0_gram"],
        "stage_summary": [
            {
                "stage": row["stage"],
                "resonant_supports": row["resonant_supports"],
                "all_residual_norms_zero": row["all_residual_norms_zero"],
            }
            for row in certificate["stage_certificates"]
        ],
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
