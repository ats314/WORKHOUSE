# Independent exact E0/P0 gate audit

Result: **confirmed; no counterexample found**.

`certify_e0_p0.py` is an independent `fractions.Fraction`/union-find Haar
contraction harness.  It imports the history construction but does not call the
integrated Haar routine for its proof.  It then cross-checks its values against
the integrated routine as a separate regression.

## Exact results

- The 192 translated/oriented scaled C-odd plaquette vectors have Gram matrix
  exactly `2 I`: every diagonal is `2/1` and every off-diagonal is `0/1`.
- W1 has one resonant support.  Its exact norm is `2/1`, its P0 projection norm
  is `2/1`, and its residual norm is `0/1`; it equals the face-0 scaled
  plaquette vector with coefficient `1/1`.
- W2 has 13 resonant history supports.  Every support-total residual norm is
  exactly `0/1`.  The integrated code refines these into 25 physical blocks,
  all with exact zero residual.
- 98,698 distinct state-pair Haar values agree exactly between the independent
  union-find implementation and the integrated partition-merging
  implementation.

The detailed exact coefficients and norms are in `e0_p0_certificate.json`.

## Haar scope

The nonzero center-neutral local contractions needed by this gate are:

- `(1,1)`: delta/delta divided by 3;
- `(2,2)`: S2 Weingarten values `1/8` and `-1/24`;
- `(3,0)` and `(0,3)`: the SU(3) determinant identity
  `epsilon(row) epsilon(column) / 6`.

Thus the informal expectation that the whole gate needs only balanced `k=1`
is too narrow: W2 reduces to `k=1`, but W1's norm uses `(2,2)` and its overlap
with the one-plaquette band uses the determinant `(3,0)/(0,3)` contraction.
The integrated generator includes both cases correctly.

## Integration recommendation

The current integrated `haar_inner_e0_exact` and
`prove_e0_p0_cancellation` implementation is mathematically consistent with
the independent audit and can replace the unresolved E0 premise.  Keep the
existing fail-closed 1-W1/25-W2 block-count test.  Also retain or expose the
fixed-scope `P0 Gram = 2 I` check, because the sequential projection is an
orthogonal projector here precisely because that Gram fact holds.

After any generator edit, regenerate the frozen ledger so its generator hash
and embedded E0 certificate remain in the same lineage.

## Reproduction

From the workspace root, using the managed Python 3.12 runtime:

```text
uv run --no-project --python 3.12 python work/exact_e0_p0_gate/certify_e0_p0.py \
  --output work/exact_e0_p0_gate/e0_p0_certificate.json
```

Current hashes:

- harness SHA-256: `2fb6bdf3312c17af802c975d49dfce8379d9aa3d1a8a3db03ec51c20f5227ed3`
- certificate SHA-256: `1eb7980d44261c09fd995192021c93b61f5645b5b86423fe7bf41f02b2abbc42`
