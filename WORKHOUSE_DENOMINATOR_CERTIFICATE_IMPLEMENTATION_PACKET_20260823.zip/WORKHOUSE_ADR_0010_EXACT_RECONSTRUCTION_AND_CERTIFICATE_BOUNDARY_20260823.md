# ADR-0010: Replace heuristic rationalization with symbolic or enclosure-certified reconstruction

**Status:** Proposed  
**Date:** 2026-08-23  
**Deciders:** WORKHOUSE maintainer and mathematical-audit owner  
**Scope:** Exact coefficient recovery, denominator-lift certification, modular reconstruction, and the boundary between large computational ledgers and the Lean-checked core

## Executive decision

WORKHOUSE should adopt a hybrid exactness architecture:

1. Generate coefficients symbolically in an exact domain whenever the algebra permits it.
2. Where a large contraction cannot yet be performed symbolically, evaluate it with outward-rounded ball arithmetic and certify a unique point on a pre-derived denominator grid.
3. Construct an exponent-sensitive `QBOUND` from typed primitive factors and prove every term denominator divides it.
4. Prefer denominator-cleared integer CRT when modular computation is useful; use bounded rational reconstruction only when no denominator divisor is available.
5. Store large history/topology ledgers outside Lean as canonical, chunked, SHA-256-bound artifacts. A streaming verifier checks every record and emits a small arithmetic certificate.
6. Have Lean verify the small certificate's localization, divisibility, grid-uniqueness, exact-sum, and CRT-uniqueness claims. Lean does not pretend to prove topology completeness or SHA-256 collision resistance.

`Fraction.limit_denominator()`, ordinary `float`, `numpy.longdouble`, fitted prime ceilings, and comparisons to historical target values may remain diagnostics. None may contribute to an artifact labeled exact.

## Context and evidence boundary

The current fourth-order denominator-lift notebook already contains most of the right architecture:

- It declares a scoped prime set
  `S4_PRIMES={2,3,5,7,11,13,17,19,23,29,31,37,47}`.
- It derives local Haar denominator multiples from the supported local patterns:
  `(1,1):3`, `(2,2):24`, `(3,3):120`, determinant patterns `:6`, and pure-six patterns `:72`.
- It constructs `QBOUND` as the prime-exponent LCM of every term denominator and checks `termden | QBOUND` before accumulating one integer numerator.
- It reduces `TOTAL_NUM/QBOUND` only after the accumulation.

Those stages are exact relative to their inputs. The two unresolved boundaries are earlier:

1. History coefficients are inferred by multiplying a binary float by `sqrt(2)`, running `limit_denominator()` with two ceilings, and accepting agreement plus a residual and prime-support check.
2. Haar contractions are evaluated with binary64, rounded after multiplication by `q_H`, and checked on samples with a dense contractor and on the largest residuals with platform-dependent `longdouble`.

These are strong diagnostics, but neither is a proof that the selected rational or integer is unique. Wrapping the output in `Fraction` does not change that fact.

The repository audit `corpus-import/records/audits/07-denominator-lift.md` also records that the notebook has no stored execution, serialized ledger, environment record, or output hash. Its injected fold literal is not bound to a producing certificate. A same-kernel recovery path has no up-front hash or version check.

The native fifth-order string-tension certificate supplies a useful modular precedent: seven residues are CRT-combined and Wang-reconstructed, with exact round trips and a uniqueness bound. Its next revision should bind the per-prime input files and engine by digest, record the exact combined modulus and a priori bounds, and replace bit-length summaries with the exact uniqueness inequality.

Source snapshot reviewed: repository commit `4f5f02c6ddba06c4ab84f393e0c3548591865d65`.

## Decision principles

### Exactness labels

Every result must carry exactly one of these machine-readable methods:

| Method | Meaning | Permitted evidence label |
|---|---|---|
| `symbolic-v1` | All value-producing operations use exact integers, rationals, or a declared exact algebraic domain. | exact, relative to enumeration/model inputs |
| `interval-grid-v1` | A directed-rounding engine encloses the full computation, and a pre-derived denominator divisor makes the enclosed rational unique. | interval-certified exact, with interval backend in the trust boundary |
| `integer-crt-v1` | A denominator-cleared integer is reconstructed from coprime modular residues under an a priori magnitude bound. | CRT-certified exact, relative to modular engines and completeness |
| `rational-crt-v1` | A rational is reconstructed under separate a priori numerator and denominator bounds and an exact uniqueness inequality. | CRT-certified exact, relative to modular engines and completeness |
| `heuristic-v1` | Continued-fraction recovery, target agreement, binary64 residuals, smoothness, or unenclosed high precision. | diagnostic only |

No certificate may silently upgrade from `heuristic-v1` because several diagnostics agree.

### Proof inputs versus forensic metadata

The proof path uses a finite denominator **divisor**, including prime exponents. An allowed-prime set alone is insufficient because it gives no finite grid spacing.

The following values are kept separate:

- `qbound`: derived from typed primitives and term construction; proof-bearing.
- `derived_pmax`: the largest prime in the factorization of that explicit `qbound`; proof-bearing only as a consequence of `qbound`.
- `observed_pmax`: the largest prime in a reduced output denominator; descriptive.
- `fitted_pmax`: a rank/order trend inferred from prior coefficients; predictive metadata only.
- `lcm_fingerprint`: a descriptive comparison of prime exponents; forensic metadata only unless it is literally the factorization of a derived `qbound`.

This separation is mandatory. A generic-looking large prime is not proof of a float reconstruction. A legitimate resolvent can contain one; repeated gaps can give a large prime an exponent above one; and cancellations can remove any prime from the reduced result.

## Architecture

```mermaid
flowchart LR
    A[Sealed typed scope manifest] --> B1[Exact symbolic producer]
    A --> B2[Directed interval producer]
    A --> B3[Per-prime modular producers]
    B1 --> C[Canonical external ledger chunks]
    B2 --> C
    B3 --> C
    C --> D[Streaming full-ledger verifier]
    D --> E[Small arithmetic certificate]
    E --> F[Lean certificate checker]
    C --> G[SHA-256 bundle verifier]
    F --> H[Arithmetic verdict]
    G --> I[Content-binding verdict]
    H --> J[Promotable only when both verdicts pass]
    I --> J
```

The large producer may use GPUs, multiple processes, checkpoints, and external storage. It is not in the proof-checked core. Its output is evidence only after a fresh-process streaming verifier consumes the complete, hash-bound ledger and the small checker validates the resulting arithmetic certificate.

## Exact certificate data model

All proof-bearing artifacts use canonical JSON or canonical NDJSON:

- UTF-8 without BOM;
- LF line endings;
- one terminal LF for NDJSON;
- keys serialized by RFC 8785/JCS rules;
- arbitrary-precision integers encoded as canonical decimal strings, never JSON numbers;
- no `NaN`, infinities, decimal approximations, or exponent notation in proof fields;
- a rational encoded as `{"n":"-13","d":"896"}`, with `d>0` and `gcd(|n|,d)=1`;
- a finite interval encoded by two normalized rational endpoints;
- digests encoded as lowercase 64-character SHA-256 hex strings.

The checker rejects unknown proof-bearing fields unless the schema version explicitly permits them. Human notes may be carried under a non-semantic `annotations` field excluded from arithmetic decisions but included in the artifact hash.

### 1. Sealed scope manifest

Proposed schema: `workhouse.coefficient-scope/v1`.

```json
{
  "schema": "workhouse.coefficient-scope/v1",
  "manifest_id": "su3-hodge-o4-t1-rest-v1",
  "scope": {
    "gauge_group": {"family": "SU", "rank": "3"},
    "perturbative_order": "4",
    "sector": "charge-odd/T1/rest",
    "lattice": {"geometry": "periodic-cubic", "L": "5"},
    "basis_id": "hodge-v10a20b-canonical-block-pair-v1",
    "normalization_id": "canonical-u/sqrt2-normalized-W2-v1"
  },
  "roles": [
    {
      "role_id": "history.W2",
      "kind": "history-coefficient",
      "exact_domain": {"kind": "scaled-rational", "stored_value": "sqrt(2)*coefficient"},
      "denominator_rule_id": "w2-denominator-divisor-v1"
    },
    {
      "role_id": "haar.local",
      "kind": "haar-factor",
      "exact_domain": {"kind": "rational"},
      "denominator_rule_id": "su3-local-projector-product-v1"
    },
    {
      "role_id": "assembly.fold",
      "kind": "fold-addend",
      "required_certificate_ref": true
    },
    {
      "role_id": "assembly.linked-vacuum",
      "kind": "linked-vacuum-addend",
      "required_certificate_ref": true
    }
  ],
  "denominator_model": {
    "rule_id": "hodge-o4-qbound-v1",
    "primitive_factor_manifest_sha256": "<digest>",
    "requires_exponents": true,
    "target_values_forbidden": true
  },
  "inputs": [
    {"role": "engine-source", "path_hint": "...", "sha256": "<digest>"},
    {"role": "geometry-input", "path_hint": "...", "sha256": "<digest>"}
  ],
  "sealed_predictions": []
}
```

The manifest is frozen and hashed before coefficient generation. A rank, order, sector, basis, normalization, coefficient role, or source change creates a new manifest ID and digest. Resuming a checkpoint requires an exact manifest-digest match.

### 2. External ledger bundle manifest

Proposed schema: `workhouse.ledger-bundle/v1`.

Large records are stored as sorted NDJSON chunks. The bundle manifest contains:

```json
{
  "schema": "workhouse.ledger-bundle/v1",
  "scope_manifest_sha256": "<digest>",
  "record_schema_sha256": "<digest>",
  "ordering": "utf8-bytewise(record_id)",
  "chunks": [
    {
      "index": "0",
      "path": "history-00000.ndjson.zst",
      "records": "50000",
      "first_record_id": "<id>",
      "last_record_id": "<id>",
      "stored_bytes_sha256": "<digest>",
      "canonical_uncompressed_sha256": "<digest>"
    }
  ],
  "totals": {"records": "117161", "chunks": "3"}
}
```

Define `bundle_id` as SHA-256 of the JCS serialization of this object. It is recorded in a detached `bundle.sha256`; the object does not hash itself. Both stored-byte and canonical-uncompressed hashes are retained so compression changes do not change semantic identity while corrupted archives still fail immediately.

The streaming verifier checks chunk order, continuity, record count, uniqueness of `record_id`, first/last IDs, both hashes, and the bundle ID. Reordering or duplicate records fails; it is never silently normalized after receipt.

### 3. Ledger record

Proposed schema: `workhouse.denominator-lift-record/v1`.

```json
{
  "schema": "workhouse.denominator-lift-record/v1",
  "record_id": "sha256:<digest-of-semantic-key>",
  "semantic_key": {
    "left_state": "<canonical-state-id>",
    "right_state": "<canonical-state-id>",
    "translation_orbit": "<canonical-orbit-id>"
  },
  "role_id": "pair.D_A",
  "weight": {"n": "-31", "d": "2448"},
  "haar_denominator": {
    "q_h": "1728",
    "factors": [
      {"pattern": "2,2", "multiplicity": "2", "factor": "24"},
      {"pattern": "1,1", "multiplicity": "1", "factor": "3"}
    ]
  },
  "haar_value": {
    "method": "interval-grid-v1",
    "interval": {
      "lo": {"n": "<integer>", "d": "<positive-integer>"},
      "hi": {"n": "<integer>", "d": "<positive-integer>"}
    },
    "grid_denominator": "1728",
    "unique_integer": "-17",
    "precision_bits": "256",
    "expression_sha256": "<digest>"
  },
  "term": {
    "unreduced_numerator": "527",
    "unreduced_denominator": "8460288",
    "qbound_multiplier": "<QBOUND/8460288>"
  },
  "provenance": {
    "scope_manifest_sha256": "<digest>",
    "producer_source_sha256": "<digest>"
  }
}
```

For `symbolic-v1`, `haar_value` instead contains a normalized exact rational. For a modular ledger it contains the prime, residue, exact input digest, topology count, and modular-engine digest.

`record_id` is derived from the semantic key, not an array index. This prevents a reordered or truncated run from manufacturing a new identity for the same topology.

### 4. Small arithmetic certificate

Proposed schema: `workhouse.arithmetic-certificate/v1`.

Required fields:

- scope-manifest digest and bundle ID;
- record schema digest, producer digest, streaming-verifier digest, toolchain lock digest, and run UUID;
- fresh-process flag and checkpoint parent digest, if any;
- exact counts for enumerated, retained, zero, nonzero, rejected, and unsupported records;
- `qbound` as a decimal integer and its complete prime-exponent factorization;
- the recipe inputs from which `qbound` was built;
- exact analytic and imported addends, each by certificate digest rather than an unbound literal;
- accumulated integer numerator over `qbound`;
- reduced final rational;
- one summary for every interval-grid family: record count, maximum interval width, maximum precision, and the hash of the per-record witnesses;
- optional CRT certificate;
- forensic observations in a separate, non-gating section;
- machine-readable verdicts, including explicit nonclaims.

Example proof-bearing core:

```json
{
  "schema": "workhouse.arithmetic-certificate/v1",
  "scope_manifest_sha256": "<digest>",
  "ledger_bundle_id": "<digest>",
  "qbound": {
    "value": "<Q>",
    "factorization": [{"p": "2", "e": "a"}, {"p": "3", "e": "b"}],
    "recipe_sha256": "<digest>"
  },
  "accumulation": {
    "numerator_over_qbound": "<T>",
    "result": {"n": "<reduced-n>", "d": "<reduced-d>"},
    "records_consumed": "117161"
  },
  "claims": {
    "every_term_denominator_divides_qbound": true,
    "result_denominator_divides_qbound": true,
    "every_interval_has_one_grid_point": true,
    "topology_completeness_proved": false,
    "physics_interpretation_proved": false
  },
  "forensics": {
    "observed_pmax": "37",
    "fitted_pmax": null,
    "lcm_fingerprint": "diagnostic-only"
  }
}
```

The certificate cannot mark an imported addend exact unless its referenced certificate and digest are present and pass. This removes the current unbound `FOLD_EX` path.

## Algorithms

### A. Symbolic coefficient generation

The preferred F07 migration stores the quantity already known to be rational:

\[
\widetilde c = \sqrt 2\,c \in \mathbb Q,
\]

instead of computing `float(c) * sqrt(2)` and guessing the rational afterward.

Implement a typed `ScaledRational`:

```text
ScaledRational {
    scale_id: "sqrt2^-1",
    coefficient: reduced Rational
}
```

Addition is allowed only for equal `scale_id`; multiplication and division follow a small, explicitly registered scale algebra. If later stages require both `1` and `sqrt(2)`, promote to a two-component exact quadratic element `a + b*sqrt(2)`. Do not approximate the algebraic basis.

The symbolic path is:

1. Construct transition amplitudes in `ScaledRational` or an exact quadratic domain.
2. Store exact `W2` values in the history ledger.
3. Derive `R2 = W2/(E0-H0)` using exact rational energies.
4. Compare the independently generated exact `R2` ledger literally, including key sets.
5. Collapse canonical pair weights exactly.
6. Construct each `q_H` from typed local patterns.
7. Contract Haar tensors exactly where feasible, or invoke the interval-grid procedure below.
8. Form every unreduced term denominator and build `QBOUND` by integer LCM.
9. Check each term denominator divides `QBOUND` and accumulate its contribution as an integer.
10. Reduce only the final `T/QBOUND`.

Any implicit conversion from the exact domain to `float` in steps 1–10 is a hard failure. Decimal output is produced only after the exact certificate is sealed.

### B. Interval-certified uniqueness on a denominator grid

Use a directed-rounding ball library backed by Arb/FLINT. `mpmath`, Python `decimal` without an audited directed-rounding wrapper, binary64, and `numpy.longdouble` are not certification backends.

For a real computation known independently to be rational with reduced denominator dividing positive integer `Q`, obtain an outward interval

\[
I=[L,U],\qquad L=\frac{a}{b},\quad U=\frac{c}{d},\quad b,d>0.
\]

Export the interval endpoints as exact dyadic rationals through the backend's endpoint API; never parse a printed decimal ball.

Compute with exact signed floor/ceiling division:

```text
k_min = ceil(Q * a / b)
k_max = floor(Q * c / d)
```

Accept exactly when `k_min == k_max`. Let the common value be `k`; the unique possible exact value is `k/Q`, reduced afterward.

Why this is a proof: if `x=p/q` lies in `[L,U]` and `q | Q`, then `Q*x` is an integer. The scaled interval `[Q*L,Q*U]` contains exactly one integer, so `Q*x=k` and `x=k/Q`.

Operational loop:

```text
for precision in [128, 256, 512, 1024, 2048, 4096]:
    I = evaluate_full_expression_with_outward_rounding(precision)
    k_min, k_max = exact_scaled_integer_range(I, Q)
    if k_min == k_max:
        emit witness and stop
    if k_min > k_max:
        fail: enclosure/model/Q mismatch
fail: ambiguity remains at maximum precision
```

An interval containing no grid point is not rounded to the nearest point. An interval containing two or more grid points is not accepted because a float residual is small. Both fail closed.

The denominator divisor must be derived without consulting the approximate target. An allowed-prime set with no exponent bounds cannot drive this method.

For the current Haar stage use the local `q_H` for each record, not the much larger global `QBOUND`; this minimizes required precision. The current nearest-integer residual becomes a display-only diagnostic. The certificate gate is the exact equality `k_min == k_max`.

Crucially, placing a narrow ball around a pre-existing float is invalid. Every operation from exact input tensors to the final contraction must run through directed interval arithmetic, or the enclosure claim is unsupported.

### C. `QBOUND` construction and exact accumulation

`QBOUND` is an LCM with exponents, not a maximum-prime rule:

```text
Q = lcm(
    analytic_addend_denominators,
    for every pair record: 2 * weight.denominator * q_h,
    certified imported-addend denominators
)
```

Each factor is tied to a typed role and provenance record. The implementation stores the unreduced factor, its factorization, and the rule that introduced it. It then verifies:

```text
Q % term_denominator == 0
T += term_numerator * (Q // term_denominator)
```

If the reduced result is `n/d`, the checker independently verifies `d | Q` and `n/d = T/Q` by cross multiplication.

The set of primes in `Q` is the only proof-bearing allowed set for that manifest. A smaller observed output denominator is expected because cancellation can occur.

### D. Denominator-cleared integer CRT — preferred modular method

When `QBOUND` is known, reconstruct the integer `T=Q*C`, not the rational `C`.

Before the modular runs, derive and seal a magnitude bound `|T| <= A`. Choose pairwise coprime moduli `m_i` with `gcd(m_i,Q)=1`; primes are convenient but pairwise coprimality is the mathematical requirement.

Each worker emits:

```text
scope_manifest_hash, engine_hash, input_bundle_hash,
modulus m_i, residue t_i, topology_count, completion status,
checkpoint-parent hash, and worker-environment hash.
```

The aggregator computes canonical CRT `R in [0,M)`, where `M=product(m_i)`, and verifies every round trip. Require the exact inequality

\[
M>2A.
\]

Map `R` to its symmetric representative `T` and require `|T|<=A`. This proves `T` is the unique admissible integer, after which `C=T/Q` is reduced exactly.

This method is simpler and stronger than generic rational reconstruction whenever a denominator divisor exists.

### E. Bounded rational CRT — fallback only

If no denominator divisor is available, seal independent bounds

\[
|n|\le N,\qquad 0<d\le D

\]

before running the modular engines. For reconstructed reduced `n/d`, verify:

1. `gcd(n,d)=1` and `d>0`;
2. `gcd(d,M)=1`;
3. `n == R*d (mod M)` and round-trip equality for every modulus;
4. `|n|<=N` and `d<=D`;
5. the exact uniqueness inequality `2*N*D < M`.

The last condition proves uniqueness: two admissible rationals with the same residue would make `M` divide `n*d' - n'*d`, whose absolute value is strictly less than `M`, hence it is zero.

A modulus bit-length threshold is not a substitute for the exact inequality. Bounds derived after seeing the candidate do not prove that the true computation lies in the admissible class. Literature values and prior floats must be loaded only after the reconstructed certificate has been hashed; post-hoc agreement remains useful but non-gating.

## Lean-checked core

Add a small module family, proposed as:

```text
lean/Workhouse/Certificate/Rational.lean
lean/Workhouse/Certificate/Localization.lean
lean/Workhouse/Certificate/IntervalGrid.lean
lean/Workhouse/Certificate/CRT.lean
lean/Workhouse/Certificate/Checker.lean
```

The checker reads the small certificate, parsing mathematical integers from decimal strings into arbitrary-precision `Int`/`Nat`. It should prove and expose these theorems:

1. **LCM closure.** If every term denominator divides `Q`, the denominator of the reduced sum divides `Q`.
2. **Accumulation soundness.** If each ledger summary contribution is scaled by `Q/termden`, then `T/Q` equals the stated sum.
3. **Grid uniqueness.** If a rational in `[L,U]` has denominator dividing `Q` and the scaled interval contains exactly integer `k`, it equals `k/Q`.
4. **Integer CRT uniqueness.** If `M>2A`, at most one integer of absolute value at most `A` has the recorded residues.
5. **Rational CRT uniqueness.** If `2*N*D<M`, at most one reduced rational within the recorded bounds and invertible denominator has the recorded residue.
6. **Certificate normalization.** Rational signs, gcds, factorization products, exact cross-products, and modulus coprimality all check.

Recommended executable interface:

```text
lake exe workhouse-cert-check <arithmetic-certificate.json>
```

It emits a minimal JSON verdict containing the certificate digest, checked claims, and Lean build/toolchain digests. A nonzero exit is mandatory on an unknown schema, malformed decimal integer, failed equality, unproved factorization, or unused proof-bearing field.

Lean checks arithmetic facts about the small certificate. In version 1 it does **not**:

- hash or parse every large ledger chunk;
- prove SHA-256 collision resistance;
- prove Arb/FLINT implements its enclosure contract;
- prove the enumerator found every physical topology;
- prove the model or normalization is physically correct.

Those are explicit trust-boundary items, not implied by a green Lean build.

## External ledger and trust boundary

| Component | Trusted or checked? | What a pass establishes |
|---|---|---|
| Exact symbolic scalar implementation | Trusted initially; heavily tested | Producer arithmetic follows its declared exact domain |
| Arb/FLINT plus thin endpoint wrapper | Trusted for `interval-grid-v1` | Stored interval encloses the full numerical expression |
| A100/GPU topology producer | Not trusted by arithmetic checker | Candidate ledger only |
| Streaming ledger verifier | Trusted implementation in v1; source and build hashed | Every external record was consumed, schema-checked, and accumulated as reported |
| SHA-256 + canonicalizer | Cryptographic/software assumption | Certificate is bound to the received bytes and canonical record stream |
| Lean kernel, pinned toolchain, and small checker | Proof trust base | Small certificate arithmetic and uniqueness statements follow |
| Scope manifest | Human-reviewed and hash-sealed | Rank/order/sector/basis/normalization were fixed before the run |
| Enumeration completeness gates | Computational evidence, not pure arithmetic | Ledger matches the declared census/protocol |
| Historical target | Untrusted and post-hoc only | Agreement is corroboration, never reconstruction input |

Promotion requires both independent verdicts:

```text
content_bound == true     # bundle hashes, schemas, counts, source identities
arithmetic_sound == true  # Lean arithmetic certificate
```

The final status must still say “exact relative to the stated enumeration and model.” Neither verdict proves continuum physics.

## Rank/order smoothness and the order-seven prediction

The reviewed note `Denominatorr Smoothness.txt` correctly upgrades global 37-smoothness to a rank/order-indexed forensic proposal. Its SHA-256 in this review is `68784b05371feceab1fa1c8258ca577df949dc4eae0678c9caeefb358b31ba2a`.

Its useful observations belong in a non-gating `forensics` or `sealed_predictions` block:

- the selected SU(3) series has observed reduced-denominator `Pmax` values 17 through order 3, 37 at orders 4–5, and 61 at the transcribed sixth-order KPS coefficient;
- the displayed denominators have an observed LCM-like shape, with small primes at higher exponents and some larger primes at exponent one;
- rank-polynomial factors can introduce large legitimate primes already at low order as `N` grows;
- a precommitted order-seven reachable-gap enumeration would be a valuable falsifier.

They must not become certificate premises. In particular:

1. Monotonicity of the **reduced output denominator** is observed, not proved. Cancellation can make a later coefficient lose earlier primes. A cumulative allowed `QBOUND` envelope can be defined to be monotone, but that is a different object.
2. “Small primes high powers, large primes first power” is a fingerprint, not a theorem. Repeated large-prime gaps can raise exponents, and cancellation can alter the final pattern.
3. A prime reachable in an intermediate denominator is allowed to appear; it need not survive the full sum. The proposed “appears iff reachable” statement needs a noncancellation theorem.
4. A slash-separated CRT modulus list is not a rational. The corpus text `33554467/33554393/...` must be typed as `crt-modulus-list`, not treated as a coefficient and then “correctly flagged.” This is a semantic scanner false positive.
5. The proposed quadratic `r^2/2 + 7r + 1` matches 17, 37, and 61 at even orders 2, 4, and 6. At order 7 it gives `74.5`, not 89; 89 is its order-8 value. Therefore the note contains no coherent integer order-seven ceiling as written.

The correct prediction artifact is not a guessed scalar ceiling. Before reading any seventh-order coefficient, seal:

```json
{
  "schema": "workhouse.denominator-prediction/v1",
  "rank": "3",
  "order": "7",
  "enumerator_source_sha256": "<digest>",
  "scope_manifest_sha256": "<digest>",
  "reachable_gap_factors": ["<exact factor records>"],
  "predicted_qbound_factorization": ["<p,e pairs>"],
  "predicted_allowed_prime_set": ["<primes>"],
  "predicted_absent_primes": ["<within a declared comparison range>"],
  "status": "precommitted-observed-model"
}
```

If the enumeration itself derives the complete resolvent denominator divisor, its `QBOUND` can later become proof-bearing for that exact manifest. The extrapolated quadratic and generic-prime shape remain fitted annotations even if the prediction succeeds once.

## Failure modes and required behavior

| Failure mode | Detection | Required behavior |
|---|---|---|
| Missing denominator factor or exponent | A term denominator does not divide `QBOUND`; scaled interval contains no integer | Abort certificate; fix the rule, issue a new manifest |
| Interval contains multiple grid points | `k_min < k_max` | Increase precision; fail diagnostic-only at cap |
| Interval contains no grid point | `k_min > k_max` | Abort as model, denominator-rule, or enclosure bug |
| Final float wrapped in a narrow ball | Provenance shows interval path begins after float evaluation | Reject; rerun the full expression with directed rounding |
| Platform-dependent `longdouble` | Backend metadata or unsupported method | Diagnostic only |
| Symbolic expression swell | Resource ceiling | Checkpoint exact ledgers or switch to denominator-cleared modular accumulation; never fall back silently to float |
| Denominator not invertible modulo a worker modulus | `gcd(modulus,Q) != 1` or inversion failure | Discard modulus and produce a new worker artifact |
| CRT modulus too small | `M<=2A` or `2ND>=M` | Add coprime moduli; emit no exact result |
| Same wrong algorithm used for every prime | Residues agree but independent implementation does not | State exactness relative to engine; require an independent holdout implementation for stronger evidence |
| Target contamination | Target digest appears in producer dependency graph before sealing | Invalidate run |
| Checkpoint from another scope/code version | Manifest/source/parent digest mismatch | Refuse resume before loading state |
| Truncated, duplicated, or reordered ledger | Chunk range/count/order checks | Reject bundle |
| Stored artifact bit flip | SHA mismatch | Reject before arithmetic verification |
| Canonicalization ambiguity | Non-JCS object, noncanonical integer/rational, CRLF in canonical stream | Reject rather than normalize silently |
| Unbound fold/vacuum literal | Missing upstream certificate reference | Final assembly remains incomplete |
| Smooth but artificial decimal denominator | Forensic power-of-ten rule | Flag diagnostically; exactness still decided by certificate path |
| Exact but rough legitimate denominator | Derived `QBOUND` includes it | Accept; roughness cannot veto a proof-bearing result |
| Semantic slash-chain mistaken for rational | Typed parser sees list/prose role | Exclude from coefficient ledger and record scanner finding |
| Hash collision or compromised hashing tool | Outside arithmetic proof | Explicit cryptographic assumption; allow a second digest algorithm in archival bundles if desired |

## Staged migration

### Stage 0 — Freeze the evidence boundary

- Mark the current v10a.20b rationalizations and integer lifts `heuristic-v1`.
- Preserve their outputs only as regression targets.
- Record the reviewed source hashes and current environment.
- Do not promote F07 from source assertions until a complete artifact exists.

**Exit:** No code path labels `limit_denominator`, binary64 rounding, or target agreement as exact.

### Stage 1 — Schemas, canonicalization, and typed scope

- Implement the four schemas above and validators.
- Implement canonical rational, interval, factorization, and digest encoders.
- Freeze rank/order/sector/basis/normalization and coefficient roles before each run.
- Give CRT modulus lists, ratios, coefficient literals, and prose examples distinct semantic types.

**Exit:** Mutation tests prove changes in scope, record order, chunk content, or source code change a digest and invalidate reuse.

### Stage 2 — External ledger and streaming replay

- Extract monolithic notebook stages into a fresh-process producer.
- Serialize exact history and pair ledgers, `q_H`, per-record proof method, and term contributions.
- Build the chunk manifest and detached bundle hash.
- Implement a streaming verifier that recomputes counts, `QBOUND`, divisibility, and `TOTAL_NUM` without loading prior same-kernel globals.
- Consume fold and linked-vacuum addends only by certificate digest.

**Exit:** A clean run can be deleted from memory and reproduced solely from the sealed manifest and external bundle.

### Stage 3 — Rigorous Haar integer lifts

- Replace binary64/`round(q_H*h)` with full-path Arb intervals.
- Export exact endpoints and apply the one-grid-point test per topology.
- Keep dense and alternate-contractor evaluations as independent regressions, not proof substitutes.

**Exit:** Every retained topology has either an exact symbolic Haar value or a stored interval-grid uniqueness witness. Zero unresolved/unsupported records.

### Stage 4 — Symbolic history coefficients

- Replace `float(c)*sqrt(2)` with `ScaledRational` generation.
- Derive `R2` from exact `W2` and rational energy gaps.
- Require literal ledger equality against an independently organized exact path.
- If any upstream primitive remains numerical, rerun that primitive through directed intervals from exact inputs; do not enclose its final float.

**Exit:** `limit_denominator()` is absent from the value-producing dependency graph.

### Stage 5 — CRT cross-certificate

- For F07, compute denominator-cleared `TOTAL_NUM mod p` from independent per-prime workers and reconstruct the bounded integer.
- For sigma5 and future coefficients, prefer the same integer route once a `QBOUND` exists; otherwise use the bounded rational protocol.
- Bind every per-prime pickle or chunk and engine source by digest.
- Precommit magnitude bounds and holdout algorithms.

**Exit:** Exact and CRT accumulations agree, all residues round-trip, and the exact uniqueness inequality passes.

### Stage 6 — Lean checker

- Formalize the five arithmetic soundness theorems.
- Parse the small certificate's decimal strings directly.
- Emit a machine-readable, digest-bound verdict.
- Pin the Lean toolchain and checker source/build identity.

**Exit:** Altering a numerator, denominator, factor exponent, interval endpoint, CRT residue, bound, or modulus makes the Lean checker fail.

### Stage 7 — Clean evidence run and downstream handoff

- Run from a fresh environment with no historical target in the producer namespace.
- Store scope manifest, chunk bundle, summary certificate, hash verdict, Lean verdict, logs, and environment lock together.
- Require F08/F09 and theory tables to consume the certificate by digest, never by copied literal.

**Exit:** One immutable bundle supports the stated coefficient, and every downstream consumer checks its digest before use.

## Test plan

### Unit tests

- Rational canonicalization: sign, zero, gcd reduction, leading-zero rejection, huge integers.
- Exact signed `floorDiv`/`ceilDiv`, especially negative endpoints and exact-grid boundaries.
- `QBOUND` factorization multiplication and LCM exponents.
- `ScaledRational` operations and rejection of incompatible scales.
- CRT combination, centered representative, modulus coprimality, and round trips.
- Canonical JSON/NDJSON serialization and detached digest calculation.

### Property tests

- Generate random `q | Q`, random `p/q`, and outward rational intervals; the grid checker recovers the value exactly whenever the scaled interval contains one integer.
- Expand an interval until it contains two grid points; the checker always rejects.
- Generate random term sets with denominators dividing `Q`; exact accumulation reduces to a denominator dividing `Q`.
- Generate bounded integers and coprime moduli with `M>2A`; integer CRT uniquely reconstructs every case.
- Generate bounded reduced rationals satisfying `2ND<M`; rational CRT reconstructs and round-trips them.

### Adversarial and mutation tests

- Remove one prime exponent from `QBOUND`.
- Flip one digit of an interval endpoint or unique integer.
- Change a worker residue, duplicate a modulus, or make a modulus share a factor with `Q`.
- Truncate a chunk, duplicate a record, swap two records, alter compression bytes, or change a semantic key without changing the record ID.
- Insert a target constant into the producer's dependency manifest.
- Resume a checkpoint under a different rank, order, sector, source hash, or normalization.
- Feed slash-separated CRT primes and confirm they are not emitted as rational coefficients.
- Feed a true rough denominator admitted by `QBOUND` and confirm forensic warnings cannot fail the exact certificate.
- Feed a smooth continued-fraction artifact and confirm smoothness cannot promote it.

### Regression tests

- Exact lower-order `sigma2`, `sigma3`, `t3`, and existing Lean rationals.
- Current F07 `W2/R2` keys and counts, with legacy floats used only for comparison.
- Supported local Haar patterns and the universal `q_H <= 120^4` claim.
- The existing seven sigma5 residues and reconstructed rational, now under exact input and digest binding.
- The linked-vacuum intended rational and the known display artifact remain distinct, with the latter diagnostic-only.

### Independent implementation tests

- Compare symbolic Haar values against Arb interval-grid values on all small patterns.
- Compare factorized and dense contractions on every tractable topology, not only a selected residual set.
- Recompute a fixed set of modular residues with a separately organized engine.
- Run canonicalization and hash fixtures in Python and Lean (or a second language) and require byte-identical fixtures.

### Formal tests

- `lake build` contains no `sorry` in the certificate modules.
- Each Boolean checker has a `check = true -> proposition` soundness theorem.
- Counterexample fixtures for every failed premise evaluate to `false`.
- The generated arithmetic verdict includes the certificate digest and pinned Lean build identity.

## Acceptance criteria for an “exact” result

All of the following are required:

1. A sealed scope manifest fixes rank, order, sector, basis, normalization, roles, sources, and denominator rules before computation.
2. Every value-producing path is symbolic, full-path interval-certified, or bounded CRT.
3. Every denominator divisor is exponent-sensitive and derived independently of the approximate target.
4. Every term denominator divides `QBOUND`; every interval witness contains exactly one denominator-grid point.
5. Every external ledger record is present in a canonical, hash-bound bundle and consumed by a fresh-process streaming verifier.
6. Imported assembly addends arrive by passing certificate digest.
7. The small arithmetic certificate passes Lean.
8. The content hash verdict passes independently.
9. Historical values are compared only after sealing.
10. The result states its nonclaims: topology completeness/model correctness/physics are not created by rational arithmetic alone.

If any item fails, the system may emit a diagnostic candidate and preserved checkpoint, but not an exact coefficient.

## Options considered

### Option A — Retain dual-ceiling `limit_denominator` plus smoothness

| Dimension | Assessment |
|---|---|
| Implementation effort | Low |
| Runtime | Low |
| Exactness | Not established |
| Forensic value | Useful |

Rejected as the proof path. Agreement across ceilings, small residual, and plausible prime support can all select the same wrong rational.

### Option B — Require symbolic arithmetic for every stage immediately

| Dimension | Assessment |
|---|---|
| Mathematical strength | Highest |
| Implementation complexity | High |
| Large-contraction performance | Uncertain |
| Trust boundary | Smallest |

Preferred wherever practical, but not selected as the sole migration route because it could strand the large Haar contractions and modular workloads.

### Option C — Symbolic core plus rigorous interval-grid and CRT fallbacks

| Dimension | Assessment |
|---|---|
| Mathematical strength | High and explicit |
| Implementation complexity | Moderate |
| Scalability | Compatible with streaming/GPU/modular runs |
| Trust boundary | Larger than all-symbolic, but named |

Selected. It converts existing denominator knowledge into exact uniqueness proofs without requiring the large ledger to live inside Lean.

### Option D — Parse and verify the full 117,161-record ledger inside Lean

| Dimension | Assessment |
|---|---|
| Formal coverage | Highest |
| Engineering cost | Very high |
| Immediate value | Lower than proving the small arithmetic kernel first |

Deferred. The external streaming verifier is a deliberate version-1 trust item. Its pure arithmetic kernels can be migrated into Lean incrementally after the certificate boundary is stable.

## Consequences

- An exact result becomes reproducible evidence rather than a number printed at the end of a live notebook.
- `QBOUND` becomes the central bridge among localization, interval uniqueness, exact accumulation, and efficient integer CRT.
- Large GPU/HPC computations remain practical and independently auditable.
- Smoothness and LCM shape retain their value as anomaly screens and precommitted predictions without contaminating exactness claims.
- Certificates and ledgers become larger and schema evolution must be managed carefully.
- Interval-certified results explicitly trust the enclosure backend until the relevant contraction is fully symbolic.
- Lean certifies the arithmetic consequence of the summary; it does not hide the remaining computational and physical assumptions.

## Action items

1. [ ] Approve this decision and allocate `ADR-0010` or the next repository-local ADR number.
2. [ ] Freeze `workhouse.coefficient-scope/v1` and its canonical JSON fixtures.
3. [ ] Implement `ScaledRational` for the `sqrt(2)`-normalized history path.
4. [ ] Implement the Arb endpoint adapter and exact one-grid-point checker.
5. [ ] Extract the F07 producer and streaming verifier from the notebook into fresh-process modules.
6. [ ] Define the external ledger schemas and chunk/hash bundle.
7. [ ] Replace unbound fold/vacuum literals with certificate references.
8. [ ] Add denominator-cleared CRT and precommitted exact bounds.
9. [ ] Formalize the small Lean checker and soundness theorems.
10. [ ] Run adversarial fixtures before the first full clean evidence run.
11. [ ] Seal any order-seven denominator prediction as a separate hypothesis artifact; first correct the inconsistent scalar extrapolation.

## Reviewed source identities

| Source | SHA-256 |
|---|---|
| `corpus-import/records/audits/07-denominator-lift.md` | `7332bf8363a13a44f329fca3d96d75584bc41447032906d5a7ae371889f4daf5` |
| `NB_O4_hodge_v10a20b_denominatorlift_exact_da_m4_a100.ipynb` | `47c6ccc18079c49416c511c2a27a9d757525d6e279992514ed63f5ba413530fd` |
| `ENGINE_STRING_sigma5_full_certificate.py` | `8b3bb93fe4733b51eafae490816ccfbd8be556f1ccf990320aa3462671c4dadc` |
| `CERT_STRING_sigma5_exact_certificate.json` | `96d4aded74d78b275ec805e1e3151e91896ce92f3921c4ae47b6ccaa6b654e27` |
| `src/workhouse/ledger.py` | `daad623d9cad534bcaf79467949d2778ede607c0c4caf497dffce8bd97feea36` |
| `src/workhouse/payloads.py` | `5858edf4fe09a05c76683dced55f5fd249cd5772df8995bdb82a8400c655c9d4` |
| `lean/Workhouse/Basic.lean` | `bd706904af4015710d1d92ececc55bbc4b62ecb4dcbd1f42cfda67667250db8e` |
| `C:/Users/Alex/Downloads/Denominatorr Smoothness.txt` | `68784b05371feceab1fa1c8258ca577df949dc4eae0678c9caeefb358b31ba2a` |

This ADR was produced outside the repository during a read-only review. No repository file was changed.
