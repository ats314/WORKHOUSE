# WORKHOUSE scoped denominator certificate — implementation packet

Date: 2026-08-23  
Status: read-only research prototype; WORKHOUSE repository unchanged

## Outcome

The proposed global “37-smoothness” rule has been replaced by a typed, scope-specific certificate architecture:

1. every coefficient is classified by rank, perturbative order, sector, normalization, and role;
2. each enforced scope supplies an independently derived allowed-prime set and exponent-sensitive `QBOUND`;
3. a coefficient passes only when its reduced denominator divides `QBOUND` (prime-set membership is a weaker diagnostic);
4. exact symbolic arithmetic is preferred; otherwise the complete numerical computation must produce an outward-rounded interval containing exactly one point of the certified rational grid;
5. the large history ledger remains external, canonical, chunked, and hashed; Lean checks the small mathematical certificate consequences.

The prototypes implement this boundary without claiming that the present example manifests prove the physics completeness of their supplied prime sets or bounds.

## Claude note: incorporated conclusions and corrections

The note's move toward rank/order-dependent denominator structure is useful and is retained as non-gating metadata. Its proposed `Pmax` and LCM patterns are observations, not proof inputs. Four corrections are load-bearing:

- the repository's exact fourth-order cubic source set includes `47`, so `37` is not a valid universal fourth-order ceiling;
- `33554467/33554393/33554383` is a slash-separated CRT-modulus list, not a rational coefficient;
- the fitted expression `r^2/2 + 7r + 1` gives `74.5` at `r = 7` and `89` at `r = 8`, so the stated order-7 prediction is internally inconsistent;
- reduced-denominator prime support and exponents can change through cancellation and repeated resolvents, so monotone `Pmax`/LCM growth is not a general theorem.

The exact fourth-order gap witnesses include

`8/3 - 13/2 = -23/6`, giving a resolvent denominator prime `23`, and

`8/3 - 21/2 = -47/6`, giving a resolvent denominator prime `47`.

Accordingly, the currently derived fourth-order source superset is

`{2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 47}`.

## Deliverables

### 1. Theory and corpus audit

`WORKHOUSE_DENOMINATOR_LOCALIZATION_THEORY_AUDIT_20260823.md`

- reconstructs the exact localization theorem and its closure limits;
- identifies the `56`-entry census bug (the sole multiline `KPS_T6` assignment was omitted);
- distinguishes genuine exact coefficients, quarantined artifacts, generated self-index entries, and scanner false positives;
- reconciles the Claude note with the repository's exact fourth-order provenance.

SHA-256: `89e6578026a1d0a50566b1ecd56712799e42fd8ec893858bd267f912f9a0859a`

### 2. Typed manifest and executable audit prototype

`WORKHOUSE_SCOPED_DENOMINATOR_AUDIT_PROTOTYPE_20260823.zip`  
`WORKHOUSE_SCOPED_DENOMINATOR_AUDIT_REPORT_20260823.json`

The package contains a dependency-free AST scanner, JSON Schema, example typed manifest, scoped audit engine, and tests. It:

- recognizes multiline rational assignments and aliases;
- rejects slash chains as non-coefficient syntax;
- excludes generated self-index material;
- checks both allowed-prime support and `denominator | QBOUND`;
- records `Pmax`/shape observations without enforcing them;
- quarantines artifacts rather than inferring their origin from denominator shape.

Verification: `13/13` bounded tests pass. The example audit has `16` entries, `15` enforced entries, `0` errors, and `5` explicit warnings that its example `QBOUND`s are reference/prototype envelopes rather than independently derived certificates.

ZIP SHA-256: `21747077f827c3f55733d8b13db95e0f693bdab85904f48a2867366d1a621e80`  
Report SHA-256: `fc1e409c2b76f70eb1ab352a706435ae48cbae25b8422859b45b379ac911daee`

### 3. Exact reconstruction and trust-boundary ADR

`WORKHOUSE_ADR_0010_EXACT_RECONSTRUCTION_AND_CERTIFICATE_BOUNDARY_20260823.md`

This specifies:

- exact symbolic and scaled-rational domains;
- full-path Arb/FLINT interval evaluation;
- exact grid-uniqueness reconstruction using `ceil(Q L) = floor(Q U)`;
- exponent-sensitive, independently derived `QBOUND`s;
- denominator-cleared integer accumulation and CRT reconstruction;
- canonical chunked NDJSON ledgers, detached hashes, and fresh-process verification;
- migration stages, failure modes, tests, and acceptance gates.

SHA-256: `d965d09b5abec7d00a632e036f6a0064b629085cb49c4e2076cea036e538bc4e`

### 4. Compiled Lean checker

`WORKHOUSE_DENOMINATOR_LEAN_CHECKER_PROTOTYPE_20260823.zip`  
`WORKHOUSE_DENOMINATOR_LEAN_CHECKER_PROTOTYPE_20260823.zip.sha256`

Verified with Lean `v4.34.0-rc1` and pinned Mathlib revision `1f29011071772620f612bf5a06433775f06067b8`:

- final `lake build` succeeded (`724` jobs);
- no `sorry` or `admit`;
- rational prime-support closure is proved for negation, addition, subtraction, multiplication, finite sums, and finite products;
- division explicitly requires numerator-prime control;
- `QBOUND` divisibility propagation is proved using LCM for addition/subtraction and products for multiplication;
- a small certified-expression AST culminates in `denominator_dvd_qBound`;
- centered CRT uniqueness is proved.

The Lean checker deliberately does **not** prove that a supplied manifest exhausts all physical histories, that its `QBOUND` is complete, that a `Pmax` pattern holds, or that an external ledger/hash is authentic. Those are inputs checked at the trust boundary.

ZIP SHA-256: `c8292b2ee8f7c2481222d11283813a59db596170b4a8730375dba0f58c3ff0d4`

## What is proved now

The small checker architecture and its algebraic consequences are real and executable. Given a correctly typed manifest whose primitive factors and inversions have been completely enumerated, the checker can certify the resulting denominator localization/divisibility claims without relying on floating-point pattern recognition.

## Exact stopping point

The example manifests do not yet contain independently derived, exhaustive primitive-factor ledgers for every WORKHOUSE sector. Their current `QBOUND`s are useful integration fixtures, not final physics certificates. The next substantive step is therefore one clean target scope—recommended: cubic rank 3, order 4—whose Haar/projector factors, nonzero reduced-resolvent gaps, normalizations, and permitted inversions are generated symbolically into a canonical hashed ledger. Its `QBOUND` must be derived before inspecting the target coefficients. Once that exists, the current Python and Lean machinery can check it without changing their trust boundary.
