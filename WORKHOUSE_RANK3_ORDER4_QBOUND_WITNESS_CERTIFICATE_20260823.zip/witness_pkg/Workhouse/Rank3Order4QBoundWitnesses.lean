import Workhouse.Rank3Order4QBoundCertificate

/-!
# Rank-3, order-4 QBOUND — per-coefficient denominator witnesses (kernel-connected)

The base certificate (`Rank3Order4QBoundCertificate`) proves the arithmetic of
the frozen bound but takes the stage LCMs `qW2`, `qR2` as **declared** integers:
Lean never sees the individual W2/R2 coefficient denominators.  This file closes
that gap for the denominator layer.

`w2Denoms` and `r2Denoms` below are the **distinct reduced denominators** of the
frozen `W2_scaled` (58) and `R2_scaled` (181) coefficients, extracted from the
hash-pinned history ledger

    rank3_order4_cubic_history_ledger.json
    sha256 = 543869b10f5137ea74fbd5f27d25027dea66f936ce9844b77a029453b8bf8c97

(the same hash recorded in the freeze).  `extract_ledger_denominators.py`
regenerates these two lists from that file and re-checks the hash, so the only
remaining external premise is "these lists are the ledger's denominators" — a
mechanical extraction against a pinned hash, no longer a trusted LCM.

What is now proved **in-kernel**:

* every frozen W2 denominator divides `qW2`, every frozen R2 denominator divides
  `qR2` (`decide`);
* `qW2 ∣ qTight` and `qR2 ∣ qTight` (explicit quotient witnesses);
* hence every frozen coefficient denominator divides `qTight`;
* any assembled coefficient `analyticRat + Σ terms` whose term denominators come
  from the frozen ledger has denominator dividing `qTight`
  (`frozen_assembly_denominator_dvd_qTight`), reusing the base certificate's
  `assembled_denominator_dvd_qTight`.

The two `native_decide` theorems at the end additionally show `qW2`/`qR2` are the
**exact** LCMs of the frozen denominators (tightness), at the cost of the
`Lean.ofReduceBool` axiom; the results above use only `propext, Classical.choice,
Quot.sound`.

This is still a *denominator* certificate: it does not compute the endpoint-Haar
numerators, `D_EXACT`, or the fold/linked-vacuum scalars, and it does not tie the
frozen scope to the physical perturbation expansion (a modeling premise).
-/

namespace Workhouse.Rank3Order4QBoundWitnesses

open Workhouse.DenominatorChecker
open Workhouse.Rank3Order4QBoundCertificate

/-- 58 distinct reduced denominators of the frozen `W2_scaled` coefficients. -/
def w2Denoms : List ℕ :=
    [4, 5, 6, 8, 12, 16, 17, 18, 20, 24, 30, 32, 34, 36, 40, 48, 51, 64, 68, 72, 80, 81, 96, 102,
     108, 128, 136, 144, 153, 160, 162, 204, 216, 240, 272, 288, 306, 320, 324, 384, 408, 432,
     480, 544, 612, 640, 648, 680, 720, 864, 960, 1224, 1296, 1360, 2040, 2592, 4080, 12240]

/-- 181 distinct reduced denominators of the frozen `R2_scaled` coefficients. -/
def r2Denoms : List ℕ :=
    [12, 16, 17, 20, 22, 24, 27, 30, 32, 34, 35, 36, 39, 40, 44, 46, 48, 50, 51, 52, 54, 55, 56,
     58, 60, 62, 63, 64, 68, 72, 74, 78, 80, 81, 84, 85, 87, 88, 92, 96, 100, 104, 105, 108, 110,
     111, 112, 114, 116, 119, 120, 124, 126, 128, 130, 132, 136, 144, 156, 160, 162, 165, 168,
     170, 174, 176, 184, 186, 187, 192, 200, 204, 208, 216, 220, 221, 222, 224, 232, 240, 252,
     256, 264, 270, 272, 276, 280, 288, 289, 312, 320, 340, 348, 360, 368, 374, 384, 396, 400,
     408, 420, 425, 442, 456, 464, 468, 476, 480, 493, 520, 527, 528, 540, 544, 552, 560, 561,
     576, 594, 595, 629, 640, 663, 680, 696, 704, 720, 748, 792, 800, 840, 896, 912, 918, 960,
     1024, 1080, 1088, 1104, 1188, 1360, 1368, 1377, 1392, 1440, 1560, 1680, 1824, 1904, 1920,
     1989, 2040, 2160, 2176, 2244, 2376, 2560, 2652, 2736, 2880, 3132, 3240, 3740, 3978, 4104,
     4320, 4680, 5120, 5472, 6264, 7956, 8064, 8208, 8640, 10152, 11220, 12528, 16416, 20304,
     26520, 79560]

/-! ### Every frozen denominator divides its stage LCM (standard axioms). -/

theorem w2Denoms_dvd_qW2 : ∀ d ∈ w2Denoms, d ∣ qW2 := by decide

theorem r2Denoms_dvd_qR2 : ∀ d ∈ r2Denoms, d ∣ qR2 := by decide

/-! ### The stage LCMs divide the frozen QTIGHT (explicit quotient witnesses). -/

theorem qW2_dvd_qTight : qW2 ∣ qTight :=
  ⟨71367848876059691829600190464000000, by norm_num [qW2, qTight]⟩

theorem qR2_dvd_qTight : qR2 ∣ qTight :=
  ⟨153468378965606400000, by norm_num [qR2, qTight]⟩

/-! ### Every frozen coefficient denominator divides QTIGHT. -/

theorem w2Denoms_dvd_qTight : ∀ d ∈ w2Denoms, d ∣ qTight :=
  fun d hd => (w2Denoms_dvd_qW2 d hd).trans qW2_dvd_qTight

theorem r2Denoms_dvd_qTight : ∀ d ∈ r2Denoms, d ∣ qTight :=
  fun d hd => (r2Denoms_dvd_qR2 d hd).trans qR2_dvd_qTight

/-- Per-coefficient witness: any rational whose reduced denominator is one of the
frozen W2/R2 denominators satisfies `DenominatorDivides qTight`. -/
theorem coefficient_denominator_witness (x : ℚ)
    (h : x.den ∈ w2Denoms ∨ x.den ∈ r2Denoms) :
    DenominatorDivides qTight x := by
  rcases h with h | h
  · exact w2Denoms_dvd_qTight x.den h
  · exact r2Denoms_dvd_qTight x.den h

/-- Capstone.  Any assembled coefficient `analyticRat + Σ terms` whose term
denominators all come from the frozen ledger has denominator dividing `qTight`,
with every input denominator now verified in-kernel rather than declared. -/
theorem frozen_assembly_denominator_dvd_qTight (terms : List ℚ)
    (h : ∀ t ∈ terms, t.den ∈ w2Denoms ∨ t.den ∈ r2Denoms) :
    DenominatorDivides qTight (analyticRat + terms.sum) := by
  apply assembled_denominator_dvd_qTight
  intro t ht
  exact coefficient_denominator_witness t (h t ht)

/-! ### Tightness (uses `Lean.ofReduceBool`): the declared LCMs are exactly the
LCMs of the frozen denominators, so `qW2`/`qR2` are derived from data, not
asserted. -/

theorem qW2_is_lcm_of_frozen : w2Denoms.foldr Nat.lcm 1 = qW2 := by native_decide

theorem qR2_is_lcm_of_frozen : r2Denoms.foldr Nat.lcm 1 = qR2 := by native_decide

end Workhouse.Rank3Order4QBoundWitnesses
