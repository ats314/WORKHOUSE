# Rank-3 order-4 QBOUND — per-coefficient denominator witnesses

This adds one Lean file, `Workhouse/Rank3Order4QBoundWitnesses.lean`, to the
existing certificate package.  It moves the bound from **declared** stage LCMs
(`qW2`, `qR2`) to **kernel-verified** per-coefficient denominator witnesses.

## What it proves (standard axioms: propext, Classical.choice, Quot.sound)

- `w2Denoms_dvd_qW2`, `r2Denoms_dvd_qR2` — each of the 58 W2 / 181 R2 distinct
  frozen denominators divides its stage LCM (`decide`).
- `qW2_dvd_qTight`, `qR2_dvd_qTight` — the stage LCMs divide QTIGHT (explicit
  quotient witnesses, `norm_num`).
- `w2Denoms_dvd_qTight`, `r2Denoms_dvd_qTight`, `coefficient_denominator_witness`
  — every frozen coefficient denominator divides QTIGHT.
- `frozen_assembly_denominator_dvd_qTight` — any `analyticRat + Σ terms` whose
  term denominators come from the frozen ledger has denominator dividing QTIGHT,
  reusing the base cert's `assembled_denominator_dvd_qTight`.

## Tightness (adds Lean.ofReduceBool)

- `qW2_is_lcm_of_frozen`, `qR2_is_lcm_of_frozen` — `qW2`/`qR2` are *exactly* the
  LCMs of the frozen denominators (`native_decide`), so they are derived from the
  ledger, not asserted.

## Provenance

`w2Denoms` / `r2Denoms` are the distinct reduced denominators of the
`W2_scaled` / `R2_scaled` records of the hash-pinned ledger
`rank3_order4_cubic_history_ledger.json`
(sha256 `543869b10f5137ea74fbd5f27d25027dea66f936ce9844b77a029453b8bf8c97`).
`extract_ledger_denominators.py <ledger.json>` regenerates both lists and
re-checks the hash and every Lean goal; the only remaining external premise is
that these lists are the ledger's denominators — a mechanical extraction against
a pinned hash.

## Trust boundary (unchanged from the base package)

Still a **denominator** certificate.  It does not compute endpoint-Haar
numerators, `D_EXACT`, or the fold/linked-vacuum scalars, and it does not
identify the frozen scope with the physical perturbation expansion.

## Build

Drop `Workhouse/Rank3Order4QBoundWitnesses.lean` beside the existing
`Workhouse/*.lean`, add `import Workhouse.Rank3Order4QBoundWitnesses` to the root
`Workhouse.lean`, and `lake build`.  Toolchain: leanprover/lean4:v4.34.0-rc1,
Mathlib rev 1f29011071772620f612bf5a06433775f06067b8 (same as the base package).
Not built in this session (no Lean toolchain available here); every `decide` /
`native_decide` / `norm_num` goal was pre-verified in Python by the extractor.
