#!/usr/bin/env python3
"""Regenerate the W2/R2 denominator lists in Rank3Order4QBoundWitnesses.lean
from the hash-pinned frozen history ledger, and re-verify every Lean goal.

Usage:  python extract_ledger_denominators.py path/to/rank3_order4_cubic_history_ledger.json
Exits nonzero if the ledger hash or any arithmetic goal fails.
"""
import json, sys, hashlib
from math import gcd
from functools import reduce

PINNED = "543869b10f5137ea74fbd5f27d25027dea66f936ce9844b77a029453b8bf8c97"
qW2, qR2 = 881280, 409824214482575692800
qTight   = 62895057857493885215590055852113920000000
lcm = lambda a, b: a * b // gcd(a, b)

def main(path):
    raw = open(path, "rb").read()
    h = hashlib.sha256(raw).hexdigest()
    assert h == PINNED, f"ledger hash {h} != pinned {PINNED}"
    recs = json.loads(raw)["records"]
    w2, r2 = set(), set()
    for r in recs:
        d = int(r["coefficient"].split("/")[1]) if "/" in r["coefficient"] else 1
        (w2 if r["stage"].startswith("W2") else r2).add(abs(d))
    w2, r2 = sorted(w2), sorted(r2)
    goals = {
        "|w2|==58": len(w2) == 58, "|r2|==181": len(r2) == 181,
        "foldr lcm w2 == qW2": reduce(lcm, reversed(w2), 1) == qW2,
        "foldr lcm r2 == qR2": reduce(lcm, reversed(r2), 1) == qR2,
        "all w2 | qW2": all(qW2 % d == 0 for d in w2),
        "all r2 | qR2": all(qR2 % d == 0 for d in r2),
        "qW2 | qTight": qTight % qW2 == 0, "qR2 | qTight": qTight % qR2 == 0,
        "all w2 | qTight": all(qTight % d == 0 for d in w2),
        "all r2 | qTight": all(qTight % d == 0 for d in r2),
    }
    for k, v in goals.items():
        print(f"[{'OK' if v else 'FAIL'}] {k}")
    assert all(goals.values())
    print("\nw2Denoms :=", w2)
    print("\nr2Denoms :=", r2)
    print("\nAll Lean goals reproduced. Ledger hash verified.")

if __name__ == "__main__":
    main(sys.argv[1])
