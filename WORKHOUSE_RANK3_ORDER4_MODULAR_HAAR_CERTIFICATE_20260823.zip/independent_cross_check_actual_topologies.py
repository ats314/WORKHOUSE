"""Stratified independent modular audit of the primary exact topology ledger."""

from __future__ import annotations

import gzip
import hashlib
import json
import pickle
import sys
import time
from collections import defaultdict
from fractions import Fraction
from pathlib import Path


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
sys.path.insert(0, str(WORK / "rank3_order4_cubic_ledger"))
import ledger_generator  # noqa: F401,E402 - pickle identity
sys.path.insert(0, str(HERE))
import modular_su3_projector as modular  # noqa: E402


def patterns(left: object, right: object) -> tuple[tuple[int, int], ...]:
    counts: dict[int, list[int]] = {}
    for link, orientation in left.occ:
        row = counts.setdefault(link, [0, 0])
        row[0 if not orientation else 1] += 1
    for link, orientation in right.occ:
        row = counts.setdefault(link, [0, 0])
        row[0 if orientation else 1] += 1
    return tuple(sorted(tuple(row) for row in counts.values()))


def state_payload(state: object) -> dict[str, object]:
    return {
        "occ": [[int(link), int(bool(orientation))] for link, orientation in state.occ],
        "part": [int(value) for value in state.part],
    }


def canonical_bytes(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("ascii")


def fraction_record(record: dict[str, int]) -> Fraction:
    return Fraction(int(record["numerator"]), int(record["denominator"]))


def topology_key(left: object, right: object) -> str:
    value = [
        [
            [[int(link), bool(orientation)] for link, orientation in state.occ],
            [int(part) for part in state.part],
        ]
        for state in (left, right)
    ]
    return json.dumps(value, separators=(",", ":"), ensure_ascii=True)


def run() -> None:
    pair_path = WORK / "root_exact_pair_topologies.pkl.gz"
    primary_path = WORK / "modular_haar_run" / "rank3_order4_exact_haar_numerators.ndjson.gz"
    summary_path = WORK / "modular_haar_run" / "rank3_order4_exact_haar_summary.json"
    with gzip.open(pair_path, "rb") as handle:
        pair_payload = pickle.load(handle)
    with gzip.open(primary_path, "rt", encoding="utf-8") as handle:
        primary_records = {
            json.dumps(record["topology"], separators=(",", ":"), ensure_ascii=True): record
            for line in handle
            if (record := json.loads(line))
        }
    primary_summary = json.loads(summary_path.read_text(encoding="utf-8"))

    items = list(pair_payload["pair_weights"].items())
    items.sort(
        key=lambda item: (
            (6, 0) in patterns(*item[0]) or (0, 6) in patterns(*item[0]),
            len(item[0][0].occ) + len(item[0][1].occ),
            item[0][0].occ,
            item[0][1].occ,
        )
    )
    if len(items) != len(primary_records):
        raise AssertionError(
            f"primary ledger has {len(primary_records)} records for {len(items)} classes"
        )

    groups: defaultdict[tuple[tuple[int, int], ...], list[int]] = defaultdict(list)
    for index, ((left, right), _weight) in enumerate(items):
        groups[patterns(left, right)].append(index)
    selected: set[int] = set()
    for indices in groups.values():
        selected.add(indices[0])
        selected.add(indices[-1])

    results = []
    started = time.monotonic()
    for progress, index in enumerate(sorted(selected), 1):
        (left, right), weight = items[index]
        key = topology_key(left, right)
        record = primary_records[key]
        stats: dict[str, object] = {}
        numerator, qh = modular.exact_haar_numerator(left, right, stats)
        observed = Fraction(numerator, qh)
        expected = fraction_record(record["haar"])
        expected_numerator = int(record["scaled_haar_numerator"])
        if observed != expected or numerator != expected_numerator:
            raise AssertionError(
                f"actual topology index {index+1} mismatch: modular={observed} "
                f"n={numerator}/{qh}, primary={expected} n={expected_numerator}"
            )
        topology = {"left": state_payload(left), "right": state_payload(right)}
        results.append(
            {
                "selection_index": index + 1,
                "primary_index": int(record["index"]),
                "signature": [list(value) for value in patterns(left, right)],
                "weight": f"{weight.numerator}/{weight.denominator}",
                "haar": f"{observed.numerator}/{observed.denominator}",
                "numerator_over_qH": numerator,
                "qH": qh,
                "topology_sha256": hashlib.sha256(canonical_bytes(topology)).hexdigest(),
                "topology": topology,
                "modular_stats": stats,
            }
        )
        print(
            f"stratified audit {progress}/{len(selected)} primary_index={record['index']} "
            f"signature={patterns(left,right)} value={observed}",
            flush=True,
        )

    certificate = {
        "schema": "workhouse-stratified-independent-modular-audit-v1",
        "primary_ledger": str(primary_path),
        "primary_ledger_sha256": primary_summary["haar_ledger_sha256"],
        "primary_D_exact": primary_summary["D_EXACT"],
        "endpoint_signature_strata": len(groups),
        "audited_topologies": len(results),
        "selection": "cheapest and hardest occurrence-ordered member of every endpoint signature",
        "all_exact_values_and_lifted_numerators_match": True,
        "results": results,
    }
    output = HERE / "stratified_actual_topology_modular_audit.json"
    output.write_text(json.dumps(certificate, indent=2, sort_keys=True), encoding="utf-8")
    print(
        f"PASS: {len(results)} actual topologies across all {len(groups)} signatures; "
        f"elapsed={time.monotonic()-started:.2f}s; output={output}",
        flush=True,
    )


if __name__ == "__main__":
    run()
