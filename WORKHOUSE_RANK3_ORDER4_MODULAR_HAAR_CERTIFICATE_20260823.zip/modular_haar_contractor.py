"""Fast exact modular SU(3) Haar contraction for the frozen O4 topology ledger.

This is scratch/certificate code.  It does not import the WORKHOUSE repository
or the independent reference contractor.  Each local Haar projector is scaled
by its certified local denominator and factorized over small auxiliary spaces.
The resulting integer tensor network is contracted modulo word-safe primes,
then recovered uniquely by a rigorous signed CRT bound.
"""

from __future__ import annotations

import gzip
import hashlib
import io
import itertools
import json
import math
import pickle
import sys
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "rank3_order4_cubic_ledger"))
import ledger_generator  # noqa: F401,E402 -- required only for frozen pickle identity


RANK = 3
Q_PATTERN = {
    (1, 1): 3,
    (2, 2): 24,
    (3, 3): 120,
    (3, 0): 6,
    (0, 3): 6,
    (6, 0): 72,
    (0, 6): 72,
}
SUPPORTED = frozenset(Q_PATTERN)
CRT_PRIMES = (1_000_000_007, 1_000_000_009, 998_244_353, 1_004_535_809)
QBOUND = 62_895_057_857_493_885_215_590_055_852_113_920_000_000


def inverse_permutation(permutation: Sequence[int]) -> tuple[int, ...]:
    result = [0] * len(permutation)
    for index, image in enumerate(permutation):
        result[image] = index
    return tuple(result)


def compose(left: Sequence[int], right: Sequence[int]) -> tuple[int, ...]:
    return tuple(left[right[index]] for index in range(len(left)))


def cycles(permutation: Sequence[int]) -> int:
    seen: set[int] = set()
    count = 0
    for start in range(len(permutation)):
        if start in seen:
            continue
        count += 1
        at = start
        while at not in seen:
            seen.add(at)
            at = permutation[at]
    return count


def permutation_sign(permutation: Sequence[int]) -> int:
    inversions = sum(
        permutation[i] > permutation[j]
        for i in range(len(permutation))
        for j in range(i + 1, len(permutation))
    )
    return -1 if inversions & 1 else 1


def invert_fraction_matrix(
    matrix: Sequence[Sequence[int | Fraction]],
) -> tuple[tuple[Fraction, ...], ...]:
    n = len(matrix)
    rows = [
        [Fraction(value) for value in row]
        + [Fraction(int(i == j)) for j in range(n)]
        for i, row in enumerate(matrix)
    ]
    for column in range(n):
        pivot = next(i for i in range(column, n) if rows[i][column])
        rows[column], rows[pivot] = rows[pivot], rows[column]
        scale = rows[column][column]
        rows[column] = [value / scale for value in rows[column]]
        for i in range(n):
            if i == column or not rows[i][column]:
                continue
            scale = rows[i][column]
            rows[i] = [a - scale * b for a, b in zip(rows[i], rows[column])]
    return tuple(tuple(row[n:]) for row in rows)


PERMUTATIONS = {
    k: tuple(itertools.permutations(range(k))) for k in (1, 2, 3)
}


def balanced_inverse(k: int) -> tuple[tuple[Fraction, ...], ...]:
    permutations = PERMUTATIONS[k]
    gram = tuple(
        tuple(
            Fraction(
                RANK
                ** cycles(compose(inverse_permutation(sigma), tau))
            )
            for tau in permutations
        )
        for sigma in permutations
    )
    return invert_fraction_matrix(gram)


BALANCED_INVERSE = {k: balanced_inverse(k) for k in (1, 2, 3)}


PURE_SIX_BASIS = (
    ((0, 1, 2), (3, 4, 5)),
    ((0, 1, 3), (2, 4, 5)),
    ((0, 1, 4), (2, 3, 5)),
    ((0, 2, 3), (1, 4, 5)),
    ((0, 2, 4), (1, 3, 5)),
)


def epsilon(values: Sequence[int]) -> int:
    return 0 if len(set(values)) != 3 else permutation_sign(values)


def pure_six_value(basis_index: int, colors: Sequence[int]) -> int:
    left, right = PURE_SIX_BASIS[basis_index]
    return epsilon(tuple(colors[i] for i in left)) * epsilon(
        tuple(colors[i] for i in right)
    )


PURE_SIX_VALUES = np.asarray(
    [
        [pure_six_value(b, colors) for colors in itertools.product(range(3), repeat=6)]
        for b in range(5)
    ],
    dtype=np.int64,
).reshape((5,) + (3,) * 6)
PURE_SIX_GRAM = tuple(
    tuple(
        Fraction(int(np.dot(PURE_SIX_VALUES[a].ravel(), PURE_SIX_VALUES[b].ravel())))
        for b in range(5)
    )
    for a in range(5)
)
PURE_SIX_INVERSE = invert_fraction_matrix(PURE_SIX_GRAM)


EPSILON3 = np.asarray(
    [epsilon(colors) for colors in itertools.product(range(3), repeat=3)],
    dtype=np.int64,
).reshape((3, 3, 3))


def integer_matrix(scale: int, matrix: Sequence[Sequence[Fraction]]) -> np.ndarray:
    values: list[list[int]] = []
    for row in matrix:
        out = []
        for value in row:
            scaled = value * scale
            if scaled.denominator != 1:
                raise ArithmeticError(f"nonintegral scaled projector entry {scaled}")
            out.append(scaled.numerator)
        values.append(out)
    return np.asarray(values, dtype=np.int64)


BALANCED_COEFFICIENT = {
    k: integer_matrix(Q_PATTERN[(k, k)], BALANCED_INVERSE[k])
    for k in (1, 2, 3)
}
PURE_SIX_COEFFICIENT = integer_matrix(72, PURE_SIX_INVERSE)


def selector_tensor(k: int, item: int) -> np.ndarray:
    """delta(x, y_{sigma(item)}) indexed by (sigma,x,y0,...,yk-1)."""
    permutations = PERMUTATIONS[k]
    result = np.zeros((len(permutations), 3) + (3,) * k, dtype=np.int64)
    for sigma_index, sigma in enumerate(permutations):
        for colors in itertools.product(range(3), repeat=k + 1):
            result[(sigma_index,) + colors] = int(colors[0] == colors[1 + sigma[item]])
    return result


SELECTOR = {
    (k, item): selector_tensor(k, item)
    for k in (2, 3)
    for item in range(k)
}


LOCAL_TRIANGLE_BOUND = {
    (1, 1): 1,
    (2, 2): int(
        Q_PATTERN[(2, 2)]
        * sum(abs(value) for row in BALANCED_INVERSE[2] for value in row)
    ),
    (3, 3): int(
        Q_PATTERN[(3, 3)]
        * sum(abs(value) for row in BALANCED_INVERSE[3] for value in row)
    ),
    (3, 0): 1,
    (0, 3): 1,
    (6, 0): int(72 * sum(abs(value) for row in PURE_SIX_INVERSE for value in row)),
    (0, 6): int(72 * sum(abs(value) for row in PURE_SIX_INVERSE for value in row)),
}


@dataclass(frozen=True)
class Factor:
    scope: tuple[int, ...]
    values: np.ndarray


def restrict_repeated_axes(
    raw_scope: Sequence[int], raw_values: np.ndarray, dimensions: dict[int, int]
) -> Factor:
    """Pull a tensor back along repeated variables, then sort its unique axes."""
    if len(raw_scope) != raw_values.ndim:
        raise ValueError("scope/rank mismatch")
    unique: list[int] = []
    position: dict[int, int] = {}
    axis_map: list[int] = []
    for variable in raw_scope:
        if variable not in position:
            position[variable] = len(unique)
            unique.append(variable)
        axis_map.append(position[variable])
    expected = tuple(dimensions[v] for v in raw_scope)
    if raw_values.shape != expected:
        raise ValueError(f"tensor dimensions {raw_values.shape} != {expected}")
    if len(unique) == len(raw_scope):
        reduced = raw_values
    else:
        grids = np.indices(tuple(dimensions[v] for v in unique), sparse=False)
        reduced = raw_values[tuple(grids[index] for index in axis_map)]
    sorted_scope = tuple(sorted(unique))
    if tuple(unique) != sorted_scope:
        permutation = tuple(unique.index(v) for v in sorted_scope)
        reduced = np.transpose(reduced, permutation)
    return Factor(sorted_scope, np.asarray(reduced, dtype=np.int64))


def combined_state(left: object, right: object) -> tuple[tuple[tuple[int, bool], ...], tuple[int, ...]]:
    left_occ = tuple((int(link), not bool(orientation)) for link, orientation in left.occ)
    right_occ = tuple((int(link), bool(orientation)) for link, orientation in right.occ)
    left_part = tuple(int(value) for value in left.part)
    right_part = tuple(int(value) for value in right.part)
    offset = max(left_part) + 1 if left_part else 0
    part = left_part + tuple(value + offset for value in right_part)
    return left_occ + right_occ, part


def build_network(left: object, right: object) -> tuple[list[Factor], dict[int, int], int, int, tuple[tuple[int, int], ...]]:
    occ, part = combined_state(left, right)
    color_count = max(part) + 1 if part else 0
    dimensions: dict[int, int] = {index: 3 for index in range(color_count)}
    next_variable = color_count
    groups: defaultdict[int, dict[bool, list[int]]] = defaultdict(
        lambda: {True: [], False: []}
    )
    for position, (link, orientation) in enumerate(occ):
        groups[link][orientation].append(position)

    factors: list[Factor] = []
    q_product = 1
    bound = 3**color_count
    patterns: list[tuple[int, int]] = []

    def color(position: int, side: int) -> int:
        return part[2 * position + side]

    def add(scope: Sequence[int], values: np.ndarray) -> None:
        factors.append(restrict_repeated_axes(scope, values, dimensions))

    for link in sorted(groups):
        positive = groups[link][True]
        negative = groups[link][False]
        pattern = (len(positive), len(negative))
        patterns.append(pattern)
        if pattern not in SUPPORTED:
            return [], dimensions, 1, 0, tuple(sorted(patterns))
        q_product *= Q_PATTERN[pattern]
        bound *= LOCAL_TRIANGLE_BOUND[pattern]

        if len(positive) == len(negative):
            k = len(positive)
            if k == 1:
                add((color(positive[0], 0), color(negative[0], 0)), np.eye(3, dtype=np.int64))
                add((color(positive[0], 1), color(negative[0], 1)), np.eye(3, dtype=np.int64))
                continue
            sigma = next_variable
            tau = next_variable + 1
            next_variable += 2
            dimensions[sigma] = math.factorial(k)
            dimensions[tau] = math.factorial(k)
            add((sigma, tau), BALANCED_COEFFICIENT[k])
            for item in range(k):
                add(
                    (sigma, color(positive[item], 0))
                    + tuple(color(position, 0) for position in negative),
                    SELECTOR[(k, item)],
                )
                add(
                    (tau, color(positive[item], 1))
                    + tuple(color(position, 1) for position in negative),
                    SELECTOR[(k, item)],
                )
            continue

        items = positive if positive else negative
        if pattern in {(3, 0), (0, 3)}:
            add(tuple(color(position, 0) for position in items), EPSILON3)
            add(tuple(color(position, 1) for position in items), EPSILON3)
            continue

        # Pure six: q P = sum_ab (q G^-1)_ab I_a(rows) I_b(cols).
        a = next_variable
        b = next_variable + 1
        next_variable += 2
        dimensions[a] = dimensions[b] = 5
        add((a, b), PURE_SIX_COEFFICIENT)
        add((a,) + tuple(color(position, 0) for position in items), PURE_SIX_VALUES)
        add((b,) + tuple(color(position, 1) for position in items), PURE_SIX_VALUES)

    return factors, dimensions, q_product, bound, tuple(sorted(patterns))


def modular_contract(
    input_factors: Sequence[Factor], dimensions: dict[int, int], prime: int,
    stats: dict[str, int] | None = None,
) -> int:
    factors = [Factor(f.scope, np.remainder(f.values, prime).astype(np.int64, copy=False)) for f in input_factors]
    peak = max((f.values.size for f in factors), default=1)
    while True:
        variables = {variable for factor in factors for variable in factor.scope}
        if not variables:
            break
        best = None
        for variable in variables:
            hit = tuple(index for index, factor in enumerate(factors) if variable in factor.scope)
            union = tuple(sorted({v for index in hit for v in factors[index].scope}))
            cost = math.prod(dimensions[v] for v in union)
            candidate = (cost, len(union), len(hit), variable, hit, union)
            if best is None or candidate[:4] < best[:4]:
                best = candidate
        assert best is not None
        cost, _width, _hit_count, variable, hit, union = best
        peak = max(peak, cost)
        product: np.ndarray | None = None
        for index in hit:
            factor = factors[index]
            shape = tuple(dimensions[v] if v in factor.scope else 1 for v in union)
            aligned = factor.values.reshape(shape)
            if product is None:
                product = aligned.copy()
            else:
                product = np.remainder(product * aligned, prime)
        assert product is not None
        axis = union.index(variable)
        reduced = np.remainder(np.sum(product, axis=axis, dtype=np.int64), prime)
        new_scope = union[:axis] + union[axis + 1 :]
        for index in reversed(hit):
            factors.pop(index)
        factors.append(Factor(new_scope, np.asarray(reduced, dtype=np.int64)))
    value = 1
    for factor in factors:
        value = (value * int(factor.values.reshape(-1)[0])) % prime
    if stats is not None:
        stats["peak_elements"] = max(stats.get("peak_elements", 0), peak)
    return value


def crt_pair(residues: Sequence[int], primes: Sequence[int]) -> tuple[int, int]:
    value = 0
    modulus = 1
    for residue, prime in zip(residues, primes):
        correction = ((residue - value) % prime) * pow(modulus, -1, prime) % prime
        value += modulus * correction
        modulus *= prime
    return value, modulus


def exact_scaled_contraction(
    left: object, right: object, stats: dict[str, int] | None = None
) -> tuple[int, int, int, tuple[int, ...], tuple[tuple[int, int], ...]]:
    factors, dimensions, q_product, bound, patterns = build_network(left, right)
    if bound == 0:
        return 0, q_product, bound, (), patterns
    required: list[int] = []
    modulus = 1
    for prime in CRT_PRIMES:
        required.append(prime)
        modulus *= prime
        if modulus > 2 * bound:
            break
    else:
        raise ArithmeticError(
            f"CRT prime pool insufficient: modulus={modulus}, 2*bound={2*bound}"
        )
    residues = [modular_contract(factors, dimensions, prime, stats) for prime in required]
    unsigned, modulus = crt_pair(residues, required)
    signed = unsigned if unsigned <= modulus // 2 else unsigned - modulus
    if abs(signed) > bound:
        raise ArithmeticError(f"CRT recovery outside rigorous bound: {signed}, {bound}")
    return signed, q_product, bound, tuple(required), patterns


def topology_key(left: object, right: object) -> str:
    record = [
        [[[int(link), bool(orientation)] for link, orientation in state.occ], list(map(int, state.part))]
        for state in (left, right)
    ]
    return json.dumps(record, separators=(",", ":"), ensure_ascii=True)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fraction_record(value: Fraction) -> dict[str, int]:
    return {"numerator": value.numerator, "denominator": value.denominator}


def stable_gzip_text_writer(path: Path):
    raw = path.open("wb")
    zipped = gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=6, mtime=0)
    return raw, zipped, io.TextIOWrapper(zipped, encoding="utf-8", newline="\n")


def run_ledger(source: Path, output_dir: Path) -> dict[str, object]:
    started = time.monotonic()
    source_sha = sha256_file(source)
    with gzip.open(source, "rb") as handle:
        payload = pickle.load(handle)
    rows = sorted(
        ((topology_key(*pair), pair, weight) for pair, weight in payload["pair_weights"].items()),
        key=lambda row: row[0],
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    ledger_path = output_dir / "rank3_order4_exact_haar_numerators.ndjson.gz"
    raw, zipped, text = stable_gzip_text_writer(ledger_path)
    weighted_sum = Fraction(0)
    zero_count = 0
    prime_histogram: Counter[int] = Counter()
    pattern_histogram: Counter[str] = Counter()
    peak_elements = 0
    try:
        for index, (key, (left, right), weight) in enumerate(rows, 1):
            local_stats: dict[str, int] = {}
            numerator, q_product, bound, primes, patterns = exact_scaled_contraction(
                left, right, local_stats
            )
            haar = Fraction(numerator, q_product)
            contribution = weight * haar
            weighted_sum += contribution
            zero_count += int(numerator == 0)
            prime_histogram[len(primes)] += 1
            peak_elements = max(peak_elements, local_stats.get("peak_elements", 0))
            pattern_key = ";".join(f"{a},{b}" for a, b in patterns)
            pattern_histogram[pattern_key] += 1
            record = {
                "index": index,
                "topology": json.loads(key),
                "patterns": [[a, b] for a, b in patterns],
                "weight": fraction_record(weight),
                "q_product": q_product,
                "scaled_haar_numerator": numerator,
                "haar": fraction_record(haar),
                "weighted_contribution": fraction_record(contribution),
                "signed_uniqueness_bound": bound,
                "crt_primes": list(primes),
            }
            text.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")
            if index % 250 == 0 or index == len(rows):
                elapsed = time.monotonic() - started
                rate = index / elapsed
                eta = (len(rows) - index) / rate if rate else float("inf")
                print(
                    f"haar {index}/{len(rows)} ({100*index/len(rows):.1f}%) "
                    f"rate={rate:.1f}/s eta={eta/60:.1f}m peak={peak_elements:,}",
                    flush=True,
                )
    finally:
        text.flush()
        text.close()  # closes zipped
        raw.close()

    d11 = Fraction(-13, 896)
    d_exact = d11 + weighted_sum / 2
    if QBOUND % d_exact.denominator:
        raise ArithmeticError(
            f"D_EXACT denominator {d_exact.denominator} does not divide QBOUND"
        )
    d_qbound_numerator = d_exact.numerator * (QBOUND // d_exact.denominator)
    if Fraction(d_qbound_numerator, QBOUND) != d_exact:
        raise ArithmeticError("integer-over-QBOUND accumulation does not reproduce D_EXACT")
    ledger_sha = sha256_file(ledger_path)
    summary = {
        "schema": "workhouse-rank3-order4-exact-haar-summary-v1",
        "source_topology_ledger": source.name,
        "source_topology_ledger_sha256": source_sha,
        "source_schema": payload.get("schema"),
        "historical_orientation_sensitive_topologies": payload["counts"]["historical_orientation_sensitive_topologies"],
        "fully_unordered_nonzero_topologies": len(rows),
        "zero_haar_topologies": zero_count,
        "local_q_pattern": {f"{a},{b}": q for (a, b), q in sorted(Q_PATTERN.items())},
        "local_triangle_bound": {f"{a},{b}": q for (a, b), q in sorted(LOCAL_TRIANGLE_BOUND.items())},
        "crt_prime_count_histogram": dict(sorted(prime_histogram.items())),
        "peak_modular_factor_elements": peak_elements,
        "weighted_haar_sum": fraction_record(weighted_sum),
        "D11": fraction_record(d11),
        "D_EXACT": fraction_record(d_exact),
        "D_EXACT_decimal": format(float(d_exact), ".17g"),
        "QBOUND": QBOUND,
        "D_EXACT_denominator_divides_QBOUND": True,
        "D_EXACT_QBOUND_numerator": d_qbound_numerator,
        "D_EXACT_integer_over_QBOUND_equality": True,
        "haar_ledger": ledger_path.name,
        "haar_ledger_sha256": ledger_sha,
        "elapsed_seconds": time.monotonic() - started,
    }
    summary_path = output_dir / "rank3_order4_exact_haar_summary.json"
    summary_path.write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, sort_keys=True), flush=True)
    return summary


if __name__ == "__main__":
    source = HERE / "root_exact_pair_topologies.pkl.gz"
    destination = HERE / "modular_haar_run"
    run_ledger(source, destination)
