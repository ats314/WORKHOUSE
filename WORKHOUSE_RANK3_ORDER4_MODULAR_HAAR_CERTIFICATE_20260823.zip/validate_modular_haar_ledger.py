from __future__ import annotations

import gzip
import hashlib
import json
from fractions import Fraction
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RUN = ROOT / "modular_haar_run"
LEDGER = RUN / "rank3_order4_exact_haar_numerators.ndjson.gz"
SUMMARY = RUN / "rank3_order4_exact_haar_summary.json"
QBOUND = 62_895_057_857_493_885_215_590_055_852_113_920_000_000
Q_PATTERN = {(0, 3): 6, (0, 6): 72, (1, 1): 3, (2, 2): 24, (3, 0): 6, (3, 3): 120, (6, 0): 72}
TRIANGLE = {(0, 3): 1, (0, 6): 66, (1, 1): 1, (2, 2): 8, (3, 0): 1, (3, 3): 120, (6, 0): 66}


def frac(row):
    return Fraction(int(row["numerator"]), int(row["denominator"]))


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


summary = json.loads(SUMMARY.read_text(encoding="utf-8"))
total = Fraction(0)
previous_key = ""
count = zeros = 0
with gzip.open(LEDGER, "rt", encoding="utf-8") as handle:
    for line in handle:
        row = json.loads(line)
        count += 1
        assert row["index"] == count
        key = json.dumps(row["topology"], separators=(",", ":"))
        assert key > previous_key
        previous_key = key
        patterns = tuple(tuple(map(int, p)) for p in row["patterns"])
        expected_q = 1
        expected_triangle = 1
        for pattern in patterns:
            expected_q *= Q_PATTERN[pattern]
            expected_triangle *= TRIANGLE[pattern]
        assert int(row["q_product"]) == expected_q
        left, right = row["topology"]
        left_classes = (max(left[1]) + 1) if left[1] else 0
        right_classes = (max(right[1]) + 1) if right[1] else 0
        expected_bound = (3 ** (left_classes + right_classes)) * expected_triangle
        assert int(row["signed_uniqueness_bound"]) == expected_bound
        modulus = 1
        for prime in row["crt_primes"]:
            modulus *= int(prime)
        assert modulus > 2 * expected_bound
        numerator = int(row["scaled_haar_numerator"])
        assert abs(numerator) <= expected_bound
        haar = Fraction(numerator, expected_q)
        assert frac(row["haar"]) == haar
        weight = frac(row["weight"])
        contribution = weight * haar
        assert frac(row["weighted_contribution"]) == contribution
        total += contribution
        zeros += int(numerator == 0)

assert count == 69_800 == int(summary["fully_unordered_nonzero_topologies"])
assert zeros == int(summary["zero_haar_topologies"])
assert frac(summary["weighted_haar_sum"]) == total
d_exact = Fraction(-13, 896) + total / 2
assert frac(summary["D_EXACT"]) == d_exact
assert QBOUND % d_exact.denominator == 0
lifted = d_exact.numerator * (QBOUND // d_exact.denominator)
assert int(summary["D_EXACT_QBOUND_numerator"]) == lifted
assert Fraction(lifted, QBOUND) == d_exact
assert sha(LEDGER) == summary["haar_ledger_sha256"]

certificate = {
    "schema": "workhouse-rank3-order4-exact-haar-ledger-validation-v1",
    "passed": True,
    "records": count,
    "strictly_sorted_unique_topology_keys": True,
    "record_q_products_recomputed": True,
    "record_signed_bounds_recomputed": True,
    "record_crt_modulus_exceeds_twice_bound": True,
    "record_haar_equal_scaled_numerator_over_q": True,
    "record_weighted_contributions_recomputed": True,
    "weighted_sum_recomputed": {"numerator": total.numerator, "denominator": total.denominator},
    "D_EXACT_recomputed": {"numerator": d_exact.numerator, "denominator": d_exact.denominator},
    "QBOUND": QBOUND,
    "D_EXACT_QBOUND_numerator": lifted,
    "QBOUND_divisibility_and_integer_lift_passed": True,
    "ledger_sha256": sha(LEDGER),
}
(RUN / "rank3_order4_exact_haar_validation.json").write_text(
    json.dumps(certificate, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
print(json.dumps(certificate, indent=2, sort_keys=True))
