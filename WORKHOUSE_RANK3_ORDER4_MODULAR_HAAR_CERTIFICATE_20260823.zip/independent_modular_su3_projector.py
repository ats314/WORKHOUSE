"""Exact SU(3) Haar numerators by modular factor-graph contraction.

This is algorithmically independent of the delta/DSU contractor.  Each local
Haar projector is first scaled by its declared common denominator to an integer
color tensor.  Shared trace indices become 3-valued factor-graph variables.
One variable is eliminated at a time modulo several machine-safe primes, and a
signed integer numerator is recovered by CRT under an explicit absolute bound.
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from typing import Iterable

import numpy as np

import exact_su3_projector as delta_reference


RANK = 3
LOCAL_Q = {
    (1, 1): 3,
    (2, 2): 24,
    (3, 3): 120,
    (3, 0): 6,
    (0, 3): 6,
    (6, 0): 72,
    (0, 6): 72,
}
CRT_PRIMES = (1_000_000_007, 1_000_000_009, 998_244_353, 1_004_535_809)
INT64_MAX = np.iinfo(np.int64).max
if any(
    math.gcd(left, right) != 1
    for index, left in enumerate(CRT_PRIMES)
    for right in CRT_PRIMES[index + 1 :]
):
    raise ArithmeticError("CRT moduli are not pairwise coprime")
if max(CRT_PRIMES) ** 2 >= INT64_MAX or 3 * max(CRT_PRIMES) >= INT64_MAX:
    raise ArithmeticError("CRT moduli exceed the proved int64 product/sum safety envelope")


def canonical_labels(labels: Iterable[int]) -> tuple[tuple[int, ...], tuple[int, ...]]:
    mapping: dict[int, int] = {}
    canonical: list[int] = []
    variables: list[int] = []
    for label in labels:
        if label not in mapping:
            mapping[label] = len(mapping)
            variables.append(label)
        canonical.append(mapping[label])
    return tuple(canonical), tuple(variables)


def epsilon(values: tuple[int, int, int]) -> int:
    if len(set(values)) != 3:
        return 0
    return delta_reference.permutation_sign(values)


@lru_cache(maxsize=None)
def balanced_integer_tensor(k: int) -> np.ndarray:
    permutations, inverse_gram = delta_reference.balanced_projector(k)
    q = LOCAL_Q[(k, k)]
    weights = np.asarray(
        [[int(value * q) for value in row] for row in inverse_gram], dtype=np.int64
    )
    assignments = tuple(itertools.product(range(RANK), repeat=2 * k))
    delta = np.zeros((len(permutations), len(assignments)), dtype=np.int64)
    for permutation_index, permutation in enumerate(permutations):
        for assignment_index, assignment in enumerate(assignments):
            positive = assignment[:k]
            negative = assignment[k:]
            delta[permutation_index, assignment_index] = int(
                all(positive[index] == negative[permutation[index]] for index in range(k))
            )
    tensor = delta.T @ weights @ delta
    return tensor.reshape((RANK,) * (4 * k))


@lru_cache(maxsize=1)
def determinant_integer_tensor() -> np.ndarray:
    values = np.asarray(
        [epsilon(colors) for colors in itertools.product(range(RANK), repeat=3)],
        dtype=np.int64,
    )
    return np.multiply.outer(values, values).reshape((RANK,) * 6)


@lru_cache(maxsize=1)
def pure_six_integer_tensor() -> np.ndarray:
    basis = delta_reference.PURE_SIX_BASIS
    inverse_gram = delta_reference.pure_six_gram_inverse()
    metric = np.asarray(
        [[int(value * 72) for value in row] for row in inverse_gram], dtype=np.int64
    )
    assignments = tuple(itertools.product(range(RANK), repeat=6))
    invariants = np.asarray(
        [
            [delta_reference.pure_six_tensor(item, colors) for colors in assignments]
            for item in basis
        ],
        dtype=np.int64,
    )
    tensor = invariants.T @ metric @ invariants
    return tensor.reshape((RANK,) * 12)


@lru_cache(maxsize=None)
def full_integer_tensor(pattern: tuple[int, int]) -> np.ndarray:
    if pattern[0] == pattern[1]:
        return balanced_integer_tensor(pattern[0])
    if pattern in {(3, 0), (0, 3)}:
        return determinant_integer_tensor()
    if pattern in {(6, 0), (0, 6)}:
        return pure_six_integer_tensor()
    raise ValueError(f"unsupported local Haar pattern {pattern}")


@lru_cache(maxsize=20_000)
def reduced_integer_tensor(
    pattern: tuple[int, int], local_equality_pattern: tuple[int, ...]
) -> np.ndarray:
    full = full_integer_tensor(pattern)
    variable_count = max(local_equality_pattern, default=-1) + 1
    grids = np.indices((RANK,) * variable_count, sparse=True)
    index = tuple(grids[label] for label in local_equality_pattern)
    reduced = np.asarray(full[index], dtype=np.int64)
    if reduced.shape != (RANK,) * variable_count:
        raise AssertionError(
            f"reduced tensor shape {reduced.shape} != {(RANK,) * variable_count}"
        )
    return reduced


@dataclass(frozen=True)
class Factor:
    variables: tuple[int, ...]
    values: np.ndarray


def combine_bra_ket(left: object, right: object) -> tuple[tuple[tuple[int, bool], ...], tuple[int, ...]]:
    bra = tuple((int(link), not bool(orientation)) for link, orientation in left.occ)
    ket = tuple((int(link), bool(orientation)) for link, orientation in right.occ)
    left_part = tuple(int(value) for value in left.part)
    right_part = tuple(int(value) for value in right.part)
    offset = max(left_part) + 1 if left_part else 0
    return bra + ket, delta_reference.canonical_partition(
        left_part + tuple(value + offset for value in right_part)
    )


def integer_factors(left: object, right: object) -> tuple[list[Factor], int, int]:
    occurrences, partition = combine_bra_ket(left, right)
    by_link: dict[int, dict[bool, list[int]]] = {}
    for position, (link, orientation) in enumerate(occurrences):
        by_link.setdefault(link, {True: [], False: []})[orientation].append(position)
    factors: list[Factor] = []
    qh = 1
    for link in sorted(by_link):
        positive = by_link[link][True]
        negative = by_link[link][False]
        pattern = (len(positive), len(negative))
        if pattern not in LOCAL_Q:
            raise ValueError(f"unsupported local Haar pattern {pattern}")
        qh *= LOCAL_Q[pattern]
        if positive and negative:
            positions = (
                tuple(2 * item for item in positive)
                + tuple(2 * item for item in negative)
                + tuple(2 * item + 1 for item in positive)
                + tuple(2 * item + 1 for item in negative)
            )
        else:
            items = positive if positive else negative
            positions = tuple(2 * item for item in items) + tuple(
                2 * item + 1 for item in items
            )
        labels = tuple(partition[position] for position in positions)
        local_pattern, global_variables = canonical_labels(labels)
        factors.append(
            Factor(global_variables, reduced_integer_tensor(pattern, local_pattern))
        )
    return factors, qh, len(set(partition))


def choose_variable(factors: list[Factor]) -> int:
    variables = sorted({variable for factor in factors for variable in factor.variables})
    if not variables:
        raise ValueError("no variable remains")
    scored = []
    for variable in variables:
        related = [factor for factor in factors if variable in factor.variables]
        union = {item for factor in related for item in factor.variables}
        scored.append((len(union), -len(related), variable))
    return min(scored)[2]


def contract_modulo(factors: list[Factor], prime: int) -> tuple[int, int, int]:
    active = [
        Factor(factor.variables, np.remainder(factor.values, prime).astype(np.int64, copy=False))
        for factor in factors
    ]
    peak_scope = peak_elements = 0
    while any(factor.variables for factor in active):
        variable = choose_variable(active)
        related = [factor for factor in active if variable in factor.variables]
        active = [factor for factor in active if variable not in factor.variables]
        union = tuple(sorted({item for factor in related for item in factor.variables}))
        peak_scope = max(peak_scope, len(union))
        peak_elements = max(peak_elements, RANK ** len(union))
        product = np.asarray(1, dtype=np.int64)
        for factor in related:
            ordered_variables = tuple(
                item for item in union if item in factor.variables
            )
            permutation = tuple(
                factor.variables.index(item) for item in ordered_variables
            )
            values = (
                factor.values.transpose(permutation)
                if permutation != tuple(range(len(permutation)))
                else factor.values
            )
            shape = [1] * len(union)
            for item in ordered_variables:
                shape[union.index(item)] = RANK
            product = np.remainder(
                product * values.reshape(tuple(shape)), prime
            ).astype(np.int64, copy=False)
        axis = union.index(variable)
        # Exactly one 3-valued color variable is removed per step.
        if 3 * (prime - 1) >= INT64_MAX:
            raise ArithmeticError("chosen modulus is unsafe for a three-term int64 sum")
        reduced = np.remainder(product.sum(axis=axis, dtype=np.int64), prime)
        remaining = tuple(item for item in union if item != variable)
        active.append(Factor(remaining, np.asarray(reduced, dtype=np.int64)))
    result = 1
    for factor in active:
        result = (result * int(np.asarray(factor.values).item())) % prime
    return result, peak_scope, peak_elements


def signed_crt(residues: tuple[int, ...], primes: tuple[int, ...]) -> tuple[int, int]:
    value = 0
    modulus = 1
    for residue, prime in zip(residues, primes):
        correction = ((residue - value) % prime) * pow(modulus % prime, -1, prime)
        correction %= prime
        value += modulus * correction
        modulus *= prime
    if value > modulus // 2:
        value -= modulus
    return value, modulus


def exact_haar_numerator(
    left: object, right: object, stats: dict[str, object] | None = None
) -> tuple[int, int]:
    factors, qh, variable_count = integer_factors(left, right)
    maximums = [int(np.max(np.abs(factor.values))) for factor in factors]
    bound = RANK**variable_count * math.prod(maximums)
    if any(value == 0 for value in maximums):
        return 0, qh
    selected_primes: list[int] = []
    selected_modulus = 1
    for prime in CRT_PRIMES:
        selected_primes.append(prime)
        selected_modulus *= prime
        if selected_modulus > 2 * bound:
            break
    if selected_modulus <= 2 * bound:
        raise ArithmeticError(
            f"available CRT primes do not isolate numerator under bound {bound}"
        )
    residues = []
    peak_scope = peak_elements = 0
    for prime in selected_primes:
        residue, scope, elements = contract_modulo(factors, prime)
        residues.append(residue)
        peak_scope = max(peak_scope, scope)
        peak_elements = max(peak_elements, elements)
    numerator, modulus = signed_crt(tuple(residues), tuple(selected_primes))
    if modulus <= 2 * bound:
        raise ArithmeticError(
            f"CRT modulus {modulus} does not isolate numerator under bound {bound}"
        )
    if abs(numerator) > bound:
        raise ArithmeticError(
            f"CRT numerator {numerator} escaped certified absolute bound {bound}"
        )
    value = Fraction(numerator, qh)
    if stats is not None:
        stats.update(
            {
                "variables": variable_count,
                "factors": len(factors),
                "qH": qh,
                "absolute_numerator_bound": bound,
                "crt_modulus": modulus,
                "peak_scope_variables": peak_scope,
                "peak_table_elements": peak_elements,
                "reduced_denominator": value.denominator,
            }
        )
    return numerator, qh


def exact_haar(
    left: object, right: object, stats: dict[str, object] | None = None
) -> Fraction:
    numerator, denominator = exact_haar_numerator(left, right, stats)
    return Fraction(numerator, denominator)
