from __future__ import annotations

import gzip
import json
import pickle
import random
import sys
import time
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [
    str(ROOT / "rank3_order4_cubic_ledger"),
    str(ROOT),
    str(ROOT / "independent_haar_audit"),
]
import ledger_generator  # noqa
import modular_haar_contractor as observed
import exact_su3_projector as reference


def fraction_row(value: Fraction):
    return {"numerator": value.numerator, "denominator": value.denominator}


started = time.monotonic()
assert observed.BALANCED_INVERSE == {
    k: reference.balanced_projector(k)[1] for k in (1, 2, 3)
}
assert observed.PURE_SIX_INVERSE == reference.pure_six_gram_inverse()

# Compare the pure-six projector through the reference's independent
# 488-permutation delta expansion on its complete 90x90 nonzero support, plus
# deterministic off-support probes.
values = observed.PURE_SIX_VALUES.reshape(5, 729)
ours_pure = values.T @ observed.PURE_SIX_COEFFICIENT @ values
colors = tuple(__import__("itertools").product(range(3), repeat=6))
support = [index for index in range(729) if np.any(values[:, index])]
assert len(support) == 90
reference_terms = reference.pure_six_permutation_coefficients()
pure_checks = 0
for row_index in support:
    row = colors[row_index]
    for col_index in support:
        col = colors[col_index]
        reference_value = sum(
            72 * coefficient
            for permutation, coefficient in reference_terms
            if all(row[i] == col[permutation[i]] for i in range(6))
        )
        assert reference_value.denominator == 1
        assert int(ours_pure[row_index, col_index]) == reference_value.numerator
        pure_checks += 1
rng = random.Random(314159265)
for _ in range(1000):
    row_index = rng.randrange(729)
    col_index = rng.randrange(729)
    row, col = colors[row_index], colors[col_index]
    reference_value = sum(
        72 * coefficient
        for permutation, coefficient in reference_terms
        if all(row[i] == col[permutation[i]] for i in range(6))
    )
    assert reference_value.denominator == 1
    assert int(ours_pure[row_index, col_index]) == reference_value.numerator
    pure_checks += 1

with gzip.open(ROOT / "root_exact_pair_topologies.pkl.gz", "rb") as handle:
    payload = pickle.load(handle)
cases: defaultdict[tuple[tuple[int, int], ...], list[tuple[object, object]]] = defaultdict(list)
for pair in payload["pair_weights"]:
    _factors, _dimensions, _q, _bound, patterns = observed.build_network(*pair)
    if (6, 0) in patterns or (0, 6) in patterns:
        continue
    if len(cases[patterns]) < 2:
        cases[patterns].append(pair)

actual_rows = []
for patterns in sorted(cases):
    for pair in cases[patterns]:
        numerator, q_product, bound, primes, _ = observed.exact_scaled_contraction(*pair)
        modular_value = Fraction(numerator, q_product)
        reference_value = reference.exact_haar(*pair)
        assert modular_value == reference_value
        actual_rows.append(
            {
                "patterns": [list(pattern) for pattern in patterns],
                "value": fraction_row(modular_value),
                "signed_bound": bound,
                "crt_primes": list(primes),
            }
        )

certificate = {
    "schema": "workhouse-modular-haar-independent-crosscheck-v1",
    "passed": True,
    "balanced_inverse_gram_exact_matches": [1, 2, 3],
    "pure_six_inverse_gram_exact_match": True,
    "pure_six_reference_delta_expansion_terms": len(reference_terms),
    "pure_six_scaled_projector_entries_checked": pure_checks,
    "pure_six_complete_nonzero_support_size": len(support),
    "actual_frozen_topologies_checked": len(actual_rows),
    "actual_endpoint_signatures_checked": len(cases),
    "actual_topology_results": actual_rows,
    "elapsed_seconds": time.monotonic() - started,
}
target = ROOT / "modular_haar_run" / "rank3_order4_modular_reference_crosscheck.json"
target.write_text(json.dumps(certificate, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({key: value for key, value in certificate.items() if key != "actual_topology_results"}, indent=2, sort_keys=True))
