"""Full exact D replay using the independent modular/CRT Haar contractor."""

from __future__ import annotations

import gzip
import hashlib
import json
import pickle
import sys
import time
from collections import Counter
from fractions import Fraction
from pathlib import Path


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
sys.path.insert(0, str(WORK / "rank3_order4_cubic_ledger"))
import ledger_generator  # noqa: F401,E402 - pickle identity
sys.path.insert(0, str(HERE))
import modular_su3_projector as modular  # noqa: E402


QBOUND = 62_895_057_857_493_885_215_590_055_852_113_920_000_000
D11 = Fraction(-13, 896)
FOLD = Fraction(5_315_003, 140_454)
LINKED_VACUUM = Fraction(-1_474_623, 1_675_520)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def patterns(left: object, right: object) -> tuple[tuple[int, int], ...]:
    counts: dict[int, list[int]] = {}
    for link, orientation in left.occ:
        row = counts.setdefault(link, [0, 0])
        row[0 if not orientation else 1] += 1
    for link, orientation in right.occ:
        row = counts.setdefault(link, [0, 0])
        row[0 if orientation else 1] += 1
    return tuple(sorted(tuple(row) for row in counts.values()))


def text(value: Fraction) -> str:
    return f"{value.numerator}/{value.denominator}"


def state_payload(state: object) -> dict[str, object]:
    return {
        "occ": [[int(link), int(bool(orientation))] for link, orientation in state.occ],
        "part": [int(value) for value in state.part],
    }


def canonical_bytes(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("ascii")


def run() -> None:
    pair_path = WORK / "root_exact_pair_topologies.pkl.gz"
    with gzip.open(pair_path, "rb") as handle:
        payload = pickle.load(handle)
    items = list(payload["pair_weights"].items())
    items.sort(
        key=lambda item: (
            len(item[0][0].occ) + len(item[0][1].occ),
            item[0][0].occ,
            item[0][1].occ,
            item[0][0].part,
            item[0][1].part,
        )
    )
    checkpoint_path = HERE / "modular_crt_replay_checkpoint.pkl"
    pair_hash = sha256_file(pair_path)
    if checkpoint_path.exists():
        checkpoint = pickle.loads(checkpoint_path.read_bytes())
        if checkpoint["pair_hash"] != pair_hash:
            raise RuntimeError("checkpoint belongs to a different pair ledger")
        start_index = int(checkpoint["index"])
        total_numerator = int(checkpoint["total_numerator"])
        nonzero, zero = checkpoint["nonzero"], checkpoint["zero"]
        denominators = Counter(checkpoint["denominators"])
        pattern_histogram = Counter(checkpoint["pattern_histogram"])
        peak_scope = checkpoint["peak_scope"]
        peak_elements = checkpoint["peak_elements"]
        max_bound = checkpoint["max_bound"]
        records = checkpoint["records"]
        print(f"resuming exact CRT replay at {start_index:,}/{len(items):,}", flush=True)
    else:
        start_index = 0
        total_numerator = D11.numerator * (QBOUND // D11.denominator)
        nonzero = zero = 0
        denominators: Counter[int] = Counter()
        pattern_histogram: Counter[str] = Counter()
        peak_scope = peak_elements = max_bound = 0
        records: list[dict[str, object]] = []
    started = last = time.monotonic()

    for index, ((left, right), weight) in enumerate(items[start_index:], start_index + 1):
        stats: dict[str, object] = {}
        numerator, qh = modular.exact_haar_numerator(left, right, stats)
        haar = Fraction(numerator, qh)
        term = weight * haar / 2
        if QBOUND % term.denominator:
            raise ArithmeticError(
                f"topology {index}: term denominator {term.denominator} escapes QBOUND"
            )
        total_numerator += term.numerator * (QBOUND // term.denominator)
        nonzero += int(bool(haar))
        zero += int(not haar)
        denominators[haar.denominator] += 1
        local_patterns = patterns(left, right)
        pattern_histogram.update(map(str, local_patterns))
        peak_scope = max(peak_scope, int(stats.get("peak_scope_variables", 0)))
        peak_elements = max(peak_elements, int(stats.get("peak_table_elements", 0)))
        max_bound = max(max_bound, int(stats.get("absolute_numerator_bound", 0)))
        topology = {"left": state_payload(left), "right": state_payload(right)}
        record = {
                "index": index,
                "topology": topology,
                "topology_sha256": hashlib.sha256(canonical_bytes(topology)).hexdigest(),
                "patterns": [list(pattern) for pattern in local_patterns],
                "weight": text(weight),
                "local_common_denominator": qh,
                "exact_haar_numerator_over_local_denominator": numerator,
                "haar": text(haar),
                "contribution": text(term),
                "crt_bound": stats.get("absolute_numerator_bound", 0),
                "peak_scope_variables": stats.get("peak_scope_variables", 0),
            }
        records.append(record)
        now = time.monotonic()
        if index % 500 == 0 or now - last >= 15 or index == len(items):
            rate = index / max(now - started, 1e-9)
            print(
                f"modular exact Haar {index:,}/{len(items):,} nonzero={nonzero:,} "
                f"rate={rate:,.1f}/s elapsed={now-started:.1f}s "
                f"ETA={(len(items)-index)/max(rate,1e-9)/60:.1f}m "
                f"peak_scope={peak_scope}",
                flush=True,
            )
            last = now
        if index % 5_000 == 0:
            checkpoint = {
                "pair_hash": pair_hash,
                "index": index,
                "total_numerator": total_numerator,
                "nonzero": nonzero,
                "zero": zero,
                "denominators": dict(denominators),
                "pattern_histogram": dict(pattern_histogram),
                "peak_scope": peak_scope,
                "peak_elements": peak_elements,
                "max_bound": max_bound,
                "records": records,
            }
            temporary = checkpoint_path.with_suffix(".tmp")
            temporary.write_bytes(pickle.dumps(checkpoint, protocol=5))
            temporary.replace(checkpoint_path)

    direct = Fraction(total_numerator, QBOUND)
    full = direct + FOLD - LINKED_VACUUM
    result = {
        "schema": "workhouse-independent-modular-crt-exact-haar-ledger-v1",
        "method": (
            "integer local projectors + greedy 3-color variable elimination modulo four primes "
            "+ signed CRT under an explicit per-topology absolute bound"
        ),
        "source_pair_ledger_sha256": pair_hash,
        "source_counts": payload["counts"],
        "fully_unordered_exact_contraction_classes": len(items),
        "nonzero_haar_values": nonzero,
        "zero_haar_values": zero,
        "qbound": QBOUND,
        "total_integer_numerator_over_qbound": total_numerator,
        "D_exact": text(direct),
        "D_decimal": float(direct),
        "fold": text(FOLD),
        "linked_vacuum": text(LINKED_VACUUM),
        "m4_rest_exact": text(full),
        "m4_rest_decimal": float(full),
        "haar_denominator_histogram": {
            str(key): value for key, value in sorted(denominators.items())
        },
        "pattern_histogram": dict(sorted(pattern_histogram.items())),
        "global_peak_scope_variables": peak_scope,
        "global_peak_table_elements": peak_elements,
        "largest_certified_numerator_bound": max_bound,
        "crt_modulus": math_product(modular.CRT_PRIMES),
        "records": records,
    }
    output = HERE / "independent_modular_crt_exact_haar_numerators.json.gz"
    with output.open("wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", compresslevel=6, mtime=0) as compressed:
            compressed.write(canonical_bytes(result))
    summary = {key: value for key, value in result.items() if key != "records"}
    print(json.dumps(summary, indent=2, sort_keys=True), flush=True)
    output_hash = sha256_file(output)
    status = {
        "status": "complete",
        "canonical_output": str(output),
        "canonical_output_sha256": output_hash,
        "elapsed_seconds": time.monotonic() - started,
    }
    (HERE / "independent_modular_crt_exact_haar_status.json").write_text(
        json.dumps(status, indent=2, sort_keys=True), encoding="utf-8"
    )
    print(f"output={output} sha256={output_hash}", flush=True)


def math_product(values: tuple[int, ...]) -> int:
    result = 1
    for value in values:
        result *= value
    return result


if __name__ == "__main__":
    run()
