# Independent referee report: rank-3, order-4 exact Haar sum

## Verdict

The exact endpoint-Haar contraction and final `D_EXACT` sum pass an independent arithmetic audit.  The result is

\[
\sum_T w_T H_T=
-\frac{805586892848311021}{8092176661386675},
\qquad
D_{\mathrm{EXACT}}
=-\frac{13}{896}+\frac12\sum_Tw_TH_T
=-\frac{361008126292641364183}{7250590288602460800}.
\]

The decimal is `-49.790170444484609`.  Its denominator divides the frozen

`QBOUND = 62895057857493885215590055852113920000000`,

and the integer-over-`QBOUND` lift reconstructs the same rational exactly.

Using the separately reproduced exact scalars

\[
F=\frac{5315003}{140454},\qquad
V_{\rm linked}=-\frac{1474623}{1675520},
\]

the requested combination is

\[
m_{4,\rm rest}=D_{\mathrm{EXACT}}+F-V_{\rm linked}
=-\frac{160506019419340168451}{14501180577204921600}
\approx -11.068479463778765.
\]

## Independent route

The primary contractor uses integer low-rank local SU(3) projectors, modular variable elimination, an explicit triangle bound, and signed CRT uniqueness.  I implemented a separate contractor with independently generated local tensors:

- balanced sectors through `k=3` from an exact inverse permutation Gram matrix;
- determinant sectors from epsilon tensors;
- pure-six sectors from the five-dimensional `(2,2,2)` invariant space, whose projector expands to 488 nonzero delta terms after exact cancellation;
- a separate factor graph and elimination implementation modulo CRT primes.

Three-way synthetic tests agreed on 180/180 contractions among two exact delta/partition implementations and the modular implementation.  On the actual frozen ledger, the independent modular implementation matched both the lifted numerator and reduced Haar rational for 44 selected topologies: the easiest and hardest representative of each of all 22 endpoint-pattern signatures, including the pure-six signatures.

The full 69,800-record primary ledger was then replayed record by record.  The verifier independently checked topology uniqueness and order, local `q` products, signed CRT bounds, lifted numerators, reduced Haar values, weighted contributions, the accumulated Haar sum, `D_EXACT`, and both `QBOUND` gates.  All checks passed.

## Topology census

The historical count of 117,161 is a count of orientation-sensitive canonical keys, not the minimal invariant contraction census.  Exact joint physical-link relabelling plus the symmetry under exchanging the two Haar arguments aggregates those records losslessly into 69,800 fully unordered contraction classes.  Of these, 10,368 contain a pure-six local sector and 9,184 have zero final Haar value.  The underlying generation census still has 5,400 matched sectors, raw pair upper bound 9,814,138, and 54 deliberately skipped one-face matches.

The quotient was performed by summing exact weights before contraction; it does not change the scalar.

## Earliest historical certificate fault

The earliest material weakness is not the final `1/2` normalization.  That factor is consistent with the stored `sqrt(2)` scaling of both halves of the bilinear.  The earliest certificate fault is the old topology contractor's use of a floating Haar value followed by multiplication by `q_H` and rounding to an integer.  Dense and long-double agreement made that a strong numerical check but did not make the numerator symbolic.  The present integer projector plus CRT route removes that circularity.

The earlier pair key was also representation-sensitive: changing insertion order could change the reported key count.  Full unordered pair canonicalization removes that false census instability.  It did not reveal a missing numerical term after exact weight aggregation.

This audit certifies the arithmetic over the frozen generator lineage.  It does not by itself prove that the frozen primitive generator is a complete physical perturbation expansion; that remains a separate modeling/provenance obligation.

## Artifacts

- Primary ledger SHA-256: `1b9ed1801e1125e15c4331cb0b06fe2a6782f0638efe725640f3602001f1b469`
- Source topology ledger SHA-256: `5337734a57bd2e1fe690c636f19bc0f65c48bac86cc029a7e4dfe87251e8ff59`
- Independent 44-case certificate: `stratified_actual_topology_modular_audit.json`
