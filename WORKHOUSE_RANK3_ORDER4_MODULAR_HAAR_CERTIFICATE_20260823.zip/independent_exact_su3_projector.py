"""Independent exact SU(3) endpoint-Haar contractor.

This module deliberately does not import the historical notebook contractor.
It realizes every local pattern in the frozen rank-3/order-4 corpus as an
exact projector onto the corresponding SU(3)-invariant subspace:

* balanced k=0,1,2,3: inverse permutation Gram (unitary Weingarten);
* pure three: the determinant/epsilon projector;
* pure six: a five-dimensional (2,2,2) invariant basis and its exact Gram
  inverse.

Every local projector is expanded into Kronecker-delta identifications.  The
global trace-network contraction is then an integer loop count, so the return
value is a ``fractions.Fraction`` with no reconstruction or tolerance.
"""

from __future__ import annotations

import itertools
import math
from collections import defaultdict
from fractions import Fraction
from functools import lru_cache
from typing import Iterable, Sequence


RANK = 3
SUPPORTED = {(1, 1), (2, 2), (3, 3), (3, 0), (0, 3), (6, 0), (0, 6)}


def canonical_partition(labels: Iterable[int]) -> tuple[int, ...]:
    mapping: dict[int, int] = {}
    result: list[int] = []
    for label in labels:
        if label not in mapping:
            mapping[label] = len(mapping)
        result.append(mapping[label])
    return tuple(result)


def merge_partition(
    part: tuple[int, ...], pairs: Iterable[tuple[int, int]]
) -> tuple[int, ...]:
    """Merge *positions* in a canonical equality partition."""

    parent = list(range(len(part)))

    def find(value: int) -> int:
        while parent[value] != value:
            parent[value] = parent[parent[value]]
            value = parent[value]
        return value

    def union(left: int, right: int) -> None:
        left_root, right_root = find(left), find(right)
        if left_root != right_root:
            parent[right_root] = left_root

    first_position: dict[int, int] = {}
    for position, label in enumerate(part):
        if label in first_position:
            union(position, first_position[label])
        else:
            first_position[label] = position
    for left, right in pairs:
        union(left, right)
    return canonical_partition(find(position) for position in range(len(part)))


def permutation_sign(permutation: Sequence[int]) -> int:
    inversions = sum(
        permutation[first] > permutation[second]
        for first in range(len(permutation))
        for second in range(first + 1, len(permutation))
    )
    return -1 if inversions % 2 else 1


def inverse_permutation(permutation: Sequence[int]) -> tuple[int, ...]:
    result = [0] * len(permutation)
    for index, image in enumerate(permutation):
        result[image] = index
    return tuple(result)


def compose_permutations(
    left: Sequence[int], right: Sequence[int]
) -> tuple[int, ...]:
    return tuple(left[right[index]] for index in range(len(left)))


def permutation_cycles(permutation: Sequence[int]) -> int:
    seen: set[int] = set()
    cycles = 0
    for start in range(len(permutation)):
        if start in seen:
            continue
        cycles += 1
        current = start
        while current not in seen:
            seen.add(current)
            current = permutation[current]
    return cycles


def invert_fraction_matrix(
    matrix: Sequence[Sequence[Fraction | int]],
) -> tuple[tuple[Fraction, ...], ...]:
    size = len(matrix)
    rows = [
        [Fraction(value) for value in row]
        + [Fraction(int(column == index)) for column in range(size)]
        for index, row in enumerate(matrix)
    ]
    for column in range(size):
        pivot = next((row for row in range(column, size) if rows[row][column]), None)
        if pivot is None:
            raise ArithmeticError("singular exact Gram matrix")
        rows[column], rows[pivot] = rows[pivot], rows[column]
        scale = rows[column][column]
        rows[column] = [value / scale for value in rows[column]]
        for row in range(size):
            if row == column or not rows[row][column]:
                continue
            scale = rows[row][column]
            rows[row] = [
                rows[row][index] - scale * rows[column][index]
                for index in range(2 * size)
            ]
    return tuple(tuple(row[size:]) for row in rows)


@lru_cache(maxsize=None)
def balanced_projector(k: int) -> tuple[tuple[tuple[int, ...], ...], tuple[tuple[Fraction, ...], ...]]:
    permutations = tuple(itertools.permutations(range(k)))
    gram = tuple(
        tuple(
            Fraction(
                RANK
                ** permutation_cycles(
                    compose_permutations(inverse_permutation(sigma), tau)
                )
            )
            for tau in permutations
        )
        for sigma in permutations
    )
    return permutations, invert_fraction_matrix(gram)


# Five standard tableaux of shape (2,2,2), represented by their two columns.
# Their epsilon-pair tensors form a basis of Inv((C^3)^tensor 6).
PURE_SIX_BASIS = (
    ((0, 1, 2), (3, 4, 5)),
    ((0, 1, 3), (2, 4, 5)),
    ((0, 1, 4), (2, 3, 5)),
    ((0, 2, 3), (1, 4, 5)),
    ((0, 2, 4), (1, 3, 5)),
)


def epsilon(values: Sequence[int]) -> int:
    if len(set(values)) < 3:
        return 0
    return permutation_sign(values)


def pure_six_tensor(
    basis: tuple[tuple[int, int, int], tuple[int, int, int]],
    colors: Sequence[int],
) -> int:
    left, right = basis
    return epsilon(tuple(colors[index] for index in left)) * epsilon(
        tuple(colors[index] for index in right)
    )


@lru_cache(maxsize=1)
def pure_six_gram_inverse() -> tuple[tuple[Fraction, ...], ...]:
    assignments = tuple(itertools.product(range(RANK), repeat=6))
    values = tuple(
        tuple(pure_six_tensor(basis, colors) for colors in assignments)
        for basis in PURE_SIX_BASIS
    )
    gram = tuple(
        tuple(Fraction(sum(x * y for x, y in zip(left, right))) for right in values)
        for left in values
    )
    return invert_fraction_matrix(gram)


@lru_cache(maxsize=1)
def pure_six_permutation_coefficients() -> tuple[tuple[tuple[int, ...], Fraction], ...]:
    """Expand the rank-five pure-six projector into delta permutations."""

    inverse_gram = pure_six_gram_inverse()
    triples = tuple(itertools.permutations(range(3)))
    coefficients: defaultdict[tuple[int, ...], Fraction] = defaultdict(Fraction)
    for left_index, left_basis in enumerate(PURE_SIX_BASIS):
        left_a, left_b = left_basis
        for right_index, right_basis in enumerate(PURE_SIX_BASIS):
            coefficient = inverse_gram[left_index][right_index]
            if not coefficient:
                continue
            right_a, right_b = right_basis
            for sigma in triples:
                sigma_sign = permutation_sign(sigma)
                for tau in triples:
                    mapping = [-1] * 6
                    for index in range(3):
                        mapping[left_a[index]] = right_a[sigma[index]]
                        mapping[left_b[index]] = right_b[tau[index]]
                    coefficients[tuple(mapping)] += (
                        coefficient * sigma_sign * permutation_sign(tau)
                    )
    return tuple(sorted((permutation, value) for permutation, value in coefficients.items() if value))


def combine_bra_ket(left: object, right: object) -> tuple[tuple[tuple[int, bool], ...], tuple[int, ...]]:
    left_occ = tuple((int(link), not bool(orientation)) for link, orientation in left.occ)
    right_occ = tuple((int(link), bool(orientation)) for link, orientation in right.occ)
    left_part = tuple(int(value) for value in left.part)
    right_part = tuple(int(value) for value in right.part)
    offset = max(left_part) + 1 if left_part else 0
    return left_occ + right_occ, canonical_partition(
        left_part + tuple(value + offset for value in right_part)
    )


@lru_cache(maxsize=500_000)
def exact_haar_from_raw(
    left_occ: tuple[tuple[int, bool], ...],
    left_part: tuple[int, ...],
    right_occ: tuple[tuple[int, bool], ...],
    right_part: tuple[int, ...],
) -> Fraction:
    class State:
        pass

    left, right = State(), State()
    left.occ, left.part = left_occ, left_part
    right.occ, right.part = right_occ, right_part
    return exact_haar(left, right)


def _exact_haar_impl(
    left: object, right: object, stats: dict[str, object] | None = None
) -> Fraction:
    occ, initial_part = combine_bra_ket(left, right)
    by_link: defaultdict[int, dict[bool, list[int]]] = defaultdict(
        lambda: {True: [], False: []}
    )
    for position, (link, orientation) in enumerate(occ):
        by_link[link][orientation].append(position)

    def branch_count(link: int) -> int:
        group = by_link[link]
        pattern = (len(group[True]), len(group[False]))
        if pattern in {(1, 1)}:
            return 1
        if pattern == (2, 2):
            return 4
        if pattern in {(3, 0), (0, 3)}:
            return 6
        if pattern == (3, 3):
            return 36
        if pattern in {(6, 0), (0, 6)}:
            return len(pure_six_permutation_coefficients())
        return 10**9

    states: dict[tuple[int, ...], Fraction] = {initial_part: Fraction(1)}
    for link in sorted(by_link, key=lambda item: (branch_count(item), item)):
        positive = by_link[link][True]
        negative = by_link[link][False]
        pattern = (len(positive), len(negative))
        if stats is not None:
            frequencies = stats.setdefault("pattern_frequency", {})
            assert isinstance(frequencies, dict)
            key = f"{pattern[0]},{pattern[1]}"
            frequencies[key] = int(frequencies.get(key, 0)) + 1
        if pattern not in SUPPORTED:
            return Fraction(0)
        new_states: defaultdict[tuple[int, ...], Fraction] = defaultdict(Fraction)

        if len(positive) == len(negative):
            k = len(positive)
            permutations, inverse_gram = balanced_projector(k)
            for part, old_coefficient in states.items():
                for sigma_index, sigma in enumerate(permutations):
                    for tau_index, tau in enumerate(permutations):
                        coefficient = inverse_gram[sigma_index][tau_index]
                        if not coefficient:
                            continue
                        pairs: list[tuple[int, int]] = []
                        for index in range(k):
                            pairs.append(
                                (2 * positive[index], 2 * negative[sigma[index]])
                            )
                            pairs.append(
                                (2 * positive[index] + 1, 2 * negative[tau[index]] + 1)
                            )
                        new_states[merge_partition(part, pairs)] += (
                            old_coefficient * coefficient
                        )

        elif pattern in {(3, 0), (0, 3)}:
            items = positive if positive else negative
            for part, old_coefficient in states.items():
                for permutation in itertools.permutations(range(3)):
                    pairs = tuple(
                        (2 * items[index], 2 * items[permutation[index]] + 1)
                        for index in range(3)
                    )
                    new_states[merge_partition(part, pairs)] += old_coefficient * Fraction(
                        permutation_sign(permutation), math.factorial(3)
                    )

        else:
            items = positive if positive else negative
            for part, old_coefficient in states.items():
                for permutation, coefficient in pure_six_permutation_coefficients():
                    pairs = tuple(
                        (2 * items[index], 2 * items[permutation[index]] + 1)
                        for index in range(6)
                    )
                    new_states[merge_partition(part, pairs)] += (
                        old_coefficient * coefficient
                    )

        states = {part: coefficient for part, coefficient in new_states.items() if coefficient}
        if stats is not None:
            stats["peak_partition_states"] = max(
                int(stats.get("peak_partition_states", 0)), len(states)
            )
            stats["integrated_links"] = int(stats.get("integrated_links", 0)) + 1
        if not states:
            return Fraction(0)

    return sum(
        (coefficient * RANK ** len(set(part)) for part, coefficient in states.items()),
        Fraction(0),
    )


@lru_cache(maxsize=150_000)
def _exact_haar_cached(left: object, right: object) -> Fraction:
    return _exact_haar_impl(left, right, None)


def exact_haar(
    left: object, right: object, stats: dict[str, object] | None = None
) -> Fraction:
    """Contract one endpoint pair, caching the ordinary no-stats route."""

    if stats is None:
        return _exact_haar_cached(left, right)
    return _exact_haar_impl(left, right, stats)


def self_certificate() -> dict[str, object]:
    balanced = {}
    for k in range(4):
        permutations, inverse_gram = balanced_projector(k)
        denominators = {value.denominator for row in inverse_gram for value in row}
        balanced[str(k)] = {
            "dimension": len(permutations),
            "inverse_denominators": sorted(denominators),
        }
    pure_six_inverse = pure_six_gram_inverse()
    pure_six_coefficients = pure_six_permutation_coefficients()
    return {
        "rank": RANK,
        "balanced": balanced,
        "pure_six_basis_dimension": len(PURE_SIX_BASIS),
        "pure_six_inverse_gram": [
            [str(value) for value in row] for row in pure_six_inverse
        ],
        "pure_six_nonzero_delta_permutations": len(pure_six_coefficients),
        "pure_six_delta_coefficient_denominators": sorted(
            {value.denominator for _, value in pure_six_coefficients}
        ),
        "pure_six_projector_trace": projector_trace_pure_six(),
    }


def projector_trace_pure_six() -> int:
    inverse_gram = pure_six_gram_inverse()
    assignments = tuple(itertools.product(range(RANK), repeat=6))
    values = tuple(
        tuple(pure_six_tensor(basis, colors) for colors in assignments)
        for basis in PURE_SIX_BASIS
    )
    trace = Fraction(0)
    for left in range(len(PURE_SIX_BASIS)):
        for right in range(len(PURE_SIX_BASIS)):
            trace += inverse_gram[left][right] * sum(
                values[left][index] * values[right][index]
                for index in range(len(assignments))
            )
    if trace.denominator != 1:
        raise ArithmeticError(f"pure-six projector trace is not integral: {trace}")
    return trace.numerator
