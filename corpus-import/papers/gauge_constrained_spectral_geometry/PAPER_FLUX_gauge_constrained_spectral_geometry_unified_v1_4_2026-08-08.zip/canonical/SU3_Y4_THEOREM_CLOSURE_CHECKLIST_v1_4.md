# SU(3) O(y^4) Theorem-Closure Checklist — v1.4

**Goal:** promote the exact fourth-order computational ledger to a cold, end-to-end computer-assisted theorem without changing the target coefficient values unless a gate actually fails.

## Gate 1 — `PVP=aP`

**Claim to verify**
\[
PVP=aP
\]
on the full degenerate one-flux model space.

**Pass condition:** construct the exact matrix `PVP`; prove every off-diagonal entry is zero and every diagonal entry is the same rational number. Record the rational `a` and a SHA-256 of the generated matrix/ledger.

**Failure consequence:** the folded perturbation formulas must be rebuilt with non-scalar `PVP`; all fourth-order physical coefficients are reopened.

## Gate 2 — degenerate folded effective Hamiltonian

**Pass condition:** generate random and/or symbolic finite Hamiltonians with model-space dimension `dim(P)>1`, compare the folded des-Cloizeaux operator coefficient through fourth/fifth order against direct order-by-order block-diagonalization, and verify both diagonal and off-diagonal matrix entries exactly or to certified rational reconstruction.

**Failure consequence:** reopen all folded topologies; homological `O(y^2)` and structural `O(y^3)` results remain intact.

## Gate 3 — full Stage-3H independent regression

Current independent coverage: 1,478 / 3,895 topologies.  
Missing: 2,417 mixed/all-resonant folded topologies.

**Pass condition:** independent implementation reproduces all 3,895 topology amplitudes and the final 189-record kernel exactly.

## Gate 4 — magnetic-prefactor normalization

**Pass condition:** derive the perturbative magnetic operator from the Kogut-Susskind Hamiltonian used by the code, establish the exact coefficient multiplying every insertion, and write a single machine-checked identity mapping the simulation variable `y` to canonical `u=beta_H/6`.

**Failure consequence:** coefficient *shape* may survive while all fourth-order numerical amplitudes require a global rescaling.

## Gate 5 — fully rigorous interval certificate

Replace all `mp.mpf -> iv` point wraps by outward-rounded interval operations, including `theta`, `delta`, `plo/phi`, and the Brillouin-zone tiling endpoints. Tile using an outward-rounded enclosure of `pi`.

**Pass condition:** zero unresolved boxes with no non-interval arithmetic in the enclosure path; save precision, box counts, margins, code SHA, and final proof log.

## Gate 6 — uniform `Gamma` touching analysis

At small momentum the second-order separation behaves as
\[
\Delta_2(k)\sim y^2|k|^2,
\]
so for `|k| ≲ y` it competes with the fourth-order correction.

**Pass condition:** prove a two-scale effective theorem covering both outer region `|k|>=c y` and inner touching region `|k|<=C y`, or diagonalize the relevant multi-band effective Hamiltonian uniformly and show the physical minimum is controlled.

**Failure consequence:** the exact coefficient function `c4(k)` may remain correct while the statement “the finite-y band minimum is at Gamma” must be weakened.

## Archival reproducibility

- Commit `y4_full_real_space_H4_kernel.json.gz`.
- Store its SHA-256 in the theorem record.
- Make stages 3F and 3H part of the one-command endgame.
- Preserve exact rational intermediate ledgers, not only final decimals.
- Correct `sc_extrap2.py` to use `c4(Gamma)` rather than the rigid CLS diagonal component when constructing the band-minimum mass series.

## Promotion rule

Only after all six gates pass should the master registry change

> `SU(3) O(y^4): Exact computational ledger — audit pending`

to

> `SU(3) O(y^4): Proven — cold-reproducible exact computer-assisted theorem`.
