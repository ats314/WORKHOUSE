# Canonical Status Registry — Gauge-Constrained Spectral Geometry v1.4

**Date:** 2026-08-08  
**Purpose:** audit-hardened authority ledger. Exact arithmetic is distinguished from end-to-end proof closure.

| Layer | Result | v1.4 status | Authority / dependency note |
|---|---|---|---|
| I | Compact `SU(3)` even class gap through `beta^{-1/2}` with `O(beta^{-1})` remainder | **Proven** | `SU3_Compact_Remainder_Proof.docx` + exact coefficient ledger |
| II | `O(y^2)` incidence factorization `S+4I=BB†` and flat carrier `ker B†` | **Proven / hand-checkable** | `PAPER homological flat bands.md`; independently highlighted by `Pasted markdown.md` |
| II | All-orders link-mediated criterion `BMB†` annihilates `ker B†` | **Proven algebraic criterion** | same |
| II | Torus flat dimension `L^3+2`, first isolation level `4 sin^2(pi/L)` | **Proven** | homological/Hodge theorem package |
| II | Centered Hodge identity `JM=-2[s]_x`; fragile unit `RP^2` hedgehog | **Proven embedded geometry; not stable BDI** | updated Hodge theorem |
| II | `O(y^3)` tromino/bare-link vanishing mechanism | **Proven structural selection rule** | audit + independent symbolic geometry checks |
| II | `O(y^3)` scalar coefficient `-109151/249696` | **Exact arithmetic; cold replay recommended** | source corpus/audit |
| II | Generic fourth-order shape space `{q,e2,4e2/q,e3/q}` | **Proven algebraic/orbit classification** | updated Hodge theorem |
| II | `SU(3)` 189-record `H4` kernel and rational pencil values | **Exact computational ledger — audit pending** | same values independently reproduced; six closure gates below |
| II | `SU(3)` fourth-order bandwidth `132329431693349/275331901291200` | **Exact computational ledger — audit pending** | coefficient identity reproduced exactly |
| II | `SU(3)` global min at `Gamma`, max at `R` for implemented `c4(k)` | **Numerically decisive; interval-proof code not fully rigorous as written** | outward-rounding leaks must be fixed; near-`Gamma` perturbative uniformity is separate |
| II | Physical tier collapse `B_N^shp=D_N^shp=0` | **Exact within accepted rank ledgers** | theorem-grade status inherits shared fourth-order proof dependencies where applicable |
| II | Universal axial law `alpha_N^pen=640/[N(N^2-1)^3]` for `N>=3` | **Exact certificate-backed rank identity** | finite ranks + stable family; shared folded/normalization dependencies must be disclosed if common |
| II | `SU(4)` exceptional completion | **PASS in narrow certificate** | `SU4_HYBRID_COMPLETE_*`; do not silently generalize beyond its declared branch |
| II | `SU(5)` axial closure / empty determinant scan | **Exact relative to accepted finite-rank certificate** | current Layer-II rank authority |
| II | `SU(6)` axial closure / `Delta q6=6/343` | **Exact relative to accepted finite-rank certificate** | current Layer-II rank authority |
| II | `SU(3)` second-pencil anomaly `Delta beta3=-25/64` | **Exact relative to accepted finite/stable ledgers** | homological-flat-band rank synthesis |
| II | No-rescaling bridge from simulation `y` to canonical `u=beta_H/6` | **Conditional / not closed** | magnetic-operator prefactor gate required |
| II | `PVP=aP` inside fourth-order pipeline | **Open load-bearing gate** | audit says assumed, not verified |
| II | Folded effective-Hamiltonian formula on degenerate model space | **Open load-bearing gate** | existing regression is nondegenerate |
| II | Full Stage-3H independent regression (3,895 topologies) | **Open reproducibility gate** | 1,478 independently regressed; 2,417 folded cases remain |
| II | Fully outward-rounded global interval certificate | **Open mechanical rigor gate** | point-to-interval wraps and rounded-pi tiling identified |
| II | Uniform perturbative control in `|k| ≲ y` near `Gamma` touching | **Open analytic gate** | branch spacing becomes comparable to `O(y^4)` correction |
| III | Exceptional-point seam atlas / crossover | **Computationally verified / selected points certified** | unchanged from v1.3 |
| IV | Wilson-Bergman transfer/certificate geometry | **Mixed Proven / Computationally verified** | unchanged from v1.3 |
| V | Uniform fixed-window projected-capacity top-norm theorem | **Rejected / no-go proved** | rare-island obstruction |
| V | Rooted projected-capacity polymer route | **Conditional** | Wilson transfer/free-energy inputs remain open |
| Quarantine | Schur/Haar-Hessian “Theorem B” | **Rejected** | independent audit finds failed hypotheses and sign pathology |
| Quarantine | 4D `SU(2)` theta/TRG physics claims | **Rejected as implemented / not yet started physically** | Wilson action/theta/coarse-graining not correctly implemented |
| Utility | q-Racah/Doob gap | **Correct but known** | standard Askey-Wilson/q-Racah eigenvalue |
| Physics | Raw one-plaquette operator = physical `1^{+-}` glueball | **Not supported** | raw overlap near zero; smeared basis couples strongly |
| Physics | Continuum glueball prediction from 5-term strong-coupling series | **Consistent, not controlled** | divergent/short series; no convergence theorem |
| Physics | Continuum Yang-Mills mass gap | **Not addressed** | scope firewall |

## Six `SU(3)` fourth-order closure gates

1. Verify `PVP=aP` directly in the exact one-flux model space.
2. Regression-test the folded des-Cloizeaux formula on a genuinely degenerate model space.
3. Extend Stage 3H independent recomputation from 1,478 to all 3,895 topologies.
4. Close the convention-dependent magnetic-prefactor normalization and map source `y` to canonical `u` explicitly.
5. Make the Brillouin-zone branch-and-bound interval implementation outward-rounded end to end.
6. Prove uniform control of the branch touching region near `Gamma`.

## Reproducibility gates

- Ship `y4_full_real_space_H4_kernel.json.gz` with a reference SHA-256.
- Correct the downstream mass-series use of the rigid `-2.5134` component; the band minimum ledger is `c4(Gamma)≈-2.857916`.
- Keep the statement “order-by-order strong-coupling result; not a continuum Yang-Mills claim” in abstracts and summaries.

## Notation lock

- Canonical master coupling: `u=beta_H/6`.
- Simulation/audit variable: retain the source symbol `y` until the magnetic-prefactor bridge is proved.
- Old fourth-order pencil: `(q_N, alpha_N^pen, beta_N^pen)`.
- Four-shape basis: `(A_N^shp,B_N^shp,C_N^shp,D_N^shp)`.
