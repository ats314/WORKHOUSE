# Gauge-Constrained Spectral Geometry — v1.4 audit-hardened release

This release supersedes v1.3 as the **narrative/status synthesis** while preserving all narrow source certificates.

## What changed

- Incorporated the independent `SIMULATIONS/` audit.
- Promoted the hand-checkable homological `O(y^2)` theorem package.
- Retained the exact `SU(3)` `O(y^4)` rational values but downgraded their end-to-end proof status to **Exact computational ledger — audit pending**.
- Added six explicit theorem-closure gates.
- Removed the unproved no-rescaling assertion between the simulation variable and canonical `u=beta_H/6`.
- Quarantined the failed Schur/Haar-Hessian “Theorem B”, the unimplemented 4D `SU(2)` theta/TRG physics claims, and the non-novel q-Racah gap thread.
- Retained the compact `SU(3)` rigorous class-gap theorem, Hodge/shape-space results, `SU(4)` narrow exceptional certificate, rank ledger, projected-capacity no-go, and rooted-polymer firewall with their scoped statuses.

## Canonical files

- `GAUGE_CONSTRAINED_SPECTRAL_GEOMETRY_UNIFIED_v1_4_2026-08-08.md`
- `GAUGE_CONSTRAINED_SPECTRAL_GEOMETRY_UNIFIED_v1_4_2026-08-08.tex`
- `GAUGE_CONSTRAINED_SPECTRAL_GEOMETRY_UNIFIED_v1_4_2026-08-08.pdf`
- `CANONICAL_STATUS_REGISTRY_v1_4_2026-08-08.md`
- `SU3_Y4_THEOREM_CLOSURE_CHECKLIST_v1_4.md`
- `dependency_graph_v14.png`
- `GAUGE_CONSTRAINED_SPECTRAL_GEOMETRY_UNIFIED_v1_4_manifest.json`

The Markdown file is the canonical editable source. The LaTeX/PDF are rendered distributions of that source.
