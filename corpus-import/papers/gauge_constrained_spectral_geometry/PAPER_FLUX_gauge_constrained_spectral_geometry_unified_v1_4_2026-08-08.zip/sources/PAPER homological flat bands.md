# Homological $C$-odd Flat Bands in Strong-Coupling $SU(N)$ Lattice Gauge Theory

**Draft — 2026-08-08**

> One message: representation theory supplies one scalar; homology supplies the band.

---

## Abstract

In the strong-coupling Kogut–Susskind Hamiltonian on the three-dimensional cubic
lattice, the lowest charge-conjugation-odd one-plaquette branch is exactly
dispersionless through $O(y^3)$ for every rank $N\ge3$. At second order the
orientation-sensitive hopping coefficient is the exact rational function

$$t_N=\frac{2N(N^2-4)}{(N^2-1)(2N^2-1)(4N^2-9)},\qquad N\ge3,$$

and the spatial operator multiplying it is the signed face adjacency
$S(k)+4I=\widetilde N(k)\widetilde N(k)^\dagger$, with $\widetilde N$ the Bloch
face-to-edge boundary matrix. Because $\partial_2\partial_3=0$, $S(k)$ has an
exactly flat eigenvalue $-4$ at every momentum, and in fact

$$\operatorname{spec}S(k)=\{-4,\;-4+q(k),\;-4+q(k)\},\qquad
q(k)=4\sum_{j=1}^{3}\sin^2\tfrac{k_j}{2}.$$

The group dependence and the spatial topology factor completely at this order.
On an $L^3$ torus the flat eigenspace has exact dimension $L^3+2$, and the first
level above it lies at $4\sin^2(\pi/L)$. Mobility first appears at fourth order,
with axial coefficient

$$\alpha_N=\frac{640}{N(N^2-1)^3}\qquad\text{for every }N\ge3,$$

proved by exhaustive rank partition. All statements are exact at fixed lattice
spacing within the one-excitation truncation. No claim is made about the
continuum limit or the Yang–Mills mass gap.

---

## 1. Introduction

The strong-coupling limit of the Kogut–Susskind Hamiltonian is one of the few
regimes of non-abelian gauge dynamics admitting exact spectral statements, and
closely related truncations are now implemented directly in tensor-network and
quantum-simulation programs. This paper concerns one structural feature of the
one-plaquette sector.

At leading nontrivial order the charge-odd problem is a signed hopping model on
plaquettes sharing a link. The signs cannot be gauged away: triangles of
plaquettes meeting at a corner have negative sign product, whereas triangles
sharing a common link have positive sign product. Nevertheless the lowest
charge-odd band is exactly flat. The mechanism is not accidental frustration but
the cellular identity that the boundary of a boundary vanishes.

Exactly static strong-coupling branches have been observed before. Dahmen
(hep-lat/9412080), computing the $SU(2)$ Hamiltonian strong-coupling expansion in
2+1 dimensions, found that for the heavier six- and seven-link states the
non-vanishing hopping matrix elements "add up to zero. Consequently the heavier
particles remain static and degenerate," and attributed this to algebraic
cancellation. The present work identifies the cancellation as forced by the chain
complex, extends it to every rank, and computes the order and strength at which
it fails.

---

## 2. The one-excitation problem

We use the dimensionless Kogut–Susskind Hamiltonian

$$h=\frac12\sum_{\text{links }\ell}C_2(\ell)-y\sum_{\text{plaquettes }p}\bigl(\chi_p+\bar\chi_p\bigr),$$

with $C_2$ the quadratic Casimir and $\chi_p$ the fundamental character of the
oriented plaquette holonomy. At $y=0$, states with one fundamental flux loop on
one plaquette are degenerate; charge conjugation splits this manifold into
$C$-even and $C$-odd sectors. For $N\ne2$ both sectors are nonempty.

Orient a plaquette for $\mu<\nu$ by

$$\partial P_{\mu\nu}(x)=\ell_\mu(x)+\ell_\nu(x+\hat\mu)-\ell_\mu(x+\hat\nu)-\ell_\nu(x),$$

and let $\epsilon_p(\ell)\in\{0,\pm1\}$ be the coefficient of $\ell$ in $\partial p$.
At second order in $y$ an excitation moves between plaquettes sharing a link, and
the charge-odd hop carries the sign

$$s(p,p')=\epsilon_p(\ell)\,\epsilon_{p'}(\ell).$$

For $L\ge3$ every plaquette has twelve such neighbours and every adjacent pair
shares a unique link. There are three plaquette orbitals per site,
$a=(12)$, $b=(13)$, $c=(23)$.

---

## 3. Exact fixed-rank channel algebra

Two plaquettes sharing one edge produce two possible fused representations on
that edge, according to the relative orientation recorded by $s(p,p')$. Of the
thirty-six neighbour relations, twenty-four are antiparallel and twelve parallel.
Summing the antiparallel and parallel channel contributions and taking the
$C$-odd combination gives the exact signed nearest-neighbour coefficient

$$\boxed{\;t_N=\frac{2N(N^2-4)}{(N^2-1)(2N^2-1)(4N^2-9)}\;}$$

for every $N\ge3$. It is positive, and

$$t_3=\frac5{612},\quad
t_4=\frac{32}{8525},\quad
t_5=\frac5{2548},\quad
t_6=\frac{128}{111825},\qquad
N^3t_N\to\tfrac14 .$$

The rank dependence enters only through this one scalar.

---

## 4. Incidence factorization and the complete Bloch spectrum

Set $u_j=1-e^{ik_j}$ and define the signed Bloch incidence matrix

$$\widetilde N(k)=
\begin{pmatrix}
u_2&-u_1&0\\
u_3&0&-u_1\\
0&u_3&-u_2
\end{pmatrix},$$

rows labelling plaquette orbitals and columns link directions.

**Lemma 4.1 (factorization).** For every $k$, $S(k)+4I=\widetilde N\widetilde N^\dagger$.

**Theorem 4.2 (complete charge-odd spectrum).** With $q(k)=\sum_j|u_j|^2=4\sum_j\sin^2(k_j/2)$,

$$\operatorname{spec}S(k)=\{-4,\;-4+q(k),\;-4+q(k)\}.$$

*Proof.* Direct multiplication gives $\widetilde N^\dagger\widetilde N=qI-uu^\dagger$
with $u=(u_1,u_2,u_3)^T$. For $u\ne0$ this annihilates $u$ and acts as $q$ on the
two-dimensional orthogonal plane, so its spectrum is $\{0,q,q\}$. The nonzero
spectra of $\widetilde N^\dagger\widetilde N$ and $\widetilde N\widetilde N^\dagger$
agree, and Lemma 4.1 gives the result. At $u=0$ both incidence matrices vanish. $\square$

Consequently the lowest $C$-odd branch is dispersionless through $O(y^2)$ for
every rank, and the two nonflat branches are exactly degenerate.

**Polarization content.** $\widetilde N$ is the lattice curl. On the link side
$\ker\widetilde N$ is the lattice gradient direction — pure gauge. On the face
side $\ker\widetilde N^\dagger$ is the flat carrier; in the centered gauge it is
$\operatorname{span}\{s\}$ with $s_j=\sin(k_j/2)$, killed by the cross-product
matrix $[s]_\times$. The flat branch is therefore the **longitudinal**
polarization of the plaquette triplet, and the two degenerate dispersive branches
are its two transverse partners. The exact degeneracy is polarization counting,
not coincidence.

The excitation carries a nonzero rest energy, so $q(k)\sim|k|^2$ is the
nonrelativistic dispersion of a massive state, $\sqrt{M^2+p^2}\simeq M+p^2/2M$;
the finite-volume scale is correspondingly $L^{-2}$, not $L^{-1}$.

---

## 5. Torus degeneracy and the finite-volume scale

$$0\to\operatorname{im}\partial_3\to\ker\partial_2\to H_2(T^3;\mathbb C)\to0,
\qquad \dim\ker\partial_2=(L^3-1)+3=\boxed{L^3+2}.$$

The $L^3-1$ compact cube boundaries are the contractible cycles; the remaining
three are wrapping cycles, $H_2(T^3)\cong H_1(T^3)\cong\mathbb C^3$, the
holonomies around the three torus cycles. After projecting out the complete $-4$
eigenspace the next adjacency eigenvalue is exactly

$$\boxed{\,4\sin^2\tfrac{\pi}{L}\,},$$

verified at $L=3,4,5$ (multiplicities $29,66,127$).

**Falsifiable integer test.** Equation (5) predicts $L^3+2$ flat states on $T^3$,
$L^3+1$ on $T^2\times I$, and $L^3$ on an open box. Reproducing $L^3+2$ under open
boundary conditions falsifies the chain-complex implementation. These are
integer, statistics-free observables and are the recommended first check for any
independent implementation.

---

## 6. Rank-cubic mobility

The full one-plaquette $C$-odd manifold has width

$$W_N^-(y)=12\,t_N\,y^2+O(y^3)=\frac{24N(N^2-4)}{(N^2-1)(2N^2-1)(4N^2-9)}\,y^2+O(y^3),$$

so at fixed strong-coupling normalization $W_N^-\sim3y^2/N^3$: the spatial
mobility of the fundamental $C$-odd excitation is suppressed by $N^{-3}$, not
merely $N^{-1}$.

For $SU(3)$ the flat branch persists through third order,

$$m^{SU(3)}_{-,\text{flat}}(y)=\frac83+y+\frac{11}{306}y^2-\frac{109151}{249696}y^3+O(y^4),$$

because every three-distinct-plaquette (tromino) numerator vanishes at $O(y^3)$
by the bare-link lemma, so the third-order effective Hamiltonian retains the
second-order signed-adjacency structure. Trominoes first activate at $O(y^4)$.

---

## 7. Fourth-order mobility

### 7.1 Shape space

With $a_i=4\sin^2(k_i/2)$, $q=\sum a_i$, $e_2=\sum_{i<j}a_ia_j$, $e_3=a_1a_2a_3$,
the space-group orbit resolution gives a four-dimensional nonconstant obstruction
space,

$$\varepsilon_4(k)=c_0+A^{\rm shp}q+B^{\rm shp}e_2+C^{\rm shp}\frac{4e_2}{q}+D^{\rm shp}\frac{e_3}{q},$$

splitting by infrared scaling into an $L^{-2}$ tier $\{q,4e_2/q\}$ and an $L^{-4}$
tier $\{e_2,e_3/q\}$.

The coefficients are recovered from four checkpoints
$X=(\pi,0,0)$, $M=(\pi,\pi,0)$, $P=(\pi,\pi/2,0)$, $R=(\pi,\pi,\pi)$ with
$\Delta_K=\varepsilon_4(K)-\varepsilon_4(\Gamma)$:

$$A=\frac{\Delta X}4,\quad
B=\frac{\Delta X+4\Delta M-6\Delta P}{16},\quad
C=\frac{3(2\Delta P-\Delta M-\Delta X)}8,\quad
D=\frac{3(\Delta R-6\Delta M+6\Delta P)}{16}.$$

Two identities follow without assumption:
$6\Delta P-4\Delta M-\Delta X=-16B$ and
$\Delta R-2\Delta M+\Delta X=16B+\tfrac{16}3D$.
The first is therefore equivalent to $B=0$ and the second to $B=-D/3$; neither is
an independent check, and the two together are equivalent to $B=D=0$.

### 7.2 Tier collapse

At every rank computed,

$$\boxed{B^{\rm shp}_N=D^{\rm shp}_N=0.}$$

The physical fourth-order correction lies entirely in the $L^{-2}$ tier. The
$L^{-4}$ shapes carry the sub-dimensional mobility content — $e_3/q$ vanishes
identically on every coordinate plane $k_i=0$ and so acts only when all three
directions are excited — so the collapse states that no restricted-mobility
sector survives. Moreover $A^{\rm shp}q+C^{\rm shp}(4e_2/q)$ has no nontrivial
zero set at any rank, since vanishing would require $e_2/q^2=-A^{\rm shp}/4C^{\rm shp}$,
whose values $0.542,\,1.085,\,1.081,\,1.079$ at $N=3,4,5,6$ all exceed the maximum
$e_2/q^2=1/3$. $\Gamma$ is the unique global minimum and $R$ the unique maximum.

### 7.3 The universal axial mobility

**Theorem 7.1.** For every integer $N\ge3$,

$$\boxed{\;\alpha_N=\frac{640}{N(N^2-1)^3}\;}$$

*Proof.* Partition $\{N\ge3\}=\{3,4,5,6\}\sqcup\{N\ge7\}$. The stable-rank
walled-Brauer contraction proves the formula for all $N\ge7$. The four remaining
ranks are closed independently by their exact finite-rank certificates:
$\alpha_3=5/12$, $\alpha_4=32/675$, $\alpha_5=1/108$, $\alpha_6=64/25725$, and
direct substitution gives $640/[N(N^2-1)^3]$ in each case. The cases exhaust
$\{N\ge3\}$. $\square$

No interpolation or asymptotic continuation is used. The proof threshold $N\ge7$
has an elementary origin: a fourth-order word has six character factors, so an
$N$-ality channel needs $|p-q|=N$ with $p+q\le6$, which is impossible for $N\ge7$.
The exceptional ranks are therefore exactly $\{3,4,5,6\}$, and the finiteness of
that set is forced, not observed.

**Finite-volume lift.** The first fourth-order lift of the caged branch on an
$L^3$ box is $\Delta^{(4)}_{N,L}=\alpha_N\sin^2(\pi/L)$, independent of $\beta_N$.

### 7.4 Exceptional sectors

The determinant channels shift the rest offset and leave the axial mobility
untouched at every resolved rank:

| $N$ | exceptional families | $\Delta q_N$ | $\Delta\alpha_N$ |
|---|---|---|---|
| 4 | $(4,0),(0,4),(5,1),(1,5)$ | $-\dfrac{304746539168}{160249753125}$ | $0$ |
| 5 | none | $0$ | $0$ |
| 6 | $(6,0),(0,6)$ | $\dfrac6{343}$ | $0$ |

For $SU(6)$ the exceptional word has root, four insertions and output on the same
plaquette, giving $(6,0)$ on every boundary link. The three des-Cloizeaux cuts
carry $\Lambda^2,\Lambda^3,\Lambda^4$ with
$C_2=(\tfrac{14}3,\tfrac{21}4,\tfrac{14}3)$; summed over four links and measured
from $E_0$ these give denominators $(-\tfrac72,-\tfrac{14}3,-\tfrac72)$, hence
$F_{\det}=-6/343$ and, with the $C$-odd phase, $\Delta q_6=6/343$.

For $SU(5)$ the mod-5 scan is empty: no determinant family survives the
requirement that $r-s\equiv0\pmod5$ hold on *every* link of a connected support,
across all $895{,}524$ support/output pairs.

### 7.5 The $SU(3)$ anomaly in the second coefficient

The stable-rank expression for the second pencil coefficient reproduces the
certified values at $N=4,5,6$ exactly and fails at $N=3$ alone. The difference is

$$\boxed{\;\Delta\beta_3=-\frac{25}{64}=-\frac{15}{16}\,\alpha_3\;},\qquad \Delta\alpha_3=0,$$

equivalently $\Delta C_3^{\rm shp}=-25/1024$ with $A,B,D$ untouched. Since the
stable expression carries no triality sector, and the difference vanishes
identically at the three ranks where the exceptional contribution to $\beta$ is
independently certified to be zero, the identification is forced: $-25/64$ is the
$SU(3)$ exceptional contribution to the mobility pencil.

The structural discriminator is the existence of $\Lambda^4V$, which requires
$N\ge4$. At $N=3$ the antisymmetric ladder truncates — $\Lambda^3$ is already the
singlet — so the channel content assumed by the stable expression is genuinely
absent.

**Consequence.** $\Delta\beta_3\ne0$ means the $SU(3)$ exceptional operator is not
scalar on the caged line. The quotient-scalarity property
$P_{\rm cage}H^{\det}P_{\rm cage}=\delta q_NP_{\rm cage}$, certified at $N=4$ and
$N=6$ and vacuous at $N=5$, therefore **fails at $N=3$**. Any conjecture of
quotient-scalarity must be stated for $N\ge4$.

---

## 8. Scope

Every result above is a statement about the strong-coupling Kogut–Susskind
Hamiltonian at fixed lattice spacing within the one-excitation truncation.

Nothing here establishes uniform control as the lattice spacing tends to zero,
and nothing bears on the Yang–Mills mass gap. The finite-volume isolation scale
sharpens rather than softens this limitation: the separation above the flat
eigenspace closes as $L^{-2}$, so it is not uniform as $L\to\infty$.

The identification of the caged branch with the physical $1^{+-}$ glueball is
**not** claimed. Monte Carlo measurement at matched volume and coupling gives a
normalized spectral weight of $0.0072\pm0.0165$ — under 4% at $2\sigma$, and
consistent with zero — for the raw one-plaquette $\operatorname{Im}\operatorname{Tr}$
operator on the physical state, while the smeared basis couples at amplitude
$0.80$. The physical $T_1^{+-}$ state is extended. The one-plaquette bridge is an
operator identity; physical completion runs through smearing.

## 9. Open

- Whether the $b_2$-fold protected level survives inclusion of multi-plaquette
  sectors. The present theorem concerns the two-chain space only.
- Whether the third-order coefficient $-109151/249696$ survives a clean rerun of
  its named certificate chain (domino resolvent, Haar moments, tromino
  classification, regression web). It is source-certified but not independently
  re-executed here and should not enter a submission until it is.
- The Betti formula is not specific to the cubic lattice and should hold on any
  cell complex where shared-link adjacency is defined. The natural test is a
  cellulation with $b_2$ tunable independently of volume.
