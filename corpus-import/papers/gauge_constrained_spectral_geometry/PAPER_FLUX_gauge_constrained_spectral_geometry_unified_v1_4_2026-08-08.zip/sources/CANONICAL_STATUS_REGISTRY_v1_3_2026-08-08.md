# Canonical Status Registry — Gauge-Constrained Spectral Geometry v1.3

**Date:** 2026-08-08  
**Purpose:** one-page authority ledger. When a derivative file conflicts with this registry, inspect the named narrow source before changing status.

| Layer | Result | Current status | Narrow authority / note |
|---|---|---|---|
| I | Compact `SU(3)` even class gap through `beta^{-1/2}` with `O(beta^{-1})` remainder | **Proven** | `SU3_Compact_Remainder_Proof.docx` + exact coefficient ledger |
| I | `SU(3)` local class coefficients at next `beta^{-1}` order | **Exact arithmetic / analytic remainder not yet extended one order** | v1.2 Layer I registry |
| II | Second-order rank scalar `t_N` for every `N>=3` | **Proven** | `PAPER homological flat bands.md` |
| II | Incidence factorization and spectrum `{-4,-4+q,-4+q}` | **Proven** | same |
| II | Centered Hodge identity `JM=-2[s]_x` | **Proven** | updated Hodge theorem + Layer-II synthesis |
| II | Fragile unit `RP^2` Hodge hedgehog | **Proven embedded winding; not stable BDI** | updated Hodge theorem |
| II | Torus flat dimension `L^3+2` and first lift `4 sin^2(pi/L)` | **Proven** | Layer-II synthesis |
| II | Generic fourth-order shape space `{q,e2,4e2/q,e3/q}` | **Proven** | updated Hodge theorem / Layer-II synthesis |
| II | Physical tier collapse `B_N^shp=D_N^shp=0` | **Exact/certificate-backed across resolved rank partition `N>=3`** | 2026-08-08 Layer-II authority + finite/stable certificates |
| II | Universal axial law `alpha_N^pen=640/[N(N^2-1)^3]` for every `N>=3` | **Proven by exhaustive rank partition** | `PAPER homological flat bands.md` |
| II | `SU(3)` exact pencil | **Proven — exact computer-assisted** | canonical `SU(3)` 189-entry kernel record retained in v1.2 |
| II | `SU(4)` exact exceptional completion | **Proven — exact computer-assisted** | `SU4_HYBRID_COMPLETE_THEOREM_V2 (2).md` + certificate + topology ledger |
| II | `SU(5)` axial coefficient `1/108`; determinant scan empty | **Exact finite-rank closure as summarized by current Layer-II authority** | `PAPER homological flat bands.md` |
| II | `SU(6)` axial coefficient `64/25725`; determinant rest shift `6/343` | **Exact finite-rank closure as summarized by current Layer-II authority** | same |
| II | `SU(3)` second-pencil anomaly `Delta beta_3=-25/64` | **Exact relative to accepted finite/stable certificates** | same |
| II | Quotient-scalarity for all ranks | **False** | fails at `N=3`; possible formulation only for `N>=4` |
| II | Third-order `SU(3)` mobility coefficient cold replay | **Open audit item** | paper explicitly requests clean rerun before submission |
| II | Survival of `b_2` caging after multi-plaquette sectors | **Open** | principal physical completion question |
| III | Exceptional-point seam atlas / crossover | **Computationally verified / selected points certified** | v1.2 Layer III |
| IV | Wilson-Bergman transfer norm and certificate geometry | **Mixed Proven / Computationally verified** | v1.2 Layer IV |
| V | Uniform fixed-window projected-capacity top-norm theorem | **False / no-go proved** | rare-island argument retained in v1.2 |
| V | Rooted projected-capacity polymer route | **Conditional; load-bearing Wilson transfer/free-energy inputs remain open** | PMBSF/projected-capacity derivations |
| Physics | Raw one-plaquette identification with physical `1^{+-}` glueball | **Not supported** | matched MC overlap consistent with zero; smeared basis couples strongly |
| Physics | Continuum Yang-Mills mass gap | **Not addressed** | scope firewall |

## Notation lock

- Old two-invariant fourth-order pencil: `(q_N, alpha_N^pen, beta_N^pen)`.
- Generic four-shape basis: `(A_N^shp,B_N^shp,C_N^shp,D_N^shp)`.
- Conversion for the physical two-tier-collapse branches:
  \[
  A_N^{\mathrm{shp}}=\alpha_N^{\mathrm{pen}}/4,\quad
  B_N^{\mathrm{shp}}=0,\quad
  C_N^{\mathrm{shp}}=(\beta_N^{\mathrm{pen}}-2\alpha_N^{\mathrm{pen}})/16,\quad
  D_N^{\mathrm{shp}}=0.
  \]
- Canonical strong-coupling symbol in the master theory: `u = beta_H/6`.
