#!/usr/bin/env python3
"""Canonical exact SU(3), order-four cubic denominator-ledger generator.

Generation and target audit are separate commands.  ``generate`` consumes only
the exact primitive specification, constructs the complete scaled two-step
half-history with :class:`fractions.Fraction`, freezes a canonical external
history ledger and a conservative QBOUND, and hashes both.  ``audit`` accepts
only an already-frozen certificate and cannot change its QBOUND.

The implementation intentionally has no numerical fallback, tolerance,
``limit_denominator``, SymPy, NumPy, or imported repository code.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import itertools
import json
import math
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Any, Iterable, Iterator


PRIMITIVE_SCHEMA = "workhouse.rank3-order4-cubic-primitives/v1"
TARGET_SCHEMA = "workhouse.rank3-order4-cubic-targets/v1"
LEDGER_SCHEMA = "workhouse.rank3-order4-cubic-history-ledger/v1"
FREEZE_SCHEMA = "workhouse.rank3-order4-cubic-freeze/v1"
AUDIT_SCHEMA = "workhouse.rank3-order4-cubic-audit/v1"
E0_VERIFIED_POLICY = "exclude-after-exact-supportwise-p0-cancellation"

# Independent path-level envelope retained only for comparison.  It is not an
# input to, and cannot change, the exact-history QBOUND derived below.
INDEPENDENT_PATH_ENVELOPE_FACTORS = {
    2: 56,
    3: 45,
    5: 7,
    7: 2,
    11: 2,
    13: 1,
    17: 3,
    19: 1,
    23: 1,
    29: 1,
    31: 1,
    37: 1,
    47: 1,
}
INDEPENDENT_PATH_ENVELOPE = (
    4302674844130269372677454153332635148085549843213189120000000
)


class ClosedGate(RuntimeError):
    """A fail-closed validation or completeness gate."""


def canonical_bytes(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode(
        "utf-8"
    )


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_canonical_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(canonical_bytes(value))


def assert_no_float(value: Any, where: str = "$" ) -> None:
    if isinstance(value, float):
        raise ClosedGate(f"{where}: inferred/decimal float is forbidden")
    if isinstance(value, dict):
        for key, item in value.items():
            assert_no_float(item, f"{where}.{key}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            assert_no_float(item, f"{where}[{index}]")


def exact(text: Any, where: str) -> Fraction:
    if not isinstance(text, str) or "/" not in text:
        raise ClosedGate(f"{where}: exact values must be explicit 'n/d' strings")
    left, right = text.split("/", 1)
    if not left.lstrip("-").isdigit() or not right.isdigit() or int(right) == 0:
        raise ClosedGate(f"{where}: malformed exact fraction {text!r}")
    value = Fraction(int(left), int(right))
    if f"{value.numerator}/{value.denominator}" != text:
        raise ClosedGate(f"{where}: fraction must be reduced and canonical")
    return value


def ftext(value: Fraction) -> str:
    return f"{value.numerator}/{value.denominator}"


def factorint(value: int) -> dict[int, int]:
    value = abs(int(value))
    if value < 1:
        raise ClosedGate("cannot factor a non-positive denominator")
    factors: dict[int, int] = {}
    divisor = 2
    while divisor * divisor <= value:
        while value % divisor == 0:
            factors[divisor] = factors.get(divisor, 0) + 1
            value //= divisor
        divisor = 3 if divisor == 2 else divisor + 2
    if value > 1:
        factors[value] = factors.get(value, 0) + 1
    return factors


def lcm(values: Iterable[int]) -> int:
    result = 1
    for value in values:
        value = abs(int(value))
        if value == 0:
            raise ClosedGate("zero has no denominator-lcm role")
        result = math.lcm(result, value)
    return result


def exact_one_face_recurrence(model: dict[str, Any]) -> tuple[Fraction, ...]:
    """Derive the one-face scalar coefficients from exact H0 and V primitives."""
    strict_keys(model, {"h0", "interaction", "order", "role", "provenance"}, "$.assembly.analytic_one_face_model")
    if not model["role"] or not model["provenance"]:
        raise ClosedGate("analytic one-face model lacks role/provenance")
    if type(model["order"]) is not int or model["order"] != 4:
        raise ClosedGate("analytic one-face recurrence order must be exactly four")
    h0 = tuple(exact(value, "analytic one-face H0") for value in model["h0"])
    interaction = tuple(
        tuple(exact(value, "analytic one-face interaction") for value in row)
        for row in model["interaction"]
    )
    dimension = len(h0)
    if dimension < 2 or len(interaction) != dimension or any(len(row) != dimension for row in interaction):
        raise ClosedGate("analytic one-face model must be a nonempty square exact matrix")
    if any(h0[0] == h0[index] for index in range(1, dimension)):
        raise ClosedGate("analytic one-face recurrence contains a resonant excited state")
    psi = [[Fraction() for _ in range(dimension)] for _ in range(model["order"] + 1)]
    coefficients = [Fraction() for _ in range(model["order"] + 1)]
    psi[0][0] = Fraction(1)
    coefficients[0] = h0[0]
    for order in range(1, model["order"] + 1):
        coefficients[order] = sum(
            (interaction[0][index] * psi[order - 1][index] for index in range(dimension)),
            Fraction(),
        )
        for state in range(1, dimension):
            rhs = sum(
                (interaction[state][index] * psi[order - 1][index] for index in range(dimension)),
                Fraction(),
            )
            rhs -= sum(
                (psi[lower][state] * coefficients[order - lower] for lower in range(1, order)),
                Fraction(),
            )
            psi[order][state] = rhs / (h0[0] - h0[state])
    return tuple(coefficients)


def strict_keys(obj: dict[str, Any], required: set[str], where: str) -> None:
    actual = set(obj)
    if actual != required:
        raise ClosedGate(
            f"{where}: keys differ; missing={sorted(required-actual)}, extra={sorted(actual-required)}"
        )


def validate_primitives(spec: dict[str, Any], repo: Path) -> None:
    assert_no_float(spec)
    strict_keys(
        spec,
        {
            "schema_version",
            "scope",
            "electric_algebra",
            "haar_projectors",
            "assembly",
            "completeness",
            "evidence_boundary",
            "source_documents",
        },
        "$",
    )
    if spec["schema_version"] != PRIMITIVE_SCHEMA:
        raise ClosedGate("primitive schema version mismatch")
    scope = spec["scope"]
    strict_keys(
        scope,
        {
            "group",
            "rank",
            "order",
            "coupling",
            "regime",
            "geometry",
            "extent",
            "sector",
            "polarization_index",
            "polarizations",
            "magnetic_steps_per_half_history",
        },
        "$.scope",
    )
    expected_scope = {
        "group": "SU",
        "rank": 3,
        "order": 4,
        "coupling": "u",
        "regime": "hamiltonian",
        "geometry": "periodic-cubic",
        "extent": 5,
        "sector": "T1+-",
        "polarization_index": 2,
        "polarizations": [[1, 2], [0, 2], [0, 1]],
        "magnetic_steps_per_half_history": 2,
    }
    if scope != expected_scope:
        raise ClosedGate("scope is not the canonical rank-3/order-4 cubic configuration")

    algebra = spec["electric_algebra"]
    strict_keys(
        algebra,
        {
            "plaquette_energy",
            "hlink_base_per_occurrence",
            "same_orientation_exchange",
            "same_orientation_trace_subtraction",
            "opposite_orientation_exchange",
            "opposite_orientation_trace_addition",
            "casimir_formula",
            "fusion_rule",
            "factor_metadata",
        },
        "$.electric_algebra",
    )
    expected_exact = {
        "plaquette_energy": Fraction(8, 3),
        "hlink_base_per_occurrence": Fraction(2, 3),
        "same_orientation_exchange": Fraction(1, 2),
        "same_orientation_trace_subtraction": Fraction(-1, 6),
        "opposite_orientation_exchange": Fraction(-1, 2),
        "opposite_orientation_trace_addition": Fraction(1, 6),
    }
    for key, expected in expected_exact.items():
        if exact(algebra[key], f"$.electric_algebra.{key}") != expected:
            raise ClosedGate(f"electric primitive {key} does not match the canonical SU(3) algebra")
    if algebra["casimir_formula"] != "(p^2+q^2+p*q+3*p+3*q)/6":
        raise ClosedGate("unknown Casimir formula")
    if algebra["fusion_rule"] != "SU3 fundamental/antifundamental Dynkin-label recursion":
        raise ClosedGate("unknown fusion rule")
    metadata = algebra["factor_metadata"]
    expected_metadata = set(algebra) - {"factor_metadata"}
    if not isinstance(metadata, list) or len(metadata) != len(expected_metadata):
        raise ClosedGate("every electric-algebra primitive needs one factor_metadata row")
    seen_metadata = set()
    for index, row in enumerate(metadata):
        strict_keys(row, {"name", "role", "provenance"}, f"$.electric_algebra.factor_metadata[{index}]")
        if row["name"] in seen_metadata or row["name"] not in expected_metadata:
            raise ClosedGate(f"duplicate or unknown electric factor metadata {row['name']!r}")
        if not row["role"] or not row["provenance"]:
            raise ClosedGate(f"electric factor {row['name']} lacks role/provenance")
        seen_metadata.add(row["name"])
    if seen_metadata != expected_metadata:
        raise ClosedGate("electric factor metadata is incomplete")

    completeness = spec["completeness"]
    required_completeness = {
        "all_faces_incident_to_occupied_links",
        "both_plaquette_orientations",
        "all_fusion_outputs",
        "exact_lagrange_projectors",
        "all_nonresonant_reduced_resolvents",
        "two_magnetic_steps",
        "scaled_charge_odd_source_exact",
        "no_float_reconstruction",
        "target_coefficients_absent_from_generation_inputs",
    }
    strict_keys(completeness, required_completeness, "$.completeness")
    failed = sorted(key for key, value in completeness.items() if value is not True)
    if failed:
        raise ClosedGate(f"completeness assertions are not all true: {failed}")

    projectors = spec["haar_projectors"]
    if not isinstance(projectors, list) or len(projectors) != 7:
        raise ClosedGate("exactly seven supported Haar pattern rows are required")
    seen_patterns: set[tuple[int, int]] = set()
    expected_projectors = {
        (1, 1): (3, 2),
        (2, 2): (24, 4),
        (3, 3): (120, 6),
        (3, 0): (6, 3),
        (0, 3): (6, 3),
        (6, 0): (72, 6),
        (0, 6): (72, 6),
    }
    for index, row in enumerate(projectors):
        strict_keys(row, {"pattern", "denominator", "occurrences", "role", "provenance"}, f"$.haar_projectors[{index}]")
        pattern = tuple(row["pattern"])
        if pattern in seen_patterns or pattern not in expected_projectors:
            raise ClosedGate(f"unsupported or duplicate Haar pattern {pattern}")
        seen_patterns.add(pattern)
        if (row["denominator"], row["occurrences"]) != expected_projectors[pattern]:
            raise ClosedGate(f"Haar primitive mismatch for pattern {pattern}")
        if not row["role"] or not row["provenance"]:
            raise ClosedGate(f"Haar pattern {pattern} lacks role/provenance")

    assembly = spec["assembly"]
    strict_keys(assembly, {"haar_occurrence_cap", "bilinear_prefactor", "analytic_one_face_model"}, "$.assembly")
    if assembly["haar_occurrence_cap"] != 24:
        raise ClosedGate("the canonical two-step bra/ket occurrence cap must be 24")
    if exact(assembly["bilinear_prefactor"], "$.assembly.bilinear_prefactor") != Fraction(1, 2):
        raise ClosedGate("the canonical bilinear prefactor must be 1/2")
    analytic_coefficients = exact_one_face_recurrence(assembly["analytic_one_face_model"])
    if len(analytic_coefficients) != 5:
        raise ClosedGate("analytic one-face recurrence did not produce orders zero through four")

    boundary = spec["evidence_boundary"]
    strict_keys(boundary, {"e0_p0_residual_cancellation"}, "$.evidence_boundary")
    e0_boundary = boundary["e0_p0_residual_cancellation"]
    strict_keys(e0_boundary, {"status", "policy", "role", "provenance", "effect"}, "$.evidence_boundary.e0_p0_residual_cancellation")
    if e0_boundary["status"] != "verification-required" or e0_boundary["policy"] != E0_VERIFIED_POLICY:
        raise ClosedGate("E0/P0 boundary must require the exact supportwise cancellation gate")
    if any(not e0_boundary[key] for key in ("role", "provenance", "effect")):
        raise ClosedGate("E0/P0 verification requirement lacks role/provenance/effect")

    documents = spec["source_documents"]
    if not isinstance(documents, list) or not documents:
        raise ClosedGate("source_documents must be non-empty")
    for index, document in enumerate(documents):
        strict_keys(document, {"path", "sha256", "role", "provenance"}, f"$.source_documents[{index}]")
        if not document["role"] or not document["provenance"]:
            raise ClosedGate(f"source document {index} lacks role/provenance")
        path = (repo / document["path"]).resolve()
        root = repo.resolve()
        if root not in path.parents or not path.is_file():
            raise ClosedGate(f"source document missing or outside repo: {document['path']}")
        actual = sha256_file(path)
        if actual != document["sha256"]:
            raise ClosedGate(f"source hash mismatch for {document['path']}: {actual}")


@dataclass(frozen=True)
class LXState:
    occ: tuple[tuple[int, bool], ...]
    part: tuple[int, ...]


def lx_canon(labels: Iterable[int]) -> tuple[int, ...]:
    mapping: dict[int, int] = {}
    result: list[int] = []
    for label in labels:
        if label not in mapping:
            mapping[label] = len(mapping)
        result.append(mapping[label])
    return tuple(result)


def lx_trace_state(steps: Iterable[tuple[int, int]]) -> LXState:
    steps = tuple(steps)
    size = len(steps)
    occ: list[tuple[int, bool]] = []
    labels: list[int] = []
    for index, (link, direction) in enumerate(steps):
        left, right = index, (index + 1) % size
        if direction > 0:
            occ.append((link, True))
            labels.extend((left, right))
        else:
            occ.append((link, False))
            labels.extend((right, left))
    return LXState(tuple(occ), lx_canon(labels))


def lx_tensor_product(left: LXState, right: LXState) -> LXState:
    offset = max(left.part) + 1 if left.part else 0
    return LXState(
        left.occ + right.occ,
        lx_canon(left.part + tuple(label + offset for label in right.part)),
    )


def lx_classes(part: tuple[int, ...]) -> dict[int, list[int]]:
    result: dict[int, list[int]] = defaultdict(list)
    for index, label in enumerate(part):
        result[label].append(index)
    return result


def lx_merge_classes(part: tuple[int, ...], pairs: Iterable[tuple[int, int]]) -> tuple[int, ...]:
    parent = list(range(len(part)))

    def find(value: int) -> int:
        while parent[value] != value:
            parent[value] = parent[parent[value]]
            value = parent[value]
        return value

    def union(left: int, right: int) -> None:
        left, right = find(left), find(right)
        if left != right:
            parent[right] = left

    first: dict[int, int] = {}
    for index, label in enumerate(part):
        if label in first:
            union(index, first[label])
        else:
            first[label] = index
    for left, right in pairs:
        union(left, right)
    return lx_canon(find(index) for index in range(len(part)))


def lx_swap_rows(part: tuple[int, ...], first: int, second: int) -> tuple[int, ...]:
    if part[first] == part[second]:
        return part
    result = list(part)
    result[first], result[second] = result[second], result[first]
    return lx_canon(result)


def lx_opposite_reconnect(part: tuple[int, ...], first: int, second: int) -> tuple[int, ...]:
    classes = lx_classes(part)
    c1, c2 = part[first], part[second]
    parent = list(range(len(part)))

    def find(value: int) -> int:
        while parent[value] != value:
            parent[value] = parent[parent[value]]
            value = parent[value]
        return value

    def union(left: int, right: int) -> None:
        left, right = find(left), find(right)
        if left != right:
            parent[right] = left

    for members in classes.values():
        remaining = [item for item in members if item not in (first, second)]
        for item in remaining[1:]:
            union(remaining[0], item)
    remaining1 = [item for item in classes[c1] if item not in (first, second)]
    remaining2 = [item for item in classes[c2] if item not in (first, second)]
    if remaining1 and remaining2:
        union(remaining1[0], remaining2[0])
    union(first, second)
    return lx_canon(find(index) for index in range(len(part)))


def lx_remove_pair(
    state: LXState, first: int, second: int, merge_slots: tuple[int, int], rank: int
) -> tuple[Fraction, LXState]:
    part = lx_merge_classes(state.part, [merge_slots])
    removed = {2 * first, 2 * first + 1, 2 * second, 2 * second + 1}
    keep = [index for index in range(len(part)) if index not in removed]
    keep_classes = {part[index] for index in keep}
    lost = len(set(part) - keep_classes)
    scalar = Fraction(rank ** max(0, lost - 1), 1)
    new_occ = tuple(item for index, item in enumerate(state.occ) if index not in (first, second))
    new_part = lx_canon(part[index] for index in keep)
    return scalar, LXState(new_occ, new_part)


def lx_simplify_unitarity(state: LXState, rank: int) -> tuple[Fraction, LXState]:
    scalar, current = Fraction(1), state
    changed = True
    while changed:
        changed = False
        classes = lx_classes(current.part)
        by_link: dict[int, list[tuple[int, bool]]] = defaultdict(list)
        for index, (link, orientation) in enumerate(current.occ):
            by_link[link].append((index, orientation))
        for items in by_link.values():
            done = False
            for left_index in range(len(items)):
                for right_index in range(left_index + 1, len(items)):
                    (first, t1), (second, t2) = items[left_index], items[right_index]
                    if t1 == t2:
                        continue
                    r1, c1, r2, c2 = 2 * first, 2 * first + 1, 2 * second, 2 * second + 1
                    if set(classes[current.part[r1]]) == {r1, r2}:
                        factor, current = lx_remove_pair(current, first, second, (c1, c2), rank)
                        scalar *= factor
                        changed = done = True
                        break
                    if set(classes[current.part[c1]]) == {c1, c2}:
                        factor, current = lx_remove_pair(current, first, second, (r1, r2), rank)
                        scalar *= factor
                        changed = done = True
                        break
                if done:
                    break
            if done:
                break
    return scalar, current


def hlink_action(state: LXState, target_link: int, rank: int) -> dict[LXState, Fraction]:
    factor0, state = lx_simplify_unitarity(state, rank)
    result: dict[LXState, Fraction] = defaultdict(Fraction)
    items = [(index, typ) for index, (link, typ) in enumerate(state.occ) if link == target_link]
    if not items:
        return {}
    result[state] += factor0 * len(items) * Fraction(2, 3)
    for left_index in range(len(items)):
        for right_index in range(left_index + 1, len(items)):
            (first, t1), (second, t2) = items[left_index], items[right_index]
            r1, r2 = 2 * first, 2 * second
            if t1 == t2:
                raw = LXState(state.occ, lx_swap_rows(state.part, r1, r2))
                factor, reduced = lx_simplify_unitarity(raw, rank)
                result[reduced] += factor0 * factor * Fraction(1, 2)
                result[state] -= factor0 * Fraction(1, 2 * rank)
            else:
                raw = LXState(state.occ, lx_opposite_reconnect(state.part, r1, r2))
                factor, reduced = lx_simplify_unitarity(raw, rank)
                result[reduced] -= factor0 * factor * Fraction(1, 2)
                result[state] += factor0 * Fraction(1, 2 * rank)
    return {item: coefficient for item, coefficient in result.items() if coefficient}


def vec_hlink(vector: dict[LXState, Fraction], link: int, rank: int) -> dict[LXState, Fraction]:
    result: dict[LXState, Fraction] = defaultdict(Fraction)
    for state, coefficient in vector.items():
        for output, factor in hlink_action(state, link, rank).items():
            result[output] += coefficient * factor
    return {item: coefficient for item, coefficient in result.items() if coefficient}


def project_link(
    vector: dict[LXState, Fraction],
    link: int,
    eigenvalue: Fraction,
    eigenvalues: tuple[Fraction, ...],
    rank: int,
) -> dict[LXState, Fraction]:
    result = dict(vector)
    for other in eigenvalues:
        if other == eigenvalue:
            continue
        denominator = eigenvalue - other
        if denominator == 0:
            raise ClosedGate("degenerate local fusion spectrum")
        acted = vec_hlink(result, link, rank)
        next_result: dict[LXState, Fraction] = defaultdict(Fraction)
        for state, coefficient in acted.items():
            next_result[state] += coefficient / denominator
        for state, coefficient in result.items():
            next_result[state] -= other * coefficient / denominator
        result = {state: coefficient for state, coefficient in next_result.items() if coefficient}
    return result


class CubicComplex:
    def __init__(self, extent: int):
        self.extent = extent
        self.vertices = [
            (x, y, z) for x in range(extent) for y in range(extent) for z in range(extent)
        ]
        self.links: list[tuple[tuple[int, int, int], int]] = []
        self.link_id: dict[tuple[tuple[int, int, int], int], int] = {}
        for vertex in self.vertices:
            for direction in range(3):
                self.link_id[(vertex, direction)] = len(self.links)
                self.links.append((vertex, direction))
        self.faces = [
            (vertex, first, second)
            for vertex in self.vertices
            for first, second in ((0, 1), (0, 2), (1, 2))
        ]
        self.link_faces: list[list[int]] = [[] for _ in self.links]
        for face in range(len(self.faces)):
            for link, _ in self.face_steps(face, 1):
                self.link_faces[link].append(face)

    def shift(self, vertex: tuple[int, int, int], direction: int) -> tuple[int, int, int]:
        result = list(vertex)
        result[direction] = (result[direction] + 1) % self.extent
        return tuple(result)  # type: ignore[return-value]

    def face_steps(self, face: int, orientation: int) -> tuple[tuple[int, int], ...]:
        vertex, first, second = self.faces[face]
        va, vb = self.shift(vertex, first), self.shift(vertex, second)
        steps = [
            (self.link_id[(vertex, first)], 1),
            (self.link_id[(va, second)], 1),
            (self.link_id[(vb, first)], -1),
            (self.link_id[(vertex, second)], -1),
        ]
        if orientation < 0:
            steps = [(link, -direction) for link, direction in reversed(steps)]
        return tuple(steps)

    def anchor_face(self, polarization: tuple[int, int]) -> int:
        return next(
            index
            for index, (vertex, first, second) in enumerate(self.faces)
            if vertex == (0, 0, 0) and (first, second) == polarization
        )

    def candidate_faces(self, vector: dict[LXState, Fraction]) -> tuple[int, ...]:
        candidates: set[int] = set()
        for state in vector:
            for link, _ in state.occ:
                candidates.update(self.link_faces[link])
        return tuple(sorted(candidates))


def energy(rep: tuple[int, int]) -> Fraction:
    p, q = rep
    return Fraction(p * p + q * q + p * q + 3 * p + 3 * q, 6)


def fuse(rep: tuple[int, int], orientation: int) -> tuple[tuple[int, int], ...]:
    p, q = rep
    result: list[tuple[int, int]] = []
    if orientation > 0:
        result.append((p + 1, q))
        if p >= 1:
            result.append((p - 1, q + 1))
        if q >= 1:
            result.append((p, q - 1))
    else:
        result.append((p, q + 1))
        if q >= 1:
            result.append((p + 1, q - 1))
        if p >= 1:
            result.append((p - 1, q))
    if len(result) != len(set(result)):
        raise ClosedGate("fusion rule emitted duplicate irreps")
    return tuple(result)


Signature = tuple[tuple[int, int, int], ...]
StateMap = dict[Signature, dict[LXState, Fraction]]
LabeledState = dict[frozenset[int], StateMap]


@dataclass
class EventLog:
    fusions: Counter[tuple[Any, ...]]
    resolvents: Counter[tuple[Any, ...]]

    @classmethod
    def empty(cls) -> "EventLog":
        return cls(Counter(), Counter())


def signature_energy(signature: Signature) -> Fraction:
    return sum((energy((p, q)) for _, p, q in signature), Fraction())


def signature_conjugate(signature: Signature) -> Signature:
    return tuple(sorted((link, q, p) for link, p, q in signature))


def signature_canonical(signature: Signature) -> Signature:
    conjugate = signature_conjugate(signature)
    return min(signature, conjugate)


def signature_from_steps(steps: Iterable[tuple[int, int]]) -> Signature:
    return tuple(
        sorted((link, 1, 0) if orientation > 0 else (link, 0, 1) for link, orientation in steps)
    )


def add_vector(destination: dict[LXState, Fraction], source: dict[LXState, Fraction], scale: Fraction) -> None:
    for state, coefficient in source.items():
        destination[state] = destination.get(state, Fraction()) + scale * coefficient
        if not destination[state]:
            del destination[state]


def add_state(destination: StateMap, signature: Signature, vector: dict[LXState, Fraction], scale: Fraction) -> None:
    current = destination.setdefault(signature, {})
    add_vector(current, vector, scale)
    if not current:
        del destination[signature]


def project_action(
    complex_: CubicComplex,
    vector: dict[LXState, Fraction],
    signature: Signature,
    face: int,
    orientation: int,
    rank: int,
    events: EventLog,
) -> list[tuple[dict[LXState, Fraction], Signature]]:
    steps = complex_.face_steps(face, orientation)
    face_by_link = {link: direction for link, direction in steps}
    current = {link: (p, q) for link, p, q in signature}
    raw: dict[LXState, Fraction] = defaultdict(Fraction)
    face_state = lx_trace_state(steps)
    for state, coefficient in vector.items():
        raw[lx_tensor_product(state, face_state)] += coefficient
    channels: list[tuple[dict[LXState, Fraction], dict[int, tuple[int, int]]]] = [(dict(raw), dict(current))]
    for link, direction in face_by_link.items():
        input_rep = current.get(link, (0, 0))
        outputs = fuse(input_rep, direction)
        eigenvalues = tuple(energy(output) for output in outputs)
        if len(eigenvalues) != len(set(eigenvalues)):
            raise ClosedGate(f"degenerate fusion at {input_rep}, orientation {direction}")
        events.fusions[
            (
                input_rep,
                direction,
                outputs,
                tuple(ftext(value) for value in eigenvalues),
            )
        ] += len(channels)
        next_channels: list[tuple[dict[LXState, Fraction], dict[int, tuple[int, int]]]] = []
        for channel_vector, channel_signature in channels:
            for output, eigenvalue in zip(outputs, eigenvalues):
                projected = (
                    channel_vector
                    if len(outputs) == 1
                    else project_link(channel_vector, link, eigenvalue, eigenvalues, rank)
                )
                if not projected:
                    continue
                updated = dict(channel_signature)
                if output == (0, 0):
                    updated.pop(link, None)
                else:
                    updated[link] = output
                next_channels.append((projected, updated))
        channels = next_channels
    return [
        (vector_out, tuple(sorted((link, p, q) for link, (p, q) in signature_out.items())))
        for vector_out, signature_out in channels
    ]


def initial_source(complex_: CubicComplex, face: int) -> LabeledState:
    positive = complex_.face_steps(face, 1)
    negative = complex_.face_steps(face, -1)
    state: StateMap = {}
    add_state(state, signature_from_steps(positive), {lx_trace_state(positive): Fraction(1)}, Fraction(1))
    add_state(state, signature_from_steps(negative), {lx_trace_state(negative): Fraction(-1)}, Fraction(1))
    return {frozenset((face,)): state}


def apply_w_labeled(
    complex_: CubicComplex, labeled: LabeledState, rank: int, events: EventLog
) -> LabeledState:
    output: dict[frozenset[int], StateMap] = {}
    for support, state_map in sorted(labeled.items(), key=lambda item: tuple(sorted(item[0]))):
        for signature, vector in sorted(state_map.items()):
            for face in complex_.candidate_faces(vector):
                for orientation in (-1, 1):
                    for projected, output_signature in project_action(
                        complex_, vector, signature, face, orientation, rank, events
                    ):
                        target_support = frozenset(set(support) | {face})
                        target = output.setdefault(target_support, {})
                        add_state(target, output_signature, projected, Fraction(-1))
    return {
        support: {signature: vector for signature, vector in state.items() if vector}
        for support, state in output.items()
        if any(state.values())
    }


def resolvent_labeled(
    labeled: LabeledState, e0: Fraction, events: EventLog, *, resonant_policy: str
) -> LabeledState:
    if resonant_policy != E0_VERIFIED_POLICY:
        raise ClosedGate("a reduced resolvent must state the exact verified E0/P0 exclusion policy")
    output: LabeledState = {}
    for support, state in labeled.items():
        target: StateMap = {}
        for signature, vector in state.items():
            current_energy = signature_energy(signature)
            gap = e0 - current_energy
            if gap == 0:
                events.resolvents[
                    (ftext(current_energy), ftext(gap), "resonant-excluded-after-exact-p0-cancellation")
                ] += 1
                continue
            events.resolvents[(ftext(current_energy), ftext(gap), ftext(1 / gap))] += 1
            add_state(
                target,
                signature,
                {state_: coefficient / gap for state_, coefficient in vector.items()},
                Fraction(1),
            )
        if target:
            output[support] = target
    return output


def iter_coefficients(labeled: LabeledState) -> Iterator[Fraction]:
    for state in labeled.values():
        for vector in state.values():
            yield from vector.values()


def state_stats(labeled: LabeledState) -> dict[str, int]:
    return {
        "supports": len(labeled),
        "signature_blocks": sum(len(state) for state in labeled.values()),
        "coefficients": sum(len(vector) for state in labeled.values() for vector in state.values()),
    }


def physical_blocks(state_map: StateMap) -> dict[tuple[Signature, Fraction], dict[LXState, Fraction]]:
    result: dict[tuple[Signature, Fraction], dict[LXState, Fraction]] = {}
    for signature, vector in state_map.items():
        key = (signature_canonical(signature), signature_energy(signature))
        destination = result.setdefault(key, {})
        add_vector(destination, vector, Fraction(1))
    return {key: vector for key, vector in result.items() if vector}


def haar_inner_e0_exact(left: LXState, right: LXState, rank: int) -> Fraction:
    """Exact E0 inner product for balanced k=1/k=2 and SU(3) determinant links."""
    bra_occ = tuple((link, not orientation) for link, orientation in left.occ)
    offset = max(left.part) + 1 if left.part else 0
    occurrences = bra_occ + right.occ
    partition = lx_canon(left.part + tuple(label + offset for label in right.part))
    by_link: dict[int, dict[bool, list[int]]] = defaultdict(lambda: {True: [], False: []})
    for index, (link, orientation) in enumerate(occurrences):
        by_link[link][orientation].append(index)
    states: dict[tuple[int, ...], Fraction] = {partition: Fraction(1)}
    for link, group in sorted(by_link.items()):
        positives, negatives = group[True], group[False]
        if (len(positives) - len(negatives)) % rank:
            return Fraction()
        next_states: dict[tuple[int, ...], Fraction] = defaultdict(Fraction)
        if len(positives) == 1 and len(negatives) == 1:
            positive, negative = positives[0], negatives[0]
            pairs = ((2 * positive, 2 * negative), (2 * positive + 1, 2 * negative + 1))
            for state, coefficient in states.items():
                next_states[lx_merge_classes(state, pairs)] += coefficient / rank
        elif len(positives) == 2 and len(negatives) == 2 and rank == 3:
            permutations = ((0, 1), (1, 0))
            for state, coefficient in states.items():
                for sigma in permutations:
                    for tau in permutations:
                        weight = Fraction(1, 8) if sigma == tau else Fraction(-1, 24)
                        pairs = []
                        for index in range(2):
                            pairs.append((2 * positives[index], 2 * negatives[sigma[index]]))
                            pairs.append((2 * positives[index] + 1, 2 * negatives[tau[index]] + 1))
                        next_states[lx_merge_classes(state, pairs)] += coefficient * weight
        elif (len(positives), len(negatives)) in ((rank, 0), (0, rank)):
            items = positives if positives else negatives
            for state, coefficient in states.items():
                for permutation in itertools.permutations(range(rank)):
                    inversions = sum(
                        permutation[first] > permutation[second]
                        for first in range(rank)
                        for second in range(first + 1, rank)
                    )
                    sign = -1 if inversions % 2 else 1
                    pairs = tuple(
                        (2 * items[index], 2 * items[permutation[index]] + 1)
                        for index in range(rank)
                    )
                    next_states[lx_merge_classes(state, pairs)] += coefficient * Fraction(
                        sign, math.factorial(rank)
                    )
        else:
            raise ClosedGate(
                f"E0/P0 exact certificate escaped k=1/k=2/determinant closure at link {link}: "
                f"({len(positives)},{len(negatives)})"
            )
        states = {state: coefficient for state, coefficient in next_states.items() if coefficient}
    return sum(
        (coefficient * rank ** len(set(state)) for state, coefficient in states.items()),
        Fraction(),
    )


def vector_inner_e0_exact(
    left: dict[LXState, Fraction], right: dict[LXState, Fraction], rank: int
) -> Fraction:
    return sum(
        (
            left_coefficient
            * right_coefficient
            * haar_inner_e0_exact(left_state, right_state, rank)
            for left_state, left_coefficient in left.items()
            for right_state, right_coefficient in right.items()
        ),
        Fraction(),
    )


def prove_e0_p0_cancellation(
    complex_: CubicComplex, labeled: LabeledState, e0: Fraction, rank: int, stage: str
) -> dict[str, Any]:
    """Subtract the exact plaquette band supportwise and require zero Gram norm."""
    catalog: dict[tuple[Signature, Fraction], list[tuple[int, dict[LXState, Fraction]]]] = defaultdict(list)
    for face in range(len(complex_.faces)):
        source_map = next(iter(initial_source(complex_, face).values()))
        for key, vector in physical_blocks(source_map).items():
            if key[1] == e0:
                catalog[key].append((face, vector))

    records: list[dict[str, Any]] = []
    for support, state_map in sorted(labeled.items(), key=lambda item: tuple(sorted(item[0]))):
        for (signature, energy_value), vector in sorted(physical_blocks(state_map).items()):
            if energy_value != e0:
                continue
            candidates = catalog.get((signature, energy_value), ())
            if not candidates:
                raise ClosedGate(f"{stage}: E0 block has no exact plaquette-band vector")
            residual = dict(vector)
            projections = []
            for face, plaquette in candidates:
                norm = vector_inner_e0_exact(plaquette, plaquette, rank)
                if norm == 0:
                    raise ClosedGate(f"{stage}: zero-norm exact plaquette-band vector")
                overlap = vector_inner_e0_exact(plaquette, residual, rank)
                coefficient = overlap / norm
                add_vector(residual, plaquette, -coefficient)
                projections.append(
                    {
                        "face": face,
                        "plaquette_norm2": ftext(norm),
                        "projection_coefficient": ftext(coefficient),
                    }
                )
            norm2 = vector_inner_e0_exact(residual, residual, rank) if residual else Fraction()
            if norm2 != 0:
                raise ClosedGate(f"{stage}: exact E0/P0 residual norm is {ftext(norm2)}")
            records.append(
                {
                    "stage": stage,
                    "support": sorted(support),
                    "signature": [list(item) for item in signature],
                    "projections": projections,
                    "residual_norm2": ftext(norm2),
                }
            )
    return {
        "stage": stage,
        "e0": ftext(e0),
        "groups": len(records),
        "all_residual_norms_exactly_zero": all(row["residual_norm2"] == "0/1" for row in records),
        "records": records,
    }


def translate_link(complex_: CubicComplex, link: int, delta: tuple[int, int, int]) -> int:
    vertex, direction = complex_.links[link]
    shifted = tuple(
        (vertex[index] + delta[index]) % complex_.extent for index in range(3)
    )
    return complex_.link_id[(shifted, direction)]


def translate_signature(
    complex_: CubicComplex, signature: Signature, delta: tuple[int, int, int]
) -> Signature:
    return tuple(
        sorted((translate_link(complex_, link, delta), p, q) for link, p, q in signature)
    )


def translate_state(
    complex_: CubicComplex, state: LXState, delta: tuple[int, int, int]
) -> LXState:
    return LXState(
        tuple((translate_link(complex_, link, delta), orientation) for link, orientation in state.occ),
        state.part,
    )


def flux_key(state: LXState) -> tuple[tuple[int, int], ...]:
    counts: dict[int, int] = defaultdict(int)
    for link, orientation in state.occ:
        counts[link] += 1 if orientation else -1
    result = []
    for link, count in counts.items():
        residue = count % 3
        if residue == 2:
            residue = -1
        if residue:
            result.append((link, residue))
    return tuple(sorted(result))


def endpoint_patterns(left: LXState, right: LXState) -> tuple[tuple[int, int], ...]:
    counts: dict[int, list[int]] = defaultdict(lambda: [0, 0])
    for link, orientation in left.occ:
        # Bra conjugation flips U <-> Ubar.
        counts[link][0 if not orientation else 1] += 1
    for link, orientation in right.occ:
        counts[link][0 if orientation else 1] += 1
    return tuple(sorted(tuple(value) for value in counts.values()))


def compatibility_census(
    complex_: CubicComplex,
    w2: LabeledState,
    r2: LabeledState,
    supported_patterns: set[tuple[int, int]],
) -> dict[str, Any]:
    """Independently prove the Haar-pattern and 24-occurrence completeness gate."""
    right_index: dict[tuple[Signature, Fraction], list[tuple[frozenset[int], dict[LXState, Fraction]]]] = defaultdict(list)
    for support, state_map in r2.items():
        for key, vector in physical_blocks(state_map).items():
            right_index[key].append((support, vector))

    left_items = []
    for support, state_map in w2.items():
        for (signature, energy_value), vector in physical_blocks(state_map).items():
            left_items.append((support, signature, energy_value, vector))

    matches = raw_upper = skipped_one_face = compatible_pairs = 0
    observed_patterns: set[tuple[int, int]] = set()
    unsupported: set[tuple[int, int]] = set()
    max_occurrences = 0
    for left_support, signature, energy_value, vector in left_items:
        for delta_list in complex_.vertices:
            delta = tuple(delta_list)
            translated_signature = signature_canonical(
                translate_signature(complex_, signature, delta)
            )
            candidates = right_index.get((translated_signature, energy_value), ())
            if not candidates:
                continue
            translated_vector = {
                translate_state(complex_, state, delta): coefficient
                for state, coefficient in vector.items()
            }
            left_by_flux: dict[tuple[tuple[int, int], ...], list[LXState]] = defaultdict(list)
            for state in translated_vector:
                left_by_flux[flux_key(state)].append(state)
            for right_support, right_vector in candidates:
                matches += 1
                raw_upper += len(translated_vector) * len(right_vector)
                if len(left_support) == 1 and len(right_support) == 1:
                    skipped_one_face += 1
                    continue
                right_by_flux: dict[tuple[tuple[int, int], ...], list[LXState]] = defaultdict(list)
                for state in right_vector:
                    right_by_flux[flux_key(state)].append(state)
                for key, left_states in left_by_flux.items():
                    right_states = right_by_flux.get(key, ())
                    for left in left_states:
                        for right in right_states:
                            compatible_pairs += 1
                            patterns = endpoint_patterns(left, right)
                            observed_patterns.update(patterns)
                            unsupported.update(set(patterns) - supported_patterns)
                            max_occurrences = max(
                                max_occurrences, len(left.occ) + len(right.occ)
                            )
    return {
        "left_physical_blocks": len(left_items),
        "matched_h0_blocks": matches,
        "raw_pair_upper_bound": raw_upper,
        "skipped_one_face_matches": skipped_one_face,
        "compatible_state_pairs": compatible_pairs,
        "observed_haar_patterns": [list(pattern) for pattern in sorted(observed_patterns)],
        "unsupported_haar_patterns": [list(pattern) for pattern in sorted(unsupported)],
        "max_bra_ket_occurrences": max_occurrences,
    }


def history_records(stage: str, labeled: LabeledState) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for support, state_map in sorted(labeled.items(), key=lambda item: tuple(sorted(item[0]))):
        for signature, vector in sorted(state_map.items()):
            for state, coefficient in sorted(vector.items(), key=lambda item: (item[0].occ, item[0].part)):
                records.append(
                    {
                        "stage": stage,
                        "support": sorted(support),
                        "signature": [list(item) for item in signature],
                        "occ": [[link, int(orientation)] for link, orientation in state.occ],
                        "part": list(state.part),
                        "coefficient": ftext(coefficient),
                    }
                )
    return records


def fusion_records(events: EventLog) -> list[dict[str, Any]]:
    records = []
    for key, count in sorted(events.fusions.items(), key=lambda item: repr(item[0])):
        input_rep, orientation, outputs, eigenvalues = key
        gaps: set[str] = set()
        for eigenvalue in map(lambda value: exact(value, "fusion eigenvalue"), eigenvalues):
            for other in map(lambda value: exact(value, "fusion eigenvalue"), eigenvalues):
                if eigenvalue != other:
                    gaps.add(ftext(1 / (eigenvalue - other)))
        records.append(
            {
                "role": "representation-projector",
                "provenance": "Exact SU(3) fusion and Lagrange projector generated before target audit.",
                "input_rep": list(input_rep),
                "orientation": orientation,
                "outputs": [list(item) for item in outputs],
                "energies": list(eigenvalues),
                "inverse_energy_differences": sorted(gaps),
                "multiplicity": count,
            }
        )
    return records


def resolvent_records(events: EventLog) -> list[dict[str, Any]]:
    return [
        {
            "role": "energy-resolvent",
            "provenance": "Exact E0-H0 signature gap generated before target audit.",
            "energy": energy_text,
            "gap": gap,
            "reciprocal_or_disposition": reciprocal,
            "multiplicity": count,
        }
        for (energy_text, gap, reciprocal), count in sorted(events.resolvents.items())
    ]


def universal_haar_divisor(projectors: list[dict[str, Any]], cap: int) -> tuple[int, dict[int, int]]:
    primes = sorted({prime for row in projectors for prime in factorint(row["denominator"])})
    max_exponents: dict[int, int] = {}
    for prime in primes:
        best = [-1] * (cap + 1)
        best[0] = 0
        for used in range(cap + 1):
            if best[used] < 0:
                continue
            for row in projectors:
                next_used = used + row["occurrences"]
                if next_used <= cap:
                    exponent = factorint(row["denominator"]).get(prime, 0)
                    best[next_used] = max(best[next_used], best[used] + exponent)
        max_exponents[prime] = max(best)
    divisor = math.prod(prime**exponent for prime, exponent in max_exponents.items())
    return divisor, max_exponents


def factor_rows_for_qbound(
    qbound: int,
    analytic_denominator: int,
    pair_term_envelope: int,
    components: dict[str, int],
) -> list[dict[str, Any]]:
    qf = factorint(qbound)
    analytic_f = factorint(analytic_denominator)
    pair_f = factorint(pair_term_envelope)
    component_f = {name: factorint(value) for name, value in components.items()}
    rows = []
    for prime, exponent in sorted(qf.items()):
        selected = "analytic-one-face" if analytic_f.get(prime, 0) >= pair_f.get(prime, 0) else "pair-term-envelope"
        contributions = [
            {
                "component": name,
                "exponent": factors.get(prime, 0),
                "role": {
                    "w2": "exact-half-history",
                    "r2": "exact-reduced-resolvent-history",
                    "haar": "haar-projector-universal-divisor",
                    "bilinear": "bilinear-prefactor",
                    "analytic": "analytic-one-face",
                }[name],
                "provenance": "Generated from exact primitive arithmetic before any target coefficient was read.",
            }
            for name, factors in component_f.items()
            if factors.get(prime, 0)
        ]
        rows.append(
            {
                "prime": prime,
                "exponent": exponent,
                "selected_lcm_branch": selected,
                "contributions": contributions,
            }
        )
    return rows


def build_exact_histories(spec: dict[str, Any]) -> tuple[LabeledState, LabeledState, dict[str, Any]]:
    scope = spec["scope"]
    rank, extent = scope["rank"], scope["extent"]
    complex_ = CubicComplex(extent)
    polarization = tuple(scope["polarizations"][scope["polarization_index"]])
    anchor = complex_.anchor_face(polarization)  # type: ignore[arg-type]
    events = EventLog.empty()
    resonant_policy = spec["evidence_boundary"]["e0_p0_residual_cancellation"]["policy"]
    source = initial_source(complex_, anchor)
    w1 = apply_w_labeled(complex_, source, rank, events)
    e0_w1 = prove_e0_p0_cancellation(complex_, w1, Fraction(8, 3), rank, "W1")
    r1 = resolvent_labeled(w1, Fraction(8, 3), events, resonant_policy=resonant_policy)
    w2 = apply_w_labeled(complex_, r1, rank, events)
    e0_w2 = prove_e0_p0_cancellation(complex_, w2, Fraction(8, 3), rank, "W2")
    r2 = resolvent_labeled(w2, Fraction(8, 3), events, resonant_policy=resonant_policy)
    supported_patterns = {tuple(row["pattern"]) for row in spec["haar_projectors"]}
    census = compatibility_census(complex_, w2, r2, supported_patterns)
    if census["unsupported_haar_patterns"]:
        raise ClosedGate(
            f"compatible exact history escaped the Haar ledger: {census['unsupported_haar_patterns']}"
        )
    if census["max_bra_ket_occurrences"] > spec["assembly"]["haar_occurrence_cap"]:
        raise ClosedGate("generated compatible history exceeds the declared Haar occurrence cap")
    expected_census = {
        "matched_h0_blocks": 5400,
        "raw_pair_upper_bound": 9814138,
        "skipped_one_face_matches": 54,
    }
    for key, expected in expected_census.items():
        if census[key] != expected:
            raise ClosedGate(
                f"exact completeness census {key}={census[key]} does not match pinned {expected}"
            )
    resonant_exclusions = sum(
        count
        for (_, _, disposition), count in events.resolvents.items()
        if disposition == "resonant-excluded-after-exact-p0-cancellation"
    )
    metadata = {
        "anchor_face": anchor,
        "anchor_geometry": [list(complex_.faces[anchor][0]), *complex_.faces[anchor][1:]],
        "stages": {
            "source": state_stats(source),
            "w1": state_stats(w1),
            "r1": state_stats(r1),
            "w2": state_stats(w2),
            "r2": state_stats(r2),
        },
        "fusion_factors": fusion_records(events),
        "resolvent_factors": resolvent_records(events),
        "compatibility_census": census,
        "e0_scope": {
            "comparison_arithmetic": "fractions.Fraction equality",
            "resonant_signature_blocks_excluded_across_r1_r2": resonant_exclusions,
            "q_reduced_nonresonant_resolvent_exact": True,
            "p0_residual_cancellation_inside_resonant_block_verified": True,
            "boundary": (
                "Every supportwise E0 physical block was projected against the exact scaled "
                "plaquette band with the k=1/k=2/determinant SU(3) Haar Gram form; every exact "
                "post-subtraction residual norm is zero before the resonant block is excluded."
            ),
            "certificates": [e0_w1, e0_w2],
        },
    }
    return w2, r2, metadata


def verify_r2_identity(
    w2: LabeledState, r2: LabeledState, e0: Fraction, *, resonant_policy: str
) -> None:
    expected_events = EventLog.empty()
    expected = resolvent_labeled(w2, e0, expected_events, resonant_policy=resonant_policy)
    if expected != r2:
        raise ClosedGate("exact R2 != W2/(E0-H0) on the nonresonant signatures")


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ClosedGate(f"cannot read JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ClosedGate(f"{path}: JSON root must be an object")
    return value


def generate(repo: Path, primitive_path: Path, out_dir: Path) -> dict[str, Any]:
    history_path = out_dir / "rank3_order4_cubic_history_ledger.json"
    freeze_path = out_dir / "rank3_order4_cubic_freeze.json"
    if history_path.exists() or freeze_path.exists():
        raise ClosedGate("refusing to overwrite an existing frozen ledger; choose a new output directory")
    spec = load_json(primitive_path)
    validate_primitives(spec, repo)
    primitive_hash = sha256_bytes(canonical_bytes(spec))
    generator_hash = sha256_file(Path(__file__).resolve())

    w2, r2, metadata = build_exact_histories(spec)
    resonant_policy = spec["evidence_boundary"]["e0_p0_residual_cancellation"]["policy"]
    verify_r2_identity(w2, r2, Fraction(8, 3), resonant_policy=resonant_policy)
    w2_denominators = sorted({value.denominator for value in iter_coefficients(w2)})
    r2_denominators = sorted({value.denominator for value in iter_coefficients(r2)})
    if not w2_denominators or not r2_denominators:
        raise ClosedGate("exact history generation produced an empty denominator ledger")
    qw2, qr2 = lcm(w2_denominators), lcm(r2_denominators)

    haar, haar_exponents = universal_haar_divisor(
        spec["haar_projectors"], spec["assembly"]["haar_occurrence_cap"]
    )
    bilinear = exact(spec["assembly"]["bilinear_prefactor"], "bilinear").denominator
    analytic_coefficients = exact_one_face_recurrence(spec["assembly"]["analytic_one_face_model"])
    analytic = analytic_coefficients[4]
    pair_term_envelope = bilinear * qw2 * qr2 * haar
    qbound = math.lcm(analytic.denominator, pair_term_envelope)
    components = {
        "w2": qw2,
        "r2": qr2,
        "haar": haar,
        "bilinear": bilinear,
        "analytic": analytic.denominator,
    }
    qbound_factorization = factor_rows_for_qbound(
        qbound, analytic.denominator, pair_term_envelope, components
    )
    independent_product = math.prod(
        prime**exponent for prime, exponent in INDEPENDENT_PATH_ENVELOPE_FACTORS.items()
    )
    if independent_product != INDEPENDENT_PATH_ENVELOPE:
        raise ClosedGate("independent conservative envelope factorization mismatch")
    if INDEPENDENT_PATH_ENVELOPE % qbound:
        raise ClosedGate("exact-history QBOUND does not divide the independent path envelope")
    envelope_quotient = INDEPENDENT_PATH_ENVELOPE // qbound
    quotient_factors = factorint(envelope_quotient)

    records = history_records("W2_scaled", w2) + history_records("R2_scaled", r2)
    history = {
        "schema_version": LEDGER_SCHEMA,
        "scope": spec["scope"],
        "normalization": "Every coefficient is sqrt(2) times the normalized C- half-history coefficient.",
        "records": records,
    }
    assert_no_float(history)
    history_bytes = canonical_bytes(history)
    history_hash = sha256_bytes(history_bytes)

    source_hashes = [
        {
            "path": document["path"],
            "sha256": document["sha256"],
            "role": document["role"],
        }
        for document in spec["source_documents"]
    ]
    freeze = {
        "schema_version": FREEZE_SCHEMA,
        "scope": spec["scope"],
        "certificate_status": "exact-q-reduced-denominator-certificate",
        "unresolved_premises": {},
        "verified_e0_requirement": spec["evidence_boundary"],
        "freeze_protocol": {
            "ledger_and_qbound_created_before_target_audit": True,
            "target_input_consumed_during_generation": False,
            "float_reconstruction_used": False,
            "missing_completeness_allowed": False,
        },
        "input_hashes": {
            "primitive_spec_sha256": primitive_hash,
            "generator_sha256": generator_hash,
            "source_documents": source_hashes,
        },
        "history_ledger": {
            "file": "rank3_order4_cubic_history_ledger.json",
            "sha256": history_hash,
            "records": len(records),
            "w2_records": len(history_records("W2_scaled", w2)),
            "r2_records": len(history_records("R2_scaled", r2)),
            "coverage": (
                "Every nonzero canonical trace-network coefficient in generated scaled W2 and "
                "Q-reduced scaled R2 is serialized; these are coefficients, not denominator-only paths."
            ),
        },
        "completeness": spec["completeness"],
        "generated_factors": {
            "electric_primitives": spec["electric_algebra"],
            "fusion_projectors": metadata["fusion_factors"],
            "resolvents": metadata["resolvent_factors"],
            "haar_projectors": spec["haar_projectors"],
            "analytic_one_face": {
                "value": ftext(analytic),
                "role": "analytic-one-face",
                "provenance": "Derived by the frozen exact scalar-P recurrence; no target coefficient is an input.",
                "recurrence_model": spec["assembly"]["analytic_one_face_model"],
                "derived_coefficients_orders_0_through_4": [
                    ftext(value) for value in analytic_coefficients
                ],
            },
            "bilinear_prefactor": {
                "value": spec["assembly"]["bilinear_prefactor"],
                "role": "bilinear-prefactor",
                "provenance": "D = D11 + (1/2) sum(weight_scaled * Haar).",
            },
        },
        "history_summary": metadata,
        "denominator_envelopes": {
            "w2_unique_denominators": [str(value) for value in w2_denominators],
            "r2_unique_denominators": [str(value) for value in r2_denominators],
            "w2_lcm": str(qw2),
            "r2_lcm": str(qr2),
            "haar_universal_divisor": str(haar),
            "haar_prime_exponents": {str(prime): exponent for prime, exponent in sorted(haar_exponents.items())},
            "pair_term_envelope": str(pair_term_envelope),
        },
        "qbound": {
            "value": str(qbound),
            "factorization": qbound_factorization,
            "derivation": "lcm(analytic denominator, 2 * LCM(W2 exact coefficients) * LCM(R2 exact coefficients) * universal Haar divisor)",
            "status": "exact-symbolic-history / universal-Haar-conservative",
        },
        "bound_comparison": {
            "symbolic_history_bound": {
                "value": str(qbound),
                "factorization": {
                    str(row["prime"]): row["exponent"] for row in qbound_factorization
                },
                "qualification": (
                    "Tight relative to the generated W2/R2 coefficient history; conservative in "
                    "the endpoint Haar exponents because it uses the universal 24-occurrence divisor."
                ),
            },
            "independent_path_level_envelope": {
                "value": str(INDEPENDENT_PATH_ENVELOPE),
                "factorization": {
                    str(prime): exponent
                    for prime, exponent in INDEPENDENT_PATH_ENVELOPE_FACTORS.items()
                },
                "provenance": (
                    "Independent conservative audit: local-H denominator-6 path envelopes over "
                    "9392 W2 and 9201 R2 paths, followed by the same Haar 2^18*3^12*5^4 envelope."
                ),
            },
            "relation": {
                "symbolic_history_bound_divides_path_envelope": True,
                "quotient": str(envelope_quotient),
                "quotient_factorization": {
                    str(prime): exponent for prime, exponent in sorted(quotient_factors.items())
                },
                "reason": (
                    "The path envelope assigns worst-case local electric denominators before exact "
                    "trace-network addition, cancellation, and fraction reduction.  Generating every "
                    "W2/R2 coefficient first reduces those excess powers exactly."
                ),
            },
        },
        "self_checks": {
            "r2_exact_resolvent_identity": True,
            "e0_exclusion_follows_exact_supportwise_p0_cancellation":
            resonant_policy == E0_VERIFIED_POLICY
            and metadata["e0_scope"]["p0_residual_cancellation_inside_resonant_block_verified"]
            and all(
                certificate["all_residual_norms_exactly_zero"]
                for certificate in metadata["e0_scope"]["certificates"]
            ),
            "analytic_one_face_is_recurrence_derived": analytic
            == exact_one_face_recurrence(spec["assembly"]["analytic_one_face_model"])[4],
            "history_contains_no_float": True,
            "qbound_numeric_equals_factor_product": math.prod(
                row["prime"] ** row["exponent"] for row in qbound_factorization
            )
            == qbound,
            "qbound_contains_analytic_denominator": qbound % analytic.denominator == 0,
            "qbound_contains_pair_term_envelope": qbound % pair_term_envelope == 0,
            "independent_path_envelope_factorization_exact": independent_product
            == INDEPENDENT_PATH_ENVELOPE,
            "symbolic_history_bound_divides_independent_path_envelope":
            INDEPENDENT_PATH_ENVELOPE % qbound == 0,
            "bound_quotient_factorization_exact": math.prod(
                prime**exponent for prime, exponent in quotient_factors.items()
            )
            == envelope_quotient,
        },
    }
    assert_no_float(freeze)
    if not all(freeze["self_checks"].values()):
        raise ClosedGate(f"freeze self-check failed: {freeze['self_checks']}")

    out_dir.mkdir(parents=True, exist_ok=True)
    history_temp = out_dir / ".rank3_order4_cubic_history_ledger.json.tmp"
    freeze_temp = out_dir / ".rank3_order4_cubic_freeze.json.tmp"
    history_temp.write_bytes(history_bytes)
    freeze_without_hash = dict(freeze)
    freeze_hash = sha256_bytes(canonical_bytes(freeze_without_hash))
    freeze["freeze_sha256"] = freeze_hash
    write_canonical_json(freeze_temp, freeze)
    # Re-read and independently verify temporary boundaries before publishing.
    if sha256_file(history_temp) != history_hash:
        raise ClosedGate("written history ledger hash mismatch")
    reread = load_json(freeze_temp)
    claimed = reread.pop("freeze_sha256", None)
    if claimed != sha256_bytes(canonical_bytes(reread)):
        raise ClosedGate("written freeze self-hash mismatch")
    history_temp.replace(history_path)
    freeze_temp.replace(freeze_path)
    return freeze


class ExactTargetEvaluator:
    def __init__(self, environment: dict[str, Fraction]):
        self.environment = environment

    def evaluate(self, node: ast.AST) -> Fraction:
        if isinstance(node, ast.Constant) and type(node.value) is int:
            return Fraction(node.value)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            value = self.evaluate(node.operand)
            return value if isinstance(node.op, ast.UAdd) else -value
        if isinstance(node, ast.Name) and node.id in self.environment:
            return self.environment[node.id]
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "Rational"
            and not node.keywords
            and len(node.args) in (1, 2)
        ):
            values = [self.evaluate(argument) for argument in node.args]
            if any(value.denominator != 1 for value in values):
                raise ClosedGate("Rational arguments are not exact integers")
            if len(values) == 1:
                return values[0]
            return Fraction(values[0].numerator, values[1].numerator)
        if isinstance(node, ast.BinOp):
            left, right = self.evaluate(node.left), self.evaluate(node.right)
            if isinstance(node.op, ast.Add):
                return left + right
            if isinstance(node.op, ast.Sub):
                return left - right
            if isinstance(node.op, ast.Mult):
                return left * right
            if isinstance(node.op, ast.Div):
                return left / right
        raise ClosedGate(f"target expression is not safely exact: {ast.dump(node)}")


def scan_exact_targets(path: Path) -> dict[str, tuple[Fraction, int, int]]:
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(path))
    environment: dict[str, Fraction] = {}
    records: dict[str, tuple[Fraction, int, int]] = {}
    for node in tree.body:
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if len(targets) != 1 or not isinstance(targets[0], ast.Name) or node.value is None:
            continue
        name = targets[0].id
        try:
            value = ExactTargetEvaluator(environment).evaluate(node.value)
        except ClosedGate:
            continue
        environment[name] = value
        if name.isupper():
            records[name] = (value, node.lineno, getattr(node, "end_lineno", node.lineno))
    return records


def verify_freeze(out_dir: Path) -> dict[str, Any]:
    freeze_path = out_dir / "rank3_order4_cubic_freeze.json"
    freeze = load_json(freeze_path)
    assert_no_float(freeze)
    claimed = freeze.pop("freeze_sha256", None)
    actual = sha256_bytes(canonical_bytes(freeze))
    if claimed != actual:
        raise ClosedGate(f"freeze self-hash mismatch: claimed={claimed}, actual={actual}")
    history = out_dir / freeze["history_ledger"]["file"]
    if sha256_file(history) != freeze["history_ledger"]["sha256"]:
        raise ClosedGate("history ledger hash mismatch")
    freeze["freeze_sha256"] = claimed
    return freeze


def audit_targets(repo: Path, target_path: Path, out_dir: Path) -> dict[str, Any]:
    freeze = verify_freeze(out_dir)
    targets = load_json(target_path)
    assert_no_float(targets)
    strict_keys(targets, {"schema_version", "source", "targets"}, "$targets")
    if targets["schema_version"] != TARGET_SCHEMA:
        raise ClosedGate("target schema mismatch")
    target_source = (repo / targets["source"]).resolve()
    if repo.resolve() not in target_source.parents or not target_source.is_file():
        raise ClosedGate("target source missing or outside repository")
    records = scan_exact_targets(target_source)
    qbound = int(freeze["qbound"]["value"])
    rows = []
    errors = []
    seen = set()
    for index, target in enumerate(targets["targets"]):
        strict_keys(target, {"symbol", "role", "policy", "provenance"}, f"$targets.targets[{index}]")
        if target["policy"] not in {"enforce", "quarantine"}:
            raise ClosedGate(f"unknown target policy {target['policy']}")
        if target["symbol"] in seen or not target["role"] or not target["provenance"]:
            raise ClosedGate(f"duplicate or unclassified target {target['symbol']}")
        seen.add(target["symbol"])
        record = records.get(target["symbol"])
        if record is None:
            errors.append({"symbol": target["symbol"], "code": "missing-or-nonexact"})
            continue
        value, line, end_line = record
        divides = qbound % value.denominator == 0
        enforced = target["policy"] == "enforce"
        if enforced and not divides:
            errors.append(
                {
                    "symbol": target["symbol"],
                    "code": "denominator-does-not-divide-frozen-qbound",
                    "denominator": str(value.denominator),
                }
            )
        rows.append(
            {
                "symbol": target["symbol"],
                "role": target["role"],
                "policy": target["policy"],
                "provenance": target["provenance"],
                "value": ftext(value),
                "line": line,
                "end_line": end_line,
                "denominator_divides_frozen_qbound": divides if enforced else "not-enforced",
            }
        )
    report = {
        "schema_version": AUDIT_SCHEMA,
        "ok": not errors,
        "certificate_status": freeze["certificate_status"],
        "unresolved_premises": freeze["unresolved_premises"],
        "verified_e0_requirement": freeze["verified_e0_requirement"],
        "freeze_sha256": freeze["freeze_sha256"],
        "frozen_qbound": freeze["qbound"],
        "target_source": {
            "path": targets["source"],
            "sha256": sha256_file(target_source),
        },
        "summary": {
            "targets": len(targets["targets"]),
            "enforced": sum(target["policy"] == "enforce" for target in targets["targets"]),
            "quarantined": sum(target["policy"] == "quarantine" for target in targets["targets"]),
            "errors": len(errors),
        },
        "errors": errors,
        "targets": rows,
    }
    assert_no_float(report)
    write_canonical_json(out_dir / "rank3_order4_cubic_target_audit.json", report)
    return report


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--repo", type=Path, required=True)
    sub = result.add_subparsers(dest="command", required=True)
    generate_parser = sub.add_parser("generate")
    generate_parser.add_argument("--primitives", type=Path, required=True)
    generate_parser.add_argument("--out", type=Path, required=True)
    audit_parser = sub.add_parser("audit")
    audit_parser.add_argument("--targets", type=Path, required=True)
    audit_parser.add_argument("--out", type=Path, required=True)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.command == "generate":
            result = generate(args.repo, args.primitives, args.out)
            print(json.dumps({"ok": True, "history": result["history_summary"]["stages"], "qbound": result["qbound"]}, indent=2))
            return 0
        report = audit_targets(args.repo, args.targets, args.out)
        print(json.dumps({"ok": report["ok"], "summary": report["summary"]}, indent=2))
        return 0 if report["ok"] else 1
    except (ClosedGate, OSError, SyntaxError, ZeroDivisionError) as exc:
        print(json.dumps({"ok": False, "closed_gate": str(exc)}, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
