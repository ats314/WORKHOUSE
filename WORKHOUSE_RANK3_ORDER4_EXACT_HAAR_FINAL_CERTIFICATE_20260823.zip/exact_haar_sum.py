#!/usr/bin/env python3
"""Exact endpoint-Haar contraction and rank-3/order-4 D accumulation.

This companion consumes the frozen exact-history lineage produced by
``ledger_generator.py``.  It regenerates W2/R2 from the pinned primitives,
requires the regenerated canonical history hash to equal the frozen hash,
collapses all translated compatible state pairs with ``Fraction`` arithmetic,
and evaluates every endpoint Haar integral by exact SU(3) projectors.

No target coefficient, floating-point arithmetic, numerical reconstruction, or
``limit_denominator`` call participates in the calculation.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import itertools
import json
import math
import os
import sys
import time
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
from typing import Any, Iterable

import numpy as np

import ledger_generator as lg


SCHEMA = "workhouse.rank3-order4-cubic-exact-haar/v1"
EXPECTED_MATCHES = 5_400
EXPECTED_RAW_UPPER = 9_814_138
EXPECTED_SKIPPED_ONE_FACE = 54
EXPECTED_COMPATIBLE_PAIRS = 2_468_250
EXPECTED_NONZERO_TOPOLOGIES = 117_161
SUPPORTED_PATTERNS = {(1, 1), (2, 2), (3, 3), (3, 0), (0, 3), (6, 0), (0, 6)}
DECLARED_LOCAL_Q = {
    (1, 1): 3,
    (2, 2): 24,
    (3, 3): 120,
    (3, 0): 6,
    (0, 3): 6,
    (6, 0): 72,
    (0, 6): 72,
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ftext(value: Fraction) -> str:
    return f"{value.numerator}/{value.denominator}"


def parse_fraction(text: str) -> Fraction:
    numerator, denominator = text.split("/", 1)
    return Fraction(int(numerator), int(denominator))


def state_key(state: lg.LXState) -> tuple[Any, ...]:
    return state.occ, state.part


def state_json(state: lg.LXState) -> dict[str, Any]:
    return {
        "occ": [[link, int(orientation)] for link, orientation in state.occ],
        "part": list(state.part),
    }


def joint_relabel_sequence(*states: lg.LXState) -> tuple[lg.LXState, ...]:
    """Jointly relabel physical links in the supplied deterministic order."""
    link_map: dict[int, int] = {}
    output = []
    for state in states:
        occurrences = []
        for link, orientation in state.occ:
            if link not in link_map:
                link_map[link] = len(link_map)
            occurrences.append((link_map[link], orientation))
        output.append(lg.LXState(tuple(occurrences), state.part))
    return tuple(output)


def joint_canon_states(left: lg.LXState, right: lg.LXState) -> tuple[lg.LXState, lg.LXState]:
    """Historical exact-pair canonicalization after whole-block relabelling."""
    first, second = joint_relabel_sequence(left, right)
    if state_key(second) < state_key(first):
        first, second = second, first
    return first, second


def fully_unordered_canon_states(
    left: lg.LXState, right: lg.LXState
) -> tuple[lg.LXState, lg.LXState]:
    """Canonicalize both link relabelling and bra/ket traversal order."""
    candidates = (
        joint_relabel_sequence(left, right),
        joint_relabel_sequence(right, left),
    )
    return min(candidates, key=lambda pair: (state_key(pair[0]), state_key(pair[1])))


def canonical_block_pair(
    left_vector: dict[lg.LXState, Fraction],
    right_vector: dict[lg.LXState, Fraction],
) -> tuple[tuple[Any, ...], tuple[tuple[lg.LXState, Fraction], ...], tuple[tuple[lg.LXState, Fraction], ...]]:
    """Canonicalize the entire pair of vectors before the state-pair collapse."""
    left_items = sorted(left_vector.items(), key=lambda item: (state_key(item[0]), item[1]))
    right_items = sorted(right_vector.items(), key=lambda item: (state_key(item[0]), item[1]))
    relabelled = joint_relabel_sequence(
        *(state for state, _ in left_items), *(state for state, _ in right_items)
    )
    split = len(left_items)
    left = tuple((state, Fraction(item[1])) for state, item in zip(relabelled[:split], left_items))
    right = tuple((state, Fraction(item[1])) for state, item in zip(relabelled[split:], right_items))
    left_key = tuple(
        (state.occ, state.part, coefficient.numerator, coefficient.denominator)
        for state, coefficient in left
    )
    right_key = tuple(
        (state.occ, state.part, coefficient.numerator, coefficient.denominator)
        for state, coefficient in right
    )
    if right_key < left_key:
        left, right = right, left
        left_key, right_key = right_key, left_key
    return (left_key, right_key), left, right


def topology_key(pair: tuple[lg.LXState, lg.LXState]) -> tuple[Any, ...]:
    return state_key(pair[0]), state_key(pair[1])


def regenerated_history_hash(w2: lg.LabeledState, r2: lg.LabeledState, scope: dict[str, Any]) -> str:
    history = {
        "schema_version": lg.LEDGER_SCHEMA,
        "scope": scope,
        "normalization": "Every coefficient is sqrt(2) times the normalized C- half-history coefficient.",
        "records": lg.history_records("W2_scaled", w2) + lg.history_records("R2_scaled", r2),
    }
    lg.assert_no_float(history)
    return hashlib.sha256(lg.canonical_bytes(history)).hexdigest()


def collapse_pair_weights(
    complex_: lg.CubicComplex,
    w2: lg.LabeledState,
    r2: lg.LabeledState,
) -> tuple[dict[tuple[lg.LXState, lg.LXState], Fraction], dict[str, Any]]:
    """Exact whole-block orbit collapse followed by exact state-pair collapse."""
    right_index: dict[
        tuple[lg.Signature, Fraction],
        list[tuple[frozenset[int], dict[lg.LXState, Fraction]]],
    ] = defaultdict(list)
    for support, state_map in r2.items():
        for key, vector in lg.physical_blocks(state_map).items():
            right_index[key].append((support, vector))

    left_items = []
    for support, state_map in w2.items():
        for (signature, energy_value), vector in lg.physical_blocks(state_map).items():
            left_items.append((support, signature, energy_value, vector))

    block_tasks: dict[
        tuple[Any, ...],
        list[Any],
    ] = {}
    matches = raw_upper = skipped_one_face = 0
    started = last = time.monotonic()
    for item_index, (left_support, signature, energy_value, vector) in enumerate(left_items, 1):
        for delta_raw in complex_.vertices:
            delta = tuple(delta_raw)
            translated_signature = lg.signature_canonical(
                lg.translate_signature(complex_, signature, delta)
            )
            candidates = right_index.get((translated_signature, energy_value), ())
            if not candidates:
                continue
            translated_vector = {
                lg.translate_state(complex_, state, delta): coefficient
                for state, coefficient in vector.items()
            }
            for right_support, right_vector in candidates:
                matches += 1
                raw_upper += len(translated_vector) * len(right_vector)
                if len(left_support) == 1 and len(right_support) == 1:
                    skipped_one_face += 1
                    continue
                key, left, right = canonical_block_pair(translated_vector, right_vector)
                record = block_tasks.get(key)
                if record is None:
                    block_tasks[key] = [1, left, right]
                else:
                    record[0] += 1
        now = time.monotonic()
        if now - last >= 10 or item_index == len(left_items):
            rate = item_index / max(now - started, 1e-9)
            eta = (len(left_items) - item_index) / max(rate, 1e-9)
            print(
                f"[collapse] blocks={item_index:,}/{len(left_items):,} "
                f"matches={matches:,} block_orbits={len(block_tasks):,} "
                f"raw_upper={raw_upper:,} elapsed={now-started:.1f}s ETA={eta:.1f}s",
                flush=True,
            )
            last = now

    if len(block_tasks) != 3_597:
        raise lg.ClosedGate(f"whole-block orbit census={len(block_tasks)}, expected=3597")

    pair_weights: dict[tuple[lg.LXState, lg.LXState], Fraction] = defaultdict(Fraction)
    pair_occurrences = 0
    collapse_started = last = time.monotonic()
    records = list(block_tasks.values())
    for task_index, (multiplicity, left, right) in enumerate(records, 1):
        left_by_flux: dict[Any, list[tuple[lg.LXState, Fraction]]] = defaultdict(list)
        right_by_flux: dict[Any, list[tuple[lg.LXState, Fraction]]] = defaultdict(list)
        for state, coefficient in left:
            left_by_flux[lg.flux_key(state)].append((state, coefficient))
        for state, coefficient in right:
            right_by_flux[lg.flux_key(state)].append((state, coefficient))
        for flux, left_rows in left_by_flux.items():
            right_rows = right_by_flux.get(flux, ())
            for left_state, left_coefficient in left_rows:
                for right_state, right_coefficient in right_rows:
                    pair_occurrences += 1
                    pair = joint_canon_states(left_state, right_state)
                    pair_weights[pair] += multiplicity * left_coefficient * right_coefficient
        now = time.monotonic()
        if now - last >= 10 or task_index == len(records):
            rate = task_index / max(now - collapse_started, 1e-9)
            eta = (len(records) - task_index) / max(rate, 1e-9)
            print(
                f"[pair-collapse] block_orbits={task_index:,}/{len(records):,} "
                f"occurrences={pair_occurrences:,} live_topologies={len(pair_weights):,} "
                f"elapsed={now-collapse_started:.1f}s ETA={eta:.1f}s",
                flush=True,
            )
            last = now

    pair_weights = {pair: weight for pair, weight in pair_weights.items() if weight}
    census = {
        "left_physical_blocks": len(left_items),
        "matched_h0_blocks": matches,
        "raw_pair_upper_bound": raw_upper,
        "skipped_one_face_matches": skipped_one_face,
        "whole_block_orbits": len(block_tasks),
        "pair_occurrences_after_block_orbit_collapse": pair_occurrences,
        "nonzero_canonical_topologies": len(pair_weights),
        "route": "exact-whole-block-orbits-then-flux-compatible-state-pairs",
    }
    expected = {
        "matched_h0_blocks": EXPECTED_MATCHES,
        "raw_pair_upper_bound": EXPECTED_RAW_UPPER,
        "skipped_one_face_matches": EXPECTED_SKIPPED_ONE_FACE,
        "whole_block_orbits": 3_597,
        "pair_occurrences_after_block_orbit_collapse": 1_829_147,
        "nonzero_canonical_topologies": EXPECTED_NONZERO_TOPOLOGIES,
    }
    for key, value in expected.items():
        if census[key] != value:
            raise lg.ClosedGate(f"exact collapse census drift: {key}={census[key]}, expected={value}")
    return pair_weights, census


def collapse_unordered_pair_weights(
    complex_: lg.CubicComplex,
    w2: lg.LabeledState,
    r2: lg.LabeledState,
) -> tuple[dict[tuple[lg.LXState, lg.LXState], Fraction], dict[str, Any]]:
    """Losslessly quotient the historical keys by Haar symmetry and link relabelling."""
    right_index: dict[
        tuple[lg.Signature, Fraction],
        list[
            tuple[
                frozenset[int],
                dict[lg.LXState, Fraction],
                dict[Any, list[tuple[lg.LXState, Fraction]]],
            ]
        ],
    ] = defaultdict(list)
    for support, state_map in r2.items():
        for key, vector in lg.physical_blocks(state_map).items():
            by_flux: dict[Any, list[tuple[lg.LXState, Fraction]]] = defaultdict(list)
            for state, coefficient in vector.items():
                by_flux[lg.flux_key(state)].append((state, coefficient))
            right_index[key].append((support, vector, by_flux))

    left_items = []
    for support, state_map in w2.items():
        for (signature, energy_value), vector in lg.physical_blocks(state_map).items():
            left_items.append((support, signature, energy_value, vector))

    pair_weights: dict[tuple[lg.LXState, lg.LXState], Fraction] = defaultdict(Fraction)
    matches = raw_upper = skipped_one_face = compatible_pairs = 0
    started = last = time.monotonic()
    for item_index, (left_support, signature, energy_value, vector) in enumerate(left_items, 1):
        for delta_raw in complex_.vertices:
            delta = tuple(delta_raw)
            translated_signature = lg.signature_canonical(
                lg.translate_signature(complex_, signature, delta)
            )
            candidates = right_index.get((translated_signature, energy_value), ())
            if not candidates:
                continue
            translated_vector = {
                lg.translate_state(complex_, state, delta): coefficient
                for state, coefficient in vector.items()
            }
            left_by_flux: dict[Any, list[tuple[lg.LXState, Fraction]]] = defaultdict(list)
            for state, coefficient in translated_vector.items():
                left_by_flux[lg.flux_key(state)].append((state, coefficient))
            for right_support, right_vector, right_by_flux in candidates:
                matches += 1
                raw_upper += len(translated_vector) * len(right_vector)
                if len(left_support) == 1 and len(right_support) == 1:
                    skipped_one_face += 1
                    continue
                for flux, left_rows in left_by_flux.items():
                    right_rows = right_by_flux.get(flux, ())
                    for left_state, left_coefficient in left_rows:
                        for right_state, right_coefficient in right_rows:
                            compatible_pairs += 1
                            pair = fully_unordered_canon_states(left_state, right_state)
                            pair_weights[pair] += left_coefficient * right_coefficient
        now = time.monotonic()
        if now - last >= 10 or item_index == len(left_items):
            rate = item_index / max(now - started, 1e-9)
            eta = (len(left_items) - item_index) / max(rate, 1e-9)
            print(
                f"[unordered-collapse] blocks={item_index:,}/{len(left_items):,} "
                f"matches={matches:,} compatible={compatible_pairs:,} "
                f"live_classes={len(pair_weights):,} elapsed={now-started:.1f}s ETA={eta:.1f}s",
                flush=True,
            )
            last = now
    pair_weights = {pair: weight for pair, weight in pair_weights.items() if weight}
    census = {
        "left_physical_blocks": len(left_items),
        "matched_h0_blocks": matches,
        "raw_pair_upper_bound": raw_upper,
        "skipped_one_face_matches": skipped_one_face,
        "compatible_state_pairs": compatible_pairs,
        "historical_orientation_sensitive_nonzero_topologies": EXPECTED_NONZERO_TOPOLOGIES,
        "fully_unordered_nonzero_contraction_classes": len(pair_weights),
        "route": "all-exact-translated-matches-quotiented-by-link-relabel-and-bra-ket-Haar-symmetry",
    }
    expected = {
        "matched_h0_blocks": EXPECTED_MATCHES,
        "raw_pair_upper_bound": EXPECTED_RAW_UPPER,
        "skipped_one_face_matches": EXPECTED_SKIPPED_ONE_FACE,
        "compatible_state_pairs": EXPECTED_COMPATIBLE_PAIRS,
        "fully_unordered_nonzero_contraction_classes": 69_800,
    }
    for key, value in expected.items():
        if census[key] != value:
            raise lg.ClosedGate(f"unordered exact collapse census drift: {key}={census[key]}, expected={value}")
    return pair_weights, census


PERMUTATIONS: dict[int, tuple[tuple[int, ...], ...]] = {
    k: tuple(itertools.permutations(range(k))) for k in range(1, 7)
}


def parity(permutation: tuple[int, ...]) -> int:
    inversions = sum(
        permutation[i] > permutation[j]
        for i in range(len(permutation))
        for j in range(i + 1, len(permutation))
    )
    return -1 if inversions % 2 else 1


def inverse_permutation(permutation: tuple[int, ...]) -> tuple[int, ...]:
    result = [0] * len(permutation)
    for index, image in enumerate(permutation):
        result[image] = index
    return tuple(result)


def compose(left: tuple[int, ...], right: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(left[right[index]] for index in range(len(left)))


def cycle_type(permutation: tuple[int, ...]) -> tuple[int, ...]:
    seen: set[int] = set()
    lengths = []
    for start in range(len(permutation)):
        if start in seen:
            continue
        current = start
        length = 0
        while current not in seen:
            seen.add(current)
            current = permutation[current]
            length += 1
        lengths.append(length)
    return tuple(sorted(lengths, reverse=True))


def wg_coefficient(k: int, sigma: tuple[int, ...], tau: tuple[int, ...]) -> Fraction:
    relative = compose(inverse_permutation(sigma), tau)
    kind = cycle_type(relative)
    if k == 1:
        return Fraction(1, 3)
    if k == 2:
        return Fraction(1, 8) if kind == (1, 1) else Fraction(-1, 24)
    if k == 3:
        return {
            (1, 1, 1): Fraction(7, 120),
            (2, 1): Fraction(-1, 40),
            (3,): Fraction(1, 60),
        }[kind]
    raise lg.ClosedGate(f"no balanced exact Weingarten primitive for k={k}")


def epsilon(indices: tuple[int, int, int]) -> int:
    if len(set(indices)) != 3:
        return 0
    return parity(indices)


def matrix_inverse(matrix: list[list[int | Fraction]]) -> list[list[Fraction]]:
    size = len(matrix)
    augmented = [
        [Fraction(value) for value in row]
        + [Fraction(int(i == j)) for j in range(size)]
        for i, row in enumerate(matrix)
    ]
    for column in range(size):
        pivot = next((row for row in range(column, size) if augmented[row][column]), None)
        if pivot is None:
            raise ZeroDivisionError("singular exact matrix")
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        scale = augmented[column][column]
        augmented[column] = [value / scale for value in augmented[column]]
        for row in range(size):
            if row == column:
                continue
            factor = augmented[row][column]
            if factor:
                augmented[row] = [
                    value - factor * pivot_value
                    for value, pivot_value in zip(augmented[row], augmented[column])
                ]
    return [row[size:] for row in augmented]


def derive_pure_six_projector() -> dict[str, Any]:
    """Derive the rank-five SU(3) projector on six equal orientations exactly."""
    partitions = []
    for combination in itertools.combinations(range(1, 6), 2):
        first = (0,) + combination
        second = tuple(index for index in range(6) if index not in first)
        partitions.append((first, second))

    assignments = tuple(itertools.product(range(3), repeat=6))
    invariant_vectors = []
    for first, second in partitions:
        invariant_vectors.append(
            tuple(
                epsilon(tuple(assignment[index] for index in first))
                * epsilon(tuple(assignment[index] for index in second))
                for assignment in assignments
            )
        )
    gram = [
        [sum(x * y for x, y in zip(left, right)) for right in invariant_vectors]
        for left in invariant_vectors
    ]

    keep = None
    inverse = None
    for choice in itertools.combinations(range(10), 5):
        minor = [[gram[i][j] for j in choice] for i in choice]
        try:
            candidate = matrix_inverse(minor)
        except ZeroDivisionError:
            continue
        keep, inverse = choice, candidate
        break
    if keep is None or inverse is None:
        raise lg.ClosedGate("pure-six epsilon-pair Gram matrix did not have exact rank at least five")

    # Prove the other five invariant vectors lie in the chosen span, hence rank=5.
    selected = [invariant_vectors[index] for index in keep]
    for vector in invariant_vectors:
        # Coordinates are G^-1 * <I_keep, vector>.
        rhs = [sum(x * y for x, y in zip(base, vector)) for base in selected]
        coordinates = [
            sum(inverse[row][column] * rhs[column] for column in range(5))
            for row in range(5)
        ]
        reconstructed = [
            sum(coordinates[index] * selected[index][slot] for index in range(5))
            for slot in range(len(assignments))
        ]
        if any(Fraction(value) != reconstructed[index] for index, value in enumerate(vector)):
            raise lg.ClosedGate("pure-six invariant basis failed exact rank-five spanning gate")

    coefficients: dict[tuple[int, ...], Fraction] = defaultdict(Fraction)
    p3 = PERMUTATIONS[3]
    for left_basis, left_index in enumerate(keep):
        left_first, left_second = partitions[left_index]
        for right_basis, right_index in enumerate(keep):
            coefficient = inverse[left_basis][right_basis]
            if not coefficient:
                continue
            right_first, right_second = partitions[right_index]
            for sigma in p3:
                for tau in p3:
                    permutation = [0] * 6
                    for index in range(3):
                        permutation[left_first[index]] = right_first[sigma[index]]
                        permutation[left_second[index]] = right_second[tau[index]]
                    coefficients[tuple(permutation)] += coefficient * parity(sigma) * parity(tau)
    coefficients = {permutation: value for permutation, value in coefficients.items() if value}
    if len(coefficients) > math.factorial(6):
        raise lg.ClosedGate("pure-six permutation expansion escaped S6")
    common_denominator = math.lcm(*(value.denominator for value in coefficients.values()))
    trace = sum(
        coefficient * 3 ** len(cycle_type(permutation))
        for permutation, coefficient in coefficients.items()
    )
    if trace != 5:
        raise lg.ClosedGate(f"pure-six exact projector trace is {trace}, expected 5")
    for permutation, coefficient in coefficients.items():
        if coefficients.get(inverse_permutation(permutation), Fraction()) != coefficient:
            raise lg.ClosedGate("pure-six exact projector is not Hermitian in permutation form")
    return {
        "partitions": partitions,
        "gram": gram,
        "keep": keep,
        "inverse": inverse,
        "selected_vectors": selected,
        "coefficients": coefficients,
        "common_denominator": common_denominator,
        "trace": trace,
    }


PURE_SIX = derive_pure_six_projector()


def _build_factor_tensors() -> dict[Any, Any]:
    tensors: dict[Any, Any] = {}
    epsilon_tensor = np.zeros((3, 3, 3), dtype=np.int64)
    for assignment in itertools.product(range(3), repeat=3):
        epsilon_tensor[assignment] = epsilon(assignment)
    tensors["epsilon"] = epsilon_tensor
    for k in (1, 2, 3):
        permutations = PERMUTATIONS[k]
        delta = np.zeros((len(permutations),) + (3,) * (2 * k), dtype=np.int64)
        for permutation_index, permutation in enumerate(permutations):
            for rows in itertools.product(range(3), repeat=k):
                columns = [0] * k
                for index in range(k):
                    columns[permutation[index]] = rows[index]
                delta[(permutation_index,) + rows + tuple(columns)] = 1
        denominator = DECLARED_LOCAL_Q[(k, k)]
        weights = np.asarray(
            [
                [
                    int(wg_coefficient(k, sigma, tau) * denominator)
                    for tau in permutations
                ]
                for sigma in permutations
            ],
            dtype=np.int64,
        )
        tensors[("balanced", k)] = (delta, weights, denominator)
    pure_vectors = np.asarray(PURE_SIX["selected_vectors"], dtype=np.int64).reshape(
        (5,) + (3,) * 6
    )
    pure_denominator = int(PURE_SIX["common_denominator"])
    pure_inverse = np.asarray(
        [
            [int(value * pure_denominator) for value in row]
            for row in PURE_SIX["inverse"]
        ],
        dtype=np.int64,
    )
    tensors["pure_six"] = (pure_vectors, pure_inverse, pure_denominator)
    return tensors


FACTOR_TENSORS = _build_factor_tensors()
CRT_PRIMES = (1_000_000_007, 1_000_000_009, 998_244_353, 1_004_535_809, 469_762_049)

# Independently replayed exact fold and linked-vacuum certificates.  These
# enter only after D_EXACT has been completely accumulated from the Haar ledger.
FOLD_EXACT = Fraction(5_315_003, 140_454)
LINKED_VACUUM_EXACT = Fraction(-1_474_623, 1_675_520)
FOLD_MINUS_LINKED_EXACT = Fraction(268_015_015_453, 6_921_573_120)
FOLD_REPRODUCER_SHA256 = "063979837850c1c8ae3bacb4317a75020c7b92db89681b5785c2c22807a9ef3c"
LINKED_FINAL_SHA256 = "ac7a0feb4581d64315cbea1e16fd81632f79754d4a30fc276d1e0411c54f25e8"
FOLD_LINKED_PACKAGE_SHA256 = "abf8e1e28f0f08eaccc98fe265cda0adeeef3b53ec482b9d4d96fc490827ec5c"


def local_projector_terms(
    positives: list[int], negatives: list[int]
) -> tuple[int, tuple[tuple[tuple[tuple[int, int], ...], int], ...]]:
    pattern = (len(positives), len(negatives))
    if pattern in ((1, 1), (2, 2), (3, 3)):
        k = len(positives)
        weighted = []
        for sigma in PERMUTATIONS[k]:
            for tau in PERMUTATIONS[k]:
                coefficient = wg_coefficient(k, sigma, tau)
                pairs = []
                for index in range(k):
                    pairs.append((2 * positives[index], 2 * negatives[sigma[index]]))
                    pairs.append((2 * positives[index] + 1, 2 * negatives[tau[index]] + 1))
                weighted.append((tuple(pairs), coefficient))
    elif pattern in ((3, 0), (0, 3)):
        items = positives if positives else negatives
        weighted = []
        for permutation in PERMUTATIONS[3]:
            pairs = tuple(
                (2 * items[index], 2 * items[permutation[index]] + 1)
                for index in range(3)
            )
            weighted.append((pairs, Fraction(parity(permutation), 6)))
    elif pattern in ((6, 0), (0, 6)):
        items = positives if positives else negatives
        weighted = []
        for permutation, coefficient in PURE_SIX["coefficients"].items():
            pairs = tuple(
                (2 * items[index], 2 * items[permutation[index]] + 1)
                for index in range(6)
            )
            weighted.append((pairs, coefficient))
    else:
        raise lg.ClosedGate(f"unsupported production Haar pattern {pattern}")
    denominator = math.lcm(*(coefficient.denominator for _, coefficient in weighted))
    terms = tuple(
        (pairs, coefficient.numerator * (denominator // coefficient.denominator))
        for pairs, coefficient in weighted
        if coefficient
    )
    return denominator, terms


def endpoint_groups(
    left: lg.LXState, right: lg.LXState
) -> tuple[tuple[tuple[int, int], ...], tuple[int, ...], list[tuple[int, list[int], list[int]]]]:
    bra_occ = tuple((link, not orientation) for link, orientation in left.occ)
    offset = max(left.part) + 1 if left.part else 0
    occurrences = bra_occ + right.occ
    partition = lg.lx_canon(left.part + tuple(label + offset for label in right.part))
    by_link: dict[int, dict[bool, list[int]]] = defaultdict(lambda: {True: [], False: []})
    for index, (link, orientation) in enumerate(occurrences):
        by_link[link][orientation].append(index)
    groups = [(link, values[True], values[False]) for link, values in by_link.items()]
    patterns = tuple(sorted((len(positive), len(negative)) for _, positive, negative in groups))
    return patterns, partition, groups


def exact_haar_dsu(left: lg.LXState, right: lg.LXState) -> tuple[Fraction, dict[str, Any]]:
    """Independent exact delta-partition expansion (slow on pure-six cases)."""
    patterns, partition, groups = endpoint_groups(left, right)
    if any((positive - negative) % 3 for positive, negative in patterns):
        return Fraction(), {"patterns": patterns, "local_common_denominator_product": 1}
    if not set(patterns) <= SUPPORTED_PATTERNS:
        raise lg.ClosedGate(f"topology escaped supported Haar patterns: {patterns}")

    expanded_groups = []
    for link, positives, negatives in groups:
        denominator, terms = local_projector_terms(positives, negatives)
        expanded_groups.append((len(terms), link, denominator, terms))
    # High-rank projectors first tie otherwise independent trace labels together;
    # determinant expansions then coalesce aggressively instead of multiplying a
    # large disconnected state set before the pure-six constraint is seen.
    expanded_groups.sort(key=lambda row: (-row[0], row[1]))

    states: dict[tuple[int, ...], int] = {partition: 1}
    denominator_product = 1
    peak_states = 1
    for _, _link, denominator, terms in expanded_groups:
        next_states: dict[tuple[int, ...], int] = defaultdict(int)
        for state, coefficient in states.items():
            for pairs, numerator in terms:
                next_states[lg.lx_merge_classes(state, pairs)] += coefficient * numerator
        states = {state: coefficient for state, coefficient in next_states.items() if coefficient}
        denominator_product *= denominator
        if states:
            common = math.gcd(denominator_product, math.gcd(*(abs(value) for value in states.values())))
            if common > 1:
                denominator_product //= common
                states = {state: value // common for state, value in states.items()}
        peak_states = max(peak_states, len(states))
        if not states:
            break
    numerator = sum(coefficient * 3 ** len(set(state)) for state, coefficient in states.items())
    value = Fraction(numerator, denominator_product)
    declared_q = math.prod(DECLARED_LOCAL_Q[pattern] for pattern in patterns)
    if declared_q % value.denominator:
        raise lg.ClosedGate(
            f"exact Haar denominator {value.denominator} does not divide declared endpoint q_H={declared_q}; "
            f"patterns={patterns}"
        )
    return value, {
        "patterns": patterns,
        "local_common_denominator_product": denominator_product,
        "declared_qh": declared_q,
        "peak_partition_states": peak_states,
        "method": "exact-dsu-projector-expansion",
    }


def diagonal_factor(array: np.ndarray, raw_labels: list[int]) -> tuple[tuple[int, ...], np.ndarray]:
    """Extract repeated-index diagonals while retaining one axis per variable."""
    unique_labels = tuple(dict.fromkeys(raw_labels))
    if len(unique_labels) == len(raw_labels):
        return unique_labels, array
    local = {label: index for index, label in enumerate(unique_labels)}
    input_axes = [local[label] for label in raw_labels]
    output_axes = list(range(len(unique_labels)))
    reduced = np.einsum(array, input_axes, output_axes, optimize=False)
    return unique_labels, np.asarray(reduced, dtype=np.int64)


def factor_network(
    partition: tuple[int, ...],
    groups: list[tuple[int, list[int], list[int]]],
) -> tuple[list[tuple[tuple[int, ...], np.ndarray]], int, dict[int, int]]:
    """Compile the exact low-rank SU(3) projectors into an integer tensor network."""
    factors: list[tuple[tuple[int, ...], np.ndarray]] = []
    dimensions = {int(label): 3 for label in set(partition)}
    next_label = (max(partition) + 1) if partition else 0
    denominator_product = 1
    for _link, positives, negatives in groups:
        pattern = (len(positives), len(negatives))
        rows = [int(partition[2 * occurrence]) for occurrence in positives + negatives]
        columns = [int(partition[2 * occurrence + 1]) for occurrence in positives + negatives]
        if pattern in ((1, 1), (2, 2), (3, 3)):
            k = len(positives)
            delta, weight, denominator = FACTOR_TENSORS[("balanced", k)]
            row_aux, column_aux = next_label, next_label + 1
            next_label += 2
            dimensions[row_aux] = len(PERMUTATIONS[k])
            dimensions[column_aux] = len(PERMUTATIONS[k])
            factors.append(diagonal_factor(delta, [row_aux] + rows))
            factors.append(((row_aux, column_aux), weight))
            factors.append(diagonal_factor(delta, [column_aux] + columns))
        elif pattern in ((3, 0), (0, 3)):
            epsilon_tensor = FACTOR_TENSORS["epsilon"]
            factors.append(diagonal_factor(epsilon_tensor, rows))
            factors.append(diagonal_factor(epsilon_tensor, columns))
            denominator = 6
        elif pattern in ((6, 0), (0, 6)):
            invariant, inverse, denominator = FACTOR_TENSORS["pure_six"]
            row_aux, column_aux = next_label, next_label + 1
            next_label += 2
            dimensions[row_aux] = 5
            dimensions[column_aux] = 5
            factors.append(diagonal_factor(invariant, [row_aux] + rows))
            factors.append(((row_aux, column_aux), inverse))
            factors.append(diagonal_factor(invariant, [column_aux] + columns))
        else:
            raise lg.ClosedGate(f"unsupported production Haar pattern {pattern}")
        denominator_product *= denominator
    return factors, denominator_product, dimensions


def modular_contract(
    source_factors: list[tuple[tuple[int, ...], np.ndarray]],
    dimensions: dict[int, int],
    modulus: int,
) -> tuple[int, int]:
    """Contract a scalar tensor network exactly in F_p by min-fill elimination."""
    factors = [
        (labels, np.remainder(array, modulus, dtype=np.int64))
        for labels, array in source_factors
    ]
    scalar = 1
    peak_entries = max((array.size for _, array in factors), default=1)
    while factors:
        variables = set(itertools.chain.from_iterable(labels for labels, _ in factors))
        if not variables:
            for _labels, array in factors:
                scalar = (scalar * int(array)) % modulus
            break

        def elimination_cost(variable: int) -> tuple[int, int, int]:
            union: set[int] = set()
            count = 0
            for labels, _array in factors:
                if variable in labels:
                    union.update(labels)
                    count += 1
            entries = math.prod(dimensions[label] for label in union)
            return entries, len(union), count

        variable = min(variables, key=lambda label: elimination_cost(label) + (label,))
        bucket = [(labels, array) for labels, array in factors if variable in labels]
        factors = [(labels, array) for labels, array in factors if variable not in labels]
        union_labels = tuple(dict.fromkeys(itertools.chain.from_iterable(labels for labels, _ in bucket)))
        union_shape = tuple(dimensions[label] for label in union_labels)
        peak_entries = max(peak_entries, math.prod(union_shape))
        joint: np.ndarray | None = None
        for labels, array in bucket:
            present = [label for label in union_labels if label in labels]
            permutation = [labels.index(label) for label in present]
            aligned = np.transpose(array, permutation) if permutation != list(range(len(labels))) else array
            reshape = tuple(dimensions[label] if label in labels else 1 for label in union_labels)
            aligned = aligned.reshape(reshape)
            if joint is None:
                joint = np.remainder(aligned, modulus, dtype=np.int64)
            else:
                joint = np.remainder(joint * aligned, modulus, dtype=np.int64)
        if joint is None:
            raise lg.ClosedGate("empty modular elimination bucket")
        axis = union_labels.index(variable)
        joint = np.remainder(np.sum(joint, axis=axis, dtype=np.int64), modulus, dtype=np.int64)
        output_labels = tuple(label for label in union_labels if label != variable)
        if output_labels:
            factors.append((output_labels, joint))
        else:
            scalar = (scalar * int(joint)) % modulus
    return scalar % modulus, peak_entries


def signed_crt(residues: list[int], moduli: list[int], bound: int) -> int:
    value = 0
    product = 1
    for residue, modulus in zip(residues, moduli):
        correction = ((residue - value) % modulus) * pow(product, -1, modulus) % modulus
        value += product * correction
        product *= modulus
    if product <= 2 * bound:
        raise lg.ClosedGate(f"CRT modulus product {product} does not isolate bound {bound}")
    if value > product // 2:
        value -= product
    if abs(value) > bound:
        raise lg.ClosedGate(f"CRT reconstruction {value} escaped rigorous bound {bound}")
    return value


def exact_haar(left: lg.LXState, right: lg.LXState) -> tuple[Fraction, dict[str, Any]]:
    """Exact integer tensor contraction with finite-field CRT reconstruction."""
    patterns, partition, groups = endpoint_groups(left, right)
    if any((positive - negative) % 3 for positive, negative in patterns):
        return Fraction(), {
            "patterns": patterns,
            "local_common_denominator_product": 1,
            "declared_qh": 1,
            "peak_partition_states": 1,
            "method": "center-selection-exact-zero",
            "crt_primes": 0,
        }
    if not set(patterns) <= SUPPORTED_PATTERNS:
        raise lg.ClosedGate(f"topology escaped supported Haar patterns: {patterns}")
    factors, denominator_product, dimensions = factor_network(partition, groups)
    declared_q = math.prod(DECLARED_LOCAL_Q[pattern] for pattern in patterns)
    if denominator_product != declared_q:
        raise lg.ClosedGate(
            f"compiled local denominator product {denominator_product} != declared q_H={declared_q}"
        )
    # Each unintegrated matrix entry has modulus <=1, and there are at most
    # 3^(number of independent trace labels) color assignments.
    numerator_bound = denominator_product * 3 ** len(set(partition))
    moduli = []
    product = 1
    for prime in CRT_PRIMES:
        moduli.append(prime)
        product *= prime
        if product > 2 * numerator_bound:
            break
    if product <= 2 * numerator_bound:
        raise lg.ClosedGate("configured exact CRT primes do not cover the Haar numerator bound")
    residues = []
    peak_entries = 1
    for prime in moduli:
        residue, peak = modular_contract(factors, dimensions, prime)
        residues.append(residue)
        peak_entries = max(peak_entries, peak)
    numerator = signed_crt(residues, moduli, numerator_bound)
    value = Fraction(numerator, denominator_product)
    if declared_q % value.denominator:
        raise lg.ClosedGate(
            f"exact Haar denominator {value.denominator} does not divide declared endpoint q_H={declared_q}"
        )
    return value, {
        "patterns": patterns,
        "local_common_denominator_product": denominator_product,
        "declared_qh": declared_q,
        "peak_partition_states": peak_entries,
        "method": "exact-integer-factor-network-crt",
        "crt_primes": len(moduli),
        "rigorous_numerator_bound": numerator_bound,
    }


def checkpoint_prefix(path: Path) -> tuple[int, str]:
    if not path.exists():
        return 0, ""
    count = 0
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for line in handle:
            if not line.endswith(b"\n"):
                raise lg.ClosedGate("truncated Haar checkpoint line")
            row = json.loads(line)
            if row.get("index") != count:
                raise lg.ClosedGate("non-contiguous Haar checkpoint")
            digest.update(line)
            count += 1
    return count, digest.hexdigest()


def write_canonical_gzip(path: Path, value: Any) -> tuple[str, str]:
    raw = lg.canonical_bytes(value)
    raw_hash = hashlib.sha256(raw).hexdigest()
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as raw_handle:
        # mtime=0 makes the compressed artifact byte-reproducible.
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw_handle, mtime=0) as handle:
            handle.write(raw)
    os.replace(temporary, path)
    return raw_hash, sha256_file(path)


def run(args: argparse.Namespace) -> dict[str, Any]:
    repo = args.repo.resolve()
    primitive_path = args.primitives.resolve()
    frozen_dir = args.frozen.resolve()
    out_dir = args.out.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    spec = lg.load_json(primitive_path)
    lg.validate_primitives(spec, repo)
    freeze_path = frozen_dir / "rank3_order4_cubic_freeze.json"
    history_path = frozen_dir / "rank3_order4_cubic_history_ledger.json"
    freeze = lg.load_json(freeze_path)
    if sha256_file(history_path) != freeze["history_ledger"]["sha256"]:
        raise lg.ClosedGate("frozen history file hash mismatch")

    print("[history] regenerating exact W2/R2 from pinned primitives", flush=True)
    w2, r2, metadata = lg.build_exact_histories(spec)
    generated_hash = regenerated_history_hash(w2, r2, spec["scope"])
    if generated_hash != freeze["history_ledger"]["sha256"]:
        raise lg.ClosedGate("regenerated exact history does not equal the frozen history hash")
    print(f"[history] frozen lineage verified sha256={generated_hash}", flush=True)

    complex_ = lg.CubicComplex(spec["scope"]["extent"])
    pair_weights, collapse_census = collapse_unordered_pair_weights(complex_, w2, r2)
    ordered_pairs = sorted(pair_weights.items(), key=lambda row: topology_key(row[0]))
    pattern_histogram: Counter[tuple[tuple[int, int], ...]] = Counter()
    pure_six_topologies = balanced_k3_topologies = 0
    for (left, right), _weight in ordered_pairs:
        patterns, _partition, _groups = endpoint_groups(left, right)
        pattern_histogram[patterns] += 1
        pure_six_topologies += int((6, 0) in patterns or (0, 6) in patterns)
        balanced_k3_topologies += int((3, 3) in patterns)
    print(
        f"[patterns] signatures={len(pattern_histogram):,} pure-six={pure_six_topologies:,} "
        f"balanced-k3={balanced_k3_topologies:,} pure-six local denominator="
        f"{PURE_SIX['common_denominator']}",
        flush=True,
    )
    if args.collapse_only:
        return {
            "schema_version": SCHEMA,
            "status": "collapse-only",
            "collapse_census": collapse_census,
            "pattern_signature_count": len(pattern_histogram),
            "pure_six_topologies": pure_six_topologies,
            "balanced_k3_topologies": balanced_k3_topologies,
        }

    checkpoint = out_dir / "exact_haar_checkpoint.jsonl"
    completed, checkpoint_hash = checkpoint_prefix(checkpoint) if args.resume else (0, "")
    if checkpoint.exists() and not args.resume:
        raise lg.ClosedGate("checkpoint exists; pass --resume or choose a fresh output directory")
    if completed > len(ordered_pairs):
        raise lg.ClosedGate("checkpoint is longer than the exact topology corpus")
    results: list[dict[str, Any]] = []
    if completed:
        with checkpoint.open("r", encoding="utf-8") as handle:
            results = [json.loads(line) for line in handle]
        for index, row in enumerate(results):
            pair, weight = ordered_pairs[index]
            expected_key = hashlib.sha256(lg.canonical_bytes([state_json(pair[0]), state_json(pair[1])])).hexdigest()
            if row["topology_sha256"] != expected_key or parse_fraction(row["weight"]) != weight:
                raise lg.ClosedGate(f"checkpoint topology mismatch at index {index}")
        print(f"[haar] resuming after {completed:,} verified rows sha256={checkpoint_hash}", flush=True)

    qbound = int(freeze["qbound"]["value"])
    d11 = parse_fraction(freeze["generated_factors"]["analytic_one_face"]["value"])
    if qbound % d11.denominator:
        raise lg.ClosedGate("QBOUND misses the derived one-face denominator")
    total_numerator = d11.numerator * (qbound // d11.denominator)
    nonzero_haar = 0
    max_peak_states = 0
    max_haar_denominator = 1
    divisibility_checked = 0
    pattern_value_cache: dict[Any, Fraction] = {}
    for index, row in enumerate(results):
        haar = parse_fraction(row["haar"])
        weight = parse_fraction(row["weight"])
        term = Fraction(1, 2) * weight * haar
        if qbound % term.denominator:
            raise lg.ClosedGate(f"checkpointed term denominator escaped QBOUND at index {index}")
        total_numerator += term.numerator * (qbound // term.denominator)
        nonzero_haar += int(bool(haar))
        max_haar_denominator = max(max_haar_denominator, haar.denominator)
        max_peak_states = max(max_peak_states, int(row["peak_partition_states"]))
        divisibility_checked += 1

    mode = "a" if completed else "w"
    started = last = time.monotonic()
    with checkpoint.open(mode, encoding="utf-8", newline="\n") as handle:
        for index in range(completed, len(ordered_pairs)):
            (left, right), weight = ordered_pairs[index]
            haar, detail = exact_haar(left, right)
            term = Fraction(1, 2) * weight * haar
            if qbound % term.denominator:
                raise lg.ClosedGate(
                    f"term denominator {term.denominator} escaped QBOUND at topology {index}"
                )
            total_numerator += term.numerator * (qbound // term.denominator)
            nonzero_haar += int(bool(haar))
            max_haar_denominator = max(max_haar_denominator, haar.denominator)
            max_peak_states = max(max_peak_states, detail["peak_partition_states"])
            divisibility_checked += 1
            topology_hash = hashlib.sha256(
                lg.canonical_bytes([state_json(left), state_json(right)])
            ).hexdigest()
            row = {
                "index": index,
                "topology_sha256": topology_hash,
                "weight": ftext(weight),
                "haar": ftext(haar),
                "haar_numerator": str(haar.numerator),
                "haar_denominator": str(haar.denominator),
                "patterns": [list(pattern) for pattern in detail["patterns"]],
                "declared_qh": str(detail["declared_qh"]),
                "peak_partition_states": detail["peak_partition_states"],
                "term_qbound_numerator": str(term.numerator * (qbound // term.denominator)),
            }
            results.append(row)
            handle.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
            if (index + 1) % args.checkpoint_every == 0:
                handle.flush()
                os.fsync(handle.fileno())
            now = time.monotonic()
            done = index + 1 - completed
            if now - last >= 10 or index + 1 == len(ordered_pairs):
                rate = done / max(now - started, 1e-9)
                eta = (len(ordered_pairs) - index - 1) / max(rate, 1e-9)
                print(
                    f"[haar] {index+1:,}/{len(ordered_pairs):,} rate={rate:,.1f}/s "
                    f"nonzero={nonzero_haar:,} max_den={max_haar_denominator:,} "
                    f"peak_DSU={max_peak_states:,} elapsed={now-started:.1f}s ETA={eta:.1f}s",
                    flush=True,
                )
                last = now
        handle.flush()
        os.fsync(handle.fileno())

    if divisibility_checked != len(ordered_pairs):
        raise lg.ClosedGate("not every collapsed topology received a QBOUND divisibility check")
    d_exact = Fraction(total_numerator, qbound)
    if qbound % d_exact.denominator:
        raise lg.ClosedGate("final D_EXACT denominator does not divide QBOUND")
    if FOLD_EXACT - LINKED_VACUUM_EXACT != FOLD_MINUS_LINKED_EXACT:
        raise lg.ClosedGate("independent fold-minus-linked arithmetic identity failed")
    m4_exact = d_exact + FOLD_EXACT - LINKED_VACUUM_EXACT
    for name, value in (
        ("fold", FOLD_EXACT),
        ("linked-vacuum", LINKED_VACUUM_EXACT),
        ("fold-minus-linked", FOLD_MINUS_LINKED_EXACT),
        ("m4-rest", m4_exact),
    ):
        if qbound % value.denominator:
            raise lg.ClosedGate(f"{name} denominator {value.denominator} does not divide QBOUND")

    # The compressed ledger includes the exact endpoint state tensors, not only hashes.
    topology_rows = []
    for ((left, right), weight), result in zip(ordered_pairs, results):
        topology_rows.append(
            {
                **result,
                "left": state_json(left),
                "right": state_json(right),
                "weight": ftext(weight),
            }
        )
    ledger = {
        "schema_version": SCHEMA,
        "scope": spec["scope"],
        "source_lineage": {
            "frozen_history_file": history_path.name,
            "frozen_history_sha256": generated_hash,
            "freeze_file": freeze_path.name,
            "freeze_sha256": sha256_file(freeze_path),
            "primitive_spec_sha256": sha256_file(primitive_path),
            "generator_sha256": sha256_file(Path(lg.__file__).resolve()),
            "contractor_sha256": sha256_file(Path(__file__).resolve()),
        },
        "collapse_census": collapse_census,
        "historical_orientation_sensitive_topologies": EXPECTED_NONZERO_TOPOLOGIES,
        "fully_unordered_exact_contraction_classes": len(topology_rows),
        "pure_six_projector": {
            "rank": 5,
            "kept_epsilon_partitions": [int(index) for index in PURE_SIX["keep"]],
            "gram_inverse": [[ftext(value) for value in row] for row in PURE_SIX["inverse"]],
            "permutation_terms": len(PURE_SIX["coefficients"]),
            "permutation_common_denominator": PURE_SIX["common_denominator"],
            "trace": ftext(PURE_SIX["trace"]),
        },
        "pattern_census": {
            "signature_histogram": [
                {
                    "patterns": [list(pattern) for pattern in patterns],
                    "topologies": count,
                }
                for patterns, count in sorted(pattern_histogram.items())
            ],
            "pure_six_topologies": pure_six_topologies,
            "balanced_k3_topologies": balanced_k3_topologies,
        },
        "assembly": {
            "formula": "D_EXACT = D11 + (1/2) * sum(weight_scaled * exact_endpoint_Haar)",
            "d11": ftext(d11),
            "qbound": str(qbound),
            "qbound_divisibility_checks": divisibility_checked,
            "nonzero_haar_values": nonzero_haar,
            "max_exact_haar_denominator": max_haar_denominator,
            "max_live_partition_states": max_peak_states,
            "qbound_integer_numerator_before_reduction": str(total_numerator),
            "d_exact": ftext(d_exact),
            "fold_exact": ftext(FOLD_EXACT),
            "linked_vacuum_exact": ftext(LINKED_VACUUM_EXACT),
            "fold_minus_linked_exact": ftext(FOLD_MINUS_LINKED_EXACT),
            "m4_rest_exact": ftext(m4_exact),
            "fold_linked_lineage": {
                "fold_reproducer_sha256": FOLD_REPRODUCER_SHA256,
                "linked_final_sha256": LINKED_FINAL_SHA256,
                "certificate_package_sha256": FOLD_LINKED_PACKAGE_SHA256,
                "certificate_package_file": "WORKHOUSE_RANK3_ORDER4_FOLD_LINKED_EXACT_REPLAY_20260823.zip",
            },
        },
        "topologies": topology_rows,
    }
    lg.assert_no_float(ledger)
    ledger_path = out_dir / "rank3_order4_exact_haar_topologies.json.gz"
    raw_hash, gzip_hash = write_canonical_gzip(ledger_path, ledger)
    summary = {
        "schema_version": SCHEMA,
        "status": "complete",
        "passed": True,
        "history_sha256": generated_hash,
        "topology_ledger": {
            "file": ledger_path.name,
            "canonical_uncompressed_sha256": raw_hash,
            "gzip_sha256": gzip_hash,
            "topologies": len(topology_rows),
        },
        "collapse_census": collapse_census,
        "historical_orientation_sensitive_topologies": EXPECTED_NONZERO_TOPOLOGIES,
        "fully_unordered_exact_contraction_classes": len(topology_rows),
        "qbound": str(qbound),
        "qbound_divisibility_checks": divisibility_checked,
        "d_exact": ftext(d_exact),
        "fold_exact": ftext(FOLD_EXACT),
        "linked_vacuum_exact": ftext(LINKED_VACUUM_EXACT),
        "fold_minus_linked_exact": ftext(FOLD_MINUS_LINKED_EXACT),
        "m4_rest_exact": ftext(m4_exact),
        "fold_reproducer_sha256": FOLD_REPRODUCER_SHA256,
        "linked_final_sha256": LINKED_FINAL_SHA256,
        "fold_linked_package_sha256": FOLD_LINKED_PACKAGE_SHA256,
        "haar_contractor_method": "exact-integer-low-rank-factor-network-with-rigorous-CRT-uniqueness",
        "nonzero_haar_values": nonzero_haar,
        "pure_six_topologies": pure_six_topologies,
        "balanced_k3_topologies": balanced_k3_topologies,
        "pure_six_projector_common_denominator": PURE_SIX["common_denominator"],
        "max_exact_haar_denominator": max_haar_denominator,
        "max_live_partition_states": max_peak_states,
        "checkpoint_sha256": sha256_file(checkpoint),
        "contractor_sha256": sha256_file(Path(__file__).resolve()),
    }
    summary_path = out_dir / "rank3_order4_exact_haar_summary.json"
    lg.write_canonical_json(summary_path, summary)
    print(f"[done] D_EXACT={ftext(d_exact)}", flush=True)
    print(f"[done] M4_REST_EXACT={ftext(m4_exact)}", flush=True)
    print(f"[done] summary={summary_path}", flush=True)
    print(f"[done] ledger={ledger_path} sha256={gzip_hash}", flush=True)
    return summary


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--primitives", type=Path, required=True)
    parser.add_argument("--frozen", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--collapse-only", action="store_true")
    parser.add_argument("--checkpoint-every", type=int, default=250)
    args = parser.parse_args(argv)
    if args.checkpoint_every < 1:
        parser.error("--checkpoint-every must be positive")
    try:
        run(args)
    except (lg.ClosedGate, OSError, ValueError, KeyError) as exc:
        print(f"FAIL CLOSED: {exc}", file=sys.stderr, flush=True)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
