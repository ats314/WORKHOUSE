#!/usr/bin/env python3
"""Independent replay verifier for the exact rank-3/order-4 Haar ledger."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from fractions import Fraction
from pathlib import Path

import exact_haar_sum as contractor
import ledger_generator as lg


def verify(run_dir: Path) -> dict[str, object]:
    summary_path = run_dir / "rank3_order4_exact_haar_summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    ledger_path = run_dir / summary["topology_ledger"]["file"]
    if contractor.sha256_file(ledger_path) != summary["topology_ledger"]["gzip_sha256"]:
        raise lg.ClosedGate("compressed topology-ledger hash mismatch")
    raw = gzip.open(ledger_path, "rb").read()
    raw_hash = hashlib.sha256(raw).hexdigest()
    if raw_hash != summary["topology_ledger"]["canonical_uncompressed_sha256"]:
        raise lg.ClosedGate("canonical uncompressed topology-ledger hash mismatch")
    ledger = json.loads(raw)
    lg.assert_no_float(ledger)
    rows = ledger["topologies"]
    if len(rows) != 69_800:
        raise lg.ClosedGate(f"topology class count {len(rows)} != 69800")
    if summary["historical_orientation_sensitive_topologies"] != 117_161:
        raise lg.ClosedGate("historical orientation-sensitive topology census drift")
    if summary["contractor_sha256"] != contractor.sha256_file(Path(contractor.__file__).resolve()):
        raise lg.ClosedGate("recorded contractor hash does not match the executable source")

    qbound = int(summary["qbound"])
    total = Fraction(-13, 896)
    nonzero = 0
    previous_key = None
    for index, row in enumerate(rows):
        if row["index"] != index:
            raise lg.ClosedGate(f"non-contiguous topology index at {index}")
        encoding = [row["left"], row["right"]]
        topology_hash = hashlib.sha256(lg.canonical_bytes(encoding)).hexdigest()
        if topology_hash != row["topology_sha256"]:
            raise lg.ClosedGate(f"canonical topology hash mismatch at {index}")
        stable_key = tuple(
            (
                tuple((int(link), bool(orientation)) for link, orientation in state["occ"]),
                tuple(int(label) for label in state["part"]),
            )
            for state in encoding
        )
        if previous_key is not None and stable_key < previous_key:
            raise lg.ClosedGate(f"topology rows are not canonically sorted at {index}")
        previous_key = stable_key
        weight = contractor.parse_fraction(row["weight"])
        haar = contractor.parse_fraction(row["haar"])
        if str(haar.numerator) != row["haar_numerator"]:
            raise lg.ClosedGate(f"Haar numerator field mismatch at {index}")
        if str(haar.denominator) != row["haar_denominator"]:
            raise lg.ClosedGate(f"Haar denominator field mismatch at {index}")
        term = Fraction(1, 2) * weight * haar
        if qbound % term.denominator:
            raise lg.ClosedGate(f"term denominator escaped QBOUND at {index}")
        scaled = term.numerator * (qbound // term.denominator)
        if int(row["term_qbound_numerator"]) != scaled:
            raise lg.ClosedGate(f"QBOUND-scaled numerator mismatch at {index}")
        total += term
        nonzero += int(bool(haar))

    if contractor.ftext(total) != summary["d_exact"]:
        raise lg.ClosedGate("replayed D_EXACT does not match the summary")
    if nonzero != summary["nonzero_haar_values"]:
        raise lg.ClosedGate("nonzero-Haar census mismatch")
    if contractor.FOLD_EXACT - contractor.LINKED_VACUUM_EXACT != contractor.FOLD_MINUS_LINKED_EXACT:
        raise lg.ClosedGate("fold-minus-linked identity failed")
    m4 = total + contractor.FOLD_EXACT - contractor.LINKED_VACUUM_EXACT
    if contractor.ftext(m4) != summary["m4_rest_exact"]:
        raise lg.ClosedGate("replayed m4_rest does not match the summary")
    if contractor.PURE_SIX["trace"] != 5 or contractor.PURE_SIX["common_denominator"] != 72:
        raise lg.ClosedGate("pure-six rank-five projector replay failed")

    return {
        "schema_version": "workhouse.rank3-order4-cubic-exact-haar-verification/v1",
        "passed": True,
        "topology_classes_verified": len(rows),
        "historical_orientation_sensitive_topologies": 117_161,
        "nonzero_haar_values": nonzero,
        "qbound_divisibility_checks": len(rows),
        "canonical_uncompressed_sha256": raw_hash,
        "gzip_sha256": contractor.sha256_file(ledger_path),
        "contractor_sha256": summary["contractor_sha256"],
        "d_exact": contractor.ftext(total),
        "fold_exact": contractor.ftext(contractor.FOLD_EXACT),
        "linked_vacuum_exact": contractor.ftext(contractor.LINKED_VACUUM_EXACT),
        "fold_minus_linked_exact": contractor.ftext(contractor.FOLD_MINUS_LINKED_EXACT),
        "m4_rest_exact": contractor.ftext(m4),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--write", type=Path)
    args = parser.parse_args()
    result = verify(args.run_dir.resolve())
    if args.write:
        lg.write_canonical_json(args.write.resolve(), result)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
